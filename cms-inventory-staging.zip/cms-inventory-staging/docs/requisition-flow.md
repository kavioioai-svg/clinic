# Requisition flow

```puml
@startuml
split
   -[hidden]->
   :Clinic1;
split again
   -[hidden]->
   :Clinic2;
end split
:PR;
@enduml


```
