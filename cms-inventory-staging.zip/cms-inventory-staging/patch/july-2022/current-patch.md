## DB

- ISSUE-01 : new management role for view sync info
  `patch/july-2022/20220711-new-mgmt-role-for-sync-info.sql`
