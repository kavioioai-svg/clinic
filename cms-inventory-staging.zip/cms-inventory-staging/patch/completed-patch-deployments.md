## Config Patch
* NAV availability and inventory service related properties
* HMC ONLY
```
use.nav.inventory=false
nav.api.available=true
```

* NAV availability and inventory service related properties
* GALEN
```
use.nav.inventory=false
nav.api.available=false
```