## PROPERTY

- ISSUE-01 : new whitelist urls for internal inventory api call

  web.whitelist.urls=/inventory-item-usage/update/,/inventory-module/inventory-item-usage/update/,/inventory-internal/uom-matrix/search/ratio/,/inventory-internal/inventory/find-and-modify/,/inventory-module/inventory-internal/uom-matrix/search/ratio/,/inventory-module/inventory-internal/inventory/find-and-modify/
