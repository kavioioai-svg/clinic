db.order.updateMany({orderStatus: "CANCELED"}, { $set: { orderStatus: "INITIAL"}})
