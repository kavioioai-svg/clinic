db.supplier.updateMany({}, { $set: { "gstEnabled": true } });
