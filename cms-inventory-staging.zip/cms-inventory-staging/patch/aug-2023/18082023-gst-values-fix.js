// Fetch GST data
var gstDocument = db.masterDataStore.findOne({ "key": "GST_SETUP" });
var gstValues = gstDocument.values;
gstValues.sort(function(a, b) {
    return a.cutOffDateAsDate.getTime() - b.cutOffDateAsDate.getTime(); //sort by ascending
});

var bulkOps = [];
db.order.find({ "orderType": "PURCHASE" }).forEach(function (doc) {
    var applicableGstValue;

    // Check if orderDate.$date.$numberLong is not undefined
    if (doc.orderDate && doc.orderDate && doc.orderDate) {
        for (var i = 0; i < gstValues.length; i++) {
            // Check if gstValues[i].cutOffDateAsDate.$date.$numberLong is not undefined
            if (gstValues[i].cutOffDateAsDate && gstValues[i].cutOffDateAsDate && gstValues[i].cutOffDateAsDate) {
                applicableGstValue = gstValues[i];
                if (gstValues[i].cutOffDateAsDate.getTime() > doc.orderDate.getTime()) {
                    break;
                }
            }
        }
    }

    if (applicableGstValue) {
        var gstPercentage = applicableGstValue.gst;

        var total = 0;
        // Go through all the items and calculate the total.
        for (var i = 0; i < doc.goodPurchasedItems.length; i++) {
            var item = doc.goodPurchasedItems[i];
            total += item.quantity * item.unitPrice.price;
        }
        var gstAmount = (total * gstPercentage / 100).toString();

        bulkOps.push(
            {
                updateOne: {
                    filter: { "_id": doc._id },
                    update: { $set: { "gstAmount": gstAmount, "gstPercentage": gstPercentage.toString(), "gstEnabled": true } }
                }
            }
        );
    }
});

// bulk execute the update operations
if(bulkOps.length > 0){
    db.order.bulkWrite(bulkOps);
    print("Update operation completed.");
} else {
    print("No operations to perform.");
}
