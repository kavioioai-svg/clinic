## PROPERTY

- ISSUE-01 : new property for gst calculations
  `gst.values.0.gst=7`
   `gst.values.0.cutOffDate=30-05-2023`
   `gst.values.0.gstString=`
