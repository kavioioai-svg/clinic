let aggregationQuery = [
    {
        '$unwind': {
            'path': '$requestItems'
        }
    }, {
        '$project': {
            'res': {
                '$mergeObjects': [
                    '$$ROOT', '$requestItems'
                ]
            }
        }
    }, {
        '$replaceRoot': {
            'newRoot': '$res'
        }
    }, {
        '$unset': [
            'requestItems', '_id'
        ]
    }, {
        '$set': {
            '_class': 'com.ilt.cms.inventory.svc.model.purchase.PurchaseRequestItemView'
        }
    }, {
        '$out': 'purchaseRequestItemView'
    }
];
