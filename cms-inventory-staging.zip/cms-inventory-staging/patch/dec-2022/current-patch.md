## PROPERTY

- ISSUE-01 : two properties for delete zero/negative qty items
  `inventory.scheduler.delete.qty.zero.since=3`
  `inventory.scheduler.delete.zero.qty=0 20 11 * * *`

