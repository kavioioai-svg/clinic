## config properties

- ISSUE-01 : new config properties
  `patch/dec-2022/20221215-new config propperties`
