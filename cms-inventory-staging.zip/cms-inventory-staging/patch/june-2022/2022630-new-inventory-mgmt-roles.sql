INSERT IGNORE INTO role (`id`,`create_date`, `last_update`,`version`,`description`,`role`) VALUES (null, now(), now(), 0, 'Current stock view', 'ROLE_CURRENT_STOCK_OVERVIEW');
INSERT IGNORE INTO groups_role (`group_id`,`role_id`) VALUES ((SELECT id FROM group_details WHERE name = 'CP Inventory'),(SELECT id FROM role WHERE role = 'ROLE_CURRENT_STOCK_OVERVIEW'));

INSERT IGNORE INTO role (`id`,`create_date`, `last_update`,`version`,`description`,`role`) VALUES (null, now(), now(), 0, 'Stock adjustment approve', 'ROLE_STOCK_ADJUSTMENT_APPROVAL');
INSERT IGNORE INTO groups_role (`group_id`,`role_id`) VALUES ((SELECT id FROM group_details WHERE name = 'CP Inventory'),(SELECT id FROM role WHERE role = 'ROLE_STOCK_ADJUSTMENT_APPROVAL'));

INSERT IGNORE INTO role (`id`,`create_date`, `last_update`,`version`,`description`,`role`) VALUES (null, now(), now(), 0, 'Nav Sync Queue', 'ROLE_VIEW_SYNC_INFO');
