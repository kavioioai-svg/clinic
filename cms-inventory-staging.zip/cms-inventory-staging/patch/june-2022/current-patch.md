## DB
* ISSUE-01 : new inventory management roles
  ``
  patch/june-2022/2020630-new-inventory-mgmt-roles.sql
  ``