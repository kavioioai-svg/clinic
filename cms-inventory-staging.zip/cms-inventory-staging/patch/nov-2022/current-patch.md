## PROPERTY

- ISSUE-01 : new property for delete nav queue record
  `nav.queue.delete=http://localhost:8081/nav/deleteNavQueue`

## DB
* Validations for location inventory.

Run following command to execute the patch:

```bash
mongo <database> patch/nov-2022/2021110-validations-for-location-inventory.js
```
