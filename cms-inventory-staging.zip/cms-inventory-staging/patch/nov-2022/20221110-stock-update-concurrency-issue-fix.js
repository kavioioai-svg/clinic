


db.runCommand({collMod: 'locationInventory', validator: {
        $jsonSchema: {
            properties: {
                availableCount: {
                    minimum: 0
                }
            }
        }
    }})
