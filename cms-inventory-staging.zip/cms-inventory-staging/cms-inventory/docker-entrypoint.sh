#!/bin/bash

BASE_DIR=$DOCKER_WORKING_DIR
echo "start checking base dir [$DOCKER_WORKING_DIR]"

# check if the config folder is empty and copy initial files
if [ "$(ls -A $BASE_DIR/conf)" ]; then
     echo "There are files in the config location. Skip restoring and continue to start application"
else
    echo "Coping initial configuration files"
    cp -rf $BASE_DIR/conf-init/* $BASE_DIR/conf/
    echo "Copy successful, continue to start application"
fi

bash -c "$*"