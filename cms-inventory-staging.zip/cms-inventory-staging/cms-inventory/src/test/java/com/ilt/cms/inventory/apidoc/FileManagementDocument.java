package com.ilt.cms.inventory.apidoc;

import org.springframework.restdocs.payload.RequestFieldsSnippet;
import org.springframework.test.web.servlet.ResultHandler;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;

public class FileManagementDocument extends ApiDocumentation{
    public static ResultHandler documentUploadDeliveryNoteFileToGRN() {
        return document("file-upload-to-grn", fileMetadataFields(), pathParameters(
                parameterWithName("orderId").description("Patient Visit Id"),
                parameterWithName("grnNo").description("This field has two function, " +
                        "if the value is OTHER document will be upload to the visit. If the value contains the testId, " +
                        "document is uploaded to the given test")
                ),
                responseAPI(true));
    }

    public static ResultHandler documentDownloadDeliveryNoteFileFromGRN() {
        return document("file-download-from-grn", pathParameters(
                parameterWithName("orderId").description("Order ID"),
                parameterWithName("grnNo").description("Number of GRN"),
                parameterWithName("fileId").description("fileId of the file to be downloaded")));
    }

    private static RequestFieldsSnippet fileMetadataFields() {
        return requestFields(
                fieldWithPath("name").description("Name related to the upload"),
                fieldWithPath("fileName").description("Upload file name"),
                fieldWithPath("uploader").description("upload user"),
                fieldWithPath("clinicId").description("File uploading clinic id"),
                fieldWithPath("type").optional().description("Upload file type"),
                fieldWithPath("size").optional().description("Uploading file size"),
                fieldWithPath("description").description("Description about the file"),
                fieldWithPath("uploadDate").description("Upload file date"),
                fieldWithPath("deleted").description("Is file deleted"));
    }
}
