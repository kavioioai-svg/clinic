package com.ilt.cms.inventory.mock;


import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.RequestItem;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestType;

import java.time.LocalDate;
import java.util.Arrays;

public class MockPurchaseRequest {

    public static PurchaseRequest mockPurchaseRequest(String id, RequestStatus requestStatus){
        PurchaseRequest purchaseRequest = new PurchaseRequest("C023232", RequestType.STANDARD, "33212329943", LocalDate.now(), LocalDate.now().plusDays(10), null,
                null, "Restock Low Items", requestStatus);

        purchaseRequest.setRequestItems(Arrays.asList(
                mockRequestItem("S00001","22k32e30023223", "BOX", 10, 10, new UnitPrice(12, false)),
                mockRequestItem("S00001","434kknd99433n43", "BOX", 12, 10, new UnitPrice(20, false))
        ));
        purchaseRequest.setId(id);
        return purchaseRequest;
    }

    public static RequestItem mockRequestItem(String supplierId, String itemRefId, String uom, int quantity, int approvedQuantity, UnitPrice unitPrice){
        RequestItem requestItem = new RequestItem(itemRefId, supplierId, uom, quantity, approvedQuantity, unitPrice,null);
        return requestItem;
    }
}
