package com.ilt.cms.inventory.rest.purchase;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.ilt.cms.api.entity.file.FileMetadataEntity;
import com.ilt.cms.core.entity.file.FileMetaData;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.FileManagementDocument;
import com.ilt.cms.inventory.apidoc.OrderRequestDocument;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.mock.MockFileManagement;
import com.ilt.cms.inventory.mock.MockOrder;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.OrderRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestRepository;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.service.purchase.FileManagementService;
import com.lippo.cms.util.AWSConfig;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.util.Base64;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"FILE_LIST", "FILE_UPLOAD", "FILE_DOWNLOAD"})
public class FileManagementRestControllerTest {


    @Autowired
    private MockMvc mockMvc;

    //@MockBean
    //private AWSConfig awsConfig;

    @MockBean
    Principal principal;

    @MockBean
    AmazonS3 amazonS3;

    @MockBean
    S3Object s3Object;

    @MockBean
    S3ObjectInputStream s3ObjectInputStream;

    @MockBean
    private OrderRepository orderRepository;

    @MockBean
    BucketVersioningConfiguration bucketVersioningConfiguration;

    //@MockBean
    //private FileManagementService fileManagementService;


    @Before
    public void setup() throws Exception {
        when(principal.getName()).thenReturn("wonderwoman");

        when(amazonS3.getBucketVersioningConfiguration(anyString())).thenReturn(bucketVersioningConfiguration);
        when(amazonS3.getObject(anyString(), anyString())).thenReturn(s3Object);
        when(s3Object.getObjectContent()).thenReturn(s3ObjectInputStream);
        when(s3ObjectInputStream.read(any())).thenReturn(11).thenReturn(12).thenReturn(-1);
        when(bucketVersioningConfiguration.getStatus()).thenReturn(BucketVersioningConfiguration.OFF);
        /*mock repository*/
        when(orderRepository.findById(anyString())).thenReturn(Optional.of(MockOrder.mockPurchaseOrder()));
        when(orderRepository.save(any())).thenReturn(MockOrder.mockPurchaseOrder());
        /*mock service*/
        //when(fileManagementService.uploadDeliveryNoteFileToGoodReceivedNote(any(Principal.class), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any()))
        //        .thenReturn(MockFileManagement.mockFileMetaData());
        //when(fileManagementService.downloadFileFromGRN(anyString(), anyString(), anyString())).thenReturn(MockFileManagement.mockFileDowloadData());
    }

    @Test
    @Ignore
    public void uploadDeliveryNoteFileToGRN() throws Exception{

        File temp = File.createTempFile("temp-file-name", ".tmp");
        FileInputStream fileInputStream = new FileInputStream(temp);
        MockMultipartFile fstmp = new MockMultipartFile("file", temp.getName(), "multipart/form-data", fileInputStream);

        MockHttpServletRequestBuilder requestBuilder = RestDocumentationRequestBuilders
                .fileUpload("/document-management/upload/grn/{orderId}/{grnNo}",
                        "4jn609lf4h3224343", "00233")
                .file(fstmp)
                .param("clinicId", "CL1000")
                .param("name", "Name of the doc")
                .param("fileName", "temp-file-name")
                .param("description", "Test Description")
                .header("Authorization", TestHelper.TOKEN).with(csrf());

        FileMetaData fileMetadata = MockFileManagement.mockFileMetaData();
        fileMetadata.setFileId(null);
        TestHelper.httpRequestBuilder(requestBuilder, fileMetadata);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(FileManagementDocument.documentUploadDeliveryNoteFileToGRN())
                .andExpect(status().isOk())
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void downloadDeliveryNoteFileFromGRN() throws Exception{
        MockHttpServletRequestBuilder requestBuilder = RestDocumentationRequestBuilders
                .post("/document-management/download/grn/{orderId}/{grnNo}/{fileId}",
                        "4jn609lf4h3224343", "00233", "b3JkZXIvMjAxOS81ZDQyZmJkOGEyNGEyNDBkMjBhZmRhNTQvMjAxOTIxODEwMDAwMzUvNTQ1ODQ0ODc4MzgyMDU3MDI1NzE1NjUyNTk1MzkwNDIxMDAwMDE=")
                .header("Authorization", TestHelper.TOKEN).with(csrf());

        requestBuilder.accept(MediaType.ALL_VALUE);
        MvcResult result = mockMvc.perform(requestBuilder)
                .andExpect(status().isOk())
                .andDo(FileManagementDocument.documentDownloadDeliveryNoteFileFromGRN())
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }
}
