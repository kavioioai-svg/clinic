package com.ilt.cms.inventory.apidoc;

import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.ResultHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;

public class OrderRequestDocument extends ApiDocumentation {

    public static ResultHandler documentListOrderRequest() {
        return document("list-order-request",
                requestHeaderForTheRequest(),
                pathParameters(
                        parameterWithName("clinicId").description("Id of the clinic"),
                        parameterWithName("page").description("page of the display"),
                        parameterWithName("size").description("size to be display")
                ), requestFields(filterParameters()),
                responseAPI(true));
    }

    public static ResultHandler documentListReturnOrder() {
        return document("search-purchase-return-order",
                pathParameters(
                        parameterWithName("clinicId").description("Id of the clinic"),
                        parameterWithName("page").description("page of the display"),
                        parameterWithName("size").description("size to be display")
                ), requestFields(searchPurchaseReturnOrderContainer()),
                responseAPI(true));
    }

    private static List<FieldDescriptor> filterParameters() {

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(

                Arrays.asList(
                        fieldWithPath(OrderRequest.Filter.ORDER_REQUEST_NO.name()).optional().type(JsonFieldType.STRING).description("search by order number/request number"),
                        fieldWithPath(OrderRequest.Filter.STATUS.name()).optional().type(JsonFieldType.STRING).description("search by status"),
                        fieldWithPath(OrderRequest.Filter.TRANSFER_PURCHASE_TYPE.name()).optional().type(JsonFieldType.STRING).description("search by [TO_PICK, TO_SENT, REQUEST_NORMAL, REQUEST_SPECIAL]"),
                        fieldWithPath(OrderRequest.Filter.CREATED_DATE_MORE.name()).optional().type(JsonFieldType.STRING).description("search by date after request date with format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(OrderRequest.Filter.CREATED_DATE_LESS.name()).optional().type(JsonFieldType.STRING).description("search by date before requst date with format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath("new").optional().type(JsonFieldType.BOOLEAN).description("???")
                )
        );

        return fieldDescriptors;
    }

    private static List<FieldDescriptor> searchPurchaseReturnOrderContainer() {
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath("startDate").description("Start date of purchase return order's create date from"),
                        fieldWithPath("endDate").description("End date of purchase return order's create date to"),
                        fieldWithPath("requestStatus").description("Filter criteria:" + Arrays.toString(GoodReceivedReturnStatus.values())),
                        fieldWithPath("number").description("OrderNo/GRNVoteNo")
                )
        );
        return fieldDescriptors;
    }
}
