package com.ilt.cms.inventory.apidoc;

import org.springframework.test.web.servlet.ResultHandler;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;

public class NavQueueDocument extends ApiDocumentation {

    public static ResultHandler documentFindRequest() {
        return document("get-sync-info",
                pathParameters(
                        parameterWithName("page").description("page number"),
                        parameterWithName("size").description("page size")
                ), requestFields(),
                responseAPI(true));
    }
}
