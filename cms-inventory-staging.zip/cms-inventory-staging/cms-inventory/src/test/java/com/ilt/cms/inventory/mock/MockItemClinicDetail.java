package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.item.DrugGroupLimits;
import com.ilt.cms.core.entity.item.DurationType;
import com.ilt.cms.core.entity.item.ItemClinicDetail;
import com.ilt.cms.core.entity.item.ItemExtraDetails;

import java.math.BigDecimal;
import java.util.List;

public class MockItemClinicDetail {

    public static ItemClinicDetail mockItemClinicDetail(String itemRefId) {
        ItemClinicDetail itemClinicDetail = new ItemClinicDetail();
        itemClinicDetail.setItemRefId(itemRefId);
        itemClinicDetail.setClinicDetails(List.of(mockItemExtraDetails("C-000001")));
        itemClinicDetail.setDrugGroupLimits(List.of(mockDrugGroupLimits()));
        return itemClinicDetail;
    }

    public static ItemClinicDetail mockItemClinicDetail(String clinicId, String itemRefId) {
        ItemClinicDetail itemClinicDetail = new ItemClinicDetail();
        itemClinicDetail.setItemRefId(itemRefId);
        itemClinicDetail.setClinicDetails(List.of(mockItemExtraDetails(clinicId)));
        itemClinicDetail.setDrugGroupLimits(List.of(mockDrugGroupLimits()));
        return itemClinicDetail;
    }

    public static ItemExtraDetails mockItemExtraDetails(String clinicId) {
        ItemExtraDetails itemExtraDetails = new ItemExtraDetails();
        itemExtraDetails.setClinicId(clinicId);
        itemExtraDetails.setReorderPoint(10);
        itemExtraDetails.setReorderQty(1000);
        itemExtraDetails.setMaximumOrderQty(100);
        itemExtraDetails.setMinimumOrderQty(1);
        itemExtraDetails.setSafetyLeadTime("1M");
        itemExtraDetails.setSafetyStockQty(10);
        itemExtraDetails.setBufferStockLevel(new BigDecimal(10));
        itemExtraDetails.setLeadTimeCalculation("7D");

        return itemExtraDetails;
    }

    public static DrugGroupLimits mockDrugGroupLimits() {
        DrugGroupLimits drugGroupLimits = new DrugGroupLimits();
        drugGroupLimits.setDuration(1);
        drugGroupLimits.setDurationType(DurationType.DAY);
        drugGroupLimits.setExclusions("exclusions");
        drugGroupLimits.setGroupName("group_name");
        drugGroupLimits.setLimit(10);
        drugGroupLimits.setStatus(Status.ACTIVE);
        drugGroupLimits.setUOM("TABLET");

        return drugGroupLimits;
    }
}
