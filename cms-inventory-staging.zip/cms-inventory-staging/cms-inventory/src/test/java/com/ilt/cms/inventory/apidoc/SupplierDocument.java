package com.ilt.cms.inventory.apidoc;

import org.springframework.test.web.servlet.ResultHandler;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;

public class SupplierDocument extends ApiDocumentation{

    public static ResultHandler documentListAll() {
        return document("supplier-list-all",
                pathParameters(
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentFindById() {
        return document("supplier-find-by-id",
                pathParameters(
                        parameterWithName("supplierId").description("Id of the supplier")
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentFindByItemId() {
        return document("supplier-find-by-item-id",
                pathParameters(
                        parameterWithName("itemId").description("Id of the item")
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentFindByItemIdWithInvQty() {
        return document("find-by-item-id",
                pathParameters(
                        parameterWithName("clinicId").description("Id of the clinic"),
                        parameterWithName("itemId").description("Id of the item"),
                        parameterWithName("uom").description("Uom of the item")
                ), requestFields(),
                responseAPI(true));
    }
}
