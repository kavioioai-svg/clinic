package com.ilt.cms.inventory.rest.inventory;

import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.item.ClinicItemMaster;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.UomMatrix;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.InventoryDocument;
import com.ilt.cms.inventory.mock.*;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationRepository;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.svc.service.nav.InventoryService;
import com.ilt.cms.repository.spring.ClinicItemMasterRepository;
import com.ilt.cms.repository.spring.ItemRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import com.ilt.cms.repository.spring.UomMatrixRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"PR_PO_INVENTORY_NAV"})
public class InventoryRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ItemRepository itemRepository;

    @MockBean
    private SupplierRepository supplierRepository;

    @MockBean
    private LocationRepository locationRepository;

    @MockBean
    private UomMatrixRepository uomMatrixRepository;

    @MockBean
    private ClinicItemMasterRepository clinicItemMasterRepository;

    @MockBean
    private InventoryService inventoryService;

    private String itemId;

    @Before
    public void setup() throws Exception {
        itemId = "j23hjk32992jkjlaaa";

        when(itemRepository.findById(anyString())).thenReturn(Optional.of(MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId(), TestHelper.mockObjectId()))));
        when(itemRepository.save(any(Item.class))).thenReturn(MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId(), TestHelper.mockObjectId())));
        when(itemRepository.findAll(any(Pageable.class))).thenReturn(
                new PageImpl<Item>(Arrays.asList(MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId(), TestHelper.mockObjectId()))))
        );
        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(MockLocation.mockLocation()));
        when(uomMatrixRepository.findByUomCode(anyString())).thenAnswer(
                invocationOnMock -> {
                    String uomCode = invocationOnMock.getArgument(0);
                    UomMatrix uomMatrix = MockUOMMatrix.mockUOMMatrix();
                    uomMatrix.setUomCode(uomCode);
                    return Optional.of(uomMatrix);
                }
        );
        when(uomMatrixRepository.save(any(UomMatrix.class))).thenAnswer(
                invocationOnMock -> {
                    UomMatrix uomMatrix = invocationOnMock.getArgument(0);
                    Field id = PersistedObject.class.getDeclaredField("id");
                    id.setAccessible(true);
                    id.set(uomMatrix, "3934342knkkd2432");
                    return uomMatrix;
                }
        );
        when(supplierRepository.findById(anyString())).thenReturn(Optional.of(MockSupplier.mockSupplier()));

        when(clinicItemMasterRepository.findByClinicIdIn(anyList())).thenAnswer(
                invocationOnMock -> {
                    List<String> clinicIds = invocationOnMock.getArgument(0);
                    return new ArrayList<>(
                            List.of(new ClinicItemMaster(clinicIds.get(0), List.of(new ClinicItemMaster.ClinicItemPrice(itemId, new BigDecimal(100.0f)))))
                    );
                }
        );
        when(itemRepository.findAllActive()).thenReturn(List.of(MockDrugItem.mockDrugItem(List.of(itemId))));
        when(itemRepository.findAllById(anyList())).thenReturn(List.of(MockDrugItem.mockDrugItem(List.of(itemId))));

        when(inventoryService.fireNavInventoryApi(anyString(), anyList()))
                .thenReturn(List.of(MockInventoryData.mockInventoryData(TestHelper.mockObjectId(), itemId, "Code", "Batch", 100)));
    }

    @Test
    public void createDrugItem() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/create/drug-item")
                        .header("Authorization", TestHelper.TOKEN)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId(), TestHelper.mockObjectId())));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentCreateDrugItem())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findDrugItem() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/search/drug-item/detail/{itemId}", "994335njkj3")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentSearchDrugItem())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listAllDrugItem() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/list/drug-item/{clinicId}", TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentListAllDrugItem())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findDrugItemQuantity() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/find/drug-item/quantity/{clinicId}/{itemId}/{uom}",
                        TestHelper.mockObjectId(), "j23hjk32992jkjlaaa", "TABLET")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentFindDrugItemQuantity())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listItemBySupplier() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/list/drug-item/{clinicId}/{supplierId}",
                        TestHelper.mockObjectId(), TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentListItemBySupplier())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listInventoryByItemId() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/list/{clinicId}/{itemId}",
                        TestHelper.mockObjectId(), TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentListInventoryByItemId())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listInventoryBySupplierId() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/inventory/list/supplier/{clinicId}/{supplierId}",
                        TestHelper.mockObjectId(), TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(InventoryDocument.documentListInventoryBySupplier())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();

    }
}
