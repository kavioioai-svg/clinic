package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.inventory.svc.model.common.ClinicFilter;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.common.OrderBuilder;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;

public class MockOrder {

    public static Order mockPurchaseOrder(String orderId){
        Order purchaseOrder = mockPurchaseOrder();
        purchaseOrder.setId(orderId);
        return purchaseOrder;
    }

    /*purchase order*/
    public static Order mockPurchaseOrder() {

        Order purchaseOrder = new OrderBuilder().setRequestClinicId("ckdiik29o34j49433r4kd")
                .setRequestId("R00001")
                .setOrderNo("100001")
                .setOrderStatus(OrderStatus.INITIAL)
                .setSupplierId("dkdi9c9iej43jju4")
                .setClinicFilter(new ClinicFilter(Set.of("ckdiik29o34j49433r4kd"), "BBTW"))
                .setInterComp(true)
                .setGoodPurchasedItems(
                        Arrays.asList(
                                MockOrder.mockGoodOrderItem("kdi3k9kfm40l4m", "fmjki4n49843985", "TABLET", 100, new UnitPrice(10, false), "additionalDescription1", "SCHV"),
                                MockOrder.mockGoodOrderItem("299232l2j3h223", "fmjki4n49843985", "TABLET", 100, new UnitPrice(10, false), "additionalDescription2", "PAV"),
                                MockOrder.mockGoodOrderItem("2993j493k23j332", "fmjki4n49843985", "BOX", 100, new UnitPrice(10, false), "additionalDescription3", "PAV")
                        ))
                .setGoodReceivedNotes(new ArrayList<>(Arrays.asList(
                        mockGoodReceivedNote("01", LocalDate.now(), LocalDate.now(), "3094032k33", "99djj328dj3", "00233", LocalDate.now(), "38fj484n9", "remark", DeliveryNoteStatus.DRAFT),
                        mockGoodReceivedNote("02", LocalDate.now(), LocalDate.now(), "3094032k33", "99djj328dj3", "00232", LocalDate.now(), "38fj484n9", "remark", DeliveryNoteStatus.CONFIRM)
                )))
                .createPurchaseOrder();
        purchaseOrder.setId("ID");
        return purchaseOrder;
    }

    public static Order mockBasicPurchaseOrder() {

        Order purchaseOrder = new OrderBuilder().setRequestClinicId("ckdiik29o34j49433r4kd")
                .setOrderStatus(OrderStatus.INITIAL)
                .setSupplierId("dkdi9c9iej43jju4")
                .setClinicFilter(new ClinicFilter(Set.of("ckdiik29o34j49433r4kd"), "BBTW"))
                .setGoodPurchasedItems(
                        Arrays.asList(
                                mockGoodOrderItem("kdi3k9kfm40l4m", "fmjki4n49843985", "BOX", 100, new UnitPrice(10, false), "additionalDescription1"),
                                mockGoodOrderItem("0834n4884bb343", "dj48fj4o0od3mndui", "BOX", 100, new UnitPrice(120, false),"additionalDescription1")
                        ))
                .createPurchaseOrder();

        return purchaseOrder;
    }

    public static GoodReceivedNote mockGoodReceivedNote(String id, LocalDate createDate, LocalDate grnDate, String delivererId, String receiverId, String grnNo, LocalDate dnDate, String dnNo, String additionalRemark, DeliveryNoteStatus status) {

        GoodReceivedNote goodReceivedNote = new GoodReceivedNote(createDate, grnDate, delivererId, receiverId, grnNo, dnDate, dnNo, additionalRemark, status);
        goodReceivedNote.setId(id);
        goodReceivedNote.setReceivedItems(new ArrayList<>(Arrays.asList(
                mockGoodReceivedItem("5782993l332j3", "299232l2j3h223", "BOX", "D-2322", 40,
                        LocalDate.of(2019, 10, 31), "INV-0001", LocalDate.now().plusMonths(4),
                        LocalDate.of(2002, 12, 31), false, "Drug is received"),
                mockGoodReceivedItem("9dkki309m32003", "2993j493k23j332", "BOX", "SU-2999", 40,
                        LocalDate.of(2020, 12, 31), "INV-0002", LocalDate.now().plusMonths(4),
                        LocalDate.of(2002, 12, 31), false, "Drug condition is not good"
                ))));
        goodReceivedNote.setNavIntegrationResult(new NavIntegrationResult("", NavIntegrationResult.ResultStatus.FAILED));
        return goodReceivedNote;
    }


    public static GoodOrderedItem mockGoodOrderItem(String itemRefId, String supplierId, String uom, int quantity, UnitPrice unitPrice, String additionalDescription) {

        GoodOrderedItem goodOrderedItem = new GoodOrderedItem("122345", itemRefId, supplierId, uom, quantity, unitPrice, additionalDescription);
        return goodOrderedItem;
    }

    public static GoodOrderedItem mockGoodOrderItem(String itemRefId, String supplierId, String uom, int quantity, UnitPrice unitPrice, String additionalDescription, String fromClinicCode) {

        GoodOrderedItem goodOrderedItem = new GoodOrderedItem("122345", itemRefId, supplierId, uom, quantity, unitPrice, additionalDescription);
        goodOrderedItem.setFromClinicCode(fromClinicCode);
        return goodOrderedItem;
    }

    public static GoodReturnItem mockGoodReturnItem(String lineNo, String itemRefId, String uom, String batchNumber, int quantity, LocalDate receiptDate,
                                                    String invoiceNo, LocalDate expiryDate, LocalDate manufacturerDate,
                                                    String reason) {
        GoodReturnItem goodReturnItem = new GoodReturnItem(lineNo, itemRefId, uom, batchNumber, quantity, receiptDate, invoiceNo, expiryDate, manufacturerDate,
                reason);
        return goodReturnItem;
    }

    public static DeliveryNote mockDeliveryNote(String id, String delivererId, String receiverId, LocalDate createDate, LocalDate receivedDate,
                                                String dnNo, DeliveryNoteStatus status) {
        DeliveryNote deliveryNote = new DeliveryNote(delivererId, receiverId, createDate,
                receivedDate, dnNo, status);
        deliveryNote.setId(id);
        deliveryNote.setTransferSendItems(Arrays.asList(
                mockDeliveryItem("9943703", "22k32e30023223", "BOX", "D-2322", 10, LocalDate.of(2015, 12, 31), false, ""
                )));
        deliveryNote.setNavIntegrationResult(new NavIntegrationResult("", NavIntegrationResult.ResultStatus.FAILED));
        return deliveryNote;
    }

    public static DeliveryItem mockDeliveryItem(String id, String itemRefId, String uom, String batchNumber, int quantity,
                                                LocalDate expiryDate, Boolean isCountInStock, String comment) {
        DeliveryItem deliveryItem = new DeliveryItem(id, itemRefId, uom, batchNumber, quantity, null, null, expiryDate, null,
                comment, BigDecimal.ZERO);
        return deliveryItem;
    }

    public static DeliveryItem mockGoodReceivedItem(String id, String itemRefId, String uom, String batchNumber, int quantity, LocalDate receiptDate,
                                                    String invoiceNo, LocalDate expiryDate, LocalDate manufacturerDate, Boolean isCountInStock, String comment) {
        DeliveryItem goodReceivedItem = new DeliveryItem(id, itemRefId, uom, batchNumber, quantity, receiptDate, invoiceNo, expiryDate, manufacturerDate, comment, BigDecimal.ZERO);
        return goodReceivedItem;
    }

    /*transfer order*/
    public static Order mockTransferOrder() {

        Order transferOrder = new OrderBuilder().setRequestClinicId("ckdiik29o34j49433r4kd")
                .setSenderClinicId("d9d9k4i9fok4j")
                .setOrderStatus(OrderStatus.INITIAL)
                .setTransferRequestItems(Arrays.asList(
                        mockTransferRequestItem("2993j493k23j332", "BOX", 30),
                        mockTransferRequestItem("0834n4884bb343", "BOX", 4),
                        mockTransferRequestItem("43400322lfk3", "BOX", 10)
                ))
                .setGoodPurchasedItems(
                        Arrays.asList(MockOrder.mockGoodOrderItem("kdi3k9kfm40l4m", "fmjki4n49843985", "TABLET", 100, new UnitPrice(10, false), "additionalDescription1")
                        ))
                .setGoodReceivedNotes(new ArrayList<>(Arrays.asList(
                        mockGoodReceivedNote("03", LocalDate.now(), LocalDate.now(), "3094032k33", "99djj328dj3", "00233", LocalDate.now(), "38fj484n9", "remark", DeliveryNoteStatus.DRAFT),
                        mockGoodReceivedNote("04", LocalDate.now(), LocalDate.now(), "3094032k33", "99djj328dj3", "00232", LocalDate.now(), "38fj484n9", "remark", DeliveryNoteStatus.CONFIRM)
                )))
                .setDeliveryNotes(new ArrayList<>(
                        Arrays.asList(
                                mockDeliveryNote("01", "4jn609lf4h3224343", "dfd323432k3b", LocalDate.now(), LocalDate.now(), "DN-993843", DeliveryNoteStatus.DRAFT),
                                mockDeliveryNote("02", "4jn609lf4h3224343", "dfd323432k3b", LocalDate.now(), LocalDate.now(), "DN-993844", DeliveryNoteStatus.CONFIRM)
                        )
                ))
                .createTransferOrder();
        transferOrder.setId("ID");
        return transferOrder;
    }

    public static Order mockReturnOrder(GoodReceivedReturnStatus status, String purchaseOrderid) {

        Order returnOrder = new OrderBuilder().setRequestClinicId("ckdiik29o34j49433r4kd")
                .setSupplierId("d9d9k4i9fok4j")
                .setReturnStatus(status)
                .setOrderType(OrderType.RETURN)
                .setOrderNo("O_00489934")
                .setCreateDate(LocalDate.now())
                .setOrderDate(LocalDate.now())
                .setCompleteDate(LocalDate.now())
                .setPurchaseOrderId(purchaseOrderid)
                .setReturnItems(Arrays.asList(
                        mockGoodReturnItem("10000", "kdi3k9kfm40l4m", "TABLET",
                                "Batch_001", 30, LocalDate.now(), "INV_102930", LocalDate.now().plusYears(3),
                                LocalDate.now(), "Condition not good"),
                        mockGoodReturnItem("10001", "299232l2j3h223", "TABLET",
                                "Batch_001", 4, LocalDate.now(), "INV_102930", LocalDate.now().plusYears(3),
                                LocalDate.now(), "Condition not good"),
                        mockGoodReturnItem("10002", "2993j493k23j332", "BOX",
                                "Batch_001", 20, LocalDate.now(), "INV_102930", LocalDate.now().plusYears(3),
                                LocalDate.now(), "Condition not good")
                ))
                .setDeliveryNotes(new ArrayList<>(
                        Arrays.asList(
                                mockDeliveryNote("01", "4jn609lf4h3224343", "dfd323432k3b", LocalDate.now(), LocalDate.now(), "DN-993843", DeliveryNoteStatus.DRAFT),
                                mockDeliveryNote("02", "4jn609lf4h3224343", "dfd323432k3b", LocalDate.now(), LocalDate.now(), "DN-993844", DeliveryNoteStatus.CONFIRM)
                        )
                ))
                .setNavIntegrationResult(new NavIntegrationResult("", NavIntegrationResult.ResultStatus.FAILED))
                .createReturnOrder();
        returnOrder.setId("ID");
        return returnOrder;
    }

    public static Order mockBasicTransferOrder() {

        Order transferOrder = new OrderBuilder().setRequestClinicId("ckdiik29o34j49433r4kd")
                .setSenderClinicId("d9d9k4i9fok4j")
                .setOrderStatus(OrderStatus.INITIAL)
                .setTransferRequestItems(Arrays.asList(
                        mockTransferRequestItem("890j3iuj33n343", "BOX", 10),
                        mockTransferRequestItem("0834n4884bb343", "BOX", 4),
                        mockTransferRequestItem("43400322lfk3", "BOX", 10)
                ))
                .setTransferRequestItems(
                        Arrays.asList(MockOrder.mockTransferRequestItem("kdi3k9kfm40l4m", "TABLET", 100)
                        ))
                .createTransferOrder();

        return transferOrder;
    }

    public static TransferRequestItem mockTransferRequestItem(String itemRefId, String uom, int transferQuantity) {
        TransferRequestItem transferRequestItem = new TransferRequestItem("10004", itemRefId, uom, transferQuantity);
        return transferRequestItem;
    }
}
