package com.ilt.cms.inventory.mock;

import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class MockLocation {

    public static Location mockLocation() {
        Location location = new Location("2829h3k221923m2");
//        location.setId("9k323j9348l32k");
        location.setInventory(
                new ArrayList<>(
                        Arrays.asList(
                                mockInventory("22k32e30023223", "BN-00001", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000),
                                mockInventory("299232l2j3h223", "INV-000001", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000),
                                mockInventory("299232l2j3h223", "D-2322", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000),
                                mockInventory("2993j493k23j332", "INV-000002", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000),
                                mockInventory("2993j493k23j332", "SU-2999", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000),
                                mockInventory("434kknd99433n43", "BN-00002", "BOX", LocalDate.now().plusMonths(1), LocalDate.now().minusMonths(1), 2200000))));
        return location;
    }

    public static Inventory mockInventory(String itemRefId, String batchNumber, String uom, LocalDate expiryDate, LocalDate manufacturerDate,
                                          int availableCount) {

        Inventory inventory = new Inventory(itemRefId, batchNumber, uom, expiryDate, manufacturerDate, BigDecimal.valueOf(availableCount), true , BigDecimal.ZERO);
        return inventory;
    }
}
