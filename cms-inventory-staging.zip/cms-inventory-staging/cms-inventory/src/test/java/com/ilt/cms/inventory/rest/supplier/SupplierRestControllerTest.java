package com.ilt.cms.inventory.rest.supplier;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.common.CorporateAddress;
import com.ilt.cms.core.entity.item.Cost;
import com.ilt.cms.core.entity.supplier.MinPurchaseAmount;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.SupplierDocument;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.mock.MockDrugItem;
import com.ilt.cms.inventory.mock.MockLocation;
import com.ilt.cms.inventory.mock.MockSupplier;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationRepository;
import com.ilt.cms.repository.spring.ItemRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"VIEW_SUPPLIER_NAV"})
public class SupplierRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SupplierRepository supplierRepository;

    @MockBean
    private ItemRepository itemRepository;

    @MockBean
    private LocationRepository locationRepository;
    @Before
    public void setup() throws Exception {
        when(supplierRepository.findAll()).thenReturn(Arrays.asList(
                MockSupplier.mockSupplier("S0001", "INITECH", "S0001", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                "   10 Eunos Road 8\n" +
                                "   #05-33 Singapore Post Centre\n" +
                                "   Singapore 408600\n" +
                                "   REPUBLIC OF SINGAPORE", "546080"),
                        Arrays.asList(new ContactPerson("Mr. Wong", "Sale manager", "12345678",
                                "98765432", "3839938323", "test@test.com", false)), Arrays.asList(new MinPurchaseAmount("398fj38jfjc9", false, 1000)),
                        Status.ACTIVE, Arrays.asList(new PurchaseItem("cjdidi99df3km4", 5, new Cost(100, false), Status.ACTIVE))),
                MockSupplier.mockSupplier("S0002", "REX", "S0002", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                "   30 Funny Road 1\n" +
                                "   #05-33 Singapore DownTown\n" +
                                "   Singapore 42939930\n" +
                                "   REPUBLIC OF SINGAPORE", "546080"),
                        Arrays.asList(new ContactPerson("Mr. Leung", "Sale executive", "12345678",
                                "98765432", "3839938323", "test@test.com", false)), Arrays.asList(new MinPurchaseAmount("398fj3odoo4390jc9", false, 2000)),
                        Status.ACTIVE, Arrays.asList(new PurchaseItem("cjdidi99df3km4", 5, new Cost(100, false), Status.ACTIVE)))
        ));
        when(supplierRepository.findById(anyString())).thenReturn(Optional.of(MockSupplier.mockSupplier()));

        when(supplierRepository.findByItemsItemId(anyString())).thenAnswer(
                invocationOnMock -> {
                    String itemId = invocationOnMock.getArgument(0);
                    return Arrays.asList(
                            MockSupplier.mockSupplier("S0001", "INITECH", "S0001", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                            "   10 Eunos Road 8\n" +
                                            "   #05-33 Singapore Post Centre\n" +
                                            "   Singapore 408600\n" +
                                            "   REPUBLIC OF SINGAPORE", "546080"),
                                    Arrays.asList(new ContactPerson("Mr. Wong", "Sale manager", "12345678",
                                            "98765432", "3839938323", "test@test.com", false)), Arrays.asList(new MinPurchaseAmount("398fj38jfjc9", false, 1000)),
                                    Status.ACTIVE, Arrays.asList(new PurchaseItem(itemId,  10, new Cost(100, false), Status.ACTIVE), new PurchaseItem("cjdidi99df3km4", 5, new Cost(100, false), Status.ACTIVE))),
                            MockSupplier.mockSupplier("S0002", "REX", "S0002", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                            "   30 Funny Road 1\n" +
                                            "   #05-33 Singapore DownTown\n" +
                                            "   Singapore 42939930\n" +
                                            "   REPUBLIC OF SINGAPORE", "546080"),
                                    Arrays.asList(new ContactPerson("Mr. Leung", "Sale executive", "12345678",
                                            "98765432", "3839938323", "test@test.com", false)), Arrays.asList(new MinPurchaseAmount("398fj3odoo4390jc9", false, 2000)),
                                    Status.ACTIVE, Arrays.asList(new PurchaseItem(itemId, 10, new Cost(100, false), Status.ACTIVE), new PurchaseItem("cjdidi99df3km4", 5, new Cost(100, false), Status.ACTIVE))));
                }
        );

        when(itemRepository.findById(anyString())).thenReturn(Optional.of(MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId()))));

        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(MockLocation.mockLocation()));
    }

    @Test
    public void listAll() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/supplier/list/all")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(SupplierDocument.documentListAll())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findById() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/supplier/get/{supplierId}", TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(SupplierDocument.documentFindById())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findByItemId() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/supplier/get/item/{itemId}", TestHelper.mockObjectId())
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(SupplierDocument.documentFindByItemId())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findSupplierByItemId() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/supplier/get/item/{clinicId}/{itemId}/{uom}",
                        TestHelper.mockObjectId(), TestHelper.mockObjectId(), "TABLET")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(SupplierDocument.documentFindByItemIdWithInvQty())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }
}
