package com.ilt.cms.inventory.rest.nav;

import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.NavQueueDocument;
import com.ilt.cms.inventory.apidoc.PurchaseDocument;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.svc.model.nav.NavQueue;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"NAV", "PURCHASE_NAV"})
public class NavQueueRestControllerTest {

    @Autowired
    RestTemplate restTemplate;
    @Autowired
    private MockMvc mockMvc;

    @Before
    public void setUp() {
    }

    @Test
    //@WithMockUser(roles = {"VIEW_SYNC_INFO"})
    public void canGetSyncInfo() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/navQueue/syncInfo/list/{page}/{size}", 0,50)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());
        TestHelper.httpRequestBuilder(requestBuilder, null);

        List<NavQueue> navQueues =new ArrayList<>();

        ResponseEntity<CmsServiceResponse<List<NavQueue>>> responseEntity = new ResponseEntity<>(new CmsServiceResponse<>(navQueues),HttpStatus.OK);

        when(restTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class>any())).thenReturn(responseEntity);

        MvcResult result = mockMvc.perform(requestBuilder)
                //.andDo(NavQueueDocument.documentFindRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }
}
