package com.ilt.cms.inventory.rest.inventory;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.core.entity.item.*;
import com.ilt.cms.core.entity.item.ClinicGroupItemMaster.ClinicGroupItemPrice;
import com.ilt.cms.core.entity.item.ClinicItemMaster.ClinicItemPrice;
import com.ilt.cms.core.entity.system.SystemStore;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.StockDocument;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.mock.MockClinic;
import com.ilt.cms.inventory.mock.MockDrugItem;
import com.ilt.cms.inventory.mock.MockItemClinicDetail;
import com.ilt.cms.inventory.mock.MockLocation;
import com.ilt.cms.inventory.mock.MockStockTake;
import com.ilt.cms.inventory.mock.MockSystemStore;
import com.ilt.cms.inventory.model.StockTakeCriteriaContainer;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationRepository;
import com.ilt.cms.inventory.svc.db.service.MongoStockTakeDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.inventory.StockCountItem;
import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.api.AdjustmentStockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.ItemGroupType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.ilt.cms.inventory.svc.service.nav.NavInventoryService;
import com.ilt.cms.inventory.svc.service.nav.NavStockTakeService;
import com.ilt.cms.repository.spring.ClinicGroupItemMasterRepository;
import com.ilt.cms.repository.spring.ClinicItemMasterRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.ItemClinicDetailRepository;
import com.ilt.cms.repository.spring.ItemRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import com.ilt.cms.repository.spring.system.SystemStoreRepository;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Sort;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.*;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"PR_PO_INVENTORY", "PR_PO_INVENTORY_NAV"})
public class StockTakeRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LocationRepository locationRepository;

    @MockBean
    private ItemRepository itemRepository;

    @MockBean
    private MongoStockTakeDatabaseService mongoStockTakeDatabaseService;

    @MockBean
    private ClinicRepository clinicRepository;

    @MockBean
    private SupplierRepository supplierRepository;

    @MockBean
    private SystemStoreRepository systemStoreRepository;

    @MockBean
    private ClinicItemMasterRepository clinicItemMasterRepository;

    @MockBean
    private ClinicGroupItemMasterRepository clinicGroupItemMasterRepository;

    @MockBean
    private ItemClinicDetailRepository itemClinicDetailRepository;

    @MockBean
    private NavStockTakeService navStockTakeService;

    @MockBean
    private ItemDatabaseService itemDatabaseService;

    @Autowired
    private NavInventoryService navInventoryService;

    private Location mockLocation;

    private DrugItem mockDrugItem;

    private String clinicId;

    @Before
    public void setup() throws Exception {
        clinicId = "C-000001";
        String itemRefId = TestHelper.mockObjectId();
        String batchNumber = "BN-00001";
        mockLocation = MockLocation.mockLocation();
        List<Inventory> inventories = new ArrayList<>(
                Arrays.asList(
                        MockLocation.mockInventory(itemRefId, batchNumber, "BOX",
                                LocalDate.of(2020, 12, 8), LocalDate.of(2017, 12, 8), 1000),
                        MockLocation.mockInventory(TestHelper.mockObjectId(), "BN-00002", "BOX",
                                LocalDate.of(2020, 12, 8), LocalDate.of(2017, 12, 8), 1000)
                )
        );
        mockLocation.setInventory(inventories);
        mockDrugItem = MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId(), TestHelper.mockObjectId()));
        mockDrugItem.setId(itemRefId);
        ClinicItemMaster clinicItem = mockClinicItems("ID-001", itemRefId);
        when(itemRepository.findById(anyString())).thenAnswer(
                invocationOnMock -> {
                    String id = invocationOnMock.getArgument(0);
                    DrugItem drugItem = MockDrugItem.mockDrugItem(Arrays.asList(TestHelper.mockObjectId()));
                    drugItem.setId(id);
                    return Optional.of(drugItem);
                }
        );
        when(itemRepository.findAllByDrugBrandNameRegex(anyString(), any(Sort.class))).thenReturn(Arrays.asList(mockDrugItem));
        when(itemRepository.searchItem(anyString(), anyString(), anyList(), any(Sort.class))).thenReturn(Arrays.asList(mockDrugItem));
        when(itemRepository.findByKeyword(anyString(), anyString(), any(Sort.class))).thenReturn(Arrays.asList(mockDrugItem));
        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(mockLocation));
        when(mongoStockTakeDatabaseService.saveStockTake(any(StockTake.class))).thenAnswer(
                invocationOnMock -> {
                    StockTake stockTake = invocationOnMock.getArgument(0);
                    return stockTake;
                }
        );

        when(mongoStockTakeDatabaseService.findStockTakeByClinicIdAndCountTypeInAndApproveStatusInAndStockCountItemsItemRedIdIn(anyString(), anyList(), anyList(), anyList(), anyInt(), anyInt(), any(), any()))
                .thenReturn(new PageImpl<>(Arrays.asList(MockStockTake.mockStockTakeAdjustment())));
        when(mongoStockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), anyString(), anyString(), anyString(), any(), any(), any()))
                .thenReturn(new PageImpl<>(Arrays.asList(MockStockTake.mockStockTakeAdjustment())));
        when(mongoStockTakeDatabaseService.findStockTakeByStockTakeName(anyString())).thenAnswer(
                invocationOnMock -> {
                    String stockTakeName = invocationOnMock.getArgument(0);
                    StockTake stockTake = MockStockTake.mockStockTake();
                    stockTake.setStockTakeName(stockTakeName);
                    return Optional.of(stockTake);
                }
        );
        when(mongoStockTakeDatabaseService.findStockTakeByStockTakeStatusOrApproveStatus(any(), any(), anyInt(), anyInt(), any(), any())).thenAnswer(
                invocationOnMock -> {
                    StockTakeStatus stockTakeStatus = invocationOnMock.getArgument(0);
                    StockTakeApproveStatus stockTakeApproveStatus = invocationOnMock.getArgument(1);

                    return new PageImpl<>(Arrays.asList(MockStockTake.mockStockTake(StockCountType.PARTIAL, "A", "B",
                            stockTakeStatus, stockTakeApproveStatus,
                            100, 99.0, 100.0)));
                }
        );

        when(mongoStockTakeDatabaseService.findStockTakeByClinicIdAndCountNameLikeAndTransactionNoLikeAndApproveStatusInAndStockTakeStatusInAndCountTypeInAndDateBetween(
                anyString(), anyString(), any(), anyList(), anyList(), anyList(), any(), any(), anyInt(), anyInt(), any(), any()))
                .thenReturn(new PageImpl<>(Arrays.asList(MockStockTake.mockStockTake(StockCountType.PARTIAL, "A", "B",
                        StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE, StockTakeApproveStatus.NOT_APPROVED,
                        100, 99.0, 100.0))));

        setupReturnStockTake(StockTakeStatus.COMPLETED);
        when(clinicRepository.findById(anyString())).thenAnswer(
                invocationOnMock -> {
                    String clinicId = invocationOnMock.getArgument(0);
                    Clinic clinic = MockClinic.mockClinic(clinicId, "test clinic");
                    return Optional.of(clinic);
                }
        );

        when(systemStoreRepository.findByKey(anyString())).thenAnswer(
                invocationOnMock -> {
                    String key = invocationOnMock.getArgument(0);
                    SystemStore systemStore = MockSystemStore.mockStockCountReasonSystemStore(key);
                    return Optional.ofNullable(systemStore);
                }
        );
        when(itemRepository.findByCode(anyString())).thenAnswer(invocationOnMock -> {
            String code = invocationOnMock.getArgument(0);
            Item item = mockItem();
            Field code1 = Item.class.getDeclaredField("code");
            code1.setAccessible(true);
            code1.set(item, code);
            return Optional.of(item);
        });
        when(itemRepository.findAllById(anyList())).thenAnswer(
                invocationOnMock -> {
                    List<String> itemIds = invocationOnMock.getArgument(0);
                    List<Item> items = new ArrayList<>();
                    itemIds.forEach(
                            id -> {
                                Item item = mockItem();
                                Field idField = null;
                                try {
                                    idField = PersistedObject.class.getDeclaredField("id");
                                    idField.setAccessible(true);
                                    idField.set(item, id);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                items.add(item);
                            }
                    );
                    return items;
                }
        );
        when(itemRepository.findAllActive()).thenReturn(Arrays.asList(mockDrugItem));
        when(clinicItemMasterRepository.findByClinicIdIn(anyList())).thenReturn(List.of(clinicItem));
        when(clinicGroupItemMasterRepository.findByGroupNameIn(anyList())).thenReturn(List.of(mockClinicGrpupItems("ID-001")));
        //when(restTemplate.exchange("http://localhost:8097/inventory/get-usage/all/{clinicId}", HttpMethod.POST, any(HttpEntity.class),
        //        any(ParameterizedTypeReference.class), anyString())).thenReturn();
        when(itemClinicDetailRepository.findByClinicDetailsClinicIdAndItemRefIdIn(anyString(), anyList())).thenAnswer(
                invocationOnMock -> {
                    return List.of(MockItemClinicDetail.mockItemClinicDetail("ITEM_ID_001"));
                }
        );

        when(navStockTakeService.getDisposedStock(anyString())).thenReturn(
                Arrays.asList(mockInventoryDetail(TestHelper.mockObjectId()))
        );
        when(navStockTakeService.getExpiredStock(anyString())).thenReturn(
                Arrays.asList(mockInventoryDetail(TestHelper.mockObjectId()))
        );
        StockTake stockTakeWithoutItem = MockStockTake.mockStockTake();
        stockTakeWithoutItem.setStockCountItems(new ArrayList<>());

//        when(navInventoryService.fireInventoryApi(anyString(), anyList())).thenReturn(
//                Arrays.asList(mockInventoryData(itemRefId))
//        );

//        when(restTemplate.exchange(Matchers.eq("https://localhost:8082/nav/get/inventory/{clinicId}"), any(HttpMethod.class), any(HttpEntity.class), any(ParameterizedTypeReference.class), anyString()))
//                .thenReturn(new ResponseEntity<CmsServiceResponse<List<InventoryDetail>>>(HttpStatus.ACCEPTED));
    }

    public static Item mockItem() {
        return mockItem("333333454");
    }

    public static Item mockItem(String itemId) {
        Item item = new Item();
        item.setId(itemId);
        item.setName("Paracetamol");
        item.setCode("PTM001");
        item.setDescription("Medicine used to treat pain and fever");
        item.setBaseUom("TABLET");
        item.setSalesUom("TABLET");
        item.setPurchaseUom("TABLET");
        item.setCategory("APAP");
        item.setSellingPrice(new SellingPriceBigDeci(new BigDecimal(120.0f), true));
        item.setInventoried(true);
        item.setAllowNegativeInventory(false);
        item.setSubItems(null);
        item.setSupplierId("SUP455752");
        item.setItemType(Item.ItemType.DRUG);
        item.setStatus(Status.ACTIVE);
        item.setTrackingCode(true);
        return item;
    }

    private static ClinicItemMaster mockClinicItems(String clinicItemId, String itemRefId) throws NoSuchAlgorithmException {
        ClinicItemMaster clinicItem = new ClinicItemMaster();
        clinicItem.setId(clinicItemId);
        clinicItem.setClinicId(clinicItemId);
        clinicItem.setItemsForClinic(List.of(new ClinicItemPrice("333333454", new BigDecimal(10.0f)), new ClinicItemPrice("4dc8524395052956d7371a1d1bd8865e", new BigDecimal(10.0f)),
                new ClinicItemPrice(itemRefId, new BigDecimal(20.0f))));
        return clinicItem;
    }

    private static ClinicGroupItemMaster mockClinicGrpupItems(String clinicItemId) {
        ClinicGroupItemMaster clinicGroupItemMaster = new ClinicGroupItemMaster();
        clinicGroupItemMaster.setId(clinicItemId);
        clinicGroupItemMaster.setGroupName("CMS");
        clinicGroupItemMaster.setClinicGroupItemPrices(
                List.of(new ClinicGroupItemPrice("333333454", new BigDecimal(10.0f)), new ClinicGroupItemPrice("djhih234h3b3kjbbj", new BigDecimal(20.0f))));
        return clinicGroupItemMaster;
    }

    private static InventoryDetail mockInventoryDetail(String clinicId) {
        InventoryDetail inventoryDetail = new InventoryDetail();
        inventoryDetail.setInventoryDetailId(123123134);
        inventoryDetail.setInventoryId(12);
        inventoryDetail.setClinicId(clinicId);
        inventoryDetail.setChargeId(0);
        inventoryDetail.setExpiryDate(new Date());
        inventoryDetail.setBatchNo("");
        inventoryDetail.setBaseUomQuantity(0);
        inventoryDetail.setQuantityTotal(0.0D);
        inventoryDetail.setAmount(0.0D);
        inventoryDetail.setItemAmount(10);
        inventoryDetail.setItemCost(10);
        inventoryDetail.setRemainingQuantity(0.0D);
        inventoryDetail.setRemainingAmount(0.0D);
        inventoryDetail.setCreatedAt(new Date());
        inventoryDetail.setCreatedUserId(0);
        inventoryDetail.setUpdatedAt(new Date());
        inventoryDetail.setUpdatedUserId(0);
        inventoryDetail.setDrugCode("");
        inventoryDetail.setItemId("");
        inventoryDetail.setInventoryUsageIndex(0);
        inventoryDetail.setPatientRegisterDetailId(0);
        inventoryDetail.setCost(0.0D);
        inventoryDetail.setMixingFlag(false);
        inventoryDetail.setTotalQuantity(10);
        inventoryDetail.setTotalAmount(10);
        inventoryDetail.setManufacturingDate(new Date());
        return inventoryDetail;
    }

    private static ItemChargeDetail.ItemChargeDetailResponse.InventoryData mockInventoryData(String itemRefId) {
        ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData = new ItemChargeDetail.ItemChargeDetailResponse.InventoryData();
        inventoryData.setInventoryDetailId(19231);
        inventoryData.setInventoryId(212121);
        inventoryData.setClinicId("323324");
        inventoryData.setChargeId(489943983);
        inventoryData.setExpireDate(LocalDate.of(2020, 10, 23));

        inventoryData.setBatchNo("BN0293");
        //inventoryData.setQuantity(11.1);
        inventoryData.setQuantityTotal(20.1);
        inventoryData.setAmount(1.1);
        inventoryData.setItemAmount(1.1);
        inventoryData.setItemCost(1.1);
        inventoryData.setRemainingQuantity(10);
        inventoryData.setRemainingAmount(10);
        inventoryData.setCreatedAt(LocalDateTime.now());
        inventoryData.setCreatedUserId(2932423);
        inventoryData.setUpdatedAt(LocalDateTime.now());

        inventoryData.setDrugCode("DC001");
        inventoryData.setTotalAmount(110.1);
        inventoryData.setTotalQuantity(10.1);
        inventoryData.setTotalAmount(200);
        inventoryData.setCost(3500.9);
        inventoryData.setMixingFlag(false);
        inventoryData.setItemId(itemRefId);
        inventoryData.setInventoryUsageIndex(1);
        inventoryData.setPatientRegisterDetailId(34093407);
        inventoryData.setBaseUom("TABLET");
        inventoryData.setSaleUom("TABLET");
        inventoryData.setPurchaseUom("BOX100");
        inventoryData.setBaseUomQuantity(100);
        inventoryData.setSaleUomQuantity(100.0);
        inventoryData.setPurchaseUomQuantity(1.0);
        return inventoryData;
    }

    private void setupReturnStockTake(StockTakeStatus status) {
        when(mongoStockTakeDatabaseService.findStockTakeById(anyString())).thenAnswer(
                invocationOnMock -> {
                    String id = invocationOnMock.getArgument(0);
                    StockTake stockTake = MockStockTake.mockStockTake();
                    Field idField = PersistedObject.class.getDeclaredField("id");
                    idField.setAccessible(true);
                    idField.set(stockTake, id);
                    stockTake.setStockTakeStatus(status);
                    stockTake.setStockCountItems(
                            new ArrayList<>(Arrays.asList(
                                    MockStockTake.mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG", "9232030ii99966", "ND2211",
                                            "BOX", LocalDate.of(2030, 12, 31), LocalDate.of(2017, 12, 8), "ND2211", "TAB",
                                            LocalDate.of(2030, 12, 31), 100, 99.0, 99.0, "mistake to count", "cpRemarks"),
                                    MockStockTake.mockStockCountItem("SCI_002","nkhnjk3343bj43", "C-00002", "item02", "SERVICE", "9232030i4366", "ND2211",
                                            "BOX", LocalDate.of(2030, 12, 31), LocalDate.of(2017, 12, 8), "ND2211", "TAB",
                                            LocalDate.of(2030, 12, 31), 422, 400.0, 400.0, "mistake to count", "cpRemarks")
                            ))
                    );
                    return Optional.of(stockTake);
                }
        );
    }

    @Test
    public void listApprovalStockTakes() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/stock-take/{stockTakeStatus}/{stockTakeApproveStatus}/{page}/{size}",
                        StockTakeStatus.COMPLETED, StockTakeApproveStatus.NOT_APPROVED, 0, 100)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void searchStockTakeInventory() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/search/inventory/{clinicId}/{itemGroup}/{page}/{size}",
                        clinicId, ItemGroupType.DRUG, 0, 10)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        Map<String, String> searchRegex = new HashMap<>();
        searchRegex.put("ITEM_NAME_REGEX", "DRUG");
        TestHelper.httpRequestBuilder(requestBuilder, searchRegex);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentSearchInventory())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void searchStockTakeItemInventory() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/search/item/{clinicId}/{itemGroup}/{page}/{size}",
                        "5b55aabd0550de0021097bef", ItemGroupType.DRUG, 0, 10)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        Map<String, String> searchRegex = new HashMap<>();
        //searchRegex.put("ITEM_NAME_REGEX", "ALL");
        TestHelper.httpRequestBuilder(requestBuilder, searchRegex);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentSearchItemInventory())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void searchInventoryByItemCode() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/search/inventory/{clinicId}/{itemCode}/{batchNo}",
                        TestHelper.mockObjectId(), "C-00001", "BN-00001")
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);
        Item item = new Item();
        item.setInventoried(true);
        when(itemDatabaseService.findByClinicIdAndCode(anyString(),anyString())).thenReturn(Optional.of(item));
        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentSearchInventoryByItemCode())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    @Ignore
    public void adjustmentStockTake() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/adjustment/stock-take/{clinicId}",
                        TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        AdjustmentStockTake adjustmentStockTake = new AdjustmentStockTake("I-0001", "BN-00001",
                "TABLET", LocalDate.of(2019, 10, 28),
                LocalDate.of(2016, 10, 28), 1000, "002", "remark", BigDecimal.ZERO);

        TestHelper.httpRequestBuilder(requestBuilder, adjustmentStockTake);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentAdjustmentStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void searchStockTakeById() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/search/stock-take/{stockTakeId}",
                        TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentSearchStockTakeByStockTakeId())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listStockTakeByClinicId() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/stock-take/{clinicId}/{page}/{size}",
                        TestHelper.mockObjectId(), 0, 10)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        StockTakeCriteriaContainer stockTakeCriteriaContainer = new StockTakeCriteriaContainer();
        stockTakeCriteriaContainer.setNameRegex("TestCountName");
        stockTakeCriteriaContainer.setStartDate(LocalDate.now().minusMonths(1));
        stockTakeCriteriaContainer.setEndDate(LocalDate.now());
        stockTakeCriteriaContainer.setStockCountTypes(Arrays.asList(StockCountType.PARTIAL, StockCountType.FULL));
        stockTakeCriteriaContainer.setStockTakeApproveStatuses(Arrays.asList(StockTakeApproveStatus.APPROVED, StockTakeApproveStatus.FAILED));
        stockTakeCriteriaContainer.setStockTakeStatuses(Arrays.asList(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE));
        TestHelper.httpRequestBuilder(requestBuilder, stockTakeCriteriaContainer);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListStockTakeByClinicId())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listStockTakeAdjustment() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/adjustment/{clinicId}/{itemGroup}/{page}/{size}",
                        TestHelper.mockObjectId(), "ALL", 0, 10)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        Map<String, Object> filterMap = new HashMap<>();
        filterMap.put("ITEM_NAME_REGEX", TestHelper.mockObjectId());
        filterMap.put("ITEM_CODE_REGEX", "testCode");
        filterMap.put("TRANSACTION_NO_REGEX", "12455");
        filterMap.put("APPROVE_STATUS", Arrays.asList("NOT_APPROVED", "REJECTED"));
        TestHelper.httpRequestBuilder(requestBuilder, filterMap);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListAdjustment())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void startCountStockTake() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/start/stock-take/{clinicId}",
                        "9d48388ee70821da6383979e05d8c85a")
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        StockTake stockTake = new StockTake(LocalDate.now(), LocalTime.now(), StockCountType.FULL, "A", "E",
                "Admin", null, StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);
        TestHelper.httpRequestBuilder(requestBuilder, stockTake);

        Location location = MockLocation.mockLocation();
        List<Inventory> inventories = new ArrayList<>(
                Collections.singletonList(
                        MockLocation.mockInventory(mockDrugItem.getId(), "BN-00001", "BOX",
                                LocalDate.of(2020, 12, 8), LocalDate.of(2017, 12, 8), 1000)
                )
        );
        location.setInventory(inventories);

        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(location));


        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentStartCountStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();

    }

    @Test
    public void stopCountStockTake() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/stop/stock-take/{stockTakeId}",
                        TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        List<StockCountItem> stockCountItems = new ArrayList<>(
                Arrays.asList(
                        MockStockTake.mockStockCountItem("SCI_001", null, null, null,
                                null, TestHelper.mockObjectId(), null, null,
                                null, null, null, "BOX", null, 1000,
                                980.0, 980.0, "Used", "cpRemarks"),
                        MockStockTake.mockStockCountItem("SCI_002",null, null, null,
                                null, TestHelper.mockObjectId(), null, null,
                                null, null, null, "BOX", null, 1000,
                                980.0, 980.0, "Used", "cpRemarks")
                ));
        TestHelper.httpRequestBuilder(requestBuilder, stockCountItems);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentStopCountStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void submitStockTakeForReview() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/submit/stock-take/{stockTakeId}",
                        TestHelper.mockObjectId())
                        .header("Authorization", TestHelper.TOKEN)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f").with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentSubmitStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void approveStockTake() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/approve/stock-take/{stockTakeId}",
                        TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentApproveStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void rejectStockTake() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/reject/stock-take/{stockTakeId}",
                        TestHelper.mockObjectId(), 10)
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentRejectStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    @WithMockUser(roles = {"STOCK_ADJUSTMENT_APPROVAL"})
    public void submitApproveStockAdjustment() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/submit/approve/stock-adjustment/{stockTakeId}",
                                TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        StockTake mockStockTake = MockStockTake.mockStockTake();
        mockStockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem mockStockCountItem1 = MockStockTake.mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG", "9232030ii99966", "ND2211",
                "BOX", LocalDate.of(2030, 12, 31), LocalDate.of(2017, 12, 8), "ND2211", "TAB",
                LocalDate.of(2030, 12, 31), 100, 99.0, 99.0, "mistake to count", "cpRemarks");
        mockStockCountItem1.setAdjustedQuantity(1200.0);

        StockCountItem mockStockCountItem1Expected = MockStockTake.mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG", "9232030ii99966", "ND2211",
                "BOX", LocalDate.of(2030, 12, 31), LocalDate.of(2017, 12, 8), "ND2211", "TAB",
                LocalDate.of(2030, 12, 31), 100, 99.0, 99.0, "mistake to count", "cpRemarks");
        mockStockCountItem1Expected.setAvailableCount(111000);
        mockStockCountItem1Expected.setStatus(StockCountItemStatus.APPROVED);

        mockStockTake.setStockCountItems(List.of(mockStockCountItem1));

        Location mockLocation = MockLocation.mockLocation();

        Inventory mockInventory =  MockLocation.mockInventory("9232030ii99966", "ND2211", "TAB",
                LocalDate.of(2020, 12, 8), LocalDate.of(2017, 12, 8), 1000);
        mockInventory.setInventoryId("huhb39934324k3");

        List<Inventory> inventories = new ArrayList<>(Arrays.asList(mockInventory));

        mockLocation.setInventory(inventories);

        Item item = new Item();
        item.setId(mockStockCountItem1.getItemRefId());

        when(mongoStockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(mockStockTake));
        mockStockTake.setStockCountItems(List.of(mockStockCountItem1Expected));
        when(mongoStockTakeDatabaseService.saveStockTake(any())).thenReturn(mockStockTake);
        when(itemDatabaseService.findItemsByIds(anyList())).thenReturn(List.of(item));
        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(mockLocation));

        TestHelper.httpRequestBuilder(requestBuilder, mockStockCountItem1);

        MvcResult result = mockMvc.perform(requestBuilder)
                //.andDo(StockDocument.documentApproveStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();

    }

    @Test
    @WithMockUser(roles = {"STOCK_ADJUSTMENT_APPROVAL"})
    public void submitRejectStockAdjustment() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/submit/reject/stock-adjustment/{stockTakeId}",
                                TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        StockTake mockStockTake = MockStockTake.mockStockTake();
        mockStockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem mockStockCountItem1 = MockStockTake.mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG", "9232030ii99966", "ND2211",
                "BOX", LocalDate.of(2030, 12, 31), LocalDate.of(2017, 12, 8), "ND2211", "TAB",
                LocalDate.of(2030, 12, 31), 100, 99.0, 99.0, "mistake to count", "cpRemarks");
        mockStockCountItem1.setAdjustedQuantity(1200.0);

        mockStockTake.setStockCountItems(List.of(mockStockCountItem1));

        when(mongoStockTakeDatabaseService.findStockTakeById(any())).thenReturn(Optional.of(mockStockTake));
        when(mongoStockTakeDatabaseService.saveStockTake(any())).thenReturn(mockStockTake);

        TestHelper.httpRequestBuilder(requestBuilder, mockStockCountItem1);

        MvcResult result = mockMvc.perform(requestBuilder)
                //.andDo(StockDocument.documentApproveStockTake())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();

    }

    @Test
    public void listReason() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/adjustment/reason")
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListReason())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listExpiredStock() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/expired-stock/{clinicId}", TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListExpiredStock())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listDisposedStock() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/list/disposed-stock/{clinicId}", TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentListDisposedStock())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void retrySaveStockAdjustmentToNav() throws Exception {
        StockTake stockTake = MockStockTake.mockStockTake();
        stockTake.setNavIntegrationResult(new NavIntegrationResult("Failed", NavIntegrationResult.ResultStatus.FAILED));
        when(mongoStockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/retry/nav/adjustment/{stockTakeId}", TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentRetrySaveStockAdjusmentToNav())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retrySaveStockTakeToNav() throws Exception {
        StockTake stockTake = MockStockTake.mockStockTake();
        stockTake.setNavIntegrationResult(new NavIntegrationResult("Failed", NavIntegrationResult.ResultStatus.FAILED));
        when(mongoStockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/retry/nav/stock-take/{stockTakeId}", TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentRetrySaveStockTakeToNav())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void deleteStockTake() throws Exception {

        setupReturnStockTake(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/stock/delete/stock-take/{stockTakeId}", TestHelper.mockObjectId())
                        .header("X-Tenant", "HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(StockDocument.documentDeleteStockTake())
                .andExpect(status().isOk())
                .andReturn();
    }

}
