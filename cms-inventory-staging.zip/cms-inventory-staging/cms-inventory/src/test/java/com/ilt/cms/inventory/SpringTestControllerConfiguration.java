package com.ilt.cms.inventory;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@TestConfiguration
public class SpringTestControllerConfiguration {

    @MockBean
    private RestTemplate restTemplate;

    @Bean
    public RestTemplateBuilder restTemplateBuilder() {

        RestTemplateBuilder restTemplateBuilder = Mockito.mock(RestTemplateBuilder.class);
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
        when(restTemplateBuilder.errorHandler(any())).thenReturn(restTemplateBuilder);
        return restTemplateBuilder;

//        RestTemplate restTemplate = new RestTemplate();
//        RestTemplateBuilder restTemplateBuilder = new RestTemplateBuilder();
//        restTemplateBuilder.configure(restTemplate);
//        restTemplateBuilder.build();
//
//        return restTemplateBuilder;

    }
}
