package com.ilt.cms.inventory.mock;

import com.ilt.cms.inventory.svc.model.inventory.StockCountItem;
import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MockStockTake {

    public static StockTake mockStockTake(){
         return mockStockTake("", LocalDate.of(2018, 11, 23), LocalTime.now(), "dkd33434mn43", StockCountType.PARTIAL,
                 "A", "E", "CountName","201902930333", StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE, null,
         new ArrayList<>(Arrays.asList(
                 mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG","9232030ii99966", "ND2211",
                        "BOX",LocalDate.of(2030, 12, 31),LocalDate.of(2030, 12, 31),"ND2211", "TAB",
                        LocalDate.of(2030, 12, 31), 100,99.0, null, "mistake to count", "cpRemarks"),
                 mockStockCountItem("SCI_002","nkhnjk3343bj43", "C-00002", "item02", "SERVICE","9232030i4366", "ND2211",
                         "BOX",LocalDate.of(2030, 12, 31), LocalDate.of(2030, 12, 31),"ND2211","TAB",
                         LocalDate.of(2030, 12, 31),422, 390.0, null,"mistake to count", "cpRemarks")
                 )));
    }

    public static StockTake mockStockTakeAdjustment(){
        return mockStockTake("", LocalDate.of(2018, 11, 23), LocalTime.now(), "dkd33434mn43", StockCountType.ADJUSTMENT,
                "A", "E", "CountName","201902930333", StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE, StockTakeApproveStatus.APPROVED,
                new ArrayList<>(Arrays.asList(
                        mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG","9232030ii99966", "ND2211",
                                "BOX",LocalDate.of(2030, 12, 31),LocalDate.of(2030, 12, 31),"ND2211", "TAB",
                                LocalDate.of(2030, 12, 31), 100,99.0, null, "drug", "cpRemarks"),
                        mockStockCountItem("SCI_001","nkhnjk3343bj43", "C-00002", "item02", "SERVICE","9232030i4366", "ND2211",
                                "BOX",LocalDate.of(2030, 12, 31), LocalDate.of(2030, 12, 31),"ND2211","TAB",
                                LocalDate.of(2030, 12, 31),422, 390.0, null,"mistake to count", "cpRemarks")
                )));
    }

    public static StockTake mockStockTake(StockCountType stockCountType, String startRange, String endRange, StockTakeStatus stockTakeStatus, StockTakeApproveStatus stockTakeApproveStatus,
                                          int availableCount, Double firstQuantity, Double secondaryQuantity){
        return mockStockTake("", LocalDate.of(2018, 11, 23), LocalTime.now(), "dkd33434mn43", stockCountType,
                startRange, endRange, "CountName", "2019021293003",stockTakeStatus, stockTakeApproveStatus,
                new ArrayList<>(Arrays.asList(
                        mockStockCountItem("SCI_001","huhb39934324k3", "C-00001", "item01", "DRUG","9232030ii99966", "ND2211",
                                "BOX",LocalDate.of(2030, 12, 31),LocalDate.of(2030, 12, 31),"ND2211", "TAB",
                                LocalDate.of(2030, 12, 31), 100,99.0, null, "mistake to count", "cpRemarks"),
                        mockStockCountItem("SCI_002","nkhnjk3343bj43", "C-00002", "item02", "SERVICE","9232030i4366", "ND2211",
                                "BOX",LocalDate.of(2030, 12, 31), LocalDate.of(2030, 12, 31),"ND2211","TAB",
                                LocalDate.of(2030, 12, 31),422, 390.0, null,"mistake to count", "cpRemarks")
                )));
    }

    public static StockTake mockStockTake(String stockTakeName, LocalDate startDate, LocalTime startTime, String clinicId, StockCountType countType,
                                          String startRange, String endRange, String countName, String transactionNo, StockTakeStatus stockTakeStatus, StockTakeApproveStatus stockTakeApproveStatus,
                                          List<StockCountItem> stockCountItems){
        StockTake stockTake = new StockTake(stockTakeName, startDate, startTime, clinicId, countType, startRange, endRange, countName, transactionNo, stockTakeStatus, stockTakeApproveStatus);
        stockTake.setStockCountItems(stockCountItems);
        return stockTake;
    }

    public static StockCountItem mockStockCountItem(String id, String inventoryId, String itemCode, String itemName, String itemType, String itemRefId,
                                                    String curBatchNumber, String curUom, LocalDate curExpiryDate, LocalDate curManufacturerDate,
                                                    String batchNumber, String uom, LocalDate expiryDate,
                                                    int availableCount, Double firstQuantity, Double secondaryQuantity, String remark, String cpRemarks){
        StockCountItem stockCountItem = new StockCountItem(inventoryId, itemCode, itemName, itemRefId, curBatchNumber, curUom, curExpiryDate, curManufacturerDate,
        availableCount);
        stockCountItem.setId(id);
        stockCountItem.setBatchNumber(batchNumber);
        stockCountItem.setExpiryDate(expiryDate);
        stockCountItem.setBaseUom(uom);
        stockCountItem.setFirstQuantity(firstQuantity);
        stockCountItem.setAdjustedQuantity(secondaryQuantity);
        stockCountItem.setRemark(remark);
        stockCountItem.setPurposeOfAdjustmentCode("034");
        stockCountItem.setCpRemarks(cpRemarks);
        return stockCountItem;
    }

}
