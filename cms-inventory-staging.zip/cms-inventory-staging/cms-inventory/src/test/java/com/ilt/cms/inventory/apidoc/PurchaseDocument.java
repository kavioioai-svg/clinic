package com.ilt.cms.inventory.apidoc;


import com.ilt.cms.inventory.svc.model.purchase.enums.*;
import com.lippo.cms.util.CMSConstant;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.payload.JsonFieldType;
import org.springframework.test.web.servlet.ResultHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.requestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;

public class PurchaseDocument extends ApiDocumentation {

    public static ResultHandler documentFindRequest() {
        return document("get-purchase-request",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request")
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentCreateRequest() {
        return document("create-purchase-request",
                pathParameters(), requestFields(purchaseRequestParameters()),
                responseAPI(true));
    }

    public static ResultHandler documentDeleteRequest() {
        return document("delete-purchase-request",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request. Only requests in DRAFT status can be deleted.")
                ),
                responseAPI(false));
    }

    public static ResultHandler documentUpdateRequest() {
        return document("update-purchase-request",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request that want to modify")
                ), requestFields(purchaseRequestParameters()),
                responseAPI(true));
    }

    public static ResultHandler documentFindOrder() {
        return document("get-order",
                pathParameters(
                        parameterWithName("orderId").description("Id of the order")
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentFindReturnOrder() {
        return document("get-return-order",
                pathParameters(
                        parameterWithName("orderId").description("Id of the order")
                ), requestFields(),
                responseAPI(true));
    }

    public static ResultHandler documentSearchPurchaseReturnOrder() {
        return document("search-purchase-return-order",
                pathParameters(), requestFields(searchPurchaseReturnOrderContainer()),
                responseAPI(true));
    }

    public static ResultHandler documentCreateOrder() {
        return document("create-blanket-purchase-order",
                pathParameters(), requestFields(purchaseOrderParameters()),
                responseAPI(true));
    }

    public static ResultHandler documentUpdateOrder() {
        return document("update-blanket-purchase-order",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to modify")
                ), requestFields(purchaseOrderParameters()),
                responseAPI(true));
    }

    public static ResultHandler documentCreateOrderByRequestId() {
        return document("create-purchase-order-by-request-id",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request that want to create order")
                ), requestFields(purchaseOrderParameters("[]")),
                responseAPI(true));
    }

    public static ResultHandler documentApproveRequest() {
        return document("approve-purchase-request",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request that want to approve")
                ), requestFields(purchaseRequestParameters()),
                responseAPI(false));
    }

    public static ResultHandler documentRejectRequest() {
        return document("reject-purchase-request",
                pathParameters(
                        parameterWithName("requestId").description("Id of the purchase request that want to reject")
                ), requestFields(),
                responseAPI(false));
    }

    public static ResultHandler documentAddGRN() {
        return document("add-purchase-grn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRN")
                ), requestFields(
                        goodReceiveNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentUpdateGRN() {
        return document("update-purchase-grn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRN"),
                        parameterWithName("grnId").description("GRN Number of the purchase order")
                ), requestFields(
                        goodReceiveNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentAddGRVN() {
        return document("add-purchase-grvn",
                pathParameters(
                        parameterWithName("requestClinicId").description("Id of the clinic that request return order"),
                        parameterWithName("supplierId").description("Id of the supplierId"),
                        parameterWithName("returnOrderStatus").description("Status[" + GoodReceivedReturnStatus.DRAFT + "," + GoodReceivedReturnStatus.CONFIRM + "]")
                ), requestFields(
                        returnItemContainer()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentUpdateGRVN() {
        return document("update-purchase-grvn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the return order"),
                        parameterWithName("supplierId").description("Id of the supplierId"),
                        parameterWithName("returnOrderStatus").description("Status[" + GoodReceivedReturnStatus.DRAFT + "," + GoodReceivedReturnStatus.CONFIRM + "]")
                ), requestFields(
                        returnItemContainer()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentApproveGRVN() {
        return document("approve-purchase-grvn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the return order")
                ), requestFields(
                        goodReturnItem("[]")
                ),
                responseAPI(false));
    }

    public static ResultHandler documentRejectGRVN() {
        return document("reject-purchase-grvn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the return order")
                ), requestFields(
                ),
                responseAPI(false));
    }

    public static ResultHandler documentReturnGRVN() {
        return document("return-purchase-grvn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRVN"),
                        parameterWithName("grvnId").description("Id of the good receive void note")
                ), requestFields(
                ),
                responseAPI(false));
    }

    public static ResultHandler documentAddGRVDN() {
        return document("add-purchase-grvdn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRVN")
                ), requestFields(
                        goodReceiveVoidDeliveryNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentUpdateGRVDN() {
        return document("update-purchase-grvdn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRVN"),
                        parameterWithName("grvndnId").description("id of the good receive void delivery note")
                ), requestFields(
                        goodReceiveVoidDeliveryNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentAddDN() {
        return document("add-purchase-dn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add GRVN")
                ), requestFields(
                        goodDeliveryNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentUpdateDN() {
        return document("update-purchase-dn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the purchase order that want to add DN"),
                        parameterWithName("dnId").description("Id of the delivery note")
                ), requestFields(
                        goodDeliveryNoteParameters()
                ),
                responseAPI(true));
    }

    public static ResultHandler documentListReturnOrderReason() {
        return document("list-pur-order-reason",
                pathParameters(
                ), requestFields(
                ),
                responseAPI(true));
    }

    public static ResultHandler documentListItemClinicDetail() {
        return document("list-item-clinic-detail",
                pathParameters(
                        parameterWithName("clinicId").description("Id of the clinic")
                ), requestFields(
                ),
                responseAPI(true));
    }

    public static ResultHandler documentCreateNavPurchaseRequest() {
        return document("retry-nav-pr", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("requestId").description("Id of the purchase request")
        ), requestFields(), responseAPI(false));
    }

    public static ResultHandler documentCreateNavPurchaseGoodReceivedNote() {
        return document("retry-nav-grn", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("orderId").description("Id of the Purchase Order"),
                parameterWithName("grnId").description("Id of the Good Received Note")
        ), requestFields(), responseAPI(false));
    }

    public static ResultHandler documentCreateNavReturnOrder() {
        return document("retry-nav-grvn", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("orderId").description("Id of the Purchase Order")
        ), requestFields(), responseAPI(false));
    }

    public static ResultHandler documentCreateNavReturnDeliveryNote() {
        return document("retry-nav-grvn-do", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("orderId").description("Id of the Purchase Order"),
                parameterWithName("doId").description("Id of the Delivery Note")
        ), requestFields(), responseAPI(false));
    }

    public static ResultHandler documentCreateNavTransferGoodReceivedNote() {
        return document("retry-nav-transfer-grn", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("orderId").description("Id of the Transfer Order"),
                parameterWithName("grnId").description("Id of the Good Received Note")
        ), requestFields(), responseAPI(false));
    }

    public static ResultHandler documentCreateNavDeliveryNote() {
        return document("retry-nav-do", pathParameters(
                parameterWithName("clinicId").description("Id of the clinic"),
                parameterWithName("orderId").description("Id of the Transfer Order"),
                parameterWithName("doId").description("Id of the Delivery Note")
        ), requestFields(), responseAPI(false));
    }

    private static List<FieldDescriptor> purchaseRequestParameters() {

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath("id").ignored().optional().type(JsonFieldType.STRING).description("Id of the request"),
                        fieldWithPath("requestClinicId").description("clinic id that create this request"),
                        fieldWithPath("requestNo").description("System generate number for request"),
                        fieldWithPath("requestType").description("Request type: " + Arrays.toString(RequestType.values())),
                        fieldWithPath("createDate").description("Date of create request"),
                        fieldWithPath("requestDate").optional().type(JsonFieldType.STRING).description("Start time to request"),
                        fieldWithPath("requiredBeforeDate").optional().type(JsonFieldType.STRING).description("Required before time of order"),
                        fieldWithPath("requestStatus").description("Request status: " + Arrays.toString(RequestStatus.values())),
                        fieldWithPath("supplierId").optional().type(JsonFieldType.STRING).description("Id of clinic want to transfer from"),
                        fieldWithPath("justificationForPurchase").description("Justification for purchase item"),
                        fieldWithPath("new").ignored().optional().type(JsonFieldType.BOOLEAN).description("???")
                )
        );
        fieldDescriptors.addAll(requestItemParameters("requestItems[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> requestItemParameters(String... variableNames) {
        String prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + ".itemRefId").description("Id of the item"),
                        fieldWithPath(prefix + ".supplierId").description("Id of the supplier"),
                        fieldWithPath(prefix + ".uom").type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + ".quantity").description("Quantity of the item requested"),
                        fieldWithPath(prefix + ".approvedQuantity").description("Quantity of the item approved"))

        );
        fieldDescriptors.addAll(unitPriceParameters(prefix, "unitPrice"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> purchaseOrderParameters() {
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath("id").optional().type(JsonFieldType.STRING).description("Id of the order"),
                        fieldWithPath("supplierId").description("Id of the supplier"),
                        fieldWithPath("requestId").optional().type(JsonFieldType.STRING).description("Id of the purchase request"),
                        fieldWithPath("requestDate").optional().type(JsonFieldType.STRING).description("Date of submit request"),
                        fieldWithPath("orderType").description("Order type:" + Arrays.toString(OrderType.values())),
                        fieldWithPath("requestClinicId").description("Id of the request clinic"),
                        fieldWithPath("createDate").description("Date of create order"),
                        fieldWithPath("orderNo").description("System generate number for the order"),
                        fieldWithPath("orderDate").optional().type(JsonFieldType.STRING).description("Order time of the order with format:[" + CMSConstant.JSON_DATE_FORMAT + "]"),
                        fieldWithPath("completeDate").optional().type(JsonFieldType.STRING).description("Order complete time of the order with format:[" + CMSConstant.JSON_DATE_FORMAT + "]"),
                        fieldWithPath("clinicFilter.clinics[]").optional().type(JsonFieldType.ARRAY).description("Filter of clinics can view purchase order"),
                        fieldWithPath("clinicFilter.clinicGroupName").optional().type(JsonFieldType.STRING).description("Filter of clinics group can view purchase order"),
                        fieldWithPath("orderStatus").description("Order status:" + Arrays.toString(OrderStatus.values()))
                )
        );
        fieldDescriptors.addAll(goodOrderedItemParameters("goodPurchasedItems[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> purchaseOrderParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + "id").optional().type(JsonFieldType.STRING).description("Id of the order"),
                        fieldWithPath(prefix + "supplierId").description("Id of the supplier"),
                        fieldWithPath(prefix + "requestId").optional().type(JsonFieldType.STRING).description("Id of the purchase request"),
                        fieldWithPath(prefix + "requestDate").optional().type(JsonFieldType.STRING).description("Date of submit request"),
                        fieldWithPath(prefix + "orderType").description("OrderType:" + Arrays.toString(OrderType.values())),
                        fieldWithPath(prefix + "requestClinicId").description("Id of the request clinic"),
                        fieldWithPath(prefix + "senderClinicId").optional().type(JsonFieldType.STRING).description("Id of the sender clinic in Transfer Order"),
                        fieldWithPath(prefix + "createDate").optional().type(JsonFieldType.STRING).description("Date of create order"),
                        fieldWithPath(prefix + "orderNo").optional().type(JsonFieldType.STRING).description("System generate number for the order"),
                        fieldWithPath(prefix + "orderDate").optional().type(JsonFieldType.STRING).description("Order time of the order with format:[" + CMSConstant.JSON_DATE_FORMAT + "]"),
                        fieldWithPath(prefix + "completeDate").optional().type(JsonFieldType.STRING).description("Order complete time of the order with format:[" + CMSConstant.JSON_DATE_FORMAT + "]"),
                        fieldWithPath(prefix + "clinicFilter.clinics[]").optional().type(JsonFieldType.ARRAY).description("Filter of clinics can view purchase order"),
                        fieldWithPath(prefix + "clinicFilter.clinicGroupName").optional().type(JsonFieldType.STRING).description("Filter of clinics group can view purchase order"),
                        fieldWithPath(prefix + "orderStatus").description("Order status:" + Arrays.toString(OrderStatus.values())),
                        fieldWithPath(prefix + "interComp").description("Whether the PO is an intercompany PO")
                )
        );
        fieldDescriptors.addAll(goodOrderedItemParameters(prefix, "goodPurchasedItems[]"));
        //fieldDescriptors.addAll(goodOrderedItemParameters(prefix,"transferRequestItems[]"));
        fieldDescriptors.add(fieldWithPath(prefix + "cPTransfer").description("cpTransfer value"));
        fieldDescriptors.add(fieldWithPath(prefix + "interComp").description("Inter company flag"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodOrderedItemParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix).description("Order item detail"),
                        fieldWithPath(prefix + "lineNo").optional().type(JsonFieldType.STRING).description("line no of the order item"),
                        fieldWithPath(prefix + "itemRefId").optional().type(JsonFieldType.STRING).description("Id of the order item"),
                        fieldWithPath(prefix + "supplierId").optional().type(JsonFieldType.STRING).description("Id of supplier"),
                        fieldWithPath(prefix + "uom").optional().type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + "quantity").optional().type(JsonFieldType.NUMBER).description("Quantity of the item "),
                        fieldWithPath(prefix + "additionalDescription").optional().type(JsonFieldType.STRING).description("Additional Description of item "),
                        fieldWithPath(prefix + "fromClinicCode").optional().type(JsonFieldType.STRING).description("When the PO is an intercompany PO, the from clinic code for this item")

                )
        );
        //fieldDescriptors.addAll(UomParameters(prefix,"uom"));
        fieldDescriptors.addAll(unitPriceParameters(prefix, "unitPrice"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> transferRequestItemParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix).description("Order item detail"),
                        fieldWithPath(prefix + "lineNo").description("line no of the order item"),
                        fieldWithPath(prefix + "itemRefId").description("Id of the order item"),
                        fieldWithPath(prefix + "supplierId").description("Id of the "),
                        fieldWithPath(prefix + "uom").type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + "quantity").description("Quantity of the item ")

                )
        );
        //fieldDescriptors.addAll(UomParameters(prefix,"uom"));
        fieldDescriptors.addAll(unitPriceParameters(prefix, "unitPrice"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodReceiveNoteParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + "id").optional().type(JsonFieldType.STRING).description("System generate id"),
                        //fieldWithPath(prefix).optional().type(JsonFieldType.ARRAY).description("Good Receive Note"),
                        fieldWithPath(prefix + "createDate").description("Date of create good receive note"),
                        fieldWithPath(prefix + "grnDate").description("Date of received items"),
                        fieldWithPath(prefix + "delivererId").description("Id of clinic that send items from"),
                        fieldWithPath(prefix + "receiverId").description("Id of clinic that receive items"),
                        fieldWithPath(prefix + "grnNo").description("Number of the GRN "),
                        fieldWithPath(prefix + "dnDate").description("Date of the delivery note "),
                        fieldWithPath(prefix + "dnNo").description("Number of the delivery note "),
                        fieldWithPath(prefix + "additionalRemark").optional().type(JsonFieldType.STRING).description("Addition remark"),
                        fieldWithPath(prefix + "status").description("Status[" + Arrays.toString(DeliveryNoteStatus.values()) + "]"),
                        fieldWithPath(prefix + "navIntegrationResult").optional().type(JsonFieldType.OBJECT).description("nav integration result"),
                        fieldWithPath(prefix + "navIntegrationResult.status").optional().type(JsonFieldType.STRING).description("nav integration result status")
                )
        );
        if (!prefix.equals("")) {
            prefix = prefix.substring(0, prefix.length() - 2);
        }
        fieldDescriptors.addAll(goodReceivedItem(prefix, "receivedItems[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodReceivedItem(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix).optional().type(JsonFieldType.ARRAY).description("Good Received items"),
                        fieldWithPath(prefix + "lineNo").description("Line no of the goodReceivedItem"),
                        fieldWithPath(prefix + "itemRefId").description("Id of the item"),
                        fieldWithPath(prefix + "uom").type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + "quantity").description("Quantity of the item received "),
                        fieldWithPath(prefix + "batchNumber").description("Batch number of the item"),
                        fieldWithPath(prefix + "expiryDate").optional().type(JsonFieldType.STRING).description("Expiry date of item"),
                        fieldWithPath(prefix + "manufacturerDate").optional().type(JsonFieldType.STRING).description("Manufacturer date of the item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "invoiceNo").optional().type(JsonFieldType.STRING).description("Invoice no of received item"),
                        fieldWithPath(prefix + "receiptDate").optional().type(JsonFieldType.STRING).description("Receipt date of the received item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "comment").optional().type(JsonFieldType.STRING).description("Comment of the item")
                )
        );
        //fieldDescriptors.addAll(UomParameters(prefix,"uom"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodReceiveVoidNoteParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + "id").optional().type(JsonFieldType.STRING).description("System generate id"),
                        fieldWithPath(prefix + "createDate").description("Date of create good receive void note"),
                        //fieldWithPath(prefix).optional().type(JsonFieldType.ARRAY).description("Good Receive Note"),
                        fieldWithPath(prefix + "grnVoidDate").optional().type(JsonFieldType.STRING).description("Date of submit good receive void note"),
                        fieldWithPath(prefix + "delivererId").description("Id of clinic that send items from"),
                        fieldWithPath(prefix + "receiverId").description("Id of clinic that receive items"),
                        fieldWithPath(prefix + "grnVoidNo").description("Number of the GRN "),
                        fieldWithPath(prefix + "additionalRemark").optional().type(JsonFieldType.STRING).description("Id of clinic inventory"),
                        fieldWithPath(prefix + "status").description("Status[" + Arrays.toString(DeliveryNoteStatus.values()) + "]"),
                        fieldWithPath(prefix + "navIntegrationResult").optional().type(JsonFieldType.OBJECT).description("nav integration result"),
                        fieldWithPath(prefix + "navIntegrationResult.status").optional().type(JsonFieldType.STRING).description("nav integration result status")
                )
        );

        fieldDescriptors.addAll(goodReturnItem(prefix, "returnItems[]"));
        fieldDescriptors.addAll(goodReceiveVoidDeliveryNoteParameters(prefix, "deliveryNotes[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodDeliveryNoteParameters(String... variableNames) {
        return goodReceiveVoidDeliveryNoteParameters(variableNames);
    }

    private static List<FieldDescriptor> goodReceiveVoidDeliveryNoteParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + "id").optional().type(JsonFieldType.STRING).description("System generate id"),
                        fieldWithPath(prefix + "delivererId").optional().type(JsonFieldType.STRING).description("Id of clinic that send items from"),
                        //fieldWithPath(prefix).optional().type(JsonFieldType.ARRAY).description("Good Receive Note"),
                        fieldWithPath(prefix + "receiverId").optional().type(JsonFieldType.STRING).description("Id of supplier that receive items"),
                        fieldWithPath(prefix + "dnNo").optional().type(JsonFieldType.STRING).description("Number of good receive void delivery note"),
                        fieldWithPath(prefix + "createDate").optional().type(JsonFieldType.STRING).description("Date of create good receive void delivery note"),
                        fieldWithPath(prefix + "sendDate").optional().type(JsonFieldType.STRING).description("Date of received item from supplier"),
                        //fieldWithPath(prefix+"deliveryItems[]").description("Id of clinic that receive items" ),
                        fieldWithPath(prefix + "additionalRemark").optional().type(JsonFieldType.STRING).optional().type(JsonFieldType.STRING).description("Id of clinic inventory"),
                        fieldWithPath(prefix + "status").optional().type(JsonFieldType.STRING).description("Status[" + Arrays.toString(DeliveryNoteStatus.values()) + "]"),
                        fieldWithPath(prefix + "navIntegrationResult").optional().type(JsonFieldType.OBJECT).description("nav integration result"),
                        fieldWithPath(prefix + "navIntegrationResult.status").optional().type(JsonFieldType.STRING).description("nav integration result status")
                )
        );

        fieldDescriptors.addAll(deliveryItemParameters(prefix, "transferSendItems[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> returnItemContainer(){
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>();
        fieldDescriptors.add(fieldWithPath("purchaseOrderId").optional().type(JsonFieldType.STRING).description("Id of purchase order"));
        fieldDescriptors.addAll(goodReturnItem("returnItems[]"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> goodReturnItem(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix).optional().type(JsonFieldType.ARRAY).description("Good Received items"),
                        fieldWithPath(prefix + "lineNo").description("line no of the goodReceivedItem"),
                        fieldWithPath(prefix + "itemRefId").optional().type(JsonFieldType.STRING).description("Id of the item"),
                        fieldWithPath(prefix + "uom").optional().type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + "quantity").optional().type(JsonFieldType.NUMBER).description("Quantity of the item return "),
                        fieldWithPath(prefix + "batchNumber").optional().type(JsonFieldType.STRING).description("Batch number of the item"),
                        fieldWithPath(prefix + "expiryDate").optional().type(JsonFieldType.STRING).description("Expiry date of the item"),
                        fieldWithPath(prefix + "manufacturerDate").optional().type(JsonFieldType.STRING).description("Manufacturer date of the item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "invoiceNo").optional().type(JsonFieldType.STRING).description("Invoice no of received item"),
                        fieldWithPath(prefix + "receiptDate").optional().type(JsonFieldType.STRING).description("Receipt date of the received item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "comment").optional().type(JsonFieldType.STRING).description("Comment of the item"),
                        fieldWithPath(prefix + "reasonCode").optional().type(JsonFieldType.STRING).description("Reason code of the return item")
                )
        );
        //fieldDescriptors.addAll(UomParameters(prefix,"uom"));
        fieldDescriptors.addAll(unitPriceParameters(prefix, "unitPrice"));
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> deliveryItemParameters(String... variableNames) {
        String prefix = "";
        if (variableNames != null && variableNames.length > 0) {
            prefix = Arrays.asList(variableNames).stream().collect(Collectors.joining("."));
            prefix += ".";
        }

        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath(prefix + "lineNo").description("Line no of the transferSendItem"),
                        fieldWithPath(prefix + "itemRefId").optional().type(JsonFieldType.STRING).description("Id of the item"),
                        fieldWithPath(prefix + "uom").optional().type(JsonFieldType.STRING).description("Code of the unit of measure"),
                        fieldWithPath(prefix + "quantity").optional().type(JsonFieldType.NUMBER).description("Quantity of the item will be sent "),
                        fieldWithPath(prefix + "batchNumber").optional().type(JsonFieldType.STRING).description("Batch number"),
                        fieldWithPath(prefix + "expiryDate").optional().type(JsonFieldType.STRING).description("Expiry date of the item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "manufacturerDate").optional().type(JsonFieldType.STRING).description("Manufacturer date of the item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "invoiceNo").optional().type(JsonFieldType.STRING).description("Invoice no of received item"),
                        fieldWithPath(prefix + "receiptDate").optional().type(JsonFieldType.STRING).description("Receipt date of the received item in format:" + CMSConstant.JSON_DATE_FORMAT),
                        fieldWithPath(prefix + "comment").optional().type(JsonFieldType.STRING).description("Comment of the delivery item")
                )
        );
        return fieldDescriptors;
    }

    private static List<FieldDescriptor> searchPurchaseReturnOrderContainer() {
        List<FieldDescriptor> fieldDescriptors = new ArrayList<>(
                Arrays.asList(
                        fieldWithPath("clinicId").description("Id of clinic"),
                        fieldWithPath("startDate").description("Start date of purchase return order's create date from"),
                        fieldWithPath("endDate").description("End date of purchase return order's create date to"),
                        fieldWithPath("filter").description("Filter criteria")
                )
        );
        return fieldDescriptors;
    }

    public static ResultHandler documentDeletePOGRN() {
        return document("delete-po-grn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the Purchase order"),
                        parameterWithName("grnId").description("Id of the GRN, only Failed GRNs will be deleted")
                ),
                responseAPI(false));
    }

    public static ResultHandler documentDeletePOGRVN() {
        return document("delete-po-grvn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the Purchase order, only Failed PROs will be deleted")
                ),
                responseAPI(false));
    }

    public static ResultHandler documentDeletePOGRVNDO() {
        return document("delete-po-grvn-do",
                pathParameters(
                        parameterWithName("orderId").description("Id of the return order, only Failed PROs will be deleted"),
                        parameterWithName("grvnDoId").description("Id of the PRO's DO, only Failed PRO's DO will be deleted")
                ),
                responseAPI(false));
    }

    public static ResultHandler documentDeleteTODo() {
        return document("delete-to-do",
                pathParameters(
                        parameterWithName("orderId").description("Id of the Purchase order"),
                        parameterWithName("dnId").description("Do Id  of Transfer order, only Failed DOs of TO will be deleted")

                ),
                responseAPI(false));
    }

    public static ResultHandler documentDeleteTOGRN() {
        return document("delete-to-grn",
                pathParameters(
                        parameterWithName("orderId").description("Id of the Purchase order"),
                        parameterWithName("grnId").description("GRN Id  of Transfer order, only Failed GRNs of TO will be deleted")

                ),
                responseAPI(false));
    }
}
