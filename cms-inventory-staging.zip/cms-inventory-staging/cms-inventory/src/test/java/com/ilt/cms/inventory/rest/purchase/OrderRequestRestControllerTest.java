package com.ilt.cms.inventory.rest.purchase;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.OrderRequestDocument;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.OrderRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestRepository;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.mock.*;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.repository.spring.ClinicRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static com.mongodb.client.model.Filters.eq;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"VIEW_ORDER_REQUEST"})
public class OrderRequestRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RequestRepository requestRepository;

    @MockBean
    private OrderDatabaseService orderDatabaseService;

    @MockBean
    private ClinicRepository clinicRepository;

    private Order transferOrder;

    private Order purchaseOrder;

    private Order returnOrder;

    private String purchaseOrderId;

    private String returnOrderId;


    @Before
    public void setup() throws Exception {
        purchaseOrderId = TestHelper.mockObjectId();
        returnOrderId = TestHelper.mockObjectId();
        purchaseOrder = MockOrder.mockPurchaseOrder();
        purchaseOrder.setId(purchaseOrderId);
        transferOrder = MockOrder.mockTransferOrder();
        returnOrder = MockOrder.mockReturnOrder(GoodReceivedReturnStatus.CONFIRM, purchaseOrderId);
        returnOrder.setId(returnOrderId);

        //when(requestRepository.findTransferRequest(any(Pageable.class))).thenReturn(Arrays.asList(MockTransferRequest.mockTransferRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED)));
        //when(requestRepository.findPurchaseRequest(any(Pageable.class))).thenReturn(Arrays.asList(MockPurchaseRequest.mockPurchaseRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED)));
        //when(requestRepository.findPurchaseRequestByClinicId(anyString(), any(Pageable.class))).thenReturn(Arrays.asList(MockPurchaseRequest.mockPurchaseRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED)));
        //when(requestRepository.findTransferRequestByClinicId(anyString(), any(Pageable.class))).thenReturn(Arrays.asList(MockTransferRequest.mockTransferRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED)));

        when(requestRepository.findAllByRequestClinicId(anyString(), any(Pageable.class))).thenReturn(Arrays.asList(MockPurchaseRequest.mockPurchaseRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED)));
        when(requestRepository.findAll(any(Pageable.class))).thenReturn(new PageImpl<>(Arrays.asList(MockPurchaseRequest.mockPurchaseRequest(TestHelper.mockObjectId(), RequestStatus.REQUESTED))));

        when(clinicRepository.findAll()).thenReturn(Arrays.asList(
                MockClinic.mockClinic("C023232", "ABSOLUTE MS PTE LTD"),
                MockClinic.mockClinic("S000212", "ABSOLUTE SS PTE LTD")
        ));
        when(clinicRepository.findByIdAndStatus(anyString(), any(Status.class))).thenAnswer(
                invocationOnMock -> {
                    String clinicId = invocationOnMock.getArgument(0);
                    Clinic clinic = MockClinic.mockClinic(clinicId, "BBTW clinic");
                    return Optional.of(clinic);
                }
        );
        when(orderDatabaseService.findReturnOrderByRequestClinicIdAndCreateDateAndReturnNumberAndRequestStatusIn(anyString(),
                anyString(), any(), any(), anyString(), anyList())).thenReturn(List.of(returnOrder));
        when(orderDatabaseService.findOrderByClinicIdOrClinicGroupName(anyString(), anyString())).thenReturn(List.of(transferOrder));
        when(orderDatabaseService.findOrderByIdsAndOrderType(anyList(), any(OrderType.class))).thenReturn(List.of(purchaseOrder));

    }

    @Test
    public void listOrderRequestList() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/order-request/list/{clinicId}/{page}/{size}", "4jn609lf4h3224343", 0, 10)
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        Map<OrderRequest.Filter, String> filterMap = new HashMap<>();
        filterMap.put(OrderRequest.Filter.CREATED_DATE_MORE, "31-12-2010");
        filterMap.put(OrderRequest.Filter.CREATED_DATE_LESS, "31-12-2021");

        TestHelper.httpRequestBuilder(requestBuilder, filterMap);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(OrderRequestDocument.documentListOrderRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listReturnOrder() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/order-request/list/return-order/{clinicId}/{page}/{size}", TestHelper.mockObjectId(), 0, 10)
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        SearchPurchaseReturnOrderContainer searchPurchaseReturnOrderContainer = new SearchPurchaseReturnOrderContainer(
                LocalDate.now(), LocalDate.now(), "APPROVED", "100001");
        TestHelper.httpRequestBuilder(requestBuilder, searchPurchaseReturnOrderContainer);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(OrderRequestDocument.documentListReturnOrder())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }
}
