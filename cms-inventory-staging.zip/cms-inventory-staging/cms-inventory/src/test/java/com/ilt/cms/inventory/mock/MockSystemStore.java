package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.system.SystemStore;
import com.ilt.cms.inventory.svc.model.common.Reason;

import java.util.Arrays;

public class MockSystemStore {

    public static SystemStore mockReturnOrderSystemStore(String key){
        SystemStore systemStore = new SystemStore();
        systemStore.setKey(key);
        systemStore.setValues(Arrays.asList(new Reason("01", "Wrong Qty During Transfer", "Wrong Qty During Transfer")));
        return systemStore;
    }

    public static SystemStore mockStockCountReasonSystemStore(String key){
        SystemStore systemStore = new SystemStore();
        systemStore.setKey(key);
        systemStore.setValues(Arrays.asList(new Reason("030", "Manufacturing Defects", "Manufacturing Defects")));
        return systemStore;
    }
}
