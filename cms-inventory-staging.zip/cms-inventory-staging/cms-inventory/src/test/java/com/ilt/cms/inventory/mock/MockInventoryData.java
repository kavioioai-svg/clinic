package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.billing.ItemChargeDetail;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class MockInventoryData {

    public static ItemChargeDetail.ItemChargeDetailResponse.InventoryData mockInventoryData(String batchNo, LocalDate expireDate, int inventoryDetailId, int inventoryId, String clinicId,
                                                                                            int chargeId, double quantityTotal, double amount, double itemAmount, double itemCost,
                                                                                            double remainingQuantity, double remainingAmount, LocalDateTime createdAt, int createdUserId,
                                                                                            LocalDateTime updatedAt, int updatedUserId, String drugCode, double totalQuantity, double totalAmount,
                                                                                            double cost, boolean mixingFlag, String itemId, int inventoryUsageIndex, int patientRegisterDetailId,
                                                                                            String baseUom, String saleUom, String purchaseUom, int baseUomQuantity, Double saleUomQuantity,
                                                                                            double purchaseUomQuantity) {

        ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData = new ItemChargeDetail.ItemChargeDetailResponse.InventoryData(
                batchNo, expireDate, inventoryDetailId, inventoryId, clinicId,
                chargeId, quantityTotal, amount, itemAmount, itemCost,
                remainingQuantity, remainingAmount, createdAt, createdUserId,
                updatedAt, updatedUserId, drugCode, totalQuantity, totalAmount,
                cost, mixingFlag, itemId, inventoryUsageIndex, patientRegisterDetailId,
                baseUom, saleUom, purchaseUom, baseUomQuantity, saleUomQuantity,
                purchaseUomQuantity);

        return inventoryData;
    }

    public static ItemChargeDetail.ItemChargeDetailResponse.InventoryData mockInventoryData(String clinicId, String itemId, String drugCode, String batchNo, double quantity) {
        return mockInventoryData(batchNo, LocalDate.now().plusYears(3), 299484, 435435, clinicId,
                39030, 100, 10, 10, 10,
                quantity, quantity * 10, LocalDateTime.now(), 0,
                LocalDateTime.now(), 0, drugCode, 100, 10,
                10, false, itemId, 0, 0,
                "TABLET", "TABLET", "TABLET", new BigDecimal(quantity).intValue(), quantity,
                quantity);
    }
}
