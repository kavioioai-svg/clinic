package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.common.CorporateAddress;
import com.ilt.cms.core.entity.item.Cost;
import com.ilt.cms.core.entity.supplier.MinPurchaseAmount;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.core.entity.supplier.Supplier;

import java.util.Arrays;
import java.util.List;

public class MockSupplier {

    public static Supplier mockSupplier(String id, String name, String supplierNo, CorporateAddress address, List<ContactPerson> contacts, List<MinPurchaseAmount> minPurchaseAmounts,
                                        Status status, List<PurchaseItem> items) {

        Supplier supplier = new Supplier(name, address, contacts, minPurchaseAmounts, status, items, supplierNo);
        supplier.setId(id);
        return supplier;
    }

    public static Supplier mockSupplier() {
        return mockSupplier("S0001", "INITECH", "S0001", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                        "   10 Eunos Road 8\n" +
                        "   #05-33 Singapore Post Centre\n" +
                        "   Singapore 408600\n" +
                        "   REPUBLIC OF SINGAPORE", "546080"),
                Arrays.asList(new ContactPerson("Mr. Wong", "Sale manager", "12345678",
                        "98765432", "3839938323", "test@test.com", false)),
                Arrays.asList(new MinPurchaseAmount("398fj38jfjc9", false, 1000)),
                Status.ACTIVE,
                Arrays.asList(new PurchaseItem("j23hjk32992jkjlaaa", 5, new Cost(100, false), Status.ACTIVE),
                        new PurchaseItem("797776e7c8cffb4b8dfe3c8086c4f042", 5, new Cost(100, false), Status.ACTIVE)));
    }
}
