package com.ilt.cms.inventory.mock;

import com.ilt.cms.core.entity.file.FileMetaData;
import com.ilt.cms.inventory.svc.model.purchase.api.FileDowload;

import java.time.LocalDateTime;

public class MockFileManagement {

    public static FileMetaData mockFullFileMetaData(){
        FileMetaData fileMetaData = new FileMetaData("cGF0aWVudC12aXNpdC8yMDE5LzVjODBjNGRlNTY5NmM0NmNhYzI3YzA3Mi85OTIyNzAzNTQwNTE0MTUxNjcxNTUzODMxNzc0NzE5MTAwMDAy",
                "file_name3","file_name3.jpg","ms_chan", "399004883", ".docx", 1000000, "", LocalDateTime.MAX);
        return fileMetaData;
    }

    public static FileMetaData mockFileMetaData(){
        FileMetaData fileMetaData = new FileMetaData("file_name3", "file_name3.jpg", "ms_chan", "399004883", "test", LocalDateTime.MAX);
        return fileMetaData;
    }

    public static FileDowload mockFileDowloadData(){
        FileDowload fileDowload = new FileDowload("test", null);
        return fileDowload;
    }
}
