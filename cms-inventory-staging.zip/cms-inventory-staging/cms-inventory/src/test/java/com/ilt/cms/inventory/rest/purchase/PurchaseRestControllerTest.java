package com.ilt.cms.inventory.rest.purchase;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.common.CorporateAddress;
import com.ilt.cms.core.entity.item.ClinicItemMaster;
import com.ilt.cms.core.entity.item.ClinicItemMaster.ClinicItemPrice;
import com.ilt.cms.core.entity.item.Cost;
import com.ilt.cms.core.entity.item.DrugItem;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.supplier.MinPurchaseAmount;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.db.service.MongoRunningNumberService;
import com.ilt.cms.inventory.SpringTestControllerConfiguration;
import com.ilt.cms.inventory.apidoc.PurchaseDocument;
import com.ilt.cms.inventory.helper.TestHelper;
import com.ilt.cms.inventory.mock.*;
import com.ilt.cms.inventory.model.ReturnItemContainer;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.OrderRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestRepository;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.purchase.GoodReturnItem;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.inventory.svc.service.nav.InventoryService;
import com.ilt.cms.repository.spring.*;
import com.ilt.cms.repository.spring.system.SystemStoreRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.restdocs.mockmvc.RestDocumentationRequestBuilders;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
@Import(SpringTestControllerConfiguration.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@WithMockUser(username = "DR02", roles = {"NAV", "PURCHASE_NAV"})
public class PurchaseRestControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private RequestRepository requestRepository;

    @MockBean
    private OrderRepository orderRepository;

    @MockBean
    private UomMatrixRepository uomMatrixRepository;

//    @MockBean
//    private UomRepository uomRepository;

    @MockBean
    private LocationRepository locationRepository;

    @MockBean
    private ItemRepository itemRepository;

    @MockBean
    private ClinicRepository clinicRepository;

    @MockBean
    private SupplierRepository supplierRepository;

    @MockBean
    private SystemStoreRepository systemStoreRepository;

    @MockBean
    private MongoRunningNumberService mongoRunningNumberService;

    @MockBean
    private ClinicItemMasterRepository clinicItemMasterRepository;

    @MockBean
    private ClinicGroupItemMasterRepository clinicGroupItemMasterRepository;

    @MockBean
    private ItemClinicDetailRepository itemClinicDetailRepository;

    @MockBean
    private InventoryService inventoryService;

    private String draftRequestId;

    private String requestedRequestId;

    private String approveRequestId;

    private String completedRequestId;

    private String purchaseOrderId;

    private String transferOrderId;

    private String draftReturnOrderId;

    private String requestedReturnOrderId;

    private String approveReturnOrderId;

    private String requestClinicId;


    @Before
    public void setup() throws Exception {

        requestClinicId = TestHelper.mockObjectId();
        draftRequestId = TestHelper.mockObjectId();
        requestedRequestId = TestHelper.mockObjectId();
        approveRequestId = TestHelper.mockObjectId();
        completedRequestId = "R00001";
        purchaseOrderId = TestHelper.mockObjectId();
        transferOrderId = TestHelper.mockObjectId();
        draftReturnOrderId = TestHelper.mockObjectId();
        requestedReturnOrderId = TestHelper.mockObjectId();
        approveReturnOrderId = TestHelper.mockObjectId();

        when(supplierRepository.findByIdIn(anyList())).thenReturn(Arrays.asList(
                MockSupplier.mockSupplier("S00001", "INITECH", "INIT1", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                "   10 Eunos Road 8\n" +
                                "   #05-33 Singapore Post Centre\n" +
                                "   Singapore 408600\n" +
                                "   REPUBLIC OF SINGAPORE", "546080"),
                        Arrays.asList(new ContactPerson("Mr. Wong", "Sale manager", "12345678",
                                "98765432", "3839938323", "test@test.com", false)),
                        Arrays.asList(new MinPurchaseAmount("jduijnj328jend8", false, 1000)),
                        Status.ACTIVE,
                        Arrays.asList(new PurchaseItem("22k32e30023223", 500, new Cost(100, false), Status.ACTIVE),
                                new PurchaseItem("434kknd99433n43", 5, new Cost(100, false), Status.ACTIVE))),
                MockSupplier.mockSupplier("S00002", "INITECH", "INIT2", new CorporateAddress("Dr. Xing", "Singapore Post Pte Ltd\n" +
                                "   10 Eunos Road 8\n" +
                                "   #05-33 Singapore Post Centre\n" +
                                "   Singapore 408600\n" +
                                "   REPUBLIC OF SINGAPORE", "546080"),
                        Arrays.asList(new ContactPerson("Mr. Wong", "Sale manager", "12345678",
                                "98765432", "3839938323", "test@test.com", false)),
                        Arrays.asList(new MinPurchaseAmount("jduijnj328jend8", false, 1000)),
                        Status.ACTIVE, Arrays.asList(new PurchaseItem("cjdidi99df3km4", 5, new Cost(100, false), Status.ACTIVE)))
                )
        );
        when(requestRepository.findAll(any(Sort.class))).thenReturn(Arrays.asList(MockPurchaseRequest.mockPurchaseRequest(TestHelper.mockObjectId(), RequestStatus.DRAFT)));
        when(requestRepository.save(any(PurchaseRequest.class))).thenAnswer(
                invocationOnMock -> {
                    PurchaseRequest purchaseRequest = invocationOnMock.getArgument(0);
                    Field id = PersistedObject.class.getDeclaredField("id");
                    id.setAccessible(true);
                    id.set(purchaseRequest, TestHelper.mockObjectId());
                    return purchaseRequest;
                }
        );
        when(requestRepository.findById(draftRequestId)).thenAnswer(
                invocationOnMock -> {
                    String requestId = invocationOnMock.getArgument(0);
                    PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(requestId, RequestStatus.DRAFT);

                    return Optional.of(purchaseRequest);
                }
        );
        when(requestRepository.findById(requestedRequestId)).thenAnswer(
                invocationOnMock -> {
                    String requestId = invocationOnMock.getArgument(0);
                    PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(requestId, RequestStatus.REQUESTED);

                    return Optional.of(purchaseRequest);
                }
        );
        when(requestRepository.findById(approveRequestId)).thenAnswer(
                invocationOnMock -> {
                    String requestId = invocationOnMock.getArgument(0);
                    PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(requestId, RequestStatus.APPROVED);

                    return Optional.of(purchaseRequest);
                }
        );
        when(requestRepository.findById(completedRequestId)).thenAnswer(
                invocationOnMock -> {
                    String requestId = invocationOnMock.getArgument(0);
                    PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(requestId, RequestStatus.APPROVED);

                    return Optional.of(purchaseRequest);
                }
        );
        when(orderRepository.findAll(any(Sort.class))).thenReturn(Arrays.asList(MockOrder.mockPurchaseOrder()));
        when(orderRepository.save(any(Order.class))).thenAnswer(
                invocationOnMock -> {
                    Order order = invocationOnMock.getArgument(0);
                    if (order.getId() == null) {
                        order.setId(TestHelper.mockObjectId());
                    }
                    return order;
                }
        );
        when(orderRepository.findById(purchaseOrderId)).thenReturn(Optional.of(MockOrder.mockPurchaseOrder()));
        when(orderRepository.findById(transferOrderId)).thenReturn(Optional.of(MockOrder.mockTransferOrder()));
        when(orderRepository.findById(requestedReturnOrderId)).thenReturn(Optional.of(MockOrder.mockReturnOrder(GoodReceivedReturnStatus.CONFIRM, purchaseOrderId)));
        when(orderRepository.findById(approveReturnOrderId)).thenReturn(Optional.of(MockOrder.mockReturnOrder(GoodReceivedReturnStatus.APPROVED, purchaseOrderId)));
        when(orderRepository.findById(draftReturnOrderId)).thenReturn(Optional.of(MockOrder.mockReturnOrder(GoodReceivedReturnStatus.DRAFT, purchaseOrderId)));
        when(orderRepository.findPurchaseOrderByRequestClinicIdGoodReceivedVoidNotesCreateDateBetween(anyString(),
                anyString(), any(LocalDateTime.class), any(LocalDateTime.class), any(Pageable.class))).thenReturn(
                Arrays.asList(MockOrder.mockPurchaseOrder())
        );
        when(orderRepository.findAllByRequestClinicIdOrClinicFilterClinicsInOrClinicFilterClinicGroupName(anyString(), anyList(), anyString(), any(Pageable.class))).thenReturn(
                Arrays.asList(MockOrder.mockTransferOrder())
        );
        when(orderRepository.findAllByIdInAndOrderType(anyList(), any(OrderType.class))).thenReturn(List.of(MockOrder.mockPurchaseOrder(purchaseOrderId)));
        Map<String, BigDecimal> map = new HashMap<>();
        map.put("BOX", new BigDecimal(2));
        map.put("TABLET", new BigDecimal(1));
        when(uomMatrixRepository.findByUomCode(anyString())).thenReturn(Optional.of(MockUOMMatrix.mockUOMMatrix("TABLET", map)));

        when(mongoRunningNumberService.generateOrderNumber()).thenReturn("12345678");
        when(mongoRunningNumberService.generateRequestNumber()).thenReturn("12345678");
        when(mongoRunningNumberService.generateDeliveryNote()).thenReturn("3225678");
        when(mongoRunningNumberService.generateGRNNumber()).thenReturn("9876543");
        when(itemRepository.findById(anyString())).thenReturn(Optional.of(MockDrugItem.mockDrugItem(Arrays.asList(draftRequestId, requestedRequestId))));
        when(itemRepository.findAllById(anyList())).thenAnswer(invocationOnMock -> {
            List<String> itemIds = invocationOnMock.getArgument(0);
            List<Item> items = new ArrayList<>();
            itemIds.forEach(
                    id -> {
                        Item item = MockDrugItem.mockDrugItem(Arrays.asList(draftRequestId, requestedRequestId));
                        Field idField = null;
                        try {
                            idField = PersistedObject.class.getDeclaredField("id");
                            idField.setAccessible(true);
                            idField.set(item, id);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        items.add(item);
                    }
            );
            return items;

        });
        when(locationRepository.findByClinicId(anyString())).thenReturn(Optional.of(MockLocation.mockLocation()));
        when(locationRepository.findById(anyString())).thenReturn(Optional.of(MockLocation.mockLocation()));
//        when(uomRepository.findByCode(anyString())).thenAnswer(invocationOnMock -> {
//            String uomCode = invocationOnMock.getArgument(0);
//            return Optional.of(new UOMMaster(uomCode, uomCode));
//        });
        when(uomMatrixRepository.save(any())).thenReturn(MockUOMMatrix.mockUOMMatrix());
        when(clinicRepository.findById(anyString())).thenAnswer(
                invocationOnMock -> {
                    String clinicId = invocationOnMock.getArgument(0);
                    Clinic clinic = MockClinic.mockClinic(clinicId, "BBTW Clinic");
                    return Optional.of(clinic);
                }
        );
        when(clinicRepository.findByIdAndStatus(anyString(), any(Status.class))).thenAnswer(
                invocationOnMock -> {
                    String clinicId = invocationOnMock.getArgument(0);
                    Clinic clinic = MockClinic.mockClinic(clinicId, "BBTW Clinic");
                    return Optional.of(clinic);
                }
        );
        when(systemStoreRepository.findByKey(anyString()))
                .thenReturn(Optional.of(MockSystemStore.mockReturnOrderSystemStore("RETURN_REASON_CODE")));
        when(itemRepository.findAllActive()).thenAnswer(invocationOnMock -> {
            DrugItem item1 = MockDrugItem.mockDrugItem(Arrays.asList(draftRequestId, requestedRequestId));
            item1.setId("22k32e30023223");
            item1.setName("Drug 1");
            DrugItem item2 = MockDrugItem.mockDrugItem(Arrays.asList(draftRequestId, requestedRequestId));
            item2.setId("434kknd99433n43");
            item2.setName("Drug 2");
            return Arrays.asList(item1, item2);
        });
        when(clinicItemMasterRepository.findByClinicIdIn(anyList())).thenReturn(List.of(mockClinicItems("C023232")));
        when(supplierRepository.findById(anyString())).thenReturn(
                Optional.of(MockSupplier.mockSupplier())
        );

        when(itemClinicDetailRepository.findByClinicDetailsClinicIdAndItemRefIdIn(anyString(), anyList())).thenAnswer(
                invocationOnMock -> {
                    List<String> itemIds = invocationOnMock.getArgument(1);
                    return List.of(MockItemClinicDetail.mockItemClinicDetail(itemIds.get(0)));
                }
        );
        when(itemClinicDetailRepository.findByItemRefId(anyString())).thenAnswer(
                invocationOnMock -> {
                    String itemId = invocationOnMock.getArgument(0);
                    return Optional.of(MockItemClinicDetail.mockItemClinicDetail("C023232", itemId));
                }
        );
        when(inventoryService.fireNavInventoryApi(anyString(), anyList())).thenReturn(List.of(
                MockInventoryData.mockInventoryData(requestClinicId, "299232l2j3h223", "ITEM_001", "Batch_001", 100)
        ));
    }

    private static ClinicItemMaster mockClinicItems(String clinicItemId) {
        ClinicItemMaster clinicItem = new ClinicItemMaster();
        clinicItem.setId(clinicItemId);
        clinicItem.setClinicId(clinicItemId);
        clinicItem.setItemsForClinic(
                List.of(new ClinicItemPrice("22k32e30023223", new BigDecimal(10.0f)), new ClinicItemPrice("434kknd99433n43", new BigDecimal(20.0f))));
        return clinicItem;
    }

    @Test
    public void findRequestById() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/get/request/{requestId}", draftRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentFindRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findOrderById() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/get/order/{orderId}", purchaseOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentFindOrder())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void findReturnOrderById() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/get/grvn/{orderId}", requestedReturnOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentFindReturnOrder())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void createRequest() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/create/request")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockPurchaseRequest.mockPurchaseRequest(null, RequestStatus.REQUESTED));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void modifyRequest() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/update/request/{requestId}", draftRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockPurchaseRequest.mockPurchaseRequest(draftRequestId, RequestStatus.DRAFT));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentUpdateRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void approveRequest() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/approve/request/{requestId}", requestedRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(null, RequestStatus.REQUESTED);

        TestHelper.httpRequestBuilder(requestBuilder, purchaseRequest);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentApproveRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void rejectRequest() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/reject/request/{requestId}", requestedRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentRejectRequest())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }


    @Test
    public void createPurchaseOrderByRequest() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/create/order/{requestId}", approveRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, Arrays.asList(MockOrder.mockBasicPurchaseOrder()));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateOrderByRequestId())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void addGoodReceivedNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/add/grn/{orderId}", purchaseOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockGoodReceivedNote(null, LocalDate.now(),
                LocalDate.now(), TestHelper.mockObjectId(), TestHelper.mockObjectId(), "100000303", LocalDate.now(), TestHelper.mockObjectId(), "Item received", DeliveryNoteStatus.DRAFT));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentAddGRN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void updateGoodReceivedNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/update/grn/{orderId}/{grnId}", purchaseOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockGoodReceivedNote("02", LocalDate.now(),
                LocalDate.now(), TestHelper.mockObjectId(), TestHelper.mockObjectId(), "00232", LocalDate.now(), TestHelper.mockObjectId(), "Item received", DeliveryNoteStatus.CONFIRM));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentUpdateGRN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void addReturnOrder() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/add/grvn/{requestClinicId}/{supplierId}/{returnOrderStatus}", TestHelper.mockObjectId(), TestHelper.mockObjectId(), GoodReceivedReturnStatus.CONFIRM)
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        ReturnItemContainer returnItemContainer = new ReturnItemContainer(purchaseOrderId, List.of(MockOrder.mockGoodReturnItem("10000", "299232l2j3h223", "TABLET",
                "Batch_001", 40, LocalDate.now(), "INV_102930", LocalDate.now().plusYears(3),
                LocalDate.now(), "Condition not good")));
        TestHelper.httpRequestBuilder(requestBuilder, returnItemContainer);


        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentAddGRVN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void updateReturnOrder() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/update/grvn/{orderId}/{supplierId}/{returnOrderStatus}", draftReturnOrderId, TestHelper.mockObjectId(), GoodReceivedReturnStatus.CONFIRM)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        ReturnItemContainer returnItemContainer = new ReturnItemContainer(null, List.of(MockOrder.mockGoodReturnItem("10000", "299232l2j3h223", "TABLET",
                "Batch_001", 40, LocalDate.now(), "INV_102930", LocalDate.now().plusYears(3),
                LocalDate.now(), "Condition not good")));

        TestHelper.httpRequestBuilder(requestBuilder, returnItemContainer);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentUpdateGRVN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void approveReturnOrder() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/approve/grvn/{orderId}", requestedReturnOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        List<GoodReturnItem> goodReturnItems = Arrays.asList(
                MockOrder.mockGoodReturnItem("5782993l332j3", "299232l2j3h223", "BOX", "D-2322", 10,
                        LocalDate.of(2020, 12, 31), "INV-00001",
                        LocalDate.of(2020, 12, 31), LocalDate.of(2020, 12, 31),
                        "Drug is received"),
                MockOrder.mockGoodReturnItem("9dkki309m32003", "2993j493k23j332", "BOX", "SU-2999", 10,
                        LocalDate.of(2020, 12, 31), "INV-00002",
                        LocalDate.of(2020, 12, 31), LocalDate.of(2020, 12, 31),
                        "Condition not good")
        );

        TestHelper.httpRequestBuilder(requestBuilder, goodReturnItems);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentApproveGRVN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void rejectGoodReceivedVoidNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/reject/grvn/{orderId}",
                        requestedReturnOrderId, "02")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentRejectGRVN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void addGoodReceivedVoidDeliveryNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/add/grvdn/{orderId}", approveReturnOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockDeliveryNote(null, TestHelper.mockObjectId(), TestHelper.mockObjectId(),
                LocalDate.now(), LocalDate.now(), "3333", DeliveryNoteStatus.CONFIRM));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentAddGRVDN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void updateGoodReceivedVoidDeliveryNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/update/grvdn/{orderId}/{grvndnId}", approveReturnOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockDeliveryNote("02", TestHelper.mockObjectId(), TestHelper.mockObjectId(),
                LocalDate.now(), LocalDate.now(), "3333", DeliveryNoteStatus.CONFIRM));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentUpdateGRVDN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void addDeliveryNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/add/dn/{orderId}", transferOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockDeliveryNote(null, TestHelper.mockObjectId(), TestHelper.mockObjectId(),
                LocalDate.now(), LocalDate.now(), "3333", DeliveryNoteStatus.CONFIRM));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentAddDN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void updateDeliveryNote() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/update/dn/{orderId}/{dnId}", transferOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, MockOrder.mockDeliveryNote("01", TestHelper.mockObjectId(), TestHelper.mockObjectId(),
                LocalDate.now(), LocalDate.now(), "3333", DeliveryNoteStatus.CONFIRM));

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentUpdateDN())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listReturnOrderReason() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/list/grvn/reason")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());


        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentListReturnOrderReason())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void listItemClinicDetail() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/list/item-clinic-detail/{clinicId}", "C-000001")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentListItemClinicDetail())
                .andExpect(status().isOk())
                .andReturn();
        MockHttpServletResponse response = result.getResponse();
    }

    @Test
    public void retryCreateNavPurchaseRequest() throws Exception {

        when(requestRepository.findById(requestedRequestId)).thenAnswer(
                invocationOnMock -> {
                    String requestId = invocationOnMock.getArgument(0);
                    PurchaseRequest purchaseRequest = MockPurchaseRequest.mockPurchaseRequest(requestId, RequestStatus.REQUESTED);
                    purchaseRequest.setNavIntegrationResult(new NavIntegrationResult("Failed", NavIntegrationResult.ResultStatus.FAILED));
                    return Optional.of(purchaseRequest);
                }
        );

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/request/{clinicId}/{requestId}", "C-000001", requestedRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavPurchaseRequest())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retryCreateNavPurchaseGoodReceivedNote() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/grn/{clinicId}/{orderId}/{grnId}", "C-000001", purchaseOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavPurchaseGoodReceivedNote())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retryCreateNavReturnOrder() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/grvn/{clinicId}/{orderId}", "C-000001", requestedReturnOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavReturnOrder())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retryCreateNavReturnDeliveryNote() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/grvdn/{clinicId}/{orderId}/{doId}", "C-000001", approveReturnOrderId, "01", "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavReturnDeliveryNote())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retryCreateNavTransferGoodReceivedNote() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/transfer-grn/{clinicId}/{orderId}/{grnId}", "C-000001", transferOrderId, "03")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavTransferGoodReceivedNote())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void retryCreateNavDeliveryNote() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/retry/nav/do/{clinicId}/{orderId}/{doId}", "C-000001", transferOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        TestHelper.httpRequestBuilder(requestBuilder, null);

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentCreateNavDeliveryNote())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void deletePurchaseRequest() throws Exception {

        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/request/{requestId}", draftRequestId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeleteRequest())
                .andExpect(status().isOk())
                .andReturn();
    }


    @Test
    public void deletePoGRN() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/grn/{orderId}/{grnId}", purchaseOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeletePOGRN())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void deletePoGRVN() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/grvn/{orderId}", requestedReturnOrderId)
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeletePOGRVN())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void deletePoGRVNDO() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/grvn/do/{orderId}/{grvnDoId}", approveReturnOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeletePOGRVNDO())
                .andExpect(status().isOk())
                .andReturn();
    }


    @Test
    public void deleteToDO() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/transfer/{orderId}/{dnId}", transferOrderId, "01")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeleteTODo())
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void deleteToGRN() throws Exception {
        MockHttpServletRequestBuilder requestBuilder =
                RestDocumentationRequestBuilders.post("/purchase/delete/transfer/grn/{orderId}/{grnId}", transferOrderId, "03")
                        .header("X-Tenant","HMC_555b5f65e8041214de5f")
                        .header("Authorization", TestHelper.TOKEN).with(csrf());

        MvcResult result = mockMvc.perform(requestBuilder)
                .andDo(PurchaseDocument.documentDeleteTOGRN())
                .andExpect(status().isOk())
                .andReturn();
    }
}
