package com.ilt.cms.inventory.rest.inventory;

import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.util.List;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/inventory-item-usage")
public class ItemUsageRestController {
    private static final Logger logger = LoggerFactory.getLogger(ItemUsageRestController.class);

    private LocationService locationService;

    public ItemUsageRestController(LocationService locationService) {
        this.locationService = locationService;
    }

    @PostMapping("/update/{clinicId}/{visitId}")
    HttpEntity<ApiResponse> updateItemUsage(@PathVariable("clinicId") String clinicId, @PathVariable("visitId") String visitId, @RequestBody List<InventoryUsage> usages) {

        try {
            logger.info("Updating inventory usage for clinic id [" + clinicId + "]");
            locationService.updateItemUsage(usages, clinicId, visitId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Updating inventory usage threw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

}
