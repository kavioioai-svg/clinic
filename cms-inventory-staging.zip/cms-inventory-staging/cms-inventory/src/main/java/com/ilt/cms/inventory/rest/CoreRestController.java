package com.ilt.cms.inventory.rest;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/core")
public class CoreRestController {

    private ClinicRepository clinicRepository;
    public CoreRestController(ClinicRepository clinicRepository) {
        this.clinicRepository = clinicRepository;
    }

    @PostMapping("/clinics/list")
    public HttpEntity<ApiResponse> getClinicList() throws CMSException {
        List<Clinic> clinics = this.clinicRepository.findActiveClinics();
        return httpApiResponse(new HttpApiResponse(clinics));
    }
}
