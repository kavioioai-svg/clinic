package com.ilt.cms.inventory.util;

import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.model.ApiInventory;
import com.ilt.cms.inventory.model.ItemInventory;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.util.HttpUtils;
import org.apache.poi.hssf.usermodel.HSSFPrintSetup;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ExcelExportService {

    private static final Logger logger = LoggerFactory.getLogger(ExcelExportService.class);
    private int noOfColumns;
    private static final float DEFAULT_CHARACTER_WIDTH = 7.001699924468994f;

    public  ResponseEntity<byte[]> generateInventoryExcel(String clinicCode, List<ItemInventory> itemInventories, List<Item> itemList) throws CMSException {
        logger.info("Start Generating inventory Excel");
        LinkedMultiValueMap<String, String> headers = HttpUtils.generateFileDownloadResponseHeader("CURRENT_STOCK_OF_" +clinicCode+"_" + System.currentTimeMillis() + ".xlsx");
        logger.error("inventory excel create file headers : [{}]", headers);

        byte[] inventoryReport = generateinventoryExcel(itemInventories, itemList);
        return new ResponseEntity<>(inventoryReport, headers, HttpStatus.OK);
    }

    private  byte[] generateinventoryExcel(List<ItemInventory> itemInventories, List<Item> itemList) throws CMSException{
        Workbook workbook = new SXSSFWorkbook(20000);
        long start = System.currentTimeMillis();
        logger.info("Processing data to generate excel report...");
        Font boldFont = setBoldFont(workbook);
        Font normalFont = setNormalFont(workbook);
        CreationHelper workbookHelper = workbook.getCreationHelper();

        CellStyle headerStyle = setHeaderCellStyle(workbook, boldFont, HorizontalAlignment.CENTER);
        CellStyle headerStyleLeftAlign = setHeaderCellStyle(workbook, boldFont, HorizontalAlignment.LEFT);
        CellStyle normalTextStyle = setBorderedTextCellStyle(workbook, normalFont);
        CellStyle normalStyleWithBackground = setBorderedTextCellWithBackGroundStyle(workbook, normalFont);
        CellStyle currencyStyle = setBorderedDoubleCellStyle(workbook, normalFont);
        CellStyle boldCurrencyWithBackgroundStyle = setBoldedBorderedDoubleCellStyle(workbook, boldFont);
        CellStyle dateStyle = setDateCellStyle(workbook, normalFont, workbookHelper);
        CellStyle normalNumberStyleRightAligned = setNumberTextCellStyleRightAligned(workbook, normalFont, workbookHelper);

        Sheet sheet = setupSheet(workbook);
        AtomicInteger rowCount = new AtomicInteger();

        Row headerRow = sheet.createRow(rowCount.get());
        createHeaderRow(headerRow, sheet, headerStyle);

        itemInventories.forEach(itemInventory -> {
            itemInventory.getInventories().forEach(inventory -> {
                Row row = sheet.createRow(rowCount.incrementAndGet());
                Optional<Item> item = itemList
                        .stream()
                        .filter(origin -> origin.getId().equals(inventory.getItemRefId()))
                        .findFirst();
                double itemPrice= (item.isPresent() && item.get().getSellingPrice() != null &&  item.get().getSellingPrice().getPrice() != null) ? item.get().getSellingPrice().getPrice().doubleValue() : 0;
                setUpDataRows(itemInventory, inventory , itemPrice , row, normalTextStyle, currencyStyle, dateStyle, normalNumberStyleRightAligned);
            });

        });
        autoSizeColumns(workbook);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            workbook.write(bos);
        } catch (IOException e) {
            logger.error("Error on excel workbook preparing ", e);
        }
        logger.info("Worksheet generated [" + rowCount.get() + "] records in [" + processTime(start) + "] seconds");
        return bos.toByteArray();
    }

    private void createHeaderRow(Row firstHeaderRrow,Sheet sheet, CellStyle cellStyle) {
        String[] titles = new String[]{"Item Code", "Item Name", "Batch No", "Expiry Date", "Total/Batch Qty", "Avg Utilization", "Unit Sales price", "Unit Cost price", "Total Cost price", "UOM", "Remarks"};

        for (int i = 0; i < titles.length; i++) {
            Cell cell = setUpCell(cellStyle, firstHeaderRrow, i);
            cell.setCellValue(titles[i]);
        }
        noOfColumns = titles.length;
    }

    private void setUpDataRows(ItemInventory itemInventory, ApiInventory inventory, double itemPrice, Row row, CellStyle normalTextStyle, CellStyle currencyStyle, CellStyle dateStyle, CellStyle number) {
        int colNumber = 0;
        Cell cell = setUpCell(normalTextStyle, row, colNumber);
        cell.setCellValue(inventory.getItemCode());
        colNumber++;
        cell = setUpCell(normalTextStyle, row, colNumber);
        cell.setCellValue(inventory.getItemName());
        colNumber++;
        cell = setUpCell(normalTextStyle, row, colNumber);
        cell.setCellValue(inventory.getBatchNumber());
        colNumber++;
        cell = setUpCell(dateStyle, row, colNumber);
        cell.setCellValue(inventory.getExpiryDate() != null ? java.util.Date.from(inventory.getExpiryDate().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()) : null);
        colNumber++;
        cell = setUpCell(number, row, colNumber);
        cell.setCellValue(inventory.getAvailableCount());
        colNumber++;
        cell = setUpCell(number, row, colNumber);
        cell.setCellValue(itemInventory.getReorderPoint());
        colNumber++;
        cell = setUpCell(currencyStyle, row, colNumber);
        cell.setCellValue(itemPrice);
        colNumber++;
        cell = setUpCell(currencyStyle, row, colNumber);
        cell.setCellValue(inventory.getPurchasePrice() != null ? inventory.getPurchasePrice().doubleValue() : 0);
        colNumber++;
        cell = setUpCell(currencyStyle, row, colNumber);
        cell.setCellValue(inventory.getPurchasePrice() != null ? (inventory.getPurchasePrice().doubleValue() * inventory.getAvailableCount()) : 0);
        colNumber++;
        cell = setUpCell(normalTextStyle, row, colNumber);
        cell.setCellValue(inventory.getBaseUom());
        colNumber++;

        String remark = inventory.getExpiryDate() != null ? inventory.getExpiryDate().isBefore(LocalDate.now()) ? "Expired" : "" : "";
        cell = setUpCell(normalTextStyle, row, colNumber);
        cell.setCellValue(remark);
        colNumber++;

    }

    private void autoSizeColumns(Workbook workbook) {
		SXSSFSheet sheet = (SXSSFSheet) workbook.getSheetAt(0);
		sheet.trackAllColumnsForAutoSizing();
		for (int i = 0; i < noOfColumns; i++) {
			sheet.autoSizeColumn(i);
		}
    }

    private int setCellWidth(float widthExcel) {
        return (int) Math.floor((widthExcel * DEFAULT_CHARACTER_WIDTH + 5) / DEFAULT_CHARACTER_WIDTH * 256);
    }

    private long processTime(long start) {
        return (System.currentTimeMillis() - start) / 1000;
    }
    private Cell setUpCell(CellStyle style, Row row, int colNo) {
        Cell cell = row.createCell(colNo);
        cell.setCellStyle(style);
        return cell;
    }

    private Sheet setupSheet(Workbook workbook) {
        Sheet sheet = workbook.createSheet("report");
        sheet.getPrintSetup().setLandscape(true);
        sheet.getPrintSetup().setPaperSize(HSSFPrintSetup.A4_PAPERSIZE);
        sheet.setMargin(Sheet.HeaderMargin, 0.0);
        sheet.setMargin(Sheet.BottomMargin, 0.0);
        sheet.setMargin(Sheet.LeftMargin, 0.0);
        sheet.setMargin(Sheet.RightMargin, 0.0);
        sheet.setMargin(Sheet.FooterMargin, 0.0);
        sheet.setMargin(Sheet.TopMargin, 0.0);

        sheet.setFitToPage(true);
        PrintSetup ps = sheet.getPrintSetup();
        ps.setFitWidth((short) 1);
        ps.setFitHeight((short) 0);
        return sheet;
    }

    private   Font setNormalFont(Workbook workbook) {
        Font font = workbook.createFont();
        font.setFontHeight((short) (9.5 * 20));
        font.setFontName("Arial");
        return font;
    }

    private   Font setBoldFont(Workbook workbook) {
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight((short) (9.5 * 20));
        font.setFontName("Arial");
        font.setColor(IndexedColors.BLACK.getIndex());
        return font;
    }

    private CellStyle setBorderedDoubleCellStyle(Workbook workbook, Font font) {
        CellStyle currencyStyle = workbook.createCellStyle();
        currencyStyle.setDataFormat((short) 8);
        currencyStyle.setWrapText(true);
        currencyStyle.setFont(font);
        currencyStyle.setAlignment(HorizontalAlignment.LEFT);
        currencyStyle.setVerticalAlignment(VerticalAlignment.TOP);
        currencyStyle.setBorderTop(BorderStyle.THIN);
        currencyStyle.setBorderBottom(BorderStyle.THIN);
        currencyStyle.setBorderLeft(BorderStyle.THIN);
        currencyStyle.setBorderRight(BorderStyle.THIN);
        return currencyStyle;
    }

    private CellStyle setBoldedBorderedDoubleCellStyle(Workbook workbook, Font font) {
        CellStyle currencyStyle = workbook.createCellStyle();
        currencyStyle.setDataFormat((short) 8);
        currencyStyle.setWrapText(true);
        currencyStyle.setFont(font);
        currencyStyle.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        currencyStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        currencyStyle.setAlignment(HorizontalAlignment.LEFT);
        currencyStyle.setVerticalAlignment(VerticalAlignment.TOP);
        currencyStyle.setBorderTop(BorderStyle.THIN);
        currencyStyle.setBorderBottom(BorderStyle.THIN);
        currencyStyle.setBorderLeft(BorderStyle.THIN);
        currencyStyle.setBorderRight(BorderStyle.THIN);
        return currencyStyle;
    }

    private CellStyle setBorderedTextCellStyle(Workbook workbook, Font font) {
        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFont(font);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle setBorderedTextCellWithBackGroundStyle(Workbook workbook, Font font) {
        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle setHeaderCellStyle(Workbook workbook, Font font, HorizontalAlignment horizontalAlignment) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setWrapText(true);
        cellStyle.setAlignment(horizontalAlignment);
        cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        return cellStyle;
    }

    public CellStyle setDateCellStyle(Workbook workbook, Font font, CreationHelper workbookHelper) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFont(font);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setDataFormat(workbookHelper.createDataFormat().getFormat("yyyy-MM-dd"));
        return style;
    }

    private CellStyle setNumberTextCellStyleRightAligned(Workbook workbook, Font font, CreationHelper workbookHelper) {
        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);
        style.setAlignment(HorizontalAlignment.RIGHT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFont(font);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setDataFormat(workbookHelper.createDataFormat().getFormat("#.##"));
        return style;
    }
}
