package com.ilt.cms.inventory.rest.inventory;

import com.ilt.cms.inventory.model.BillAdjustmentUpdateRequest;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/core-integration")
public class CoreIntegrationRestController {
    private static final Logger logger = LoggerFactory.getLogger(CoreIntegrationRestController.class);
    private final LocationService locationService;

    public CoreIntegrationRestController(LocationService locationService) {
        this.locationService = locationService;
    }

    @PostMapping("/bill-adjustment/update")
    public HttpEntity<ApiResponse> updateBillAdjustment(@RequestBody BillAdjustmentUpdateRequest request) {
        logger.info("bill adjustment update for   [" + request.toString() + "]");
        try {
            List<LocationInventory> locationInventories = locationService
                    .billAdjustmentUpdate(request.getUpdates(), request.getCaseId());
            logger.info("bill adjustment update completed.");
            return httpApiResponse(new HttpApiResponse(locationInventories));
        } catch (CMSException e) {
            logger.error("bill-adjustment update throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

}
