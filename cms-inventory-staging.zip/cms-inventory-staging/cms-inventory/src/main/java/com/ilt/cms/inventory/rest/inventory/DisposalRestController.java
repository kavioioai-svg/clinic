package com.ilt.cms.inventory.rest.inventory;

import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.svc.model.inventory.api.DisposeItemEntity;
import com.ilt.cms.inventory.model.DisposeStockCriteriaContainer;
import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import com.ilt.cms.inventory.svc.service.inventory.DisposalService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/disposal")
@RolesAllowed("ROLE_PR_PO_INVENTORY_NAV")
public class DisposalRestController {

    private static final Logger logger = LoggerFactory.getLogger(DisposalRestController.class);

    private DisposalService disposalService;

    public DisposalRestController(DisposalService disposalService) {
        this.disposalService = disposalService;
    }

    @PostMapping("/list/{clinicId}/{page}/{size}")
    HttpEntity<ApiResponse> listDisposalStock(@PathVariable("clinicId") String clinicId,
                                              @PathVariable("page") int page,
                                              @PathVariable("size") int size,
                                              @RequestBody DisposeStockCriteriaContainer criteria, Principal principal) {

        logger.info("List disposal stock from the system by [" + principal.getName() + "]");

        try {
            return httpApiResponse(new HttpApiResponse(disposalService.listDisposalStock(clinicId,
                    criteria.getDisposeStatuses(), criteria.getStartDate(), criteria.getEndDate(), page, size)));
        } catch (CMSException e) {
            logger.error("list disposalStock throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/{page}/{size}")
    HttpEntity<ApiResponse> listDisposalStock(@PathVariable("page") int page,
                                              @PathVariable("size") int size,
                                              @RequestBody DisposeStockCriteriaContainer criteria, Principal principal) {

        logger.info("List disposal stock from the mgmt module by [" + principal.getName() + "]");

        try {
            return httpApiResponse(new HttpApiResponse(disposalService.listExpiredStockAndDisposedStock(criteria.getClinicId(),
                    criteria.getDisposeStatuses(), criteria.getStartDate(), criteria.getEndDate(), page, size)));
        } catch (CMSException e) {
            logger.error("list disposalStock from mgmt throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/mark/complete/{clinicId}")
    HttpEntity<ApiResponse> markAsComplete(@PathVariable("clinicId") String clinicId,
                                           @RequestBody DisposeItemEntity disposeItemEntity, Principal principal) {

        logger.info("Mark dispose item as complete by [" + principal.getName() + "]");
        try {
            DisposeItem updatedDisposeItem = disposalService.markDisposeItemAsComplete(clinicId, disposeItemEntity);
            return httpApiResponse(new HttpApiResponse(updatedDisposeItem));
        } catch (CMSException e) {
            logger.error("Mark dispose item as complete throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/mark/complete")
    HttpEntity<ApiResponse> markAsComplete(@RequestBody DisposeItemEntity disposeItemEntity, Principal principal) {

        logger.info("Mark dispose item as complete by [" + principal.getName() + "]");
        try {
            DisposeItem updatedDisposeItem = disposalService.markDisposeItemAsComplete(disposeItemEntity);
            return httpApiResponse(new HttpApiResponse(updatedDisposeItem));
        } catch (CMSException e) {
            logger.error("Mark dispose item as complete from mgmt throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

}
