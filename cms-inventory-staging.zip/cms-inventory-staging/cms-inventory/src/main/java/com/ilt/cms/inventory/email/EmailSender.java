package com.ilt.cms.inventory.email;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.RawMessage;
import com.amazonaws.services.simpleemail.model.SendRawEmailRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.List;

@Configuration
public class EmailSender {

    private static final Logger logger = LoggerFactory.getLogger(EmailSender.class);
    @Value("${system.sender.mail.address}")
    private String systemMailAddress;

    @Value("${system.sender.mail.address}")
    private String senderEmail;

    @Value("${aws.access.key}")
    private String awsAccessKey;

    @Value("${aws.secret.key}")
    private String awsSecretKey;

    @Value("${system.mail.can.send:false}")
    private boolean canSendMail;

    private JavaMailSender mailSender;

    public EmailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public String getSystemMailAddress() {
        return systemMailAddress;
    }
    public void setSystemMailAddress(String systemMailAddress) {
        this.systemMailAddress = systemMailAddress;
    }
    public String getSenderEmail() {
        return senderEmail;
    }
    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }
    public String getAwsAccessKey() {
        return awsAccessKey;
    }
    public void setAwsAccessKey(String awsAccessKey) {
        this.awsAccessKey = awsAccessKey;
    }
    public String getAwsSecretKey() {
        return awsSecretKey;
    }
    public void setAwsSecretKey(String awsSecretKey) {
        this.awsSecretKey = awsSecretKey;
    }
    public boolean isCanSendMail() {
        return canSendMail;
    }
    public void setCanSendMail(boolean canSendMail) {
        this.canSendMail = canSendMail;
    }

    public void sendEmail(List<String> receivers, String subject, String messageContent) throws JsonProcessingException {
        for (String receiver : receivers) {
            try {
                MimeMessage mimeMessage = createMimeMessage(subject, messageContent, senderEmail, List.of(receiver));
                sendRawEmail(mimeMessage);
            } catch (CMSException e) {
                logger.error("Email sending failed to " + receiver, e);
            }
        }
    }

	public void sendEmailMultipleRecipients(List<String> receivers, String subject, String messageContent) throws JsonProcessingException {
		try {
			MimeMessage mimeMessage = createMimeMessage(subject, messageContent, senderEmail, receivers);
			sendRawEmail(mimeMessage);
		} catch (CMSException e) {
			logger.error("Email sending failed to " + receivers, e);
		}
	}

    public MimeMessage createMimeMessage(String subject, String body, String fromEmail, List<String> toEmail) {
        logger.info("Creating mime message with the subject [" + subject + "], body [" + body + "] from Email [" + fromEmail + "], to Email [" + toEmail + "]");
        MimeMessage message = mailSender.createMimeMessage();

        try {
            message.setSender(new InternetAddress(fromEmail));
            message.setFrom(new InternetAddress(fromEmail));
            message.setSubject(subject);
			InternetAddress[] emailIds = InternetAddress.parse(String.join(",", toEmail) , true);
            message.setRecipients(javax.mail.Message.RecipientType.TO, emailIds);

            Multipart multipart = new MimeMultipart("alternative");
            BodyPart messageBodyPart = buildHtmlTextPart(body);
            multipart.addBodyPart(messageBodyPart, 0);

            MimeBodyPart wrap = new MimeBodyPart();
            wrap.setContent(multipart);
            Multipart multipart2 = new MimeMultipart("mixed");
            multipart2.addBodyPart(wrap);
            message.setContent(multipart2);
        } catch (Exception e) {
            logger.warn("Error creating MimeMessage for the order ", e);
        }

        return message;
    }

    private BodyPart buildHtmlTextPart(String body) throws MessagingException {

        MimeBodyPart descriptionPart = new MimeBodyPart();
        descriptionPart.setContent(body, "text/html; charset=utf-8");

        return descriptionPart;
    }

    private void sendRawEmail(MimeMessage mimeMessage) throws CMSException {
        logger.info("Mime message : " + mimeMessage);
        if (!canSendMail) {
            logger.info("Send mail function is disabled.");
            return;
        }
        try {
            AmazonSimpleEmailService client =
                    AmazonSimpleEmailServiceClientBuilder.standard()
                            .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsAccessKey, awsSecretKey)))
                            // Replace US_WEST_2 with the AWS Region you're using for
                            // Amazon SES.
                            .withRegion(Regions.US_EAST_1).build();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            mimeMessage.writeTo(outputStream);
            RawMessage rawMessage = new RawMessage(ByteBuffer.wrap(outputStream.toByteArray()));
            SendRawEmailRequest rawEmailRequest = new SendRawEmailRequest(rawMessage);
            client.sendRawEmail(rawEmailRequest);
            logger.info("Email sent!");
        } catch (Exception ex) {
            logger.error("Send mail error[" + ex.getMessage() + "]");
            throw new CMSException(StatusCode.I5000, "Send mail problem occur");
        }
    }
}
