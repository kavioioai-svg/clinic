package com.ilt.cms.inventory.rest.purchase;

import com.ilt.cms.core.entity.file.FileMetaData;
import com.ilt.cms.inventory.svc.model.purchase.api.FileDowload;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.service.purchase.FileManagementService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.security.RolesAllowed;
import java.io.IOException;
import java.security.Principal;
import java.util.Map;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@Controller
@RequestMapping("/document-management")
@RolesAllowed("ROLE_FILE_LIST")
public class FileManagementRestController {

    private static final Logger logger = LoggerFactory.getLogger(FileManagementRestController.class);

    private FileManagementService fileManagementService;

    public FileManagementRestController(FileManagementService fileManagementService) {
        this.fileManagementService = fileManagementService;
    }

    @PostMapping("/upload/grn/{orderId}/{grnId}")
    @RolesAllowed("ROLE_FILE_UPLOAD")
    HttpEntity<ApiResponse> uploadDeliveryNoteFileToGRN(@PathVariable("orderId") String orderId,
                                                        @PathVariable("grnId") String grnId,
                                                        @RequestParam("name") String name,
                                                        @RequestParam("fileName") String fileName,
                                                        @RequestParam("clinicId") String clinicId,
                                                        @RequestParam("description") String description,
                                                        @RequestParam("file") MultipartFile uploadFile, Principal principal) {

        logger.info("uploadDeliveryNoteToGRN, order["+orderId+"], grnId["+grnId+"], fileName["+fileName+"] by [" + principal.getName() + "]");

        try {
            FileMetaData metaData = fileManagementService.uploadDeliveryNoteFileToGoodReceivedNote(principal, name, clinicId,
                    orderId, grnId, fileName, description, uploadFile);
            return httpApiResponse(new HttpApiResponse(metaData));
        } catch (CMSException e) {
            logger.error("list  orderRequest throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        } catch (IOException e) {
            logger.error("list  orderRequest throw message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getMessage()));
        }
    }

    @PostMapping("/download/grn/{orderId}/{grnId}/{fileId}")
    @RolesAllowed("ROLE_FILE_DOWNLOAD")
    public ResponseEntity downloadDeliveryNoteFromGRN(Principal principal,
                                                      @PathVariable("orderId") String orderId,
                                                      @PathVariable("grnId") String grnId,
                                                      @PathVariable("fileId") String fileId) {

        logger.info("downloadDeliveryNoteFromGRN[" + fileId + "] for order [" + orderId + "], grnId[" + grnId + "] for user [" + principal.getName() + "]");
        try {
            FileDowload fileDowload = fileManagementService.downloadFileFromGRN(orderId, grnId, fileId);
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
            headers.add("Content-Transfer-Encoding", "binary");
            headers.add("Content-Disposition", "attachment; filename=\"" + fileDowload.getFileName() + "\"");
            return new ResponseEntity<>(fileDowload.getOutputStream().toByteArray(), headers, HttpStatus.OK);
        } catch (IOException e) {
            logger.error("downloadDeliveryNoteFromGRN throw IOException[" + e.getMessage() + "]", e);
            return new ResponseEntity<>(null, null, HttpStatus.OK);
        } catch (CMSException e) {
            logger.error("downloadDeliveryNoteFromGRN throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return new ResponseEntity<>(null, null, HttpStatus.OK);
        }
    }

    @PostMapping("/get/grn/{orderId}/{grnId}")
    HttpEntity<ApiResponse> findDeliveryNoteFromGRN(Principal principal,
                                                    @PathVariable("orderId") String orderId,
                                                    @PathVariable("grnId") String grnId) {

        logger.info("findDeliveryNoteFromGRN, orderId[" + orderId + "] for grnId[" + grnId + "] by system user[" + principal.getName() + "]");
        try {
            FileMetaData fileMetaData = fileManagementService.findMetaDataFromGRN(orderId, grnId);
            return httpApiResponse(new HttpApiResponse(fileMetaData));
        } catch (CMSException e) {
            logger.error("list  orderRequest throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }
}
