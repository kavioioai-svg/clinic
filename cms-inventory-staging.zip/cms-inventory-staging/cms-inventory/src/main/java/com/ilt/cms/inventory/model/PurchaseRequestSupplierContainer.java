package com.ilt.cms.inventory.model;

import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;

import java.util.List;

public class PurchaseRequestSupplierContainer {

    private PurchaseRequest purchaseRequest;

    private List<Supplier> suppliers;

    public PurchaseRequestSupplierContainer(PurchaseRequest purchaseRequest, List<Supplier> suppliers) {
        this.purchaseRequest = purchaseRequest;
        this.suppliers = suppliers;
    }

    public PurchaseRequest getPurchaseRequest() {
        return purchaseRequest;
    }

    public void setPurchaseRequest(PurchaseRequest purchaseRequest) {
        this.purchaseRequest = purchaseRequest;
    }

    public List<Supplier> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(List<Supplier> suppliers) {
        this.suppliers = suppliers;
    }

    @Override
    public String toString() {
        return "PurchaseRequestSupplierContainer{" +
                "purchaseRequest=" + purchaseRequest +
                ", suppliers=" + suppliers +
                '}';
    }
}
