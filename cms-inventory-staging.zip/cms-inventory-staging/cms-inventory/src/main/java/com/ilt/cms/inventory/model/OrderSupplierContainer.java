package com.ilt.cms.inventory.model;

import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderSupplierContainer {

    private Order order;

    private List<Supplier> suppliers;

    private Map<String, Double> backOrderCounts;

    public OrderSupplierContainer(Order order, List<Supplier> suppliers, Map<String, Double> backOrderCounts) {
        this.order = order;
        this.suppliers = suppliers;
        this.backOrderCounts = backOrderCounts;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public List<Supplier> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(List<Supplier> suppliers) {
        this.suppliers = suppliers;
    }

    public Map<String, Double> getBackOrderCounts() {
        return backOrderCounts;
    }

    public void setBackOrderCounts(HashMap<String, Double> backOrderCounts) {
        this.backOrderCounts = backOrderCounts;
    }

    @Override
    public String toString() {
        return "OrderSupplierContainer{" +
                "order=" + order +
                ", suppliers=" + suppliers +
                ", backOrderCounts=" + backOrderCounts +
                '}';
    }
}
