package com.ilt.cms.inventory.model;

import com.ilt.cms.inventory.svc.model.purchase.GoodReturnItem;

import java.util.ArrayList;
import java.util.List;

public class ReturnItemContainer {

    private String purchaseOrderId;

    private List<GoodReturnItem> returnItems = new ArrayList<>();

    public ReturnItemContainer() {
    }

    public ReturnItemContainer(String purchaseOrderId, List<GoodReturnItem> returnItems) {
        this.purchaseOrderId = purchaseOrderId;
        this.returnItems = returnItems;
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public List<GoodReturnItem> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(List<GoodReturnItem> returnItems) {
        this.returnItems = returnItems;
    }
}
