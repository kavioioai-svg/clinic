package com.ilt.cms.inventory.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UomMatrixSearchParam {
	private String itemId;
	private String sourceUom;
	private String destinationUom;
}
