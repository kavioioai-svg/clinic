package com.ilt.cms.inventory;

import com.lippo.commons.util.CommonUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import software.amazon.codeguruprofilerjavaagent.Profiler;

@SpringBootApplication(scanBasePackages = {"com.ilt.cms", "com.lippo.commons.web", "com.lippo.cms", "com.hmc.multi.tenant"})
@EntityScan("com.ilt.cms")
@EnableTransactionManagement
@EnableMongoRepositories(value = "com.ilt.cms")
@EnableMongoAuditing
@EnableScheduling
public class InventoryStarter {
    public static void main(String[] args) {
        if (CommonUtils.isStringValid(System.getenv("PROFILE_APP_NAME"))) {
            new Profiler.Builder()
                    .profilingGroupName(System.getenv("PROFILE_APP_NAME"))
                    .withHeapSummary(true)
                    .build().start();
        }
        SpringApplication.run(InventoryStarter.class, args);
    }

}
