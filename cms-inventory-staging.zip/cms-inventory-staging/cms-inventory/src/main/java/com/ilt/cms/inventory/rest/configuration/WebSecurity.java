package com.ilt.cms.inventory.rest.configuration;

import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.web.AuthorizationFilter;
import com.lippo.commons.web.config.CloudConfigDetails;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.data.domain.AuditorAware;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.servlet.ServletContext;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//@Order(200)
@EnableWebSecurity
@EnableGlobalMethodSecurity(jsr250Enabled = true, securedEnabled = true, prePostEnabled = true)
public class WebSecurity extends WebSecurityConfigurerAdapter {

    private RestTemplate restTemplate;
    private CloudConfigDetails cloudConfigDetails;
    private ServletContext servletContext;

    @Value("#{'${domain.allowed.origins}'.split(',')}")
    private List<String> allowedOrigins;

    public WebSecurity(CloudConfigDetails cloudConfigDetails, RestTemplate restTemplate, ServletContext servletContext) {
        this.restTemplate = restTemplate;
        this.cloudConfigDetails = cloudConfigDetails;
        this.servletContext = servletContext;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //http.httpBasic();
        Set<String> whitelistUrlSet = cloudConfigDetails.getWhitelistUrls().stream()
                .flatMap(url -> {
                    if (CommonUtils.isStringValid(servletContext.getContextPath())) {
                        return Stream.of(servletContext.getContextPath() + url, url);
                    }
                    return Stream.of(url);
                })
                .collect(Collectors.toSet());
        String[] whitelistUrls = whitelistUrlSet.stream()
                .map(url -> url.endsWith("/") ? url + "**" : url)
                .toArray(String[]::new);

        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.cors().configurationSource(corsConfigurationSource());

        http.csrf().disable().authorizeRequests()
                //.antMatchers("/**").permitAll();
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .antMatchers(whitelistUrls).permitAll()
                .anyRequest().authenticated()
                .and()
                 //yes this can be annotated but this is kept here so that someone new can easily navigate it
                .addFilter(new AuthorizationFilter(authenticationManager(), cloudConfigDetails, restTemplate));
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(allowedOrigins);
        configuration.setAllowedMethods(Arrays.asList("OPTIONS", "GET", "POST"));
        configuration.setMaxAge(3600L);
        configuration.setAllowCredentials(true);
        configuration.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization", "Accept", "Host", "Content-Length",
                "Accept-Encoding", "Accept-Language", "Access-Control-Request-Headers", "Access-Control-Request-Method",
                "Connection", "Origin", "User-Agent", "Access-Control-Allow-Origin", "Referrer-Policy", "X-LOGGED-IN-CLINIC-ID", "X-LOGGED-IN-CLINIC-CODE", "X-Tenant"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public AuditorAware<String> auditor() {
        return () -> Optional.of(((String) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal()));
    }


    @ControllerAdvice
    @Order(10000)
    public class BinderControllerAdvice {

        @InitBinder
        public void setAllowedFields(WebDataBinder dataBinder) {
            String[] denylist = new String[]{"class.*", "Class.*", "*.class.*", "*.Class.*"};
            dataBinder.setDisallowedFields(denylist);
        }
    }
}
