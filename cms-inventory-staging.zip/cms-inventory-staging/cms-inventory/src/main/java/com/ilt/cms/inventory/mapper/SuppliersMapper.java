package com.ilt.cms.inventory.mapper;

import com.ilt.cms.api.entity.supplier.*;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.supplier.*;

import java.util.stream.Collectors;

public class SuppliersMapper {

	public static Supplier mapToCore(SupplierEntity supplierEntity) {
		if (supplierEntity == null) {
			return null;
		}
		Supplier supplier = new Supplier();

		supplier.setId(supplierEntity.getId());
		supplier.setName(supplierEntity.getName());
		supplier.setSupplierNo(supplierEntity.getSupplierNo());

		if (supplierEntity.getStatus() != null) {
			supplier.setStatus(Status.valueOf(supplierEntity.getStatus().name()));
		}
		if (supplierEntity.getClinicMinPurchaseAmounts() != null) {
			supplier.setMinPurchaseAmounts(supplierEntity.getClinicMinPurchaseAmounts().stream()
				.map(minPurchaseAmountEntity -> mapToCore(minPurchaseAmountEntity))
				.collect(Collectors.toList()));
		}
		if (supplierEntity.getItems() != null) {
			supplier.setItems(supplierEntity.getItems().stream()
				.map(purchaseItemEntity -> mapToCore(purchaseItemEntity))
				.collect(Collectors.toList()));
		}
		if (supplierEntity.getPurchaseBonuses() != null) {
			supplier.setPurchaseBonuses(supplierEntity.getPurchaseBonuses().stream()
				.map(purchaseBonusEntity -> mapToCore(purchaseBonusEntity))
				.collect(Collectors.toList()));
		}

		return supplier;
	}

	public static SupplierEntity mapToEntity(Supplier supplier) {
		if (supplier == null) {
			return null;
		}
		SupplierEntity supplierEntity = new SupplierEntity();
		supplierEntity.setId(supplier.getId());
		supplierEntity.setName(supplier.getName());
		supplierEntity.setSupplierNo(supplier.getSupplierNo());
		if (supplier.getStatus() != null) {
			supplierEntity.setStatus(com.ilt.cms.api.entity.common.Status.valueOf(supplier.getStatus().name()));
		}
		if (supplier.getMinPurchaseAmounts() != null) {
			supplierEntity.setClinicMinPurchaseAmounts(supplier.getMinPurchaseAmounts().stream()
				.map(clinicMinPurchaseAmount -> mapToEntity(clinicMinPurchaseAmount))
				.collect(Collectors.toList()));
		}
		if (supplier.getItems() != null) {
			supplierEntity.setItems(supplier.getItems().stream()
				.map(purchaseItem -> mapToEntity(purchaseItem))
				.collect(Collectors.toList()));
		}
		if (supplier.getPurchaseBonuses() != null) {
			supplierEntity.setPurchaseBonuses(supplier.getPurchaseBonuses().stream()
				.map(purchaseBonus -> mapToEntity(purchaseBonus))
				.collect(Collectors.toList()));
		}
		return supplierEntity;
	}

	public static PurchaseItem mapToCore(PurchaseItemEntity purchaseItemEntity) {
		if (purchaseItemEntity == null) {
			return null;
		}

		PurchaseItem purchaseItem = new PurchaseItem();
		purchaseItem.setItemId(purchaseItemEntity.getItemId());
		purchaseItem.setMinPurchaseQuantity(purchaseItemEntity.getMinPurchaseQuantity());
		return purchaseItem;
	}

	public static PurchaseItemEntity mapToEntity(PurchaseItem purchaseItem) {
		if (purchaseItem == null) {
			return null;
		}

		PurchaseItemEntity purchaseItemEntity = new PurchaseItemEntity();
		purchaseItemEntity.setItemId(purchaseItem.getItemId());
		purchaseItemEntity.setMinPurchaseQuantity(purchaseItem.getMinPurchaseQuantity());
		purchaseItemEntity.setStatus(purchaseItem.getStatus());
		return purchaseItemEntity;
	}

	public static MinPurchaseAmount mapToCore(MinPurchaseAmountEntity minPurchaseAmountEntity) {
		if (minPurchaseAmountEntity == null) {
			return null;
		}
		MinPurchaseAmount minPurchaseAmount = new MinPurchaseAmount(minPurchaseAmountEntity.getClinicId(),
			minPurchaseAmountEntity.isGlobal(), minPurchaseAmountEntity.getMinPurchaseAmount());
		return minPurchaseAmount;
	}

	public static MinPurchaseAmountEntity mapToEntity(MinPurchaseAmount minPurchaseAmount) {
		if (minPurchaseAmount == null) {
			return null;
		}
		MinPurchaseAmountEntity minPurchaseAmountEntity = new MinPurchaseAmountEntity(minPurchaseAmount.getClinicId(),
			minPurchaseAmount.isGlobal(), minPurchaseAmount.getMinPurchaseAmount());
		return minPurchaseAmountEntity;
	}

	public static PurchaseBonus mapToCore(PurchaseBonusEntity purchaseBonusEntity) {
		if (purchaseBonusEntity == null) {
			return null;
		}
		PurchaseBonus purchaseBonus = new PurchaseBonus(purchaseBonusEntity.getItemId());
		if (purchaseBonusEntity.getBonusDetails() != null) {
			purchaseBonus.setBonusDetails(purchaseBonusEntity.getBonusDetails().stream()
				.map(bonusDetailEntity -> mapToCore(bonusDetailEntity))
				.collect(Collectors.toList()));
		}
		return purchaseBonus;
	}

	public static PurchaseBonusEntity mapToEntity(PurchaseBonus purchaseBonus) {
		if (purchaseBonus == null) {
			return null;
		}
		PurchaseBonusEntity purchaseBonusEntity = new PurchaseBonusEntity();
		purchaseBonusEntity.setItemId(purchaseBonus.getItemId());
		if (purchaseBonus.getBonusDetails() != null) {
			purchaseBonusEntity.setBonusDetails(purchaseBonus.getBonusDetails().stream()
				.map(bonusDetail -> mapToEntity(bonusDetail))
				.collect(Collectors.toList()));
		}
		return purchaseBonusEntity;

	}

	public static BonusDetail mapToCore(BonusDetailEntity bonusDetailEntity) {
		if (bonusDetailEntity != null) {
			return null;
		}
		BonusDetail bonusDetail = new BonusDetail(bonusDetailEntity.getPurchaseQuantity(), bonusDetailEntity.getBonusQuantity(),
			bonusDetailEntity.getUom());
		return bonusDetail;
	}

	public static BonusDetailEntity mapToEntity(BonusDetail bonusDetail) {
		if (bonusDetail == null) {
			return null;
		}
		BonusDetailEntity bonusDetailEntity = new BonusDetailEntity(bonusDetail.getPurchaseQuantity(),
			bonusDetail.getBonusQuantity(),
			bonusDetail.getUom());
		return bonusDetailEntity;
	}
}