package com.ilt.cms.inventory.rest.inventory;

import com.google.common.base.Strings;
import com.ilt.cms.api.container.PageableHttpApiResponse;
import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.ItemClinicDetail;
import com.ilt.cms.core.entity.item.ItemExtraDetails;
import com.ilt.cms.database.clinic.ClinicDatabaseService;
import com.ilt.cms.inventory.model.ApiInventory;
import com.ilt.cms.inventory.model.ItemInventory;
import com.ilt.cms.inventory.model.StockTakeCriteriaContainer;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockCountItemEntity;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockTakeSearchDTO;
import com.ilt.cms.inventory.svc.model.common.Reason;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.StockCountItem;
import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.api.AdjustmentStockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockAlertType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.service.common.ItemClinicDetailService;
import com.ilt.cms.inventory.svc.service.common.SystemConfigService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.inventory.svc.service.inventory.StockTakeService;
import com.ilt.cms.inventory.svc.service.nav.NavStockTakeService;
import com.ilt.cms.inventory.util.ExcelExportService;
import com.ilt.cms.repository.spring.ItemRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.util.CMSConstant;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/stock")
@RolesAllowed("ROLE_PR_PO_INVENTORY_NAV")
public class StockTakeRestController {
    private static final Logger logger = LoggerFactory.getLogger(StockTakeRestController.class);

    private static final String SEARCH_STOCK_ALERT = "STOCK_ALERT";

    private static final String SEARCH_SUPPLIER_NAME_REGEX = "SUPPLIER_NAME_REGEX";

    private static final String SEARCH_ITEM_CODE_REGEX = "ITEM_CODE_REGEX";

    private static final String SEARCH_ITEM_NAME_REGEX = "ITEM_NAME_REGEX";

	private static final String SEARCH_COMMON_REGEX = "COMMON_REGEX";

    private static final String SEARCH_APPROVE_STATUS = "APPROVE_STATUS";

    private static final String SEARCH_TRANSACTION_NO_REGEX = "TRANSACTION_NO_REGEX";

    private static final String SEARCH_ITEM_ID = "ITEM_ID";

    private StockTakeService stockTakeService;

    private LocationService locationService;

    private ItemClinicDetailService itemClinicDetailService;

    private SystemConfigService systemConfigService;

    private NavStockTakeService navStockTakeService;

    private ClinicDatabaseService clinicDatabaseService;
    private  ExcelExportService excelExportService;
    private ItemRepository itemRepository;
    private UOMMatrixService uomMatrixService;

    public StockTakeRestController(StockTakeService stockTakeService, LocationService locationService, SystemConfigService systemConfigService,
                                   ItemClinicDetailService itemClinicDetailService,
                                   NavStockTakeService navStockTakeService, ClinicDatabaseService clinicDatabaseService, ExcelExportService excelExportService, ItemRepository itemRepository, UOMMatrixService uomMatrixService) {
        this.stockTakeService = stockTakeService;
        this.locationService = locationService;
        this.itemClinicDetailService = itemClinicDetailService;
        this.systemConfigService = systemConfigService;
        this.navStockTakeService = navStockTakeService;
        this.clinicDatabaseService = clinicDatabaseService;
        this.excelExportService = excelExportService;
        this.itemRepository = itemRepository;
        this.uomMatrixService = uomMatrixService;
    }

    @PostMapping("/list/stock-take/{stockTakeStatus}/{stockTakeApproveStatus}/{page}/{size}")
    HttpEntity<ApiResponse> listStockTakeByStockTakeStatusAndApproveStatus(@PathVariable("stockTakeStatus") StockTakeStatus stockTakeStatus,
                                                                           @PathVariable("stockTakeApproveStatus") StockTakeApproveStatus stockTakeApproveStatus,
                                                                           @PathVariable("page") int page,
                                                                           @PathVariable("size") int size, Principal principal) {

        logger.info("list stock take list from the system by [" + principal.getName() + "]");
        int totalElements, totalPage, pageNumber;
        Page<StockTake> stockTakes = stockTakeService.findStockTakesByStockTakeStatusAndApproveStatus(stockTakeStatus,
                stockTakeApproveStatus, page, size);
        totalElements = (int) stockTakes.getTotalElements();
        totalPage = stockTakes.getTotalPages();
        pageNumber = stockTakes.getNumber();
        return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, stockTakes.getContent()));
    }

    @PostMapping("/search/inventory/{clinicId}/{itemGroup}/{page}/{size}")
    HttpEntity<ApiResponse> searchInventory(@PathVariable("clinicId") String clinicId,
                                            @PathVariable("itemGroup") String itemGroup,
                                            @PathVariable("page") int page,
                                            @PathVariable("size") int size,
                                            @RequestBody Map<String, String> searchRegex, Principal principal) throws CMSException {

        logger.info("Search inventory from the system by [" + principal.getName() + "]");
        String stockAlert = searchRegex.get(SEARCH_STOCK_ALERT);
        String supplierNameRegex = searchRegex.get(SEARCH_SUPPLIER_NAME_REGEX);
        String itemCodeRegex = searchRegex.get(SEARCH_ITEM_CODE_REGEX);
        String itemNameRegex = searchRegex.get(SEARCH_ITEM_NAME_REGEX);
		String commonRegex = searchRegex.get(SEARCH_COMMON_REGEX);
        List<Inventory> inventories = locationService.searchInventory(clinicId, itemGroup, stockAlert,
                itemNameRegex, supplierNameRegex, itemCodeRegex, commonRegex);

        List<String> itemIds = inventories.stream()
                .map(Inventory::getItemRefId)
                .collect(Collectors.toList());
        Map<String, List<ItemExtraDetails>> itemClinicDetailMap = itemClinicDetailService.listItemClinicDetailByClinicIdAndItemIds(clinicId, itemIds).stream()
                .collect(Collectors.toMap(ItemClinicDetail::getItemRefId, ItemClinicDetail::getClinicDetails));

        List<ApiInventory> apiInventories = inventories.stream()
                .map(inventory -> mapToApiInventory(inventory, itemClinicDetailMap.get(inventory.getItemRefId())))
                .sorted(Comparator.comparing(ApiInventory::getItemName, Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());

        Map<String, Object> responseMap = mapToPageData(apiInventories, page, size);
        return httpApiResponse(new HttpApiResponse(responseMap));
    }

    @PostMapping("/search/item/uom-ratio/{baseUom}/{sourceUom}")
    ResponseEntity searchItemUomRatio(@PathVariable("baseUom") String baseUom,
                                      @PathVariable("sourceUom") String sourceUom,
                                               Principal principal) throws CMSException {

        logger.info("findReverseRatio by sourceUom[" + sourceUom + "] to baseUom[" + baseUom + "] by system user[" + principal.getName() + "]");
        try {
            double ratio = uomMatrixService.findReverseRatio(baseUom,sourceUom);
            return httpApiResponse(new HttpApiResponse(ratio));
        } catch (Exception e) {
            logger.error("findReverseRatio throw error, message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(StatusCode.E2000, e.getMessage()));
        }
    }


    //    @RolesAllowed("ROLE_CURRENT_STOCK_OVERVIEW")
    @PostMapping("/search/item/{clinicId}/{itemGroup}/{page}/{size}")
    ResponseEntity searchInventoryGroupByItem(@PathVariable("clinicId") String clinicId,
                                                       @PathVariable("itemGroup") String itemGroup,
                                                       @PathVariable("page") int page,
                                                       @PathVariable("size") int size,
                                                       @RequestBody Map<String, String> otherDetails, Principal principal) throws CMSException {

        logger.info("Search inventory from the system by [" + principal.getName() + "]");
        String stockAlert = otherDetails.get(SEARCH_STOCK_ALERT);
        String supplierNameRegex = otherDetails.get(SEARCH_SUPPLIER_NAME_REGEX);
        String itemCodeRegex = otherDetails.get(SEARCH_ITEM_CODE_REGEX);
        String itemNameRegex = otherDetails.get(SEARCH_ITEM_NAME_REGEX);
		String commonRegex = otherDetails.get(SEARCH_COMMON_REGEX);

        boolean doExport = otherDetails.get("EXPORT_EXCEL") != null ? Boolean.valueOf(otherDetails.get("EXPORT_EXCEL")) : false;
        List<Inventory> inventories = locationService.searchInventory(clinicId, itemGroup, stockAlert,
                itemNameRegex, supplierNameRegex, itemCodeRegex, commonRegex);

        List<String> itemIds = inventories.stream()
                .map(Inventory::getItemRefId)
                .collect(Collectors.toList());
        Map<String, List<ItemExtraDetails>> itemClinicDetailMap = itemClinicDetailService.listItemClinicDetailByClinicIdAndItemIds(clinicId, itemIds).stream()
                .collect(Collectors.toMap(ItemClinicDetail::getItemRefId, ItemClinicDetail::getClinicDetails));

        List<ItemInventory> itemInventories = inventories.stream()
                .map(inventory -> mapToApiInventory(inventory, itemClinicDetailMap.get(inventory.getItemRefId())))
                .collect(Collectors.groupingBy(ApiInventory::getItemRefId))
                .entrySet().stream()
                .map(e -> mapToItemInventory(e.getKey(), e.getValue(), clinicId, inventories, itemClinicDetailMap))
                .sorted(Comparator.comparing(ItemInventory::getItemName, Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());

        if (StockAlertType.INVENTORY_LOW.name().
                equals(stockAlert)) {
            itemInventories = itemInventories.stream()
                    .filter(ItemInventory::isLowStockLevel)
                    .collect(Collectors.toList());
        }
        if (StockAlertType.INVENTORY_HIGH.name().equals(stockAlert)) {

            itemInventories = itemInventories.stream()
                    .filter(inventory -> !inventory.isLowStockLevel())
                    .collect(Collectors.toList());
        }

        if (doExport) {
            Optional<Clinic> clinic = clinicDatabaseService.findOne(clinicId);
            List<Item> itemList = itemRepository.findAllByIdIn(itemIds);
            String clinicCode = clinic.get().getClinicCode();
            return excelExportService.generateInventoryExcel(clinicCode,itemInventories, itemList);
        } else {
            Map<String, Object> responseMap = mapToPageData(itemInventories, page, size);
            return httpApiResponse(new HttpApiResponse(responseMap));
        }
    }

    @PostMapping("/search/inventory/{clinicId}/{itemCode}/{batchNo}")
    HttpEntity<ApiResponse> searchInventoryByItemCode(@PathVariable("clinicId") String clinicId,
                                                      @PathVariable("itemCode") String itemCode,
                                                      @PathVariable("batchNo") String batchNo) {

        try {
            Inventory inventory = locationService.searchInventoryByItemCode(clinicId, itemCode, batchNo);

            Map<String, List<ItemExtraDetails>> itemClinicDetailMap = itemClinicDetailService.listItemClinicDetailByClinicIdAndItemIds(
                            clinicId, Arrays.asList(inventory.getItemRefId())).stream()
                    .collect(Collectors.toMap(ItemClinicDetail::getItemRefId, ItemClinicDetail::getClinicDetails));

            ApiInventory apiInventory = Optional.ofNullable(inventory).stream()
                    .map(invent -> mapToApiInventory(invent, itemClinicDetailMap.get(inventory.getItemRefId())))
                    .findFirst()
                    .orElseThrow(() -> {
                        logger.error("Mapping ApiInventory error");
                        return new CMSException(StatusCode.I5000, "Mapping entity error");
                    });
            return httpApiResponse(new HttpApiResponse(apiInventory));
        } catch (CMSException e) {
            logger.error("searchInventoryByItemCode throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/adjustment/stock-take/{clinicId}")
    HttpEntity<ApiResponse> adjustStockLevel(@PathVariable("clinicId") String clinicId,
                                             @RequestBody AdjustmentStockTake adjustmentStockTake, Principal principal) {

        logger.info("Adjust stock level that clinic[" + clinicId + "] from the system by [" + principal.getName() + "]");

        try {
            StockTake stockTake = stockTakeService.adjustStockLevel(clinicId, principal.getName(), adjustmentStockTake.getInventoryId(),
                    adjustmentStockTake.getItemCode(), adjustmentStockTake.getBatchNo() != null ? adjustmentStockTake.getBatchNo().toUpperCase() : null,
                    adjustmentStockTake.getUom(), adjustmentStockTake.getExpiryDate(), adjustmentStockTake.getManufacturerDate(),
                    adjustmentStockTake.getNewStockLevel(), adjustmentStockTake.getPurposeOfAdjustmentCode(), adjustmentStockTake.getRemark(), adjustmentStockTake.getPurchasePrice(),
                    adjustmentStockTake.getNewBatchNo());
            return httpApiResponse(new HttpApiResponse(stockTake));
        } catch (CMSException e) {
            logger.error("adjustStockLevel throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/search/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> searchStockTakeById(Principal principal, @PathVariable("stockTakeId") String stockTakeId) {

        logger.info("search stock take by id[" + stockTakeId + "] from the system by [" + principal.getName() + "]");

        try {
            StockTake stockTake = stockTakeService.findStockTakeById(stockTakeId);
            return httpApiResponse(new HttpApiResponse(stockTake));
        } catch (CMSException e) {
            logger.error("search stock take by id throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/stock-take/{clinicId}/{page}/{size}")
    HttpEntity<ApiResponse> listStocktakeByClinicId(@PathVariable("clinicId") String clinicId,
                                                    @PathVariable("page") int page,
                                                    @PathVariable("size") int size,
                                                    @RequestBody StockTakeCriteriaContainer stockTakeCriteriaContainer,
                                                    Principal principal) {

        logger.info("List stock take of clinic[" + clinicId + "] from the system by [" + principal.getName() + "]");

        int totalElements, totalPage, pageNumber;
        Page<StockTake> stockTakes = stockTakeService.listAllStockTake(clinicId, stockTakeCriteriaContainer.getNameRegex(), stockTakeCriteriaContainer.getTransactionNoRegex(),
                stockTakeCriteriaContainer.getStockTakeApproveStatuses(), stockTakeCriteriaContainer.getStockTakeStatuses(), stockTakeCriteriaContainer.getStockCountTypes(),
                stockTakeCriteriaContainer.getStartDate(), stockTakeCriteriaContainer.getEndDate(), page, size, Sort.Direction.DESC, "startDate", "startTime");
        totalElements = (int) stockTakes.getTotalElements();
        totalPage = stockTakes.getTotalPages();
        pageNumber = stockTakes.getNumber();
        List<StockTake> stockContent = stockTakes.getContent();

        return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, stockContent));
    }

    @PostMapping("/search/stock-take/{page}/{size}")
    HttpEntity<ApiResponse> searchStockTakes(@PathVariable("page") int page,
                                             @PathVariable("size") int size,
                                             @RequestBody StockTakeSearchDTO search,
                                             Principal principal) {
        logger.info("Search stock take of from the mgmt by [" + principal.getName() + "]");

        Pageable pageable = PageRequest.of(page, size);
        Page<StockCountItemEntity> stockCountItemEntityPage = null;
        try {
            stockCountItemEntityPage = stockTakeService.searchStockTakes(search, pageable);
        } catch (CMSException e) {
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }

        return httpApiResponse(new HttpApiResponse(stockCountItemEntityPage));
    }

    @PostMapping("/list/adjustment/{clinicId}/{itemGroup}/{page}/{size}")
    HttpEntity<ApiResponse> listAdjustmentByClinicId(@PathVariable("clinicId") String clinicId,
                                                     @PathVariable("itemGroup") String itemGroup,
                                                     @PathVariable("page") int page,
                                                     @PathVariable("size") int size,
                                                     @RequestBody Map<String, Object> searchRegex,
                                                     Principal principal) {

        logger.info("List stock take of clinic[" + clinicId + "] from the system by [" + principal.getName() + "]");

        String itemCodeRegex = (String) searchRegex.get(SEARCH_ITEM_CODE_REGEX);
        String itemNameRegex = (String) searchRegex.get(SEARCH_ITEM_NAME_REGEX);
        String transactionNoRegex = (String) searchRegex.get(SEARCH_TRANSACTION_NO_REGEX);
        String itemId = (String) searchRegex.get(SEARCH_ITEM_ID);
        List<String> approveStatuses = (List<String>) searchRegex.get(SEARCH_APPROVE_STATUS);
        if (approveStatuses == null || approveStatuses.size() == 0) {
            approveStatuses = new ArrayList<>();
            approveStatuses.addAll(Arrays.asList(StockTakeApproveStatus.values()).stream()
                    .map(StockTakeApproveStatus::name)
                    .collect(Collectors.toList()));
        }

        int totalElements, totalPage, pageNumber;
        Page<StockTake> stockTakes = stockTakeService.listAllAdjustment(clinicId, itemGroup, itemCodeRegex, itemNameRegex, transactionNoRegex, itemId, approveStatuses, page, size, Sort.Direction.DESC, "startDate");
        totalElements = (int) stockTakes.getTotalElements();
        totalPage = stockTakes.getTotalPages();
        pageNumber = stockTakes.getNumber();

        return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, stockTakes.getContent()));
    }

    @RolesAllowed("ROLE_STOCK_ADJUSTMENT_APPROVAL")
    @PostMapping("/list/adjustment/byCriteria/{page}/{size}")
    HttpEntity<ApiResponse> listAdjustmentByCriteria(@RequestBody StockTakeSearchDTO searchDTO,
                                                     @PathVariable("page") int page,
                                                     @PathVariable("size") int size,
                                                     Principal principal) {
        logger.info("List stock take of start date from[" + searchDTO.getStartDateFrom() + "] to[" + searchDTO.getStartDateFrom() + "] from the system by [" + principal.getName() + "]");

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "startDate"));

        Page<StockTake> stockTakes = stockTakeService.listAllAdjustment(searchDTO, pageable);

        int totalElements = (int) stockTakes.getTotalElements();
        int totalPage = stockTakes.getTotalPages();
        int pageNumber = stockTakes.getNumber();

        return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, stockTakes.getContent()));
    }

    @RolesAllowed("ROLE_STOCK_ADJUSTMENT_APPROVAL")
    @PostMapping("/isExceeds/stock-adjustment/{stockTakeId}/{stockCountItemId}")
    HttpEntity<ApiResponse> isStockAdjQuantityExceedsLimit(@PathVariable("stockTakeId") String stockTakeId,
                                                           @PathVariable("stockCountItemId") String stockCountItemId, Principal principal) {
        logger.info("Check quantity adjustment of Stock Count Item[" + stockCountItemId + "] of stock take[" + stockTakeId + "] is exceeded");

        try {
            boolean isExceeds = stockTakeService.isStockAdjQuantityExceedsLimit(stockTakeId, stockCountItemId);
            Map<String, Object> res = new HashMap<>();
            res.put("isExceeds", isExceeds);
            return httpApiResponse(new HttpApiResponse(res));
        } catch (CMSException e) {
            logger.error("Approve Adjust Stock Item throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @RolesAllowed("ROLE_STOCK_ADJUSTMENT_APPROVAL")
    @PostMapping("/submit/approve/stock-adjustment/{stockTakeId}")
    HttpEntity<ApiResponse> submitApproveStockAdjustment(@PathVariable("stockTakeId") String stockTakeId,
                                                         @RequestBody() StockCountItem stockCountItem, Principal principal) {
        logger.info("Approve quantity adjustment of Stock Item which is in Stock Take[" + stockTakeId + "] and update Stock Count Item[" + stockCountItem + "] details");

        try {
            boolean approved = stockTakeService.approveAdjustStockItems(stockTakeId, stockCountItem);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Approve Adjust Stock Item throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @RolesAllowed("ROLE_STOCK_ADJUSTMENT_APPROVAL")
    @PostMapping("/submit/reject/stock-adjustment/{stockTakeId}")
    HttpEntity<ApiResponse> submitRejectStockAdjustment(@PathVariable("stockTakeId") String stockTakeId,
                                                        @RequestBody() StockCountItem stockCountItem, Principal principal) {

        logger.info("Reject quantity adjustment of Stock Item which is in Stock Take[" + stockTakeId + "] and update Stock Count Item[" + stockCountItem + "] details");
        try {
            boolean rejected = stockTakeService.rejectAdjustStockItems(stockTakeId, stockCountItem);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Reject Adjust Stock Item throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/start/stock-take/{clinicId}")
    HttpEntity<ApiResponse> startStockTake(@PathVariable("clinicId") String clinicId,
                                           @RequestBody StockTake stockTake,
                                           Principal principal) {

        logger.info("Start stock take from the system by [" + principal.getName() + "]");
        try {
            StockTake newStockTake = stockTakeService.createStockTake(clinicId, stockTake.getStartDate(),
                    stockTake.getStartTime(), stockTake.getCountName(), stockTake.getCountType(), stockTake.getStartRange(),
                    stockTake.getEndRange(), stockTake.getItemStockTakeRange());
            return httpApiResponse(new HttpApiResponse(newStockTake));
        } catch (CMSException e) {
            logger.error("startStockTake throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/stop/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> stopCountStockTake(@PathVariable("stockTakeId") String stockTakeId,
                                               @RequestBody List<StockCountItem> stockCountItems,
                                               Principal principal) {

        logger.info("Stop stock take by id[" + stockTakeId + "], stockCountItems[" + stockCountItems + "] from the system by [" + principal.getName() + "]");
        try {
            StockTake stockTake = stockTakeService.stopCountStockTake(stockTakeId, stockCountItems);
            return httpApiResponse(new HttpApiResponse(stockTake));
        } catch (CMSException e) {
            logger.error("stopCountStockTake throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/submit/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> submitStockTakeForReview(@PathVariable("stockTakeId") String stockTakeId,
                                                     Principal principal) {

        logger.info("Submit stock take[" + stockTakeId + "] from the system by [" + principal.getName() + "]");
        try {
            StockTake stockTake = stockTakeService.submitStockTakeForReview(stockTakeId);
            return httpApiResponse(new HttpApiResponse(stockTake));
        } catch (CMSException e) {
            logger.error("submitStockTakeForReview throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/get/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> getStockTakeForReview(@PathVariable("stockTakeId") String stockTakeId,
                                                  Principal principal) {

        logger.info("Get stock take[" + stockTakeId + "] from the system by [" + principal.getName() + "]");
        try {
            StockTake stockTake = stockTakeService.getStockTake(stockTakeId);
            return httpApiResponse(new HttpApiResponse(stockTake));
        } catch (CMSException e) {
            logger.error("submitStockTakeForReview throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> approveStockTake(@PathVariable("stockTakeId") String stockTakeId, Principal principal) {
        //TODO Handle reporting when using for Item Movement Report
        logger.info("Approve stock take from the system by [" + principal.getName() + "]");
        try {
            boolean isSuccess = stockTakeService.approveStockTake(stockTakeId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("approveStockTake throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/reject/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> rejectStockTake(@PathVariable("stockTakeId") String stockTakeId, Principal principal) {

        logger.info("Reject stock take from the system by [" + principal.getName() + "]");
        try {
            stockTakeService.rejectStockTake(stockTakeId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("rejectStockTake throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/stock-count-item")
    HttpEntity<ApiResponse> approveStockCountItem(@RequestBody List<StockCountItemEntity> stockCountItemEntities, Principal principal) {
        logger.info("Approve stock count items from the mgmt by [" + principal.getName() + "]");
        try {
            List<StockCountItemEntity> stockCountItems = stockTakeService.approveOrRejectStockTake(
                    stockCountItemEntities, StockCountItemStatus.APPROVED);
            return httpApiResponse(new HttpApiResponse(stockCountItems));
        } catch (CMSException e) {
            logger.error("rejectStockCountItem throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/reject/stock-count-item")
    HttpEntity<ApiResponse> rejectStockCountItem(@RequestBody List<StockCountItemEntity> stockCountItemEntities, Principal principal) {
        logger.info("Reject stock count items from the mgmt by [" + principal.getName() + "]");
        try {
            List<StockCountItemEntity> stockCountItems = stockTakeService.approveOrRejectStockTake(
                    stockCountItemEntities, StockCountItemStatus.REJECTED);
            return httpApiResponse(new HttpApiResponse(stockCountItems));
        } catch (CMSException e) {
            logger.error("rejectStockCountItem throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/stock-count-items-of-zero-variance")
    HttpEntity<ApiResponse> approveStockCountItemsOfZeroVariance(Principal principal) {
        logger.info("Approve stock count items which has zero variance from the mgmt by [" + principal.getName() + "]");
        try {
            List<StockCountItemEntity> stockCountItemEntities = stockTakeService.approveStockCountItemsOfZeroVariance();
            return httpApiResponse(new HttpApiResponse(stockCountItemEntities));
        } catch (CMSException e) {
            logger.error("approveStockCountItemOfZeroVariance throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> deleteStockTake(@PathVariable("stockTakeId") String stockTakeId, Principal principal) {

        logger.info("Delete stock take from the system by [" + principal.getName() + "]");

        try {
            stockTakeService.deleteStockTake(stockTakeId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("deleteStockTake throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/expired-stock/{clinicId}")
    HttpEntity<ApiResponse> listExpiredStock(@PathVariable("clinicId") String clinicId, Principal principal) {

        logger.info("List expired stock from the system by [" + principal.getName() + "]");
        List<InventoryDetail> expiredStock = stockTakeService.getExpiredStock(clinicId);
        return httpApiResponse(new HttpApiResponse(expiredStock));
    }

    @PostMapping("/list/disposed-stock/{clinicId}")
    HttpEntity<ApiResponse> listDisposedStock(@PathVariable("clinicId") String clinicId, Principal principal) {

        logger.info("List disposed stock from the system by [" + principal.getName() + "]");
        List<InventoryDetail> disposedStock = stockTakeService.getDisposedStock(clinicId);
        return httpApiResponse(new HttpApiResponse(disposedStock));
    }

    @PostMapping("/list/adjustment/reason")
    HttpEntity<ApiResponse> listAdjustmentReason() {

        logger.info("listAdjustmentReason");
        List<Reason> reasons = systemConfigService.listAdjustmentReason();
        return httpApiResponse(new HttpApiResponse(reasons));
    }

    @PostMapping("/retry/nav/adjustment/{stockTakeId}")
    HttpEntity<ApiResponse> retrySaveStockAdjustmentToNav(@PathVariable("stockTakeId") String stockTakeId) {

        logger.info("retrySaveStockAdjustmentToNav stockTakeId[" + stockTakeId + "]");
        try {
            validateStockTakeFailedStatus(stockTakeId);
            stockTakeService.createNavStockAdjustment(stockTakeId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retrySaveStockAdjustmentToNav throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/stock-take/{stockTakeId}")
    HttpEntity<ApiResponse> retrySaveStockTakeToNav(@PathVariable("stockTakeId") String stockTakeId) {

        logger.info("retrySaveStockTakeToNav stockTakeId[" + stockTakeId + "]");
        try {
            validateStockTakeFailedStatus(stockTakeId);
            stockTakeService.createNavStockTake(stockTakeId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retrySaveStockTakeToNav throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    private void validateStockTakeFailedStatus(String stockTakeId) throws CMSException {
        StockTake stockTake = stockTakeService.getStockTake(stockTakeId);
        if (stockTake.getNavIntegrationResult() == null || stockTake.getNavIntegrationResult().getStatus() != NavIntegrationResult.ResultStatus.FAILED) {
            throw new CMSException(StatusCode.E1010, "Unable to retry if nav integration did not fail");
        }
    }

    private Map<String, Object> mapToPageData(List<? extends Object> dataList, int page, int size) {
        Map<String, Object> dataMap = new HashMap<>();
        int listSize = dataList.size();
        int startIndex;
        int endIndex;
        int lastPageSize = listSize % size;
        int totalPage = listSize / size + (lastPageSize == 0 ? 0 : 1);
        startIndex = page * size;
        endIndex = (startIndex + size) >= listSize ? listSize : startIndex + size;
        List<? extends Object> returnObjects;
        if (startIndex >= listSize) {
            logger.warn("return empty content due to startIndex[" + startIndex + "] greater than lastPageSize[" + lastPageSize + "]");
            returnObjects = new ArrayList<>();
        } else {
            returnObjects = dataList.subList(startIndex, endIndex);
        }
        logger.debug("startIndex[" + startIndex + "], endIndex[" + endIndex + "], lastPageSize[" + lastPageSize + "], totalPage[" +
                totalPage + "], listSize[" + listSize + "]");
        dataMap.put(CMSConstant.PAYLOAD_KEY_CONTENT, returnObjects);
        dataMap.put(CMSConstant.PAYLOAD_KEY_PAGE_NUMBER, page);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_PAGES, totalPage);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_ELEMENTS, listSize);
        return dataMap;
    }

    private ItemInventory mapToItemInventory(String itemId, List<ApiInventory> inventories, String clinicId,
                                             List<Inventory> existingInventories, Map<String, List<ItemExtraDetails>> itemClinicDetailMap) {
        String itemCode = null;
        String itemName = null;
        if (inventories != null && inventories.size() > 0) {
            itemCode = inventories.get(0).getItemCode();
            itemName = inventories.get(0).getItemName();
        }
        //calculate average purchase price
        BigDecimal purchasePriceAvg = calculateAveragePurchasePrice(inventories);

        boolean isLowStockLevel = false;
        int reorderPoint = 0;
        BigDecimal bufferStockLevel = null;
        Map<String, Integer> itemIdInventoryStockMap = getClinicInventoryStockMap(existingInventories);

        if (itemClinicDetailMap.get(itemId) != null) {
            Optional<ItemExtraDetails> itemExtraDetailsOpt = itemClinicDetailMap.get(itemId).stream()
                    .filter(itemExtraDetails1 -> itemExtraDetails1.getClinicId().equals(clinicId))
                    .findFirst();

            if (itemExtraDetailsOpt.isPresent()) {
                ItemExtraDetails itemExtraDetails = itemExtraDetailsOpt.get();
                reorderPoint = itemExtraDetails.getReorderPoint();
                bufferStockLevel = itemExtraDetails.getBufferStockLevel();
                if (itemIdInventoryStockMap.get(itemId) != null) {
                    Integer totalStockLevel = itemIdInventoryStockMap.get(itemId);
                    if (totalStockLevel != null && reorderPoint > totalStockLevel) {
                        isLowStockLevel = true;
                    }
                }
            }
        }
        return new ItemInventory(itemId, itemName, itemCode, inventories, isLowStockLevel, bufferStockLevel, reorderPoint, purchasePriceAvg);
    }

    private BigDecimal calculateAveragePurchasePrice(List<ApiInventory> inventories) {
        final List<ApiInventory> priceAvailableInventory = inventories.stream()
                .filter(inv -> inv.getPurchasePrice() != null && inv.getPurchasePrice().compareTo(BigDecimal.ZERO) > 0)
                .collect(Collectors.toList());

        final BigDecimal totalInventoryValue = priceAvailableInventory.stream()
                .map(inv -> inv.getPurchasePrice())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal purchasePriceAvg = priceAvailableInventory.size() > 0 ?
                totalInventoryValue.divide(new BigDecimal(priceAvailableInventory.size()), 4, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        return purchasePriceAvg;
    }

    private ApiInventory mapToApiInventory(Inventory inventory, List<ItemExtraDetails> itemExtraDetails) {
        BigDecimal purchasePrice = inventory.getBatchPrice() == null ? BigDecimal.ZERO : inventory.getBatchPrice();
        return new ApiInventory(inventory.getInventoryId(), inventory.getItemRefId(), inventory.getItemName(),
                inventory.getItemCode(), inventory.getBatchNumber(), inventory.getBaseUom(), inventory.getManufacturerDate(),
                inventory.getExpiryDate(), inventory.getAvailableCountInt(), inventory.getBaseUomQuantity(), purchasePrice);
    }

    private Map<String, Integer> getClinicInventoryStockMap(List<Inventory> inventories) {

        Map<String, List<Inventory>> itemInventoryMap;

        itemInventoryMap = inventories.stream().collect(Collectors.groupingBy(Inventory::getItemRefId));

        Map<String, Integer> itemStockLevelMap = new HashMap<>();

        itemInventoryMap.keySet().forEach(
                key -> {
                    itemInventoryMap.compute(key, (itemId, inventoryList) -> {

                        itemStockLevelMap.put(itemId, inventoryList.stream()
                                .filter(inventory -> inventory.getExpiryDate() == null || inventory.getExpiryDate().isAfter(LocalDate.now()))
                                .mapToInt(Inventory::getAvailableCountInt)
                                .sum());
                        return inventoryList;
                    });
                }
        );
        return itemStockLevelMap;
    }
}
