package com.ilt.cms.inventory.rest.uom;

import com.ilt.cms.core.entity.item.UomMatrix;
import com.ilt.cms.inventory.svc.model.common.UomMatrixResultEntity;
import com.ilt.cms.inventory.svc.model.common.UomMatrixSearchEntity;
import com.ilt.cms.inventory.svc.model.common.UomConversionRequest;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.bouncycastle.cms.CMSRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.List;
import java.util.Map;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/uom-matrix")
@RolesAllowed("ROLE_UOM_MATRIX")
public class UOMMatrixRestController {
    private static final Logger logger = LoggerFactory.getLogger(UOMMatrixRestController.class);

    private UOMMatrixService uomMatrixService;

    public UOMMatrixRestController(UOMMatrixService uomMatrixService) {
        this.uomMatrixService = uomMatrixService;

    }

    @PostMapping("/search/ratio/{sourceUom}/{destinationUom}")
    HttpEntity<ApiResponse> findReverseRatio(@PathVariable("sourceUom") String sourceUom,
                                      @PathVariable("destinationUom") String destinationUom,
                                      Principal principal) {

        logger.info("findReverseRatio by sourceUom[" + sourceUom + "] to destinationUom[" + destinationUom + "] by system user[" + principal.getName() + "]");
        try {
            double ratio = uomMatrixService.findReverseRatio(sourceUom, destinationUom);
            return httpApiResponse(new HttpApiResponse(ratio));
        } catch (CMSException e) {
            logger.error("findReverseRatio throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/create/uom-matrix")
    HttpEntity<ApiResponse> createUOMMatrix(@RequestBody UomMatrix uomMatrix, Principal principal) {

        logger.info("createUOMMatrix[" + uomMatrix + "] by system user[" + principal.getName() + "]");
        try {
            UomMatrix newUOMatrix = uomMatrixService.saveUOMMatrix(uomMatrix);
            return httpApiResponse(new HttpApiResponse(newUOMatrix));
        } catch (CMSException e) {
            logger.error("createUOMMatrix throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

	@PostMapping("/search-multiple/ratio")
	HttpEntity<ApiResponse> findReverseRatio(@RequestBody List<UomMatrixSearchEntity> searchEntityList,
											 Principal principal) {
		logger.info("findReverseRatio by multiple search[" + searchEntityList + "] by system user[" + principal.getName() + "]");
		try {
			List<UomMatrixResultEntity> uomMatrixResultEntityList = uomMatrixService.findReverseRatio(searchEntityList);
			return httpApiResponse(new HttpApiResponse(uomMatrixResultEntityList));
		} catch(CMSRuntimeException e) {
			logger.error("findReverseRatio by multiple search throw error", e);
			return httpApiResponse(new HttpApiResponse(e.getMessage()));
		}
	}
}
