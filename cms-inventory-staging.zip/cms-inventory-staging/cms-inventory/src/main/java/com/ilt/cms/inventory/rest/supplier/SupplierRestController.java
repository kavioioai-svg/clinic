package com.ilt.cms.inventory.rest.supplier;

import com.ilt.cms.api.entity.supplier.SupplierEntity;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.inventory.mapper.SuppliersMapper;
import com.ilt.cms.inventory.model.SearchParam;
import com.ilt.cms.inventory.model.SupplierItemApiEntityContainer;
import com.ilt.cms.inventory.model.SupplierItemContainer;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.inventory.svc.service.supplier.SupplierService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.util.*;
import java.util.stream.Collectors;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/supplier")
@RolesAllowed({"ROLE_VIEW_SUPPLIER_NAV"})
public class SupplierRestController {

    private static final Logger logger = LoggerFactory.getLogger(SupplierRestController.class);

    private SupplierService supplierService;
    private LocationService locationService;

    public SupplierRestController(SupplierService supplierService, LocationService locationService) {
        this.supplierService = supplierService;
        this.locationService = locationService;
    }

    @PostMapping("/list/all")
    public HttpEntity<ApiResponse> listAll(Principal principal) {

        logger.info("Listing all suppliers for user [" + principal.getName() + "]");
        List<Supplier> suppliers = supplierService.findAll();
        return httpApiResponse(new HttpApiResponse(suppliers));
    }

    @PostMapping("/get/{supplierId}")
    public HttpEntity<ApiResponse> findSupplierById(@PathVariable("supplierId") String supplierId, Principal principal) {

        logger.info("Find supplier by id[" + supplierId + "] by system [" + principal.getName() + "]");
        try {
            Supplier supplier = supplierService.findSupplierById(supplierId);
            return httpApiResponse(new HttpApiResponse(supplier));
        } catch (CMSException e) {
            logger.error("Find supplier by id throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/get/item/{itemId}")
    public HttpEntity<ApiResponse> findSupplierByItemId(@PathVariable("itemId") String itemId, Principal principal) {

        logger.info("Find supplier by item id[" + itemId + "] by system [" + principal.getName() + "]");
        List<Supplier> suppliers = supplierService.findSupplierByItem(itemId);
        return httpApiResponse(new HttpApiResponse(suppliers));
    }

    @PostMapping("/get/item/{clinicId}/{itemId}/{uom}")
    public HttpEntity<ApiResponse> findSupplierByItemId(@PathVariable("clinicId") String clinicId,
                                                        @PathVariable("itemId") String itemId,
                                                        @PathVariable("uom") String uom, Principal principal) {

        logger.info("Find supplier by item id[" + itemId + "], uom[" + uom + "], clinicId[" + clinicId + "] by system [" + principal.getName() + "]");
        try {
            List<Supplier> suppliers = supplierService.findSupplierByItem(itemId);
            Map<String, String> itemIdUomMap = new HashMap<>();
            itemIdUomMap.put(itemId, uom);
            Map<String, Double> itemIdQtyMap = locationService.findInventoryQuantityByClinicIdAndItemCodeAndUom(clinicId, itemIdUomMap);
            double totalQuantity = itemIdQtyMap.get(itemId) == null ? 0 : itemIdQtyMap.get(itemId);
            return httpApiResponse(new HttpApiResponse(new SupplierItemContainer(itemId, suppliers, BigDecimal.valueOf(totalQuantity).setScale(2, RoundingMode.HALF_UP))));
        } catch (CMSException e) {
            logger.error("Find supplier by id throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

	@PostMapping("/list-by-items/{clinicId}")
	public HttpEntity<ApiResponse> findSupplierByItemIdList(@PathVariable("clinicId") String clinicId,
															@RequestBody List<SearchParam.SupplierSearch> searchParams,
															Principal principal) {
		logger.info("Find supplier by item id list [" + searchParams + "], clinicId[" + clinicId + "] by system [" + principal.getName() + "]");
		try {
			Set<String> itemIds = searchParams.stream()
				.map(SearchParam.SupplierSearch::getItemId)
				.collect(Collectors.toSet());

			List<Supplier> suppliers = supplierService.listSupplierWithLimitedFieldsByItems(List.copyOf(itemIds), Status.ACTIVE);

			Map<String, String> itemIdUomMap = searchParams.stream()
				.collect(Collectors.toMap(SearchParam.SupplierSearch::getItemId, SearchParam.SupplierSearch::getUom));
			Map<String, Double> itemIdQtyMap = locationService.findInventoryQuantityByClinicIdAndItemCodeAndUom(clinicId, itemIdUomMap);

			List<SupplierItemApiEntityContainer> supplierItemContainers = new ArrayList<>();

			for (SearchParam.SupplierSearch searchParam : searchParams) {
				double totalQuantity = itemIdQtyMap.get(searchParam.getItemId()) == null ? 0 : itemIdQtyMap.get(searchParam.getItemId());
				List<SupplierEntity> curItemSuppliers = new ArrayList<>();

				supplierService.filterSuppliersByItemId(suppliers, searchParam.getItemId())
					.forEach(supplier -> {
						SupplierEntity supplierEntity = SuppliersMapper.mapToEntity(supplier);
						supplierEntity.setSupplierPurchaseItems(Set.of(searchParam.getItemId()));
						curItemSuppliers.add(supplierEntity);
					});

				supplierItemContainers.add(new SupplierItemApiEntityContainer(searchParam.getItemId(), curItemSuppliers,
					BigDecimal.valueOf(totalQuantity).setScale(2, RoundingMode.HALF_UP)));
			}

			return httpApiResponse(new HttpApiResponse(supplierItemContainers));
		} catch (CMSException e) {
			logger.error("Find supplier by list of items throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
			return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
		}
	}

    @PostMapping("/list-by-items")
    public HttpEntity<ApiResponse> findSupplierByItemIds(@RequestBody List<String> itemIds, Principal principal) {
        logger.info("Find supplier by item ids[" + itemIds.size() + "] by system [" + principal.getName() + "]");

        List<Supplier> suppliers = supplierService.findSupplierByItems(itemIds);
        return httpApiResponse(new HttpApiResponse(suppliers));
    }
}
