package com.ilt.cms.inventory.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ItemInventory {

    private String itemId;

    private String itemName;

    private String itemCode;

    private List<ApiInventory> inventories = new ArrayList<>();

    private boolean isLowStockLevel;

    private BigDecimal bufferStockLevel;

    private int reorderPoint;

    private BigDecimal purchasePriceAvg;

    public ItemInventory(String itemId, String itemName, String itemCode, List<ApiInventory> inventories, boolean isLowStockLevel,
                         BigDecimal bufferStockLevel, int reorderPoint, BigDecimal purchasePriceAvg) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.inventories = inventories;
        this.isLowStockLevel = isLowStockLevel;
        this.bufferStockLevel = bufferStockLevel;
        this.reorderPoint = reorderPoint;
        this.purchasePriceAvg = purchasePriceAvg;
    }

    public String getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemCode() {
        return itemCode;
    }

    public List<ApiInventory> getInventories() {
        return inventories;
    }

    public boolean isLowStockLevel() {
        return isLowStockLevel;
    }

    public BigDecimal getBufferStockLevel() {
        return bufferStockLevel;
    }

    public int getReorderPoint() {
        return reorderPoint;
    }

    public BigDecimal getPurchasePriceAvg() {
        return purchasePriceAvg;
    }
}
