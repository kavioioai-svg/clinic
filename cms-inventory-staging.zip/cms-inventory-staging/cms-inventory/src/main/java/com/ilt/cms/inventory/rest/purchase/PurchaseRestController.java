package com.ilt.cms.inventory.rest.purchase;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.item.ItemClinicDetail;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.inventory.email.EmailSender;
import com.ilt.cms.inventory.model.OrderSupplierContainer;
import com.ilt.cms.inventory.model.PurchaseRequestSupplierContainer;
import com.ilt.cms.inventory.model.ReturnItemContainer;
import com.ilt.cms.inventory.svc.model.common.Reason;
import com.ilt.cms.inventory.svc.model.common.UomConversionRequest;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.api.PurchaseOrderPrint;
import com.ilt.cms.inventory.svc.model.purchase.api.PurchaseRequestItemViewFilter;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.service.common.ItemClinicDetailService;
import com.ilt.cms.inventory.svc.service.common.SystemConfigService;
import com.ilt.cms.inventory.svc.service.nav.NavPurchaseService;
import com.ilt.cms.inventory.svc.service.purchase.OrderService;
import com.ilt.cms.inventory.svc.service.purchase.RequestService;
import com.ilt.cms.inventory.svc.service.supplier.SupplierService;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.util.Tuple;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.bouncycastle.cms.CMSRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/purchase")
@RolesAllowed({ "ROLE_PURCHASE_NAV" })
public class PurchaseRestController {

    private static final Logger logger = LoggerFactory.getLogger(PurchaseRestController.class);

    private OrderService orderService;

    private RequestService requestService;

    private SystemConfigService systemConfigService;

    private ItemClinicDetailService itemClinicDetailService;

    private SupplierService supplierService;

    private NavPurchaseService navPurchaseService;

    private EmailSender emailSender;

    public PurchaseRestController(OrderService orderService, RequestService requestService, SystemConfigService systemConfigService,
                                  ItemClinicDetailService itemClinicDetailService, SupplierService supplierService,
                                  NavPurchaseService navPurchaseService, EmailSender emailSender) {
        this.orderService = orderService;
        this.requestService = requestService;
        this.systemConfigService = systemConfigService;
        this.itemClinicDetailService = itemClinicDetailService;
        this.supplierService = supplierService;
        this.navPurchaseService = navPurchaseService;
        this.emailSender = emailSender;
    }

    @PostMapping("/get/request/{requestId}")
    HttpEntity<ApiResponse> findRequestById(@PathVariable("requestId") String requestId,
                                            Principal principal) {

        logger.info("find request By id[" + requestId + "] from the system by [" + principal.getName() + "]");
        try {
            PurchaseRequest request = requestService.findRequestById(requestId);
            Map<String, List<String>> supplierItems = new HashMap<>();
            request.getRequestItems()
                    .forEach(requestItem -> supplierItems.computeIfAbsent(requestItem.getSupplierId(), supplierId -> new ArrayList<>()).add(requestItem.getItemRefId()));
            List<Supplier> suppliers = supplierService.findSupplierByIds(new ArrayList<>(supplierItems.keySet()));
            return httpApiResponse(new HttpApiResponse(new PurchaseRequestSupplierContainer(request, filterSupplierItems(suppliers, supplierItems))));
        } catch (CMSException e) {
            logger.error("Reject purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/request/{clinicId}")
    HttpEntity<ApiResponse> findRequestByClinicId(@PathVariable("clinicId") String clinicId, Principal principal) {

        logger.info("findRequestByClinicId[" + clinicId + "] from the system by [" + principal.getName() + "]");
        List<PurchaseRequest> purchaseRequests = requestService.listPurchaseRequestByClinicId(clinicId);
        return httpApiResponse(new HttpApiResponse(purchaseRequests));
    }

    @PostMapping("/create/request")
    HttpEntity<ApiResponse> createRequest(@RequestBody PurchaseRequest request, Principal principal) {

        logger.info("Create request from the system by [" + principal.getName() + "]");

        try {
            request.setUserName(principal.getName());
            PurchaseRequest purchaseRequest = requestService.createPurchaseRequest(request);
            return httpApiResponse(new HttpApiResponse(purchaseRequest));
        } catch (CMSException e) {
            logger.error("Create purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/request/{requestId}")
    HttpEntity<ApiResponse> modifyRequest(@PathVariable("requestId") String requestId,
                                          @RequestBody PurchaseRequest purchaseRequest, Principal principal) {

        logger.info("Modify request from the system by [" + principal.getName() + "]");

        try {
            purchaseRequest.setUserName(principal.getName());
            PurchaseRequest modifiedRequest = requestService.modifyPurchaseRequest(requestId, purchaseRequest);
            return httpApiResponse(new HttpApiResponse(modifiedRequest));
        } catch (CMSException e) {
            logger.error("Modify request throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/request/{requestId}")
    HttpEntity<ApiResponse> modifyRequest(@PathVariable("requestId") String requestId, Principal principal) {

        logger.info("Delete request from the system by [" + principal.getName() + "]");
        try {
            requestService.deletePurchaseRequest(requestId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Delete request throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/request/{requestId}")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> approvePurchaseRequest(@PathVariable("requestId") String requestId,
                                                   @RequestBody PurchaseRequest purchaseRequest, Principal principal) {

        logger.info("Approve request[" + requestId + "] from the system by [" + principal.getName() + "]");

        try {
            requestService.approvePurchaseRequest(requestId, purchaseRequest);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Approve purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/reject/request/{requestId}")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> rejectPurchaseRequest(@PathVariable("requestId") String requestId, Principal principal) {

        logger.info("Reject request[" + requestId + "] from the system by [" + principal.getName() + "]");

        try {
            requestService.rejectPurchaseRequest(requestId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Reject purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/requests/reject")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> rejectPurchaseRequests(@RequestBody List<PurchaseRequestItemView> purchaseRequestItemViewList, Principal principal) {

        logger.info("Reject requests by request item view[" + purchaseRequestItemViewList + "] from the system by [" + principal.getName() + "]");

        try {
            requestService.rejectPurchaseRequests(purchaseRequestItemViewList);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Reject purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/get/order/{orderId}")
    HttpEntity<ApiResponse> findOrderById(@PathVariable("orderId") String orderId,
                                          Principal principal) {

        logger.info("find order By id[" + orderId + "] from the system by [" + principal.getName() + "]");
        try {
            Order order = orderService.findOrderById(orderId);
            List<String> orderItemIds = new ArrayList<>();
            orderItemIds.addAll(order.getGoodPurchasedItems().stream().map(GoodOrderedItem::getItemRefId).collect(Collectors.toList()));
            orderItemIds.addAll(order.getTransferRequestItems().stream().map(TransferRequestItem::getItemRefId).collect(Collectors.toList()));
            List<Supplier> suppliers = supplierService.findSupplierByItems(orderItemIds);
            Map<String, Double> backOrderCounts = orderService.findBackOrderCounts(order);
            return httpApiResponse(new HttpApiResponse(new OrderSupplierContainer(order, filterSupplierItems(suppliers, orderItemIds), backOrderCounts)));
        } catch (CMSException e) {
            logger.error("Reject purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }



    @PostMapping("/uom/convert")
    HttpEntity<ApiResponse> convertUom(Principal principal, @RequestBody List<UomConversionRequest> requests) {
        logger.info("findReverseRatios by multiple search[" + requests + "] by system user[" + principal.getName() + "]");
        try {
            Map<String, BigDecimal> ratioMap = orderService.convertUom(requests);
            return httpApiResponse(new HttpApiResponse(ratioMap));
        } catch (CMSRuntimeException | ExecutionException | CMSException e) {
            logger.error("findReverseRatios by multiple search throw error", e);
            return httpApiResponse(new HttpApiResponse(e.getMessage()));
        }
    }

    @PostMapping("/get/backorder-count/{orderType}/{orderId}/{itemRefId}/{clinicId}")
    HttpEntity<ApiResponse> findBackOrderCountByItemRefIdAndClinicId(@PathVariable("itemRefId") String itemRefId,
                                                                     @PathVariable("orderType") String orderType,
                                                                     @PathVariable("clinicId") String clinicId,
                                                                     @PathVariable("orderId") String orderId,
                                                                     Principal principal) {

        logger.info("find back order count By itemRefId[" + itemRefId + "] and clinicId[" + clinicId + "] from the system by [" + principal.getName() + "]");
        Map<String, Double> backOrderCount = orderService.findBackOrderCount(Collections.singleton(itemRefId), clinicId, orderId, OrderType.valueOf(orderType));
        return httpApiResponse(new HttpApiResponse(backOrderCount.getOrDefault(itemRefId, 0D)));

    }

    @PostMapping("/get/grvn/{orderId}")
    HttpEntity<ApiResponse> findReturnOrderById(@PathVariable("orderId") String orderId,
                                                Principal principal) {

        logger.info("find order By id[" + orderId + "] from the system by [" + principal.getName() + "]");
        try {
            Order returnOrder = orderService.findReturnOrderByOrderId(orderId);
            String purchaseOrderId = returnOrder.getPurchaseOrderId();
            if (CommonUtils.isStringValid(purchaseOrderId)) {
                Optional<Order> purchaseOrderOpt = orderService.findPurchaseOrderByIds(new ArrayList<>(List.of(purchaseOrderId))).stream()
                        .findFirst();
                if (purchaseOrderOpt.isPresent()) {
                    returnOrder.setPoNo(purchaseOrderOpt.get().getOrderNo());
                    returnOrder.setPoDate(purchaseOrderOpt.get().getOrderDate());
                }
            }
            return httpApiResponse(new HttpApiResponse(returnOrder));
        } catch (CMSException e) {
            logger.error("Reject purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/add/grn/{orderId}")
    HttpEntity<ApiResponse> addGoodReceivedNote(@PathVariable("orderId") String orderId,
                                                @RequestBody GoodReceivedNote goodReceivedNote, Principal principal) {

        logger.info("Add goodReceivedNote to order[" + orderId + "], goodReceiveNote[" + goodReceivedNote + "] from the system by [" +
                principal.getName() + "]");

        try {
            goodReceivedNote.setUserId(principal.getName());
            //goodReceivedNote.setUserId("ca.nd");
            GoodReceivedNote savedReceiveNote = orderService.addGoodReceivedNote(orderId, goodReceivedNote);
            return httpApiResponse(new HttpApiResponse(savedReceiveNote));
        } catch (CMSException e) {
            logger.error("Add goodReceivedNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/alter/grn/{orderId}/{grnId}/{revert}")
    HttpEntity<ApiResponse> revertGoodReceivedNote(@PathVariable("orderId") String orderId,
                                                   @PathVariable("grnId") String grnId, @PathVariable("revert") boolean revert,
                                                   Principal principal) {

        logger.info("Revert goodReceivedNote of order[" + orderId + "], grn id[" + grnId + "] from the system by [" +
                principal.getName() + "]" + " reverting : " + revert);
        try {
            orderService.revertGoodReceivedNote(orderId, grnId, revert);
            return httpApiResponse(new HttpApiResponse("Successfully reverted GRN inventory"));
        } catch (CMSException e) {
            logger.error("Add goodReceivedNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/grn/{orderId}/{grnId}")
    HttpEntity<ApiResponse> updateGoodReceivedNote(@PathVariable("orderId") String orderId,
                                                   @PathVariable("grnId") String grnId,
                                                   @RequestBody GoodReceivedNote goodReceivedNote, Principal principal) {

        logger.info("Update goodReceivedNote to order[" + orderId + "], goodReceiveNote[" + goodReceivedNote +
                "] from the system by [" + principal.getName() + "]");

        try {
            goodReceivedNote.setUserId(principal.getName());
            //goodReceivedNote.setUserId("ca.nd");
            GoodReceivedNote savedReceiveNote = orderService.updateGoodReceivedNote(orderId, grnId, goodReceivedNote);
            return httpApiResponse(new HttpApiResponse(savedReceiveNote));
        } catch (CMSException e) {
            logger.error("Update goodReceivedNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/add/grvn/{requestClinicId}/{supplierId}/{returnOrderStatus}")
    HttpEntity<ApiResponse> addReturnOrder(@PathVariable("requestClinicId") String clinicId,
                                           @PathVariable("supplierId") String supplierId,
                                           @PathVariable("returnOrderStatus") GoodReceivedReturnStatus status,
                                           @RequestBody ReturnItemContainer returnItemContainer, Principal principal) {

        logger.info("Add goodReceivedVoidNote to request clinicId[" + clinicId + "] status[" + status + "], returnItemContainer[" + returnItemContainer +
                "] from the system by [" + principal.getName() + "]");

        try {

            Order returnOrder = orderService.createReturnOrder(clinicId, supplierId, returnItemContainer.getPurchaseOrderId(), status, returnItemContainer.getReturnItems());
            String purchaseOrderId = returnOrder.getPurchaseOrderId();
            if (CommonUtils.isStringValid(purchaseOrderId)) {
                Optional<Order> purchaseOrderOpt = orderService.findPurchaseOrderByIds(new ArrayList<>(List.of(purchaseOrderId))).stream()
                        .findFirst();
                if (purchaseOrderOpt.isPresent()) {
                    returnOrder.setPoNo(purchaseOrderOpt.get().getOrderNo());
                    returnOrder.setPoDate(purchaseOrderOpt.get().getOrderDate());
                }
            }

            return httpApiResponse(new HttpApiResponse(returnOrder));
        } catch (CMSException e) {
            logger.error("Add return order throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/grvn/{orderId}/{supplierId}/{returnOrderStatus}")
    HttpEntity<ApiResponse> updateReturnOrder(@PathVariable("orderId") String orderId,
                                              @PathVariable("supplierId") String supplierId,
                                              @PathVariable("returnOrderStatus") GoodReceivedReturnStatus status,
                                              @RequestBody ReturnItemContainer returnItemContainer, Principal principal) {

        logger.info("Update goodReceivedVoidNote to order[" + orderId + "], status[" + status + "] returnItems[" + returnItemContainer +
                "] from the system by [" + principal.getName() + "]");

        try {

            Order returnOrder = orderService.updateReturnOrder(orderId, supplierId, status, returnItemContainer.getReturnItems());

            String purchaseOrderId = returnOrder.getPurchaseOrderId();
            if (CommonUtils.isStringValid(purchaseOrderId)) {
                Optional<Order> purchaseOrderOpt = orderService.findPurchaseOrderByIds(new ArrayList<>(List.of(purchaseOrderId))).stream()
                        .findFirst();
                if (purchaseOrderOpt.isPresent()) {
                    returnOrder.setPoNo(purchaseOrderOpt.get().getOrderNo());
                    returnOrder.setPoDate(purchaseOrderOpt.get().getOrderDate());
                }
            }

            return httpApiResponse(new HttpApiResponse(returnOrder));
        } catch (CMSException e) {
            logger.error("Update return order throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/grvn/{orderId}")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> approveReturnOrder(@PathVariable("orderId") String orderId,
                                               @RequestBody List<GoodReturnItem> goodReturnItems, Principal principal) {

        logger.info("Approve good received void note, order[" + orderId + "], goodReturnItems[" +
                goodReturnItems + "] by the system[" + principal.getName() + "]");

        try {
            orderService.approveReturnOrder(orderId, goodReturnItems);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Approve goodReceivedVoidNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/reject/grvn/{orderId}")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> rejectReturnOrder(@PathVariable("orderId") String orderId, Principal principal) {

        logger.info("Reject good received void note, order[" + orderId + "], by the system user[" + principal.getName() + "]");

        try {
            orderService.rejectReturnOrder(orderId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Reject goodReceivedVoidNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/add/grvdn/{orderId}")
    HttpEntity<ApiResponse> addReturnOrderDeliveryNote(@PathVariable("orderId") String orderId,
                                                       @RequestBody DeliveryNote goodReceivedVoidDeliveryNote, Principal principal) {

        logger.info("add goodReceivedVoidDeliveryNote to order[" + orderId + "], " +
                "goodReceivedVoidDeliveryNote[" + goodReceivedVoidDeliveryNote + "] from the system by [" + principal.getName() + "]");

        try {
            goodReceivedVoidDeliveryNote.setUserId(principal.getName());
            //goodReceivedVoidDeliveryNote.setUserId("ca.nd");
            DeliveryNote addedDeliveryNote = orderService.addReturnOrderDeliveryNote(orderId, goodReceivedVoidDeliveryNote);

            return httpApiResponse(new HttpApiResponse(addedDeliveryNote));
        } catch (CMSException e) {
            logger.error("Add goodReceivedVoidDeliveryNote throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/grvdn/{orderId}/{grvndnId}")
    HttpEntity<ApiResponse> updateReturnOrderDeliveryNote(@PathVariable("orderId") String orderId,
                                                          @PathVariable("grvndnId") String grvndnId,
                                                          @RequestBody DeliveryNote returnOrderDeliveryNote, Principal principal) {

        logger.info("update goodReceivedVoidDeliveryNote to order[" + orderId + "], grvndnId[" + grvndnId + "]" +
                "goodReceivedVoidDeliveryNote[" + returnOrderDeliveryNote + "]from the system by [" + principal.getName() + "]");

        try {
            returnOrderDeliveryNote.setUserId(principal.getName());
            //returnOrderDeliveryNote.setUserId("ca.nd");
            DeliveryNote addedDeliveryNote = orderService.updateReturnOrderDeliveryNote(orderId, grvndnId, returnOrderDeliveryNote);
            return httpApiResponse(new HttpApiResponse(addedDeliveryNote));
        } catch (CMSException e) {
            logger.error("Update goodReceivedVoidDeliveryNote throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @GetMapping("/requests/{requestId}")
    HttpEntity<ApiResponse> getPurchaseRequest(@PathVariable("requestId") String requestId, Principal principal) {

        logger.info("Get purchase request by the system user[" + principal.getName() + "]");

        try {
            PurchaseRequest purchaseRequest = requestService.findRequestById(requestId);
            return httpApiResponse(new HttpApiResponse(purchaseRequest));
        } catch (CMSException e) {
            logger.error("Get purchase request throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/requests/create-orders/{type}/{variant}")
    HttpEntity<ApiResponse> createOrdersFromRequests(
            @PathVariable("type") String type,
            @PathVariable("variant") String variant,
            @RequestBody List<PurchaseRequestItemView> requestItemIds,
            Principal principal) {

        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            List<String> orders = orderService.saveOrdersFromRequests(type, variant, requestItemIds);
            return httpApiResponse(new HttpApiResponse(orders));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/clinics")
    HttpEntity<ApiResponse> purchaseOrderClinics(@RequestBody Order order, Principal principal) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            List<Clinic> clinics = orderService.purchaseOrderClinics(order);
            return httpApiResponse(new HttpApiResponse(clinics));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/cancel/{id}")
    HttpEntity<ApiResponse> cancelOrder(@PathVariable("id") String id, Principal principal) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            Order canceledOrder = orderService.cancelOrder(id);
            return httpApiResponse(new HttpApiResponse(canceledOrder));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/orders/issue")
    HttpEntity<ApiResponse> modifyPurchaseOrders(@RequestBody List<Order> orders, Principal principal,
                                                 @RequestHeader(value = "Authorization") String authorization) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            List<Order> savedOrders = orderService.modifyPurchaseOrders(orders, true);
            return httpApiResponse(new HttpApiResponse(savedOrders));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/issue")
    HttpEntity<ApiResponse> issueOrder(@RequestBody Order order, Principal principal,
                                       @RequestHeader(value = "Authorization") String authorization,
                                       @RequestParam(value = "email", required = false) List<String> email) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            Order savedOrder = null;
            if (OrderType.PURCHASE.equals(order.getOrderType())) {
                savedOrder = orderService.modifyPurchaseOrder(order, true);
            } else {
                savedOrder = orderService.modifyTransferOrder(order, true);
            }
            if (email != null && !email.isEmpty()) {
                String subject = "PURCHASE ORDER[" + savedOrder.getOrderNo() + "]";
                Tuple<List<String>, String> tuple = orderService.createOrderMail(savedOrder.getId(), email);
                emailSender.sendEmailMultipleRecipients(tuple.getFirst(), subject, tuple.getSecond());
            }
            return httpApiResponse(new HttpApiResponse(savedOrder));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        } catch (IOException e) {
            logger.error("Create orders from purchase requests throw error message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    @PostMapping("/order/save")
    HttpEntity<ApiResponse> saveOrder(@RequestBody Order order, Principal principal,
                                      @RequestHeader(value = "Authorization") String authorization) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        try {
            Order savedOrder = null;
            if (OrderType.PURCHASE.equals(order.getOrderType())) {
                savedOrder = orderService.modifyPurchaseOrder(order, false);
            } else {
                savedOrder = orderService.modifyTransferOrder(order, false);
            }

            return httpApiResponse(new HttpApiResponse(savedOrder));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/save/draft")
    HttpEntity<ApiResponse> modifyPurchaseOrderDraft(@RequestBody Order order, Principal principal,
                                                     @RequestHeader(value = "Authorization") String authorization) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");

        if (!order.getOrderStatus().equals(OrderStatus.DRAFT)) {
            return httpApiResponse(new HttpApiResponse(StatusCode.E1002, "Order status must be DRAFT"));
        }

        try {
            Order savedOrder = null;
            if (OrderType.PURCHASE.equals(order.getOrderType())) {
                savedOrder = orderService.modifyPurchaseOrder(order, false);
            } else {
                savedOrder = orderService.modifyTransferOrder(order, false);
            }
            return httpApiResponse(new HttpApiResponse(savedOrder));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/delete/{orderId}")
    HttpEntity<ApiResponse> deleteOrder(@PathVariable String orderId, Principal principal) {
        logger.info("delete order[" + orderId + "] by the system user[" + principal.getName() + "]");
        try {
            return httpApiResponse(new HttpApiResponse(orderService.deleteOrder(orderId)));
        } catch (CMSException e) {
            logger.error("delete order by order id throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/orders/reject")
    HttpEntity<ApiResponse> rejectOrder(@RequestBody List<String> orderIds, Principal principal) {
        logger.info("reject order[" + orderIds + "] by the system user[" + principal.getName() + "]");
        try {
            return httpApiResponse(new HttpApiResponse(orderService.rejectOrder(orderIds)));
        } catch (CMSException e) {
            logger.error("reject order by order id throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/order/{orderId}/email")
    HttpEntity<ApiResponse> emailOrderToSupplier(@PathVariable String orderId,
                                                 @RequestParam(value = "email") List<String> email, Principal principal) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");
        try {

            String subject = "PURCHASE ORDER";
            Tuple<List<String>, String> tuple = orderService.createOrderMail(orderId, email);
            emailSender.sendEmailMultipleRecipients(tuple.getFirst(), subject, tuple.getSecond());
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Create orders from purchase requests throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        } catch (JsonProcessingException e) {
            logger.error("Create orders from purchase requests throw error message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        } catch (IOException e) {
            logger.error("Create orders from purchase requests throw error message[" + e.getMessage() + "]");

            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    @PostMapping("/order/{orderId}/print-content")
    HttpEntity<ApiResponse> getOrderPrintContent(@PathVariable String orderId, Principal principal) {
        logger.info("Create orders from purchase requests by the system user[" + principal.getName() + "]");
        try {
            PurchaseOrderPrint printContent = orderService.getPrintContent(orderId);
            return httpApiResponse(new HttpApiResponse(printContent));
        } catch (CMSException e) {
            logger.error("get print details of a order throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/create/order/{requestId}")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> createOrderByRequest(@PathVariable("requestId") String requestId,
                                                 @RequestBody List<Order> orders, Principal principal) {

        logger.info("createPurchaseOrderByRequest[" + requestId + "], purchaseOrders[" + orders + "] from system by [" + principal.getName() + "]");

        try {
            List<Order> savedPurchaseOrders = orderService.createOrderByRequestId(requestId, orders);
            return httpApiResponse(new HttpApiResponse(savedPurchaseOrders));
        } catch (CMSException e) {
            logger.error("create order throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/add/dn/{orderId}")
    HttpEntity<ApiResponse> addDeliveryNote(@PathVariable("orderId") String orderId,
                                            @RequestBody DeliveryNote deliveryNote, Principal principal) {

        logger.info("Add deliveryNote to orderId[" + orderId + "], deliveryNote[" + deliveryNote + "] from the system by [" + principal.getName() + "]");

        try {
            deliveryNote.setUserId(principal.getName());
            DeliveryNote savedDeliveryNote = orderService.addDeliveryNote(orderId, deliveryNote);
            return httpApiResponse(new HttpApiResponse(savedDeliveryNote));
        } catch (CMSException e) {
            logger.error("Add delivery note throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/dn/{orderId}/{dnId}")
    HttpEntity<ApiResponse> updateDeliveryNote(@PathVariable("orderId") String orderId,
                                               @PathVariable("dnId") String dnId,
                                               @RequestBody DeliveryNote deliveryNote, Principal principal) {

        logger.info("Update deliveryNote to orderId[" + orderId + "], deliveryNote[" + deliveryNote + "] from the system by [" + principal.getName() + "]");

        try {
            deliveryNote.setUserId(principal.getName());
            DeliveryNote savedDeliveryNote = orderService.updateDeliveryNote(orderId, dnId, deliveryNote);
            return httpApiResponse(new HttpApiResponse(savedDeliveryNote));
        } catch (CMSException e) {
            logger.error("Update delivery note throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/grvn/reason")
    HttpEntity<ApiResponse> listReturnOrderReason(Principal principal) {

        logger.info("listReturnOrderReason by system user[" + principal.getName() + "]");
        List<Reason> reasons = systemConfigService.listReturnPurOrderReason();
        return httpApiResponse(new HttpApiResponse(reasons));
    }

    @PostMapping("/list/request/justification")
    HttpEntity<ApiResponse> listPurchaseRequestJustification(Principal principal) {

        logger.info("listPurchaseRequestJustification by system user[" + principal.getName() + "]");
        List<Reason> reasons = systemConfigService.listPurchaseRequestJustification();
        return httpApiResponse(new HttpApiResponse(reasons));
    }

    @PostMapping("/list/item-clinic-detail/{clinicId}")
    HttpEntity<ApiResponse> listItemClinicDetails(@PathVariable("clinicId") String clinicId, Principal principal) {

        logger.info("listItemClinicDetail by system user [" + principal.getName() + "]");
        List<ItemClinicDetail> itemClinicDetails = itemClinicDetailService.listItemClinicDetailByClinicId(clinicId);
        return httpApiResponse(new HttpApiResponse(itemClinicDetails));
    }

    @PostMapping("/retry/nav/request/{clinicId}/{requestId}")
    HttpEntity<ApiResponse> retryCreateNavPurchaseRequest(@PathVariable("clinicId") String clinicId,
                                                          @PathVariable("requestId") String requestId,
                                                          Principal principal) {

        logger.info("retryCreateNavPurchaseRequest by system user [" + principal.getName() + "]");
        try {
            PurchaseRequest purchaseRequest = requestService.findRequestById(requestId);
            validateFailedNavIntegration(purchaseRequest.getNavIntegrationResult());
            navPurchaseService.createNavPurchaseRequest(clinicId, requestId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavPurchaseRequest error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/grn/{clinicId}/{orderId}/{grnId}")
    HttpEntity<ApiResponse> retryCreateNavPurchaseGoodReceivedNote(@PathVariable("clinicId") String clinicId,
                                                                   @PathVariable("orderId") String orderId,
                                                                   @PathVariable("grnId") String grnId,
                                                                   Principal principal) {

        logger.info("retryCreateNavPurchaseGoodReceivedNote by system user [" + principal.getName() + "]");
        try {
            Order order = orderService.findOrderById(orderId);
            GoodReceivedNote grn = order.getGoodReceivedNoteByGrnId(grnId)
                    .orElseThrow(() -> new CMSException(StatusCode.E1002, "Invalid grnId [" + grnId + "]"));
            validateFailedNavIntegration(grn.getNavIntegrationResult());
            navPurchaseService.createPurchaseGoodReceivedNote(clinicId, orderId, grnId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavPurchaseGoodReceivedNote error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/grvn/{clinicId}/{orderId}")
    HttpEntity<ApiResponse> retryCreateNavReturnOrder(@PathVariable("clinicId") String clinicId,
                                                      @PathVariable("orderId") String orderId,
                                                      Principal principal) {

        logger.info("retryCreateNavReturnOrder by system user [" + principal.getName() + "]");
        try {
            Order returnOrder = orderService.findReturnOrderByOrderId(orderId);

            validateFailedNavIntegration(returnOrder.getNavIntegrationResult());
            navPurchaseService.createNavReturnOrder(clinicId, orderId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavReturnOrder error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/grvdn/{clinicId}/{orderId}/{doId}")
    HttpEntity<ApiResponse> retryCreateNavReturnDeliveryNote(@PathVariable("clinicId") String clinicId,
                                                             @PathVariable("orderId") String orderId,
                                                             @PathVariable("doId") String doId,
                                                             Principal principal) {

        logger.info("retryCreateNavReturnDeliveryNote by system user [" + principal.getName() + "]");
        try {
            Order returnOrder = orderService.findReturnOrderByOrderId(orderId);
            DeliveryNote dn = returnOrder.getDeliveryNoteByDnId(doId)
                    .orElseThrow(() -> new CMSException(StatusCode.E1002, "Invalid doId [" + doId + "]"));
            validateFailedNavIntegration(dn.getNavIntegrationResult());
            navPurchaseService.createPurchaseReturnDeliveryNote(clinicId, orderId, doId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavReturnDeliveryNote error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/transfer-grn/{clinicId}/{orderId}/{grnId}")
    HttpEntity<ApiResponse> retryCreateNavTransferGoodReceivedNote(@PathVariable("clinicId") String clinicId,
                                                                   @PathVariable("orderId") String orderId,
                                                                   @PathVariable("grnId") String grnId,
                                                                   Principal principal) {

        logger.info("retryCreateNavTransferGoodReceivedNote by system user [" + principal.getName() + "]");
        try {
            Order order = orderService.findOrderById(orderId);
            GoodReceivedNote grn = order.getGoodReceivedNoteByGrnId(grnId)
                    .orElseThrow(() -> new CMSException(StatusCode.E1002, "Invalid grnId [" + grnId + "]"));
            validateFailedNavIntegration(grn.getNavIntegrationResult());
            navPurchaseService.createTransferGoodReceivedNote(clinicId, orderId, grnId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavTransferGoodReceivedNote error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/retry/nav/do/{clinicId}/{orderId}/{doId}")
    HttpEntity<ApiResponse> retryCreateNavDeliveryNote(@PathVariable("clinicId") String clinicId,
                                                       @PathVariable("orderId") String orderId,
                                                       @PathVariable("doId") String doId,
                                                       Principal principal) {

        logger.info("retryCreateNavPurchaseGoodReceivedNote by system user [" + principal.getName() + "]");
        try {
            Order order = orderService.findOrderById(orderId);
            DeliveryNote dn = order.getDeliveryNoteByDnId(doId)
                    .orElseThrow(() -> new CMSException(StatusCode.E1002, "Invalid doId [" + doId + "]"));
            validateFailedNavIntegration(dn.getNavIntegrationResult());
            navPurchaseService.createDeliveryNote(clinicId, orderId, doId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("retryCreateNavPurchaseGoodReceivedNote error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    private List<Supplier> filterSupplierItems(List<Supplier> suppliers, Map<String, List<String>> supplierItems) {

        return filterSupplierItems(suppliers, (supplier, itemId) -> supplierItems.get(supplier.getId()) != null
                && supplierItems.get(supplier.getId()).contains(itemId));
    }

    private List<Supplier> filterSupplierItems(List<Supplier> suppliers, List<String> itemIds) {

        return filterSupplierItems(suppliers, (supplier, itemId) -> itemIds.contains(itemId));
    }

    private List<Supplier> filterSupplierItems(List<Supplier> suppliers, BiFunction<Supplier, String, Boolean> predicate) {

        suppliers.forEach(supplier -> {
            supplier.setItems(supplier.getItems()
                    .stream()
                    .filter(purchaseItem -> predicate.apply(supplier, purchaseItem.getItemId()))
                    .collect(Collectors.toList()));
            supplier.setPurchaseBonuses(supplier.getPurchaseBonuses()
                    .stream()
                    .filter(bonus -> predicate.apply(supplier, bonus.getItemId()))
                    .collect(Collectors.toList()));
        });
        return suppliers;
    }

    @PostMapping("/delete/grn/{orderId}/{grnId}")
    HttpEntity<ApiResponse> deleteGoodReceivedNote(@PathVariable("orderId") String orderId,
                                                   @PathVariable("grnId") String grnId, Principal principal) {
        logger.info("delete goodReceivedNote from order[" + orderId + "], goodReceiveNote[" + grnId + "] from the system by [" +
                principal.getName() + "]");
        try {
            GoodReceivedNote deletedGrn = orderService.deleteGoodReceivedNote(orderId, grnId);
            return httpApiResponse(new HttpApiResponse(deletedGrn));
        } catch (CMSException e) {
            logger.error("delete goodReceivedNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/grvn/{orderId}")
    HttpEntity<ApiResponse> deleteGoodReceivedVoidNote(@PathVariable("orderId") String orderId, Principal principal) {
        logger.info("delete GoodReceivedVoidNote from order[" + orderId + "] from the system by [" +
                principal.getName() + "]");
        try {
            Order returnOrder = orderService.deleteReturnOrder(orderId);
            return httpApiResponse(new HttpApiResponse(returnOrder));
        } catch (CMSException e) {
            logger.error("delete GoodReceivedVoidNote throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/grvn/do/{orderId}/{grvndoId}")
    HttpEntity<ApiResponse> deleteGoodReceivedVoidNoteDo(@PathVariable("orderId") String orderId,
                                                         @PathVariable("grvndoId") String grvndoId, Principal principal) {
        logger.info("delete GoodReceivedVoidNoteDo from order[" + orderId + "] from the system by [" +
                principal.getName() + "]");
        try {
            DeliveryNote deliveryNote = orderService.deleteReturnOrderDn(orderId, grvndoId);
            return httpApiResponse(new HttpApiResponse(deliveryNote));
        } catch (CMSException e) {
            logger.error("delete GoodReceivedVoidNoteDo throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/transfer/{orderId}/{dnId}")
    HttpEntity<ApiResponse> deleteTransferShipment(@PathVariable("orderId") String orderId,
                                                   @PathVariable("dnId") String dnId, Principal principal) {
        logger.info("delete TransferShipment from order[" + orderId + "], TransferShipment[" + dnId + "] from the system by [" +
                principal.getName() + "]");
        try {
            DeliveryNote deliveryNote = orderService.deleteTransferShipment(orderId, dnId);
            return httpApiResponse(new HttpApiResponse(deliveryNote));
        } catch (CMSException e) {
            logger.error("delete TransferShipment throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/delete/transfer/grn/{orderId}/{grnId}")
    HttpEntity<ApiResponse> deleteTransferReceipt(@PathVariable("orderId") String orderId,
                                                  @PathVariable("grnId") String grnId, Principal principal) {
        logger.info("delete TransferReceipt from order[" + orderId + "], TransferReceipt[" + grnId + "] from the system by [" +
                principal.getName() + "]");
        try {
            GoodReceivedNote deletedGrn = orderService.deleteGoodReceivedNote(orderId, grnId);
            return httpApiResponse(new HttpApiResponse(deletedGrn));
        } catch (CMSException e) {
            logger.error("delete TransferReceipt throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/calculate/gst")
    HttpEntity<ApiResponse> calculateGst(@RequestBody Order order) {
        logger.info("calculate gst for order[" + order.getId() + "]");
        try {
            Tuple<Double, Double> gstTuple = orderService.calculateGst(order);
            return httpApiResponse(new HttpApiResponse(gstTuple));
        } catch (CMSException e) {
            logger.error("calculate gst throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/request-items")
    HttpEntity<ApiResponse> searchRequestItems(@RequestBody PurchaseRequestItemViewFilter criteria) {
        logger.info("search request items by criteria[" + criteria + "]");
        try {
            Page<PurchaseRequestItemView> requestItems = requestService.searchRequestItems(criteria);
            return httpApiResponse(new HttpApiResponse(requestItems));
        } catch (CMSException e) {
            logger.error("search request items throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/approve/return-order")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> approveReturnOrders(@RequestBody
                                                List<String> orderIds, Principal principal) {

        try {
            List<Order> returnOrders = orderService.approveOrRejectReturnOrders(orderIds, GoodReceivedReturnStatus.APPROVED);
            return httpApiResponse(new HttpApiResponse(returnOrders));
        } catch (CMSException e) {
            logger.error("Approve purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/reject/return-order")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> rejectReturnOrders(
            @RequestBody List<String> orderIds,Principal principal) {

        try {
            List<Order> returnOrders = orderService.approveOrRejectReturnOrders(orderIds, GoodReceivedReturnStatus.REJECTED);
            return httpApiResponse(new HttpApiResponse(returnOrders));
        } catch (CMSException e) {
            logger.error("Approve purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/edit/return-order")
    @RolesAllowed("ROLE_NAV")
    HttpEntity<ApiResponse> editReturnOrders(@RequestBody Order returnOrder, Principal principal) {

        try {
            Order savedReturnOrder = orderService.editAndApproveReturnOrder(returnOrder);
            return httpApiResponse(new HttpApiResponse(savedReturnOrder));
        } catch (CMSException e) {
            logger.error("Approve purchaseRequest throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    private void validateFailedNavIntegration(NavIntegrationResult navResult) throws CMSException {
        if (navResult == null || navResult.getStatus() != NavIntegrationResult.ResultStatus.FAILED) {
            throw new CMSException(StatusCode.E1010, "Unable to retry if nav integration did not fail");
        }
    }
}
