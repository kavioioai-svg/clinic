package com.ilt.cms.inventory.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DisposeStockCriteriaContainer {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;

    private List<DisposeStatus> disposeStatuses = new ArrayList<>();

    private String clinicId;

    public DisposeStockCriteriaContainer() {
    }

    public DisposeStockCriteriaContainer(LocalDate startDate, LocalDate endDate, List<DisposeStatus> disposeStatuses) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.disposeStatuses = disposeStatuses;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public List<DisposeStatus> getDisposeStatuses() {
        return disposeStatuses;
    }

    public void setDisposeStatuses(List<DisposeStatus> disposeStatuses) {
        this.disposeStatuses = disposeStatuses;
    }

    public String getClinicId() {
        return clinicId;
    }
    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    @Override
    public String toString() {
        return "StockTakeCriteriaContainer{" +
                "startDate='" + startDate + '\'' +
                ", endDate=" + endDate +
                ", disposeStatuses=" + disposeStatuses +
                '}';
    }
}
