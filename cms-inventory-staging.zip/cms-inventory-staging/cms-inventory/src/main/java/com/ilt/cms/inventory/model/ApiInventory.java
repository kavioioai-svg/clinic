package com.ilt.cms.inventory.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.annotation.Transient;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ApiInventory {


    private String inventoryId;
    private String itemRefId;
    @Transient
    private String itemName;
    @Transient
    private String itemCode;
    private String batchNumber;
    private String baseUom;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    protected LocalDate manufacturerDate;
    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;

    private double availableCount;

    private int baseUomQuantity;

    private BigDecimal purchasePrice;

    public ApiInventory() {
    }

    public ApiInventory(String inventoryId, String itemRefId, String itemName, String itemCode, String batchNumber,
                        String baseUom, LocalDate manufacturerDate, LocalDate expiryDate, double availableCount, int baseUomQuantity,
                        BigDecimal purchasePrice) {
        this.inventoryId = inventoryId;
        this.itemRefId = itemRefId;
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.manufacturerDate = manufacturerDate;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.baseUomQuantity = baseUomQuantity;
        this.purchasePrice = purchasePrice;
    }


    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getBaseUom() {
        return baseUom;
    }

    public void setBaseUom(String baseUom) {
        this.baseUom = baseUom;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public double getAvailableCount() {
        return availableCount;
    }

    public void setAvailableCount(double availableCount) {
        this.availableCount = availableCount;
    }

    public int getBaseUomQuantity() {
        return baseUomQuantity;
    }

    public void setBaseUomQuantity(int baseUomQuantity) {
        this.baseUomQuantity = baseUomQuantity;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "ApiInventory{" +
                "inventoryId='" + inventoryId + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemCode='" + itemCode + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                ", baseUom='" + baseUom + '\'' +
                ", manufacturerDate=" + manufacturerDate +
                ", expiryDate=" + expiryDate +
                ", availableCount=" + availableCount +
                '}';
    }
}
