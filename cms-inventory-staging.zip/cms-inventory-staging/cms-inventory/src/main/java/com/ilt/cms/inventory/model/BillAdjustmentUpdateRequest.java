package com.ilt.cms.inventory.model;

import com.ilt.cms.inventory.svc.service.inventory.dto.BillAdjustmentUpdate;
import lombok.Data;

import java.util.List;

@Data
public class BillAdjustmentUpdateRequest {

    private String caseId;
    private List<BillAdjustmentUpdate> updates;

}
