package com.ilt.cms.inventory.rest.so;

import com.ilt.cms.inventory.svc.service.purchase.OrderService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/so")
@RolesAllowed({ "ROLE_SO_CORRECTION" })
public class SalesOrderRestController {

    private static final Logger logger = LoggerFactory.getLogger(SalesOrderRestController.class);
    private OrderService orderService;

    public SalesOrderRestController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/create/{caseId}")
    HttpEntity<ApiResponse> saveSalesOrderService(@PathVariable("caseId") String caseId) {
        logger.info("saving Sales Order into the nav system  for case Id::" + caseId);
        try {
            orderService.updateInventoryByCaseId(caseId, false, false);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Saving Sales order inventory throw error[" + e.getCode() + "], message[" + e.getMessage()
                    + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/update/{caseId}")
    HttpEntity<ApiResponse> updateSalesOrderService(@PathVariable("caseId") String caseId) {
        logger.info("saving Sales Order into the nav system  for case Id::" + caseId);
        try {
            orderService.updateInventoryByCaseId(caseId, false, false);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Saving Sales order inventory throw error[" + e.getCode() + "], message[" + e.getMessage()
                    + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/correct/{caseId}")
    HttpEntity<ApiResponse> correctSalesOrderService(@PathVariable("caseId") String caseId) {
        logger.info("saving Sales Order Correction into the nav system  for case Id::" + caseId);
        try {
            orderService.updateInventoryByCaseId(caseId, true, false);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            logger.error("Correcting Sales order inventory throw error[" + e.getCode() + "], message[" + e.getMessage()
                    + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }
}
