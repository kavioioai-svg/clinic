package com.ilt.cms.inventory.rest.nav;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.api.container.PageableHttpApiResponse;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.inventory.svc.model.nav.NavQueue;
import com.ilt.cms.inventory.svc.model.nav.NavQueueFilter;

import com.ilt.cms.inventory.svc.model.nav.NavQueuePage;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Nullable;
import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/navQueue")
@RolesAllowed("ROLE_VIEW_SYNC_INFO")
public class NavQueueRestController {

    @Value("${nav.sync.list:}")
    private String syncInfo;
    @Value("${nav.sync.filter:}")
    private String filter;
    @Value("${nav.sync.retry:}")
    private String retrySyncToNav;
    private static final Logger logger = LoggerFactory.getLogger(NavQueueRestController.class);
    private RestTemplate restTemplate;

    public NavQueueRestController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    //@RolesAllowed("ROLE_VIEW_SYNC_INFO")
    @PostMapping("/syncInfo/list/{page}/{size}")
    HttpEntity<ApiResponse> getSyncInfo(@PathVariable("page") int page,
                                        @PathVariable("size") int size) {
        logger.info("Get sync info of CMS-NAV");
        try {
            ParameterizedTypeReference<CmsServiceResponse<NavQueuePage>> responseType = new ParameterizedTypeReference<>() {
            };

            HttpEntity<String> entity = getCustomHeaderHttpEntity(null);
            ResponseEntity<CmsServiceResponse<NavQueuePage>> responseEntity = restTemplate
                    .exchange(syncInfo + "/" + page + "/" + size, HttpMethod.POST, entity, responseType);

            CmsServiceResponse<NavQueuePage> body = responseEntity.getBody();
            NavQueuePage<NavQueue> navQueuePage = body.getPayload();

            Pageable pageable = PageRequest.of(page, size);
            Page<NavQueue> navQueueNewPage = new PageImpl<>(navQueuePage.getContent(), pageable, navQueuePage.getTotalElements());
            int totalElements, totalPage, pageNumber;
            totalElements = (int) navQueuePage.getTotalElements();
            totalPage = navQueuePage.getTotalPages();
            pageNumber = navQueuePage.getPageNumber();

            //return httpApiResponse(new HttpApiResponse(navQueuePage));
            return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, navQueueNewPage));
        } catch (Exception e) {
            logger.error("Error getting sync info : [" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    //@RolesAllowed("ROLE_VIEW_SYNC_INFO")
    @PostMapping("/syncInfo/filter/{page}/{size}")
    HttpEntity<ApiResponse> filter(@RequestBody NavQueueFilter navQueueFilter, @PathVariable("page") int page,
                                   @PathVariable("size") int size) {
        logger.info("Filter sync info of CMS-NAV");
        try {
            ParameterizedTypeReference<CmsServiceResponse<NavQueuePage>> responseType = new ParameterizedTypeReference<>() {
            };
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            String navQueueFilterStr = ow.writeValueAsString(navQueueFilter);
            HttpEntity<String> entity = getCustomHeaderHttpEntity(navQueueFilterStr);
            ResponseEntity<CmsServiceResponse<NavQueuePage>> responseEntity = restTemplate
                    .exchange(filter + "/" + page + "/" + size, HttpMethod.POST, entity, responseType);

            CmsServiceResponse<NavQueuePage> body = responseEntity.getBody();
            NavQueuePage navQueuePage = body.getPayload();

            Pageable pageable = PageRequest.of(page, size);
            Page<NavQueue> navQueueNewPage = new PageImpl<>(navQueuePage.getContent(), pageable, navQueuePage.getTotalElements());
            int totalElements, totalPage, pageNumber;
            totalElements = (int) navQueuePage.getTotalElements();
            totalPage = navQueuePage.getTotalPages();
            pageNumber = navQueuePage.getPageNumber();

            //return httpApiResponse(new HttpApiResponse(navQueuePage));
            return httpApiResponse(new PageableHttpApiResponse(totalElements, totalPage, pageNumber, navQueueNewPage));
        } catch (Exception e) {
            logger.error("Error getting sync info : [" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    //@RolesAllowed("ROLE_VIEW_SYNC_INFO")
    @PostMapping("/retrySyncToNav/{navQueueId}")
    HttpEntity<ApiResponse> retrySyncToNav(@PathVariable(name = "navQueueId") String navQueueId) {
        logger.info("Retry sync to Nav of failed record");
        try {
            ParameterizedTypeReference<CmsServiceResponse<NavQueue>> responseType = new ParameterizedTypeReference<>() {
            };
            HttpEntity<String> entity = getCustomHeaderHttpEntity(null);
            ResponseEntity<CmsServiceResponse<NavQueue>> responseEntity = restTemplate
                    .exchange(retrySyncToNav + "/" + navQueueId, HttpMethod.POST, entity, responseType);

            CmsServiceResponse<NavQueue> body = responseEntity.getBody();
            NavQueue navQueue = body.getPayload();

            return httpApiResponse(new HttpApiResponse(navQueue));
        } catch (Exception e) {
            logger.error("Error getting sync info : [" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    @PostMapping("/retryStockAdjustmentSyncToNav/{stockTakeId}")
    HttpEntity<ApiResponse> retryStockAdjustmentSyncToNav(@PathVariable(name = "stockTakeId") String stockTakeId) {
        logger.info("Retry sync to Nav of failed record");
        try {
            ParameterizedTypeReference<CmsServiceResponse<NavQueue>> responseType = new ParameterizedTypeReference<>() {
            };
            HttpEntity<String> entity = getCustomHeaderHttpEntity(null);
            ResponseEntity<CmsServiceResponse<NavQueue>> responseEntity = restTemplate
                    .exchange(retrySyncToNav + "/" + NavQueue.ServiceName.STOCK_ADJUSTMENT + "/" + stockTakeId + "/", HttpMethod.POST, entity, responseType);

            CmsServiceResponse<NavQueue> body = responseEntity.getBody();
            NavQueue navQueue = body.getPayload();

            return httpApiResponse(new HttpApiResponse(navQueue));
        } catch (Exception e) {
            logger.error("Error getting sync info : [" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(StatusCode.I5000, e.getMessage()));
        }
    }

    private HttpEntity<String> getCustomHeaderHttpEntity(@Nullable String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Tenant", TenantContext.getTenantId());
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return entity;
    }
}


