package com.ilt.cms.inventory.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UomMatrixSearchResult extends UomMatrixSearchParam{
	private double reverseRatio;

	public UomMatrixSearchResult(String itemId, String sourceUom, String destinationUom, double reverseRatio) {
		super(itemId, sourceUom, destinationUom);
		this.reverseRatio = reverseRatio;
	}
}
