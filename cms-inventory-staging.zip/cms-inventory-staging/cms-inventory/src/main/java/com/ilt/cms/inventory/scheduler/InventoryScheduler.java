package com.ilt.cms.inventory.scheduler;

import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class InventoryScheduler {
    private LocationService locationService;

    @Value("${inventory.scheduler.delete.qty.zero.since}")
    private long zeroSince;

    public InventoryScheduler(LocationService locationService) {
        this.locationService = locationService;
    }

    @Scheduled(cron = "${inventory.scheduler.delete.zero.qty}")
    public void deleteZeroQuantityItemsScheduler(){
        locationService.deleteZeroQuantityItems(zeroSince);
    }

}
