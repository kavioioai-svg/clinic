package com.ilt.cms.inventory.model;

import com.ilt.cms.core.entity.supplier.Supplier;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SupplierItemContainer {

    private String itemId;

    private List<Supplier> suppliers = new ArrayList<>();

    private BigDecimal totalQuantity;

    public SupplierItemContainer() {
    }

    public SupplierItemContainer(String itemId, List<Supplier> suppliers, BigDecimal totalQuantity) {
        this.itemId = itemId;
        this.suppliers = suppliers;
        this.totalQuantity = totalQuantity;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public List<Supplier> getSuppliers() {
        return suppliers;
    }

    public void setSuppliers(List<Supplier> suppliers) {
        this.suppliers = suppliers;
    }

    public BigDecimal getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(BigDecimal totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    @Override
    public String toString() {
        return "SupplierItemContainer{" +
                "itemId='" + itemId + '\'' +
                ", suppliers=" + suppliers +
                ", totalQuantity=" + totalQuantity +
                '}';
    }
}
