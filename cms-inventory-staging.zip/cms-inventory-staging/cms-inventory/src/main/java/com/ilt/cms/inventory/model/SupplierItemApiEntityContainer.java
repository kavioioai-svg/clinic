package com.ilt.cms.inventory.model;

import com.ilt.cms.api.entity.supplier.SupplierEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SupplierItemApiEntityContainer {
	private String itemId;
	private List<SupplierEntity> suppliers = new ArrayList<>();
	private BigDecimal totalQuantity;

	public SupplierItemApiEntityContainer() {
	}

	public SupplierItemApiEntityContainer(String itemId, List<SupplierEntity> suppliers, BigDecimal totalQuantity) {
		this.itemId = itemId;
		this.suppliers = suppliers;
		this.totalQuantity = totalQuantity;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public List<SupplierEntity> getSuppliers() {
		return suppliers;
	}

	public void setSuppliers(List<SupplierEntity> suppliers) {
		this.suppliers = suppliers;
	}

	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	@Override
	public String toString() {
		return "SupplierItemApiEntityContainer{" +
			"itemId='" + itemId + '\'' +
			", suppliers=" + suppliers +
			", totalQuantity=" + totalQuantity +
			'}';
	}
}
