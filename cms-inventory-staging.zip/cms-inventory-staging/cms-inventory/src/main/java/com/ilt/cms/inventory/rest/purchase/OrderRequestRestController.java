package com.ilt.cms.inventory.rest.purchase;

import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequestFilter;
import com.ilt.cms.inventory.svc.model.purchase.api.ReturnOrder;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.service.purchase.IntegrationService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.security.Principal;
import java.util.List;
import java.util.Map;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/order-request")
@RolesAllowed({"ROLE_VIEW_ORDER_REQUEST"})
public class OrderRequestRestController {

    private static final Logger logger = LoggerFactory.getLogger(OrderRequestRestController.class);

    private IntegrationService integrationService;

    public OrderRequestRestController(IntegrationService integrationService) {
        this.integrationService = integrationService;
    }

    @PostMapping("/list/{clinicId}/{page}/{size}")
    HttpEntity<ApiResponse> listOrderRequest(@PathVariable("clinicId") String clinicId,
                                             @PathVariable("page") int page,
                                             @PathVariable("size") int size,
                                             @RequestBody Map<OrderRequest.Filter, String> filterMap, Principal principal) {

        logger.info("List orderRequest from the system by [" + principal.getName() + "]");

        try {
            Map<String, Object> orderRequestMap = integrationService.listOrderRequests(clinicId, filterMap, page, size);
            return httpApiResponse(new HttpApiResponse(orderRequestMap));
        } catch (CMSException e) {
            logger.error("list orderRequest throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/{page}/{size}")
    HttpEntity<ApiResponse> listOrderRequests(@PathVariable("page") int page,
                                             @PathVariable("size") int size,
                                             @RequestBody OrderRequestFilter orderRequestFilter, Principal principal) {

        logger.info("List orderRequests from the system by [" + principal.getName() + "]");

        try {
            Map<String, Object> orderRequestMap = integrationService.listOrderRequests(orderRequestFilter, page, size);
            return httpApiResponse(new HttpApiResponse(orderRequestMap));
        } catch (CMSException e) {
            logger.error("list orderRequests throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/return-order/{clinicId}/{page}/{size}")
    HttpEntity<ApiResponse> listReturnOrder(@PathVariable("clinicId") String clinicId,
                                            @PathVariable("page") int page,
                                            @PathVariable("size") int size,
                                            @RequestBody SearchPurchaseReturnOrderContainer searchPurchaseReturnOrderContainer,
                                            Principal principal) {

        logger.info("listReturnOrder, clinicId[" + clinicId + "], searchPurchaseReturnOrderContainer[" + searchPurchaseReturnOrderContainer +
                "] from the system by [" + principal.getName() + "]");

        try {
            Map<String, Object> returnOrderMap = integrationService.listReturnOrder(clinicId, searchPurchaseReturnOrderContainer, page, size);
            return httpApiResponse(new HttpApiResponse(returnOrderMap));
        } catch (CMSException e) {
            logger.error("list  orderRequest throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }

    }

    @PostMapping("/list/return-order/{page}/{size}")
    HttpEntity<ApiResponse> listReturnOrder(@PathVariable("page") int page,
                                            @PathVariable("size") int size,
                                            @RequestBody SearchPurchaseReturnOrderContainer search,
                                            Principal principal) {

        logger.info("listReturnOrder, by criteria[" + search + "], searchPurchaseReturnOrderContainer[" + search +
                "] from the system by [" + principal.getName() + "]");

        try {
            Map<String, Object> returnOrderMap = integrationService.listReturnOrders(search, page, size);
            return httpApiResponse(new HttpApiResponse(returnOrderMap));
        } catch (CMSException e) {
            logger.error("list  orderRequest throw error[" + e.getCode() + "], message[" + e.getMessage() + "]", e);
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }

    }
}
