package com.ilt.cms.inventory.rest.inventory;

import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.core.entity.inventory.InventoryTransaction;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.model.ApiInventory;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.inventory.svc.util.PurchasePriceCalculator;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import com.lippo.commons.web.api.ApiResponse;
import com.lippo.commons.web.api.HttpApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.lippo.commons.web.CommonWebUtil.httpApiResponse;

@RestController
@RequestMapping("/inventory")
@RolesAllowed({ "ROLE_PR_PO_INVENTORY_NAV", "ROLE_DOCTOR" })
public class InventoryRestController {
    private static final Logger logger = LoggerFactory.getLogger(InventoryRestController.class);

    private DrugItemService drugItemService;

    private LocationService locationService;

    public InventoryRestController(DrugItemService drugItemService, LocationService locationService) {

        this.drugItemService = drugItemService;
        this.locationService = locationService;
    }

    @PostMapping("/create/drug-item")
    HttpEntity<ApiResponse> createDrugItem(@RequestBody Item drugItem, Principal principal) {

        logger.info("Create item from the system by [" + principal.getName() + "]");
        Item newDrugItem = drugItemService.createItem(drugItem);
        return httpApiResponse(new HttpApiResponse(newDrugItem));
    }

    @PostMapping("/search/drug-item/detail/{itemId}")
    HttpEntity<ApiResponse> findDrugItem(@PathVariable("itemId") String drugItemId, Principal principal) {

        logger.info("Find item from the system by [" + principal.getName() + "]");
        Item drugItem = null;
        try {
            drugItem = drugItemService.findItemById(drugItemId);
            return httpApiResponse(new HttpApiResponse(drugItem));
        } catch (CMSException e) {
            logger.error("findDrugItem throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/drug-item/{clinicId}")
    HttpEntity<ApiResponse> listAllDrugItem(@PathVariable("clinicId") String clinicId, Principal principal) {
        logger.info("List clinic item from the system by [" + principal.getName() + "]");
        List<Item> drugItems = drugItemService.listItemByClinicId(clinicId);
        return httpApiResponse(new HttpApiResponse(drugItems));
    }

    @PostMapping("/find/drug-item/quantity/{clinicId}/{itemId}/{uom}")
    HttpEntity<ApiResponse> findInventoryQuantityByItemCode(@PathVariable("clinicId") String clinicId,
                                                            @PathVariable("itemId") String itemId,
                                                            @PathVariable("uom") String uom,
                                                            Principal principal) {

        logger.info("Find inventory item quantity from the system by [" + principal.getName() + "]");
        try {
            Map<String, String> itemIdUomMap = new HashMap<>();
            itemIdUomMap.put(itemId, uom);
            Map<String, Double> itemIdQtyMap = locationService.findInventoryQuantityByClinicIdAndItemCodeAndUom(clinicId, itemIdUomMap);
            double totalQuantity = itemIdQtyMap.get(itemId) == null ? 0 : itemIdQtyMap.get(itemId).doubleValue();
            return httpApiResponse(new HttpApiResponse(totalQuantity));
        } catch (CMSException e) {
            logger.error("findInventoryQuantityByItemCode throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/find/clinics/by/items")
    HttpEntity<ApiResponse> findClinicsByItems(@RequestBody List<String> itemIds, Principal principal) {
        logger.info("Find clinics by items from the system by [" + principal.getName() + "]");
        try {
            List<String> clinicIds = locationService.findClinicsByItems(itemIds);
            return httpApiResponse(new HttpApiResponse(clinicIds));
        } catch (CMSException e) {
            logger.error("findClinicsByItems throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @GetMapping("/find/inventory/by/clinic/{clinicId}")
    HttpEntity<ApiResponse> findInventoryByClinic(@PathVariable("clinicId") String clinicId, Principal principal) {
        logger.info("Find item by clinic from the system by [" + principal.getName() + "]");
        try {
            List<Inventory> items = locationService.findItemByClinic(clinicId);
            return httpApiResponse(new HttpApiResponse(items));
        } catch (CMSException e) {
            logger.error("findItemByClinic throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/{clinicId}/{itemId}")
    HttpEntity<ApiResponse> listInventoryByItemId(@PathVariable("clinicId") String clinicId,
                                                  @PathVariable("itemId") String itemId, Principal principal) throws CMSException {

        logger.info("SearchInventoryByItemCode, clinicId[" + clinicId + "], itemId[" + itemId + "], [" + principal.getName() + "]");
        List<Inventory> inventories = locationService.listInventoryByItemId(clinicId, List.of(itemId));
        BigDecimal purchasePriceAvg = PurchasePriceCalculator.getAveragePurchasePrice(inventories);
        List<ApiInventory> apiInventories = inventories.stream()
                .map(this.mapToApiInventory(purchasePriceAvg))
                .collect(Collectors.toList());
        return httpApiResponse(new HttpApiResponse(apiInventories));
    }


    @PostMapping("/list/all/{clinicId}")
    HttpEntity<ApiResponse> listInventoryByItemIds(@PathVariable("clinicId") String clinicId,
                                                   @RequestBody List<String> itemIds, Principal principal) {

        logger.info("SearchInventoryByItemIds, clinicId[" + clinicId + "], itemIds[" + itemIds + "], [" + principal.getName() + "]");
        try {
            List<Inventory> inventories = locationService.listInventoryByItemId(clinicId, itemIds);
            List<InventoryDetail> apiInventories = inventories.stream()
                    .map(mapToInventoryDetail())
                    .collect(Collectors.toList());
            return httpApiResponse(new HttpApiResponse(apiInventories));
        } catch (CMSException e) {
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/validate/inventory/{clinicId}")
    HttpEntity<ApiResponse> validateInventory(@PathVariable("clinicId") String clinicId, @RequestBody List<InventoryUsage> usages,
                                              Principal principal) {

        logger.info("Validate inventory , clinicId[" + clinicId + "], item usages [" + usages + "], [" + principal.getName() + "]");
        try {
            locationService.validateInventoryUsage(usages, clinicId);
            return httpApiResponse(new HttpApiResponse(StatusCode.S0000));
        } catch (CMSException e) {
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/drug-item/{clinicId}/{supplierId}")
    HttpEntity<ApiResponse> listItemBySupplier(@PathVariable("clinicId") String clinicId,
                                               @PathVariable("supplierId") String supplierId, Principal principal) {

        logger.info("list item by supplier[" + supplierId + "], in clinic[" + clinicId + "], [" + principal.getName() + "]");
        try {
            List<Item> items = drugItemService.listSupplierItem(clinicId, supplierId);
            return httpApiResponse(new HttpApiResponse(items));
        } catch (CMSException e) {
            logger.error("listItemBySupplier throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    @PostMapping("/list/supplier/{clinicId}/{supplierId}")
    HttpEntity<ApiResponse> listInventoryBySupplier(@PathVariable("clinicId") String clinicId,
                                                    @PathVariable("supplierId") String supplierId, Principal principal) {

        logger.info("list inventory by supplier[" + supplierId + "], in clinic[" + clinicId + "], [" + principal.getName() + "]");
        try {
            List<Item> items = drugItemService.listSupplierItem(clinicId, supplierId);
            List<String> itemIds = items.stream()
                    .map(Item::getId)
                    .collect(Collectors.toList());
            List<Inventory> inventories = locationService.listInventoryByItemId(clinicId, itemIds);
            BigDecimal purchasePriceAvg = PurchasePriceCalculator.getAveragePurchasePrice(inventories);
            List<ApiInventory> apiInventories = inventories.stream()
                    .map(this.mapToApiInventory(purchasePriceAvg))
                    .collect(Collectors.toList());
            return httpApiResponse(new HttpApiResponse(apiInventories));
        } catch (CMSException e) {
            logger.error("listItemBySupplier throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }

    private Function<Inventory, ApiInventory> mapToApiInventory(BigDecimal purchasePriceAvg) {
        logger.info("mapToApiInventory started");
        return inventory -> new ApiInventory(inventory.getInventoryId(), inventory.getItemRefId(), inventory.getItemName(),
                inventory.getItemCode(), inventory.getBatchNumber(), inventory.getBaseUom(), inventory.getManufacturerDate(),
                inventory.getExpiryDate(), inventory.getAvailableCountInt(), inventory.getBaseUomQuantity(),
                (inventory.getBatchPrice() == null || inventory.getBatchPrice().compareTo(BigDecimal.ZERO) == 0) ?
                        purchasePriceAvg : inventory.getBatchPrice());
    }

    private Function<Inventory, InventoryDetail> mapToInventoryDetail() {
        return inventory -> {
            InventoryDetail inventoryDetail = new InventoryDetail();
            inventoryDetail.setItemId(inventory.getItemRefId());
            inventoryDetail.setRemainingQuantity(inventory.getAvailableCountInt());
            inventoryDetail.setBatchNo(inventory.getBatchNumber());
            if (inventory.getExpiryDate() != null) {
                inventoryDetail.setExpiryDate(Date.from(inventory.getExpiryDate().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()));
            }
            inventoryDetail.setBaseUom(inventory.getBaseUom());
            inventoryDetail.setSaleUom(inventory.getSalesUom());
            inventoryDetail.setSaleUomQuantity(inventory.getSalesUomQuantity());
            inventoryDetail.setPurchaseUom(inventory.getPurchaseUom());
            inventoryDetail.setPurchaseUomQuantity(inventory.getPurchaseUomQuantity());
            return inventoryDetail;
        };
    }

    @PostMapping("/find-and-modify")
    HttpEntity<ApiResponse> findAndModify(@RequestBody Location location,
                                          @RequestParam(name = "sendingDifference") boolean sendingDifference,
                                          @RequestParam(name = "sendingDifference") String refId,
                                          @RequestParam(name = "type") InventoryTransaction.Type type,
                                          Principal principal) {

        logger.info("Update inventories from the system by [" + principal.getName() + "]");
        try {
            List<InventoryTransaction> inventoryTransactions = locationService.findAndModify(location, sendingDifference, false);
            locationService.saveInventoryTransactions(inventoryTransactions, refId, type);
            return httpApiResponse(new HttpApiResponse(inventoryTransactions));
        } catch (CMSException e) {
            logger.error("rest endpoint findAndModify from throw error[" + e.getStatusCode() + "], message[" + e.getMessage() + "]");
            return httpApiResponse(new HttpApiResponse(e.getStatusCode(), e.getMessage()));
        }
    }
    
    private BigDecimal getPurchasePriceAvg(List<Inventory> inventories) {
        int totalQuantity = inventories.stream()
                .filter(inv -> inv.getBatchPrice() != null)
                .mapToInt(inv -> inv.getAvailableCountInt())
                .sum();

        final BigDecimal totalInventoryValue = inventories.stream()
                .filter(inv -> inv.getBatchPrice() != null)
                .map(inv -> new BigDecimal(inv.getAvailableCountInt()).multiply(inv.getBatchPrice()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return totalQuantity > 0 ? totalInventoryValue.divide(new BigDecimal(totalQuantity),
                2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
    }
}
