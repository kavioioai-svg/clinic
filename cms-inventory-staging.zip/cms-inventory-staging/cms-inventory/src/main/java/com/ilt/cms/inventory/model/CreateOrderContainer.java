package com.ilt.cms.inventory.model;

import com.ilt.cms.inventory.svc.model.purchase.common.Order;

import java.util.ArrayList;
import java.util.List;

public class CreateOrderContainer {
    String requestId;

    List<Order> orders = new ArrayList<>();

    public CreateOrderContainer(String requestId, List<Order> orders) {
        this.requestId = requestId;
        this.orders = orders;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

    @Override
    public String toString() {
        return "CreateOrderContainer{" +
                "requestId='" + requestId + '\'' +
                ", orders=" + orders +
                '}';
    }
}
