package com.ilt.cms.inventory.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SearchParam {
	private SupplierSearch supplierSearch;

	@Getter
	@Setter
	@NoArgsConstructor
	public static class SupplierSearch {
		private String itemId;
		private String uom;
	}
}
