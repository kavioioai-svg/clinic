package com.ilt.cms.inventory.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StockTakeCriteriaContainer {

    private String nameRegex;

    private String transactionNoRegex;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;

    private List<StockTakeStatus> stockTakeStatuses = new ArrayList<>();

    private List<StockTakeApproveStatus> stockTakeApproveStatuses = new ArrayList<>();

    private List<StockCountType> stockCountTypes = new ArrayList<>();

    public StockTakeCriteriaContainer() {
    }

    public StockTakeCriteriaContainer(String nameRegex, LocalDate startDate, LocalDate endDate, List<StockTakeStatus> stockTakeStatuses,
                                      List<StockTakeApproveStatus> stockTakeApproveStatuses, List<StockCountType> stockCountTypes) {
        this.nameRegex = nameRegex;
        this.startDate = startDate;
        this.endDate = endDate;
        this.stockTakeStatuses = stockTakeStatuses;
        this.stockTakeApproveStatuses = stockTakeApproveStatuses;
        this.stockCountTypes = stockCountTypes;
    }

    public String getNameRegex() {
        return nameRegex;
    }

    public void setNameRegex(String nameRegex) {
        this.nameRegex = nameRegex;
    }

    public String getTransactionNoRegex() {
        return transactionNoRegex;
    }

    public void setTransactionNoRegex(String transactionNoRegex) {
        this.transactionNoRegex = transactionNoRegex;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public List<StockTakeStatus> getStockTakeStatuses() {
        return stockTakeStatuses;
    }

    public void setStockTakeStatuses(List<StockTakeStatus> stockTakeStatuses) {
        this.stockTakeStatuses = stockTakeStatuses;
    }

    public List<StockTakeApproveStatus> getStockTakeApproveStatuses() {
        return stockTakeApproveStatuses;
    }

    public void setStockTakeApproveStatuses(List<StockTakeApproveStatus> stockTakeApproveStatuses) {
        this.stockTakeApproveStatuses = stockTakeApproveStatuses;
    }

    public List<StockCountType> getStockCountTypes() {
        return stockCountTypes;
    }

    public void setStockCountTypes(List<StockCountType> stockCountTypes) {
        this.stockCountTypes = stockCountTypes;
    }

    @Override
    public String toString() {
        return "StockTakeCriteriaContainer{" +
                "nameRegex='" + nameRegex + '\'' +
                ", transactionNoRegex='" + transactionNoRegex + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", stockTakeStatuses=" + stockTakeStatuses +
                ", stockTakeApproveStatuses=" + stockTakeApproveStatuses +
                ", stockCountTypes=" + stockCountTypes +
                '}';
    }
}
