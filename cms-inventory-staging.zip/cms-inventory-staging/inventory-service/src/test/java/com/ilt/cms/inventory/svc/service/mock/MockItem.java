package com.ilt.cms.inventory.svc.service.mock;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.DrugItem;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.SellingPrice;
import com.ilt.cms.core.entity.item.SellingPriceBigDeci;
import com.lippo.cms.util.IdGenerator;

import java.math.BigDecimal;

public class MockItem {

    public static Item mockConsumableItem(String itemId, String code, Item.ItemType itemType){
        DrugItem drugItem = new DrugItem();
        drugItem.setId(itemId);
        drugItem.setName("Paracetamol");
        drugItem.setCode(code);
        drugItem.setDescription("Medicine used to treat pain and fever");
        drugItem.setBaseUom("PIECE");
        drugItem.setSalesUom("PIECE");
        drugItem.setPurchaseUom("BOX30");
        drugItem.setCategory("APAP");
        drugItem.setSellingPrice(new SellingPriceBigDeci(new BigDecimal(120.0f), true));
//        drugItem.setReorderPoint(100);
//        drugItem.setReorderQty(10000);
//        drugItem.setMinimumOrderQty(1000);
//        drugItem.setMaximumOrderQty(100000);
//        drugItem.setSafetyStockQty(1000);
        drugItem.setInventoried(true);
        drugItem.setAllowNegativeInventory(false);
        drugItem.setSupplierId("SUP455752");
        drugItem.setItemType(itemType);
        drugItem.setStatus(Status.ACTIVE);
        drugItem.setDosageUom("TABLET");
        drugItem.setBrandName("Brand name");
        drugItem.setBrandNameJapanese("Brand name J");
        drugItem.setBrandNameChinese("Brand name C");
        drugItem.setGenericName("Generic name");
        drugItem.setGenericNameJapanese("Generic name J");
        drugItem.setGenericNameChinese("Generic name C");
        drugItem.setPrintDrugLabel(false);
        drugItem.setRemarks("End of life");
        drugItem.setMimsClassification("mims classification");
        drugItem.setDrugType("drug type");
        drugItem.setDrugBrandedType("Drug branded type");
        drugItem.setModeOfAdministration("Admin");
        drugItem.setDosageQty(120.9);
        drugItem.setFrequency("One week");
        drugItem.setFrequencyCode("OW");
        drugItem.setDosageInstructionCode("DIC01");
        drugItem.setPrecautionaryInstructions("");
        drugItem.setIndications("Indication");
        drugItem.setControlledDrug(true);
        drugItem.setTrackingCode(false);
        drugItem.setDispensingMultiples(10002);

        return drugItem;
    }


    public static DrugItem mockDrugItem(String itemId, String code, Item.ItemType itemType){
        DrugItem drugItem = new DrugItem();
        drugItem.setId(itemId);
        drugItem.setName("Paracetamol");
        drugItem.setCode(code);
        drugItem.setDescription("Medicine used to treat pain and fever");
        drugItem.setBaseUom("TABLET");
        drugItem.setSalesUom("TABLET");
        drugItem.setPurchaseUom("TABLET");
        drugItem.setCategory("APAP");
        drugItem.setSellingPrice(new SellingPriceBigDeci(new BigDecimal(120.0f), true));
//        drugItem.setReorderPoint(100);
//        drugItem.setReorderQty(10000);
//        drugItem.setMinimumOrderQty(1000);
//        drugItem.setMaximumOrderQty(100000);
//        drugItem.setSafetyStockQty(1000);
        drugItem.setInventoried(true);
        drugItem.setAllowNegativeInventory(false);
        drugItem.setSupplierId("SUP455752");
        drugItem.setItemType(itemType);
        drugItem.setStatus(Status.ACTIVE);
        drugItem.setDosageUom("TABLET");
        drugItem.setBrandName("Brand name");
        drugItem.setBrandNameJapanese("Brand name J");
        drugItem.setBrandNameChinese("Brand name C");
        drugItem.setGenericName("Generic name");
        drugItem.setGenericNameJapanese("Generic name J");
        drugItem.setGenericNameChinese("Generic name C");
        drugItem.setPrintDrugLabel(false);
        drugItem.setRemarks("End of life");
        drugItem.setMimsClassification("mims classification");
        drugItem.setDrugType("drug type");
        drugItem.setDrugBrandedType("Drug branded type");
        drugItem.setModeOfAdministration("Admin");
        drugItem.setDosageQty(120.9);
        drugItem.setFrequency("One week");
        drugItem.setFrequencyCode("OW");
        drugItem.setDosageInstructionCode("DIC01");
        drugItem.setPrecautionaryInstructions("");
        drugItem.setIndications("Indication");
        drugItem.setControlledDrug(true);
        drugItem.setTrackingCode(true);
        drugItem.setDispensingMultiples(10002);

        return drugItem;
    }

    public static InventoryUsage mockInventoryUsage(InventoryUsage.InventoryType inventoryType, String itemId, double qty, String salesUom, String baseUom){
        return new InventoryUsage(inventoryType, itemId, qty, "ABCD", salesUom, baseUom, true);
    }

}
