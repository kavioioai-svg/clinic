package com.ilt.cms.inventory.svc.service.purchase;

import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.item.UomMatrixDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestItemRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.purchase.DeliveryItem;
import com.ilt.cms.inventory.svc.model.purchase.GoodOrderedItem;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedNote;
import com.ilt.cms.inventory.svc.model.purchase.TransferRequestItem;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.service.common.LogoUtil;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import com.lippo.cms.gst.service.GstUtilsService;
import com.lippo.cms.notify.SystemNotifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.*;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BackOrderCountTests {
    private final OrderDatabaseService orderDatabaseServiceMock = mock(OrderDatabaseService.class);
    private final UOMMatrixService uomMatrixServiceMock = mock(UOMMatrixService.class);
    private final DrugItemService itemServiceMock = mock(DrugItemService.class);
    private OrderService orderService = new OrderService(
            orderDatabaseServiceMock,
            mock(RunningNumberService.class),
            mock(LocationService.class),
            uomMatrixServiceMock,
            mock(UomMatrixDatabaseService.class),
            itemServiceMock,
            mock(ClinicRepository.class),
            mock(SupplierRepository.class),
            mock(SystemNotifier.class),
            mock(CaseRepository.class),
            mock(InventoryTransactionRepository.class),
            mock(RequestService.class),
            mock(RequestItemRepository.class),
            mock(GstUtilsService.class),
            mock(LogoUtil.class)
    );

    @BeforeEach
    void setUp() {
        Mockito.reset(orderDatabaseServiceMock);
    }

    @Test
    void findBackOrderCountTest() throws ExecutionException {
        Set<String> itemRefIds = Set.of("itemId1", "itemId2");
        String clinicId = "clinicId";
        String orderId = "orderId";

        // Mock GoodOrderedItems
        GoodOrderedItem goodOrderedItem1 = createGoodOrderedItem("itemId1", "unit1", 10);
        GoodOrderedItem goodOrderedItem2 = createGoodOrderedItem("itemId1", "unit1", 20);
        List<GoodOrderedItem> goodOrderedItems = Arrays.asList(goodOrderedItem1, goodOrderedItem2);

        // Mock DeliveryItems
        DeliveryItem deliveryItem1 = createDeliveryItem("itemId1", "unit1", 10);
        List<DeliveryItem> deliveryItems1 = Collections.singletonList(deliveryItem1);

        // Create Order with GoodOrderedItems and DeliveryItems
        Order order1 = createOrder(orderId, goodOrderedItems, Collections.emptyList(), deliveryItems1);

        // Mock TransferRequestItem
        TransferRequestItem transferRequestItem1 = createTransferRequestItem("itemId2", "unit2", 5);
        TransferRequestItem transferRequestItem2 = createTransferRequestItem("itemId2", "unit2", 15);
        List<TransferRequestItem> transferRequestItems = Arrays.asList(transferRequestItem1, transferRequestItem2);

        // Mock DeliveryItems
        DeliveryItem deliveryItem2 = createDeliveryItem("itemId2", "unit2", 5);
        List<DeliveryItem> deliveryItems2 = Collections.singletonList(deliveryItem2);

        // Create Order with TransferRequestItems and DeliveryItems
        Order order2 = createOrder(orderId, Collections.emptyList(), transferRequestItems, deliveryItems2);

        // Mock ItemService
        Item item1 = createItem("itemId1", "unit1");
        Item item2 = createItem("itemId2", "unit2");
        List<Item> itemsList = Arrays.asList(item1, item2);
        when(itemServiceMock.findItemByIds(new ArrayList<>(itemRefIds))).thenReturn(itemsList);

        // Mock UomMatrixService
        double baseQuantity1_10 = 100; // For example, converting 10 'unit1' quantity of itemId1 to base quantity gives 100
        double baseQuantity1_20 = 200; // For example, converting 20 'unit1' quantity of itemId1 to base quantity gives 200
        when(uomMatrixServiceMock.convertItemUom(item1, "unit1", item1.getBaseUom(), 10)).thenReturn(baseQuantity1_10);
        when(uomMatrixServiceMock.convertItemUom(item1, "unit1", item1.getBaseUom(), 20)).thenReturn(baseQuantity1_20);

        double baseQuantity2_5 = 50; // For example, converting 5 'unit2' quantity of itemId2 to base quantity gives 50
        double baseQuantity2_15 = 150; // For example, converting 15 'unit2' quantity of itemId2 to base quantity gives 150
        when(uomMatrixServiceMock.convertItemUom(item2, "unit2", item2.getBaseUom(), 5)).thenReturn(baseQuantity2_5);
        when(uomMatrixServiceMock.convertItemUom(item2, "unit2", item2.getBaseUom(), 15)).thenReturn(baseQuantity2_15);

        List<Order> orders = Arrays.asList(order1, order2);
        when(orderDatabaseServiceMock.findOpenOrdersWithItemRefIds(itemRefIds, clinicId)).thenReturn(orders);

        // call the method to be tested
        Map<String, Double> result = orderService.findBackOrderCount(itemRefIds, clinicId, orderId, OrderType.TRANSFER);

        // check results
        assertEquals(2, result.size());
        assertEquals((int)(baseQuantity1_10 + baseQuantity1_20 - baseQuantity1_10), result.get("itemId1"));  // 100 + 200 - 100 = 200
        assertEquals((int)(baseQuantity2_5 + baseQuantity2_15 - baseQuantity2_5), result.get("itemId2"));  // 50 + 150 - 50 = 150
    }

    public Item createItem(String itemId, String baseUom){
        Item item = mock(Item.class);
        when(item.getId()).thenReturn(itemId);
        when(item.getBaseUom()).thenReturn(baseUom);
        return item;
    }

    private GoodOrderedItem createGoodOrderedItem(String itemId, String uom, int quantity) {
        GoodOrderedItem item = mock(GoodOrderedItem.class);
        when(item.getItemRefId()).thenReturn(itemId);
        when(item.getUom()).thenReturn(uom);
        when(item.getQuantity()).thenReturn(quantity);
        return item;
    }

    private TransferRequestItem createTransferRequestItem(String itemId, String uom, int quantity) {
        TransferRequestItem item = mock(TransferRequestItem.class);
        when(item.getItemRefId()).thenReturn(itemId);
        when(item.getUom()).thenReturn(uom);
        when(item.getQuantity()).thenReturn(quantity);
        return item;
    }

    private DeliveryItem createDeliveryItem(String itemId, String uom, int quantity) {
        DeliveryItem item = mock(DeliveryItem.class);
        when(item.getItemRefId()).thenReturn(itemId);
        when(item.getUom()).thenReturn(uom);
        when(item.getQuantity()).thenReturn(quantity);
        return item;
    }

    public Order createOrder(String orderId, List<GoodOrderedItem> orderedItems, List<TransferRequestItem> transferRequestItems,
                             List<DeliveryItem> deliveryItems){
        Order order = mock(Order.class);
        when(order.getGoodPurchasedItems()).thenReturn(orderedItems);
        when(order.getTransferRequestItems()).thenReturn(transferRequestItems);

        GoodReceivedNote goodReceivedNote = mock(GoodReceivedNote.class);
        when(goodReceivedNote.getReceivedItems()).thenReturn(deliveryItems);
        when(order.getGoodReceivedNotes()).thenReturn(Collections.singletonList(goodReceivedNote));

        return order;
    }
}
