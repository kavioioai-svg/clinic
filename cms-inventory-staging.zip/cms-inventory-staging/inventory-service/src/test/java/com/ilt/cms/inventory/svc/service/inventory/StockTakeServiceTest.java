package com.ilt.cms.inventory.svc.service.inventory;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.SellingPriceBigDeci;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.clinic.ClinicDatabaseService;
import com.ilt.cms.database.item.ItemClinicDetailDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.database.store.SystemStoreDatabaseService;
import com.ilt.cms.inventory.svc.db.service.interfaces.StockTakeDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.inventory.StockCountItem;
import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.observer.NavStockNotification;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.ilt.cms.inventory.svc.service.common.SystemConfigService;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.nav.NavStockTakeService;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.cms.util.IdUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class StockTakeServiceTest {

    private static final String CLINIC_ID = "C0001";
    private static final String INVENTORY_ID = "I0001";
    private static final String CODE = "ITEM_A";
    private static final String ITEM_ID = "I0001";
    private static final String BATCH_NO = "ABC123";
    private static final String STOCK_TAKE_ID = "ST001";

    @Mock
    private ItemDatabaseService itemDatabaseService;
    @Mock
    private StockTakeDatabaseService stockTakeDatabaseService;
    @Mock
    private UOMMatrixService uomMatrixService;
    @Mock
    private ClinicDatabaseService clinicDatabaseService;
    @Mock
    private ItemClinicDetailDatabaseService itemClinicDetailDatabaseService;
    @Mock
    private RunningNumberService runningNumberService;
    @Mock
    private SystemConfigService systemConfigService;
    @Mock
    private LocationService locationService;
    @Mock
    private SystemNotifier systemNotifier;

    @Mock
    private DrugItemService itemService;
    @Mock
    private RestTemplate restTemplate;

    private StockTakeService stockTakeService;
    @Mock
    InventoryTransactionRepository inventoryTransactionRepository;
    @Mock
    private NavStockTakeService navStockTakeService;

    @Mock
    private InventoryUtilsService inventoryUtilsService;
    @Mock
    SystemStoreDatabaseService systemStoreDatabaseService;


    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Before
    public void setup() throws CMSException {

        MockitoAnnotations.initMocks(this);
        stockTakeService = new StockTakeService(itemDatabaseService, locationService, stockTakeDatabaseService,
                uomMatrixService, clinicDatabaseService, itemClinicDetailDatabaseService,
                runningNumberService, systemConfigService, systemNotifier,itemService, restTemplate, inventoryTransactionRepository, systemStoreDatabaseService,
                inventoryUtilsService, navStockTakeService);

        Item item = new Item();
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");
        item.setItemType(Item.ItemType.DRUG);
        item.setInventoried(true);
        when(itemDatabaseService.findByClinicIdAndCode(CLINIC_ID, CODE)).thenReturn(Optional.of(item));
        when(stockTakeDatabaseService.findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
                eq(CLINIC_ID), eq(StockCountType.ADJUSTMENT), anyList(), eq(ITEM_ID), eq(BATCH_NO))).thenReturn(new ArrayList<>());

        Clinic clinic = new Clinic();
        clinic.setName("Clinic A");
        clinic.setId(CLINIC_ID);
        when(clinicDatabaseService.findOne(CLINIC_ID)).thenReturn(Optional.of(clinic));

        Inventory inventory = new Inventory();
        inventory.setBatchNumber(BATCH_NO);
        inventory.setInventoryId(INVENTORY_ID);
        Location location = new Location();
        location.setInventory(List.of(inventory));
        when(locationService.findLocationByClinicId(eq(CLINIC_ID), anyList())).thenReturn(Optional.of(location));

        when(uomMatrixService.findReverseRatio(anyString(), anyString())).thenReturn(Double.valueOf("1.00"));
        StockTake stockTake1 = new StockTake();
        stockTake1.setClinicId("asda");
        stockTake1.setStockTakeName("dwasda");
        stockTake1.setTransactionNo("sdsf");
        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId("123123");
        stockCountItem.setItemCode("123123");
        stockTake1.setStockCountItems(List.of(stockCountItem));
        when(stockTakeDatabaseService.saveStockTake(any(StockTake.class))).thenAnswer(
                invocationOnMock -> {
                    StockTake stockTake = invocationOnMock.getArgument(0);
                    stockTake.setId("ST0001");
                    return stockTake;
                }
        );


        StockTake stockTake2 = new StockTake();
        stockTake2.setClinicId("asda");
        stockTake2.setStockTakeName("dwasda");
        stockTake2.setTransactionNo("sdsf");
        StockCountItem stockCountItem2 = new StockCountItem();
        stockCountItem2.setItemRefId(null);
        stockCountItem2.setItemCode("123123");
        stockTake2.setStockCountItems(List.of(stockCountItem2));
        when(stockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), anyString(), anyString(),
                anyString(), anyString(), anyList(), any(Pageable.class))).thenReturn(new PageImpl<>(List.of(stockTake1)));

        when(stockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), anyString(), isNull(),
                isNull(), isNull(), anyList(), any(Pageable.class))).thenReturn(new PageImpl<>(List.of(stockTake2)));

        StockTake stockTake3 = new StockTake();
        stockTake3.setClinicId("asda");
        stockTake3.setStockTakeName("dwasda");
        stockTake3.setTransactionNo("sdsf");
        StockCountItem stockCountItem3 = new StockCountItem();
        stockCountItem3.setItemName("123123");
        stockCountItem3.setItemCode(null);
        stockTake3.setStockCountItems(List.of(stockCountItem3));
        when(stockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), isNull(), anyString(),
                isNull(), isNull(), anyList(), any(Pageable.class))).thenReturn(new PageImpl<>(List.of(stockTake3)));

        when(stockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), isNull(), isNull(),
                anyString(), isNull(), anyList(), any(Pageable.class))).thenReturn(new PageImpl<>(List.of(stockTake1)));
        StockTake stockTake4 = new StockTake();
        stockTake4.setClinicId("asda");
        stockTake4.setStockTakeName("dwasda");
        stockTake4.setTransactionNo("sdsf");
        StockCountItem stockCountItem4 = new StockCountItem();
        stockCountItem4.setItemName(null);
        stockCountItem4.setItemRefId("123123");
        stockCountItem4.setItemCode(null);
        stockTake4.setStockCountItems(List.of(stockCountItem4));
        when(stockTakeDatabaseService.searchStockAdjustmentsByCriteria(anyString(), anyString(), isNull(), isNull(),
                isNull(), anyString(), anyList(), any(Pageable.class))).thenReturn(new PageImpl<>(List.of(stockTake1)));

    }

    @Test
    public void shouldNotSaveStockAdjustmentWhenAnotherPendingAdjustmentExists() throws CMSException {

        expectedException.expect(CMSException.class);
        expectedException.expectMessage("Existing adjustment exist for the same item/batch no");

        when(stockTakeDatabaseService.findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
                eq(CLINIC_ID), eq(StockCountType.ADJUSTMENT), anyList(), eq(ITEM_ID), eq(BATCH_NO))).thenReturn(List.of(new StockTake()));

        stockTakeService.adjustStockLevel(CLINIC_ID, "count", INVENTORY_ID, CODE, BATCH_NO, "tablet",
                LocalDate.now(), LocalDate.now(), 100, "P1", "Remark", BigDecimal.ZERO, null);
    }

    @Test
    public void shouldSaveStockAdjustment() throws CMSException {

        stockTakeService.adjustStockLevel(CLINIC_ID, "count", INVENTORY_ID, CODE, BATCH_NO, "tablet",
                LocalDate.now(), LocalDate.now(), 100, "P1", "Remark", BigDecimal.ZERO, null);

        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));
        verify(systemNotifier).notify(any(NavStockNotification.class));
    }

    @Test
    public void shouldDeleteFirstInProcessStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));

        stockTakeService.deleteStockTake(STOCK_TAKE_ID);

        verify(stockTakeDatabaseService).deleteStockTake(STOCK_TAKE_ID);
    }

    @Test
    public void shouldDeleteSecondInProcessStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE);
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));

        stockTakeService.deleteStockTake(STOCK_TAKE_ID);

        verify(stockTakeDatabaseService).deleteStockTake(STOCK_TAKE_ID);
    }

    @Test
    public void shouldNotDeleteCompletedAndNavSuccessStockTake() throws CMSException {

        expectedException.expect(CMSException.class);
        expectedException.expectMessage("Not allow to delete with status [" + StockTakeStatus.COMPLETED + "]");

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);
        stockTake.setNavIntegrationResult(new NavIntegrationResult(null, NavIntegrationResult.ResultStatus.SUCCESS));
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));

        stockTakeService.deleteStockTake(STOCK_TAKE_ID);
    }

    @Test
    public void shouldNewStockCountItemStopStockTake() throws CMSException {
        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "", null, LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                0);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(120.0);
        stockCountItem.setPurposeOfAdjustmentCode("030");
        stockCountItem.setRemark(null);

        Item item = new Item();
        item.setTrackingCode(true);
        item.setId(ITEM_ID);
        item.setItemType(Item.ItemType.DRUG);
        item.setBaseUom("TABLET");
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));
        when(itemDatabaseService.findItemByItemId(ITEM_ID)).thenReturn(Optional.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));
    }

    @Test
    public void shouldNotAllowCurrentBatchNoNotSameStopStockTake() throws CMSException {

        expectedException.expect(CMSException.class);
        expectedException.expectMessage("Not valid in stockCountItem");

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER_1", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(null);
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
    }

    @Test
    public void stockCountItemValidateInFirstStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(null);
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setItemType(Item.ItemType.DRUG);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));

    }

    @Test
    public void stockCountItemValidateInFirstStockTakeWithConsumableTrackCode() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(null);
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setItemType(Item.ItemType.CONSUMABLE);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));

    }

    @Test
    public void stockCountItemValidateInFirstStockTakeWithConsumableNonTrackCode() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "", "TABLET", null, LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(null);
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(false);
        item.setItemType(Item.ItemType.CONSUMABLE);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));

    }

    @Test
    public void stockCountItemValidateInSecondStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(null);
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setItemType(Item.ItemType.DRUG);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));

    }

    @Test
    public void stockCountItemValidateInCompleteStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                120);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(100.0);
        stockCountItem.setAdjustedQuantity(120.0);
        stockCountItem.setPurposeOfAdjustmentCode("");
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setItemType(Item.ItemType.DRUG);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));
        verify(stockTakeDatabaseService).saveStockTake(any(StockTake.class));

    }

    @Test
    public void stockCountItemValidateInCompleteStockTakeWithNoAdjustmentCode() throws CMSException {

        expectedException.expect(CMSException.class);
        expectedException.expectMessage("Not valid in stockCountItem");

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem("", null, null, ITEM_ID,
                "BN_NUMBER", "TABLET", LocalDate.now().plusYears(3), LocalDate.now().minusYears(1),
                100);
        stockCountItem.setId("STOCK_COUNT_ITEM_ID");
        stockCountItem.setBatchNumber("BN_NUMBER");
        stockCountItem.setExpiryDate(LocalDate.now().plusYears(4));
        stockCountItem.setBaseUom("TABLET");
        stockCountItem.setFirstQuantity(120.0);
        stockCountItem.setAdjustedQuantity(130.0);
        stockCountItem.setPurposeOfAdjustmentCode("");
        stockCountItem.setRemark(null);
        stockTake.setStockCountItems(new ArrayList<>(List.of(stockCountItem)));

        Item item = new Item();
        item.setTrackingCode(true);
        item.setItemType(Item.ItemType.DRUG);
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");

        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(List.of(ITEM_ID))).thenReturn(List.of(item));

        stockTakeService.stopCountStockTake(STOCK_TAKE_ID, new ArrayList<>(List.of(stockCountItem)));

    }


    @Test
    public void shouldDeleteCompletedAndNavFailedStockTake() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);
        stockTake.setNavIntegrationResult(new NavIntegrationResult(null, NavIntegrationResult.ResultStatus.FAILED));
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));

        stockTakeService.deleteStockTake(STOCK_TAKE_ID);

        verify(stockTakeDatabaseService).deleteStockTake(STOCK_TAKE_ID);
    }

    @Test
    public void testListAllAdjustments() {
        Page<StockTake> stockTakePage = stockTakeService.listAllAdjustment(CLINIC_ID, "ALL", "code1", "code 1", "2123123", ITEM_ID,
                List.of("APPROVED"), 0, 10, Sort.Direction.ASC, "transactionNo");

        assertEquals("Total elements ", 1, stockTakePage.getContent().size());
        assertEquals("Total Pages ", 1, stockTakePage.getTotalPages());
    }

    @Test
    public void testListAllAdjustmentsByItemCode() {
        Page<StockTake> stockTakePage = stockTakeService.listAllAdjustment(CLINIC_ID, "ALL", "code1", null, null, null,
                List.of("APPROVED"), 0, 10, Sort.Direction.ASC, "transactionNo");
        List<StockTake> stockTakes = stockTakePage.getContent();


        assertEquals("Total elements ", 1, stockTakePage.getContent().size());
        assertEquals("Total Pages ", 1, stockTakePage.getTotalPages());
        assertTrue(stockTakes.stream().flatMap(stockTake -> stockTake.getStockCountItems().stream()).anyMatch(stockCountItem ->
                stockCountItem.getItemCode().equals("123123")));
    }

    @Test
    public void testListAllAdjustmentsByItemRefId() {
        Page<StockTake> stockTakePage = stockTakeService.listAllAdjustment(CLINIC_ID, "ALL", null, null, null, ITEM_ID,
                List.of("APPROVED"), 0, 10, Sort.Direction.ASC, "transactionNo");
        List<StockTake> stockTakes = stockTakePage.getContent();

        assertEquals("Total elements ", 1, stockTakePage.getContent().size());
        assertEquals("Total Pages ", 1, stockTakePage.getTotalPages());
        assertTrue(stockTakes.stream().flatMap(stockTake -> stockTake.getStockCountItems().stream()).anyMatch(stockCountItem ->
                stockCountItem.getItemRefId().equals("123123")));
    }

    @Test
    public void testListAllAdjustmentsByItemName() {
        Page<StockTake> stockTakePage = stockTakeService.listAllAdjustment(CLINIC_ID, "ALL", null, "code 1", null, null,
                List.of("APPROVED"), 0, 10, Sort.Direction.ASC, "transactionNo");
        List<StockTake> stockTakes = stockTakePage.getContent();
        assertEquals("Total elements ", 1, stockTakePage.getContent().size());
        assertEquals("Total Pages ", 1, stockTakePage.getTotalPages());
        assertTrue(stockTakes.stream().flatMap(stockTake -> stockTake.getStockCountItems().stream()).anyMatch(stockCountItem ->
                stockCountItem.getItemName().equals("123123")));
    }

    @Test
    public void testListAllAdjustmentsByTransactionNo() {
        Page<StockTake> stockTakePage = stockTakeService.listAllAdjustment(CLINIC_ID, "ALL", null, null, "2123123", null,
                List.of("APPROVED"), 0, 10, Sort.Direction.ASC, "transactionNo");
        List<StockTake> stockTakes = stockTakePage.getContent();

        assertEquals("Total elements ", 1, stockTakePage.getContent().size());
        assertEquals("Total Pages ", 1, stockTakePage.getTotalPages());
        assertTrue(stockTakes.stream().anyMatch(stockTake -> stockTake.getTransactionNo().equals("sdsf")));
    }

    @Test
    public void shouldSaveStockAdjustmentWhenBatchNumberNotExists() throws CMSException {
        Inventory inventory = new Inventory();
        inventory.setInventoryId("I10002");
        inventory.setItemRefId("I0001");
        inventory.setAvailableCount(BigDecimal.valueOf(2000));
        Location location = new Location();
        location.setInventory(List.of(inventory));
        when(locationService.findLocationByClinicId(eq(CLINIC_ID), anyList())).thenReturn(Optional.of(location));
        Item item = new Item();
        item.setId(ITEM_ID);
        item.setBaseUom("TABLET");
        item.setItemType(Item.ItemType.CONSUMABLE);
        item.setInventoried(true);
        item.setTrackingCode(false);
        when(itemDatabaseService.findByClinicIdAndCode(CLINIC_ID, CODE)).thenReturn(Optional.of(item));


        StockTake stockTake = stockTakeService.adjustStockLevel(CLINIC_ID, "count", INVENTORY_ID, CODE, null, "tablet",
                null, LocalDate.now(), 100, "P1", "Remark",BigDecimal.ZERO, null);
        assertEquals("Available Count should exist ", true, stockTake.getStockCountItems().stream().anyMatch(stockCountItem -> stockCountItem.getAvailableCount() > 0));
    }


    @Test
    public void shouldDeleteCompletedAndNavFailedStockAdjustment() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setCountType(StockCountType.ADJUSTMENT);
        stockTake.setId(STOCK_TAKE_ID);
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);
        stockTake.setApproveStatus(StockTakeApproveStatus.NOT_APPROVED);
        stockTake.setNavIntegrationResult(new NavIntegrationResult(null, NavIntegrationResult.ResultStatus.FAILED));
        when(stockTakeDatabaseService.findStockTakeById(STOCK_TAKE_ID)).thenReturn(Optional.of(stockTake));

        stockTakeService.deleteStockTake(STOCK_TAKE_ID);

        verify(stockTakeDatabaseService).deleteStockTake(STOCK_TAKE_ID);
    }

    @Test
    public void shouldNotBeAbleToAdjustStockItemWithStockStakeStatusCompleted() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE);

        StockCountItem stockCountItem = new StockCountItem();

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.approveAdjustStockItems(stockTake.getId(), stockCountItem);
        });

        String expected = "Not allow to approve with Stock Take Status[" + stockTake.getStockTakeStatus() + "]";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldNotBeAbleToAdjustStockItemWithStockStakeApproveStatusApprovedOrRejected() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);
        stockTake.setApproveStatus(StockTakeApproveStatus.APPROVED);

        StockCountItem stockCountItem = new StockCountItem();

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.approveAdjustStockItems(stockTake.getId(), stockCountItem);
        });

        String expected = "Stock Take is already "+stockTake.getApproveStatus();
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldNotBeAbleToAdjustStockItemIfStockCountItemIfNotPresentInStockTakeStockCountItemList() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.approveAdjustStockItems(stockTake.getId(), stockCountItem);
        });

        String expected = "Stock Count Item [ "+stockCountItem.getItemRefId()+" ] not found";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldNotBeAbleToAdjustStockItemIfStockCountItemIfNotPresentInItemDatabase() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());

        stockTake.setStockCountItems(List.of(stockCountItem));

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.approveAdjustStockItems(stockTake.getId(), stockCountItem);
        });

        String expected = "Stock Count Item [ "+stockCountItem.getItemRefId()+" ] not found in item database";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldBeAbleToAdjustStockItemQuantityCpRemarksApproveStatusApprovedDate() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setAdjustedQuantity(Double.valueOf(100));
        stockCountItem.setCpRemarks("Test");

        stockTake.setStockCountItems(List.of(stockCountItem));

        Item item = new Item();
        item.setId(stockCountItem.getItemRefId());

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        when(itemDatabaseService.findItemsByIds(anyList())).thenReturn(List.of(item));

        when(stockTakeDatabaseService.saveStockTake(any(StockTake.class))).thenAnswer((args)->{
            StockTake modifiedStockStake = args.getArgument(0);

            assertEquals(stockCountItem.getCpRemarks(),modifiedStockStake.getStockCountItems().get(0).getCpRemarks());
            assertEquals(LocalDate.now(),modifiedStockStake.getStockCountItems().get(0).getApprovedDate());

            return modifiedStockStake;

        });

        stockTakeService.approveAdjustStockItems(stockTake.getId(), stockCountItem);
        
    }

    @Test
    public void shouldNotBeAbleToCheckStockAdjQuantityExceedsLimitIfStockTakeIsNotFound() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());

        StockCountItem stockCountItem = new StockCountItem();

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.isStockAdjQuantityExceedsLimit(stockTake.getId(), stockCountItem.getId());
        });

        String expected = "Stock take[" + stockTake.getId() + "] not found";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldNotBeAbleToCheckStockAdjQuantityExceedsLimitIfStockItemIsNotFound() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());

        StockCountItem stockCountItem = new StockCountItem();

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.isStockAdjQuantityExceedsLimit(stockTake.getId(), stockCountItem.getId());
        });

        String expected = "Stock count item[" + stockCountItem.getId() + "] not found";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldNotBeAbleToCheckStockAdjQuantityExceedsLimitIfStockItemRefIdIsNotFoundInItemDatabase() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());

        stockTake.setStockCountItems(List.of(stockCountItem));

        Item item = new Item();
        item.setId(IdUtils.lineNoGenerator());

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        //when(itemService.listItemByClinicId(anyString())).thenReturn(List.of(item));

        CMSException cmsException = assertThrows(CMSException.class,()->{
            stockTakeService.isStockAdjQuantityExceedsLimit(stockTake.getId(), stockCountItem.getId());
        });

        String expected = "Stock Count Item [ "+stockCountItem.getItemRefId()+" ] not found in item database";
        String actual = cmsException.getMessage();

        assertEquals(expected, actual);

    }

    @Test
    public void shouldBeAbleToCheckStockAdjQuantityExceedsLimitIfItemSellingPriceNotNull() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setClinicId("123");

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setAvailableCount(129);
        stockCountItem.setAdjustedQuantity(135.0);

        stockTake.setStockCountItems(List.of(stockCountItem));

        Item item = new Item();
        item.setId(stockCountItem.getItemRefId());
        item.setSellingPrice(new SellingPriceBigDeci(BigDecimal.valueOf(2.0),true));

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        when(itemService.listItemByClinicId(anyString())).thenReturn(List.of(item));

        stockTakeService.setThreshold(BigDecimal.valueOf(11.0));

        boolean actual = stockTakeService.isStockAdjQuantityExceedsLimit(stockTake.getId(),stockCountItem.getId());
        boolean expected = true;

        assertEquals(expected,actual);

    }

    @Test
    public void shouldBeAbleToCheckStockAdjQuantityExceedsLimitIfEvenItemSellingPriceIsNull() throws CMSException {

        StockTake stockTake = new StockTake();
        stockTake.setId(IdUtils.lineNoGenerator());
        stockTake.setClinicId("123");

        StockCountItem stockCountItem = new StockCountItem();
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setItemRefId(IdUtils.lineNoGenerator());
        stockCountItem.setAvailableCount(129);
        stockCountItem.setAdjustedQuantity(135.0);

        stockTake.setStockCountItems(List.of(stockCountItem));

        Item item = new Item();
        item.setId(stockCountItem.getItemRefId());
        item.setSellingPrice(new SellingPriceBigDeci());

        when(stockTakeDatabaseService.findStockTakeById(anyString())).thenReturn(Optional.of(stockTake));
        when(itemService.listItemByClinicId(anyString())).thenReturn(List.of(item));

        stockTakeService.setThreshold(BigDecimal.valueOf(5.0));

        boolean actual = stockTakeService.isStockAdjQuantityExceedsLimit(stockTake.getId(),stockCountItem.getId());
        boolean expected = true;

        assertEquals(expected,actual);

    }

}
