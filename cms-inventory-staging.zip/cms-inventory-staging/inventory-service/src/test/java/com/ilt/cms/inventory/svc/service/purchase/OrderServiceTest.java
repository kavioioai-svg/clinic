package com.ilt.cms.inventory.svc.service.purchase;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.casem.*;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.SellingPrice;
import com.ilt.cms.core.entity.item.SellingPriceBigDeci;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemClinicDetailDatabaseService;
import com.ilt.cms.database.item.UomMatrixDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestItemRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.service.common.LogoUtil;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.lippo.cms.gst.service.GstUtilsService;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.inventory.svc.service.mock.MockItem;
import com.ilt.cms.inventory.svc.service.mock.MockLocation;
import com.ilt.cms.inventory.svc.service.mock.MockOrder;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.cms.util.CMSConstant;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static com.lippo.cms.util.Calculations.roundingQuantity;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class OrderServiceTest {
    private static String PURCHASE_REQUEST_ID = "PR0001";

    private static String ITEM_ID = "ITEM_ID";
    private static String CONSUMABLE_ITEM_ID = "CONSUMABLE_ITEM_ID";
    private static String ITEM_CODE_1 = "ITEM_CODE_1";
    private static String CONSUMABLE_ITEM_CODE = "CONSUMABLE_ITEM_CODE";

    private static String SENDER_CLINIC_ID = "SENDER_CLINIC_ID";

    private static String REQUEST_ID = "REQUEST_ID";
    private static String ORDER_ID_INITIAL = "ORDER_ID_INITIAL";
    private static String ORDER_ID_FULL = "ORDER_ID_FULL";
    private static String ORDER_ID_RETURN_FULL = "ORDER_ID_RETURN_FULL";
    private static String ORDER_ID_RETURN_INITIAL = "ORDER_ID_RETURN_INITIAL";
    private static String ORDER_ID_RETURN_DRAFT = "ORDER_ID_RETURN_DRAFT";
    private static String ORDER_ID_TRANSFER_FULL = "ORDER_ID_TRANSFER_FULL";
    private static String ORDER_ID_TRANSFER_INITIAL = "ORDER_ID_TRANSFER_INITIAL";
    private static String REQUIRE_CLINIC_ID = "REQUIRE_CLINIC_ID";
    private static String SUPPLIER_ID = "SUPPLIER_ID";
    private static String BATCH_NO = "BATCH_NO";
    private static String GRN_NO = "GRN_NO";
    private static String GRVN_NO = "GRVN_NO";
    private static String DN_NO = "DN_NO";
    private static String GRN_ID = "GRN_ID";
    private static String GRVN_ID = "GRVN_ID";
    private static String GRVNDN_ID = "GRVNDN_ID";
    private static String DN_ID = "DN_ID";
    private static String RETURN_ITEM_ID = "RETURN_ITEM_ID";

    @MockBean
    private OrderDatabaseService orderDatabaseService;
    @MockBean
    private RunningNumberService runningNumberService;
    @MockBean
    private DrugItemService itemService;
    @MockBean
    private SupplierDatabaseService supplierDatabaseService;
    @MockBean
    private ItemClinicDetailDatabaseService itemClinicDetailDatabaseService;
    @MockBean
    private LocationService locationService;
    @MockBean
    private UOMMatrixService uomMatrixService;
    @MockBean
    private UomMatrixDatabaseService uomMatrixDatabaseService;
    @MockBean
    private RequestRepository requestRepository;
    @MockBean
    private SystemNotifier systemNotifier;

    @MockBean
    private MongoTemplate mongoTemplate;

    @MockBean
    private ClinicRepository clinicRepository;
    @MockBean
    private SupplierRepository supplierRepository;

    @MockBean
    private GstUtilsService gstUtilsService;

    @MockBean
    private LogoUtil logoUtil;

    private OrderService orderService;
    private IntegrationService integrationService;

    @MockBean
    private RequestService requestService;
    private Item drugItem;
    private Item consumableItem;

    private Order initialPurchaseOrder;
    private Order fullPurchaseOrder;
    private Order fullReturnOrder;
    private Order initialReturnOrder;
    private Order draftReturnOrder;
    private Order fullTransferOrder;
    private Order initialTransferOrder;

    private Location location;

    @MockBean
    CaseRepository caseRepository;

    @MockBean
    InventoryTransactionRepository inventoryTransactionRepository;

    @MockBean
    private RequestItemRepository requestItemRepository;

    @Before
    public void setup() throws Exception {

        drugItem = MockItem.mockDrugItem(ITEM_ID, ITEM_CODE_1, Item.ItemType.DRUG);
        consumableItem = MockItem.mockConsumableItem(CONSUMABLE_ITEM_ID, CONSUMABLE_ITEM_CODE, Item.ItemType.CONSUMABLE);
        location = MockLocation.mockLocation(REQUIRE_CLINIC_ID);
        location.setInventory(new ArrayList<>(List.of(
                MockLocation.mockInventory(ITEM_ID, ITEM_CODE_1, BATCH_NO, LocalDate.now().plusYears(3), "TABLET", 10000),
                MockLocation.mockInventory(CONSUMABLE_ITEM_ID, CONSUMABLE_ITEM_CODE, null, null, "PIECE", 10000)
        )));
        initialPurchaseOrder = MockOrder.mockBasicPurchaseOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, ITEM_ID,
                "TABLET", 100, OrderStatus.INITIAL);
        fullPurchaseOrder = MockOrder.mockBasicPurchaseOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, ITEM_ID,
                "TABLET", 100, OrderStatus.FULL_RECEIVED);
        fullPurchaseOrder.setGoodPurchasedItems(new ArrayList<>(
                List.of(
                        MockOrder.mockGoodOrderItem(ITEM_ID, SUPPLIER_ID,
                                "TABLET", 100, new UnitPrice()),
                        MockOrder.mockGoodOrderItem(CONSUMABLE_ITEM_ID, SUPPLIER_ID,
                                "PIECE", 100, new UnitPrice())
                )
        ));
        createMockGRN(fullPurchaseOrder);

        fullReturnOrder = MockOrder.mockBasicReturnOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, ITEM_ID,
                "TABLET", 100, GoodReceivedReturnStatus.RETURNED, ORDER_ID_FULL);
        createMockReturnItem(fullReturnOrder, ORDER_ID_INITIAL);
        createMockDN(fullReturnOrder, GRVNDN_ID);

        initialReturnOrder = MockOrder.mockBasicReturnOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, ITEM_ID,
                "TABLET", 100, GoodReceivedReturnStatus.APPROVED, ORDER_ID_FULL);
        createMockGRN(initialReturnOrder);

        draftReturnOrder = MockOrder.mockBasicReturnOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, ITEM_ID,
                "TABLET", 100, GoodReceivedReturnStatus.DRAFT, ORDER_ID_FULL);
        createMockGRN(draftReturnOrder);

        fullTransferOrder = MockOrder.mockBasicTransferOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SENDER_CLINIC_ID, ITEM_ID,
                "TABLET", 100, OrderStatus.FULL_RECEIVED);
        createMockGRN(fullTransferOrder);
        createMockDN(fullTransferOrder, DN_ID);

        initialTransferOrder = MockOrder.mockBasicTransferOrder(REQUEST_ID, REQUIRE_CLINIC_ID, SENDER_CLINIC_ID, ITEM_ID,
                "TABLET", 100, OrderStatus.INITIAL);

        orderService = new OrderService(orderDatabaseService, runningNumberService, locationService,
                uomMatrixService, uomMatrixDatabaseService, itemService,
                clinicRepository, supplierRepository
                , systemNotifier, caseRepository, inventoryTransactionRepository,
                requestService, requestItemRepository, gstUtilsService, logoUtil);
        when(orderDatabaseService.findOrderById(ORDER_ID_INITIAL)).thenReturn(Optional.of(initialPurchaseOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_FULL)).thenReturn(Optional.of(fullPurchaseOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_RETURN_FULL)).thenReturn(Optional.of(fullReturnOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_RETURN_INITIAL)).thenReturn(Optional.of(initialReturnOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_RETURN_DRAFT)).thenReturn(Optional.of(draftReturnOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_TRANSFER_FULL)).thenReturn(Optional.of(fullTransferOrder));
        when(orderDatabaseService.findOrderById(ORDER_ID_TRANSFER_INITIAL)).thenReturn(Optional.of(initialTransferOrder));

        when(itemService.findItemById(eq(ITEM_ID))).thenReturn(drugItem);
        when(itemService.findItemByIds(anyList())).thenReturn(List.of(drugItem, consumableItem));
        when(uomMatrixService.findReverseRatio(anyString(), anyString())).thenReturn(1.0);
        when(locationService.convertQuantityWithNavCheck(anyInt(), anyString(), anyString())).thenAnswer(invocationOnMock -> {
            int quantity = invocationOnMock.getArgument(0);
            return new BigDecimal(quantity).doubleValue();
        });
        when(locationService.findLocationByClinicId(anyString(), anyList())).thenReturn(Optional.of(location));
        when(orderDatabaseService.saveOrder(any(Order.class))).thenAnswer(invocationOnMock -> {
            Order order = invocationOnMock.getArgument(0);
            order.setId(ORDER_ID_INITIAL);
            return order;
        });
        when(orderDatabaseService.findPurchaseRequestById(REQUEST_ID)).thenReturn(Optional.of(new PurchaseRequest()));
        when(requestRepository.findById(REQUEST_ID)).thenReturn(Optional.of(new PurchaseRequest()));
        when(runningNumberService.generateGRNNumber()).thenReturn(GRN_NO);
        when(runningNumberService.generateDeliveryNote()).thenReturn(DN_NO);

        Clinic clinic4 = new Clinic();
        clinic4.setId("ckdiik29o34j49433r4kd");
        clinic4.setName("Clinic1");
        clinic4.setClinicCode("BBTW");
        clinic4.setGroupName("B03");
        clinic4.setStatus(Status.ACTIVE);
        when(clinicRepository.findAll()).thenReturn(List.of(clinic4));
        when(clinicRepository.findByIdAndStatus(any(), any())).thenReturn(Optional.of(clinic4));

        when(clinicRepository.findByIdAndStatus(REQUIRE_CLINIC_ID, Status.ACTIVE)).thenReturn(Optional.of(new Clinic()));
        when(supplierRepository.findById(SUPPLIER_ID)).thenReturn(Optional.of(new Supplier()));
    }

    private void createMockGRN(Order order) {
        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(GRN_ID, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, GRN_NO, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);
        DeliveryItem deliveryItem1 = MockOrder.mockDeliveryItem("0002", CONSUMABLE_ITEM_ID, "PIECE", null, 100,
                null, false, null);
        goodReceivedNote.setReceivedItems(List.of(deliveryItem, deliveryItem1));
        order.setGoodReceivedNotes(new ArrayList<>(List.of(goodReceivedNote)));
    }

    private void createMockReturnItem(Order order, String purchaseOrderId) {
        GoodReturnItem goodReturnItem = MockOrder.mockGoodReturnItem(RETURN_ITEM_ID, ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        order.setReturnItems(new ArrayList<>(List.of(goodReturnItem)));
    }

//    private void createMockGRVN(Order order, GoodReceivedReturnStatus goodReceivedReturnStatus) {
//        GoodReceivedVoidNote goodReceivedVoidNote = MockOrder.mockGoodReceivedVoidNote(GRVN_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID,
//                GRVN_NO, null, goodReceivedReturnStatus);
//        GoodReturnItem goodReturnItem = MockOrder.mockGoodReturnItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
//                LocalDate.now(), "INVOICE_NO", LocalDate.now(), LocalDate.now(), "", new UnitPrice());
//        goodReceivedVoidNote.setReturnItems(new ArrayList<>(List.of(goodReturnItem)));
//        goodReceivedVoidNote.setDeliveryNotes(new ArrayList<>());
//        order.setGoodReceivedVoidNotes(new ArrayList<>(List.of(goodReceivedVoidNote)));
//    }
//
//    private void createMockGRVNDN(Order order) {
//        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(GRVNDN_ID, REQUIRE_CLINIC_ID, SUPPLIER_ID, LocalDate.now(),
//                LocalDate.now(), DN_NO, DeliveryNoteStatus.CONFIRM);
//        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
//                LocalDate.now(), false, null);
//        deliveryNote.setTransferSendItems(new ArrayList<>(List.of(deliveryItem)));
//        Optional<GoodReceivedVoidNote> goodReceivedVoidNoteOpt = order.getGoodReceivedVoidNotes().stream().findFirst();
//        if (goodReceivedVoidNoteOpt.isPresent()) {
//            goodReceivedVoidNoteOpt.get().setDeliveryNotes(new ArrayList<>(List.of(deliveryNote)));
//        }
//    }

    private void createMockDN(Order order, String id) {
        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(id, REQUIRE_CLINIC_ID, SUPPLIER_ID, LocalDate.now(),
                LocalDate.now(), DN_NO, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now(), false, null);
        deliveryNote.setTransferSendItems(new ArrayList<>(List.of(deliveryItem)));

        order.setDeliveryNotes(new ArrayList<>(List.of(deliveryNote)));
    }

    @Test
    public void createReturnOrderWithPO() throws CMSException {

        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem1 = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        GoodReturnItem goodReturnItem2 = MockOrder.mockGoodReturnItem("10002", CONSUMABLE_ITEM_ID, "PIECE", null, 100, LocalDate.now(), "INVOICE",
                null, null, "re-stock");
        goodReturnItems.addAll(List.of(goodReturnItem1, goodReturnItem2));
        Order returnOrder = orderService.createReturnOrder(REQUIRE_CLINIC_ID, SUPPLIER_ID, ORDER_ID_FULL, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
        assertThat(returnOrder.getReturnItems().size(), is(2));
        assertThat(returnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.CONFIRM));
        assertNotNull(returnOrder.getCreateDate());
        assertNotNull(returnOrder.getOrderDate());
    }

    @Test(expected = CMSException.class)
    public void createReturnOrderWithInvalidDrugItems() throws CMSException {

        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem1 = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", null, 100, null, "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        GoodReturnItem goodReturnItem2 = MockOrder.mockGoodReturnItem("10002", CONSUMABLE_ITEM_ID, "PIECE", null, 100, LocalDate.now(), "INVOICE",
                null, null, "re-stock");
        goodReturnItems.addAll(List.of(goodReturnItem1, goodReturnItem2));
        Order returnOrder = orderService.createReturnOrder(REQUIRE_CLINIC_ID, SUPPLIER_ID, ORDER_ID_FULL, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
    }

    @Test(expected = CMSException.class)
    public void createReturnOrderWithInvalidConsumableItems() throws CMSException {

        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem1 = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        GoodReturnItem goodReturnItem2 = MockOrder.mockGoodReturnItem("10002", CONSUMABLE_ITEM_ID, "PIECE", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                null, null, "re-stock");
        goodReturnItems.addAll(List.of(goodReturnItem1, goodReturnItem2));
        Order returnOrder = orderService.createReturnOrder(REQUIRE_CLINIC_ID, SUPPLIER_ID, ORDER_ID_FULL, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
    }

    @Test(expected = RuntimeException.class)
    public void createReturnOrderWithInvalidInventory() throws CMSException {
        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem1 = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        GoodReturnItem goodReturnItem2 = MockOrder.mockGoodReturnItem("10002", CONSUMABLE_ITEM_ID, "PIECE", null, 101, LocalDate.now(), "INVOICE",
                null, null, "re-stock");
        goodReturnItems.addAll(List.of(goodReturnItem1, goodReturnItem2));
        Order returnOrder = orderService.createReturnOrder(REQUIRE_CLINIC_ID, SUPPLIER_ID, ORDER_ID_FULL, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
        assertThat(returnOrder.getReturnItems().size(), is(2));
        assertThat(returnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.CONFIRM));
        assertNotNull(returnOrder.getCreateDate());
        assertNotNull(returnOrder.getOrderDate());
    }

    @Test
    public void createReturnOrderWithoutPO() throws CMSException {

        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        goodReturnItems.add(goodReturnItem);
        Order returnOrder = orderService.createReturnOrder(REQUIRE_CLINIC_ID, SUPPLIER_ID, null, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
        assertThat(returnOrder.getReturnItems().size(), is(1));
        assertThat(returnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.CONFIRM));
        assertNotNull(returnOrder.getCreateDate());
        assertNotNull(returnOrder.getOrderDate());
    }

    @Test
    public void updateReturnOrder() throws CMSException {

        List<GoodReturnItem> goodReturnItems = new ArrayList<>();
        GoodReturnItem goodReturnItem = MockOrder.mockGoodReturnItem("10001", ITEM_ID, "TABLET", BATCH_NO, 100, LocalDate.now(), "INVOICE",
                LocalDate.now().plusYears(3), null, "re-stock");
        goodReturnItems.add(goodReturnItem);
        Order returnOrder = orderService.updateReturnOrder(ORDER_ID_RETURN_DRAFT, SUPPLIER_ID, GoodReceivedReturnStatus.CONFIRM, goodReturnItems);
        assertThat(returnOrder.getReturnItems().size(), is(1));
        assertThat(returnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.CONFIRM));
        assertNotNull(returnOrder.getCreateDate());
        assertNotNull(returnOrder.getOrderDate());
    }

    @Test
    public void addGoodReceivedNote() throws CMSException {

        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(null, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, null, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);
        goodReceivedNote.setReceivedItems(List.of(deliveryItem));

        orderService.addGoodReceivedNote(ORDER_ID_INITIAL, goodReceivedNote);
        verify(orderDatabaseService).saveOrder(initialPurchaseOrder);
        assertThat(initialPurchaseOrder.getGoodReceivedNotes().get(0).getGrnNo(), is(GRN_NO));
        assertThat(initialPurchaseOrder.getOrderStatus().toString(), is(OrderStatus.FULL_RECEIVED.toString()));
    }

    @Test
    public void testDeleteGRN() throws CMSException {

        orderService.deleteGoodReceivedNote(ORDER_ID_FULL, GRN_ID);

        verify(orderDatabaseService).saveOrder(fullPurchaseOrder);
        assertThat(fullPurchaseOrder.getGoodReceivedNotes().size(), is(0));
        assertThat(fullPurchaseOrder.getOrderStatus(), is(OrderStatus.INITIAL));
    }

    @Test
    public void testDeleteGRVN() throws CMSException {

        Order returnOrder = orderService.deleteReturnOrder(ORDER_ID_RETURN_DRAFT);
        verify(orderDatabaseService).deleteOrder(ORDER_ID_RETURN_DRAFT);
    }

    @Test
    public void testDeleteGRVNDO() throws CMSException {

        orderService.deleteReturnOrderDn(ORDER_ID_RETURN_FULL, GRVNDN_ID);

        verify(orderDatabaseService).saveOrder(fullReturnOrder);

        assertThat(fullReturnOrder.getDeliveryNotes().size(), is(0));
        assertThat(fullReturnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.APPROVED));
    }

    @Test
    public void testTOReceipts() throws CMSException {

        orderService.deleteGoodReceivedNote(ORDER_ID_TRANSFER_FULL, GRN_ID);

        verify(orderDatabaseService).saveOrder(fullTransferOrder);
        assertThat(fullTransferOrder.getGoodReceivedNotes().size(), is(0));
        assertThat(fullTransferOrder.getOrderStatus(), is(OrderStatus.INITIAL));
    }

    @Test
    public void testTODO() throws CMSException {

        orderService.deleteTransferShipment(ORDER_ID_TRANSFER_FULL, DN_ID);
        verify(orderDatabaseService).saveOrder(fullTransferOrder);
        assertThat(fullTransferOrder.getDeliveryNotes().size(), is(0));
    }

    @Test
    public void testPOFlow() throws CMSException {

        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(null, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, null, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 50,
                LocalDate.now().plusYears(1), false, null);
        goodReceivedNote.setReceivedItems(List.of(deliveryItem));
        GoodReceivedNote goodReceivedNote1 = orderService.addGoodReceivedNote(ORDER_ID_INITIAL, goodReceivedNote);

        assertNotNull(goodReceivedNote1.getId());
        assertThat(initialPurchaseOrder.getGoodReceivedNotes().size(), is(1));
        assertThat(initialPurchaseOrder.getOrderStatus(), is(OrderStatus.PARTIAL_RECEIVED));

        GoodReceivedNote goodReceivedNote2 = orderService.deleteGoodReceivedNote(ORDER_ID_INITIAL, goodReceivedNote1.getId());

        assertNotNull(goodReceivedNote2.getId());
        assertThat(initialPurchaseOrder.getGoodReceivedNotes().size(), is(0));
        assertThat(initialPurchaseOrder.getOrderStatus(), is(OrderStatus.INITIAL));

        GoodReceivedNote goodReceivedNote3 = orderService.addGoodReceivedNote(ORDER_ID_INITIAL, goodReceivedNote);

        assertNotNull(goodReceivedNote3.getId());
        assertThat(initialPurchaseOrder.getGoodReceivedNotes().size(), is(1));
        assertThat(initialPurchaseOrder.getOrderStatus(), is(OrderStatus.PARTIAL_RECEIVED));

        GoodReceivedNote goodReceivedNote4 = orderService.addGoodReceivedNote(ORDER_ID_INITIAL, goodReceivedNote);

        assertNotNull(goodReceivedNote4.getId());
        assertThat(initialPurchaseOrder.getGoodReceivedNotes().size(), is(2));
        assertThat(initialPurchaseOrder.getOrderStatus(), is(OrderStatus.FULL_RECEIVED));
    }

    @Test
    public void testTOFlow() throws CMSException {

        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(null, REQUIRE_CLINIC_ID, SUPPLIER_ID, LocalDate.now(),
                LocalDate.now(), DN_NO, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);
        deliveryNote.setTransferSendItems(new ArrayList<>(List.of(deliveryItem)));

        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(null, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, null, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        goodReceivedNote.setReceivedItems(new ArrayList<>(List.of(deliveryItem)));

        DeliveryNote deliveryNote1 = orderService.addDeliveryNote(ORDER_ID_TRANSFER_INITIAL, deliveryNote);
        assertNotNull(deliveryNote1.getId());
        assertThat(initialTransferOrder.getDeliveryNotes().size(), is(1));
        assertThat(initialTransferOrder.getOrderStatus(), is(OrderStatus.INITIAL));

        GoodReceivedNote goodReceivedNote1 = orderService.addGoodReceivedNote(ORDER_ID_TRANSFER_INITIAL, goodReceivedNote);
        assertNotNull(goodReceivedNote1.getId());
        assertThat(initialTransferOrder.getGoodReceivedNotes().size(), is(1));
        assertThat(initialTransferOrder.getOrderStatus(), is(OrderStatus.FULL_RECEIVED));

        GoodReceivedNote goodReceivedNote2 = orderService.deleteGoodReceivedNote(ORDER_ID_TRANSFER_INITIAL, goodReceivedNote1.getId());
        assertNotNull(goodReceivedNote2.getId());
        assertThat(initialTransferOrder.getGoodReceivedNotes().size(), is(0));
        assertThat(initialTransferOrder.getOrderStatus(), is(OrderStatus.INITIAL));

        DeliveryNote deliveryNote2 = orderService.deleteTransferShipment(ORDER_ID_TRANSFER_INITIAL, deliveryNote1.getId());
        assertNotNull(deliveryNote2.getId());
        assertThat(initialTransferOrder.getDeliveryNotes().size(), is(0));
        assertThat(initialTransferOrder.getOrderStatus(), is(OrderStatus.INITIAL));
    }

    @Test
    public void testGRVNfFlow() throws CMSException {

        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(null, REQUIRE_CLINIC_ID, SUPPLIER_ID, LocalDate.now(),
                LocalDate.now(), DN_NO, DeliveryNoteStatus.CONFIRM);
        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);
        deliveryNote.setTransferSendItems(new ArrayList<>(List.of(deliveryItem)));

        DeliveryNote deliveryNote1 = orderService.addReturnOrderDeliveryNote(ORDER_ID_RETURN_INITIAL, deliveryNote);
        assertNotNull(deliveryNote1.getId());
        assertThat(initialReturnOrder.getDeliveryNotes().size(), is(1));
        assertThat(initialReturnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.RETURNED));

        DeliveryNote deliveryNote2 = orderService.deleteReturnOrderDn(ORDER_ID_RETURN_INITIAL, deliveryNote1.getId());
        assertNotNull(deliveryNote2.getId());
        assertThat(initialReturnOrder.getDeliveryNotes().size(), is(0));
        assertThat(initialReturnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.APPROVED));

        DeliveryNote deliveryNote3 = orderService.addReturnOrderDeliveryNote(ORDER_ID_RETURN_INITIAL, deliveryNote);
        assertNotNull(deliveryNote3.getId());
        assertThat(initialReturnOrder.getDeliveryNotes().size(), is(1));
        assertThat(initialReturnOrder.getReturnStatus(), is(GoodReceivedReturnStatus.RETURNED));
    }

    @Test
    public void testListAllOrder() throws CMSException {
        orderService = Mockito.mock(OrderService.class);
        fullTransferOrder.setInterComp(false);
        when(orderService.listOrderByClinicIdOrClinicGroupName(anyString())).thenReturn(List.of(fullTransferOrder));
        integrationService = new IntegrationService(orderService, clinicRepository, requestService, null, gstUtilsService);
        Map<String, Object> ordersMap = integrationService.listOrderRequests(REQUIRE_CLINIC_ID, new HashMap<>(), 0, 10);
        List<OrderRequest> returnObjects = (List<OrderRequest>) ordersMap.get(CMSConstant.PAYLOAD_KEY_CONTENT);
        Assert.assertEquals("Transfer Orders are not equal to 1 ", 4, ordersMap.size());
        assertNotNull("Order Requests shouldn't be null", returnObjects);
        Assert.assertEquals("Transfer Orders size should be 1 ", 1, returnObjects.size());
        Assert.assertFalse("Transfer Orders incoming interCompSo should be false ", returnObjects.stream().anyMatch(orderRequest -> {
            Order order = (Order) orderRequest.getData();
            return order.isInterComp();
        }));
        Assert.assertTrue("Transfer Orders Should be incoming ", returnObjects.stream().anyMatch(orderRequest -> orderRequest.getFilterType().equals(OrderRequest.FilterType.TO_PICK)));

        fullTransferOrder.setInterComp(true);
        when(orderService.listOrderByClinicIdOrClinicGroupName(anyString())).thenReturn(List.of(fullTransferOrder));
        integrationService = new IntegrationService(orderService, clinicRepository, requestService, null, gstUtilsService);
        Map<String, Object> trueOrdersMap = integrationService.listOrderRequests(REQUIRE_CLINIC_ID, new HashMap<>(), 0, 10);
        List<OrderRequest> trueInterCompReturnObjects = (List<OrderRequest>) trueOrdersMap.get(CMSConstant.PAYLOAD_KEY_CONTENT);
        Assert.assertEquals("Transfer Orders are not equal to 1 ", 4, trueOrdersMap.size());
        assertNotNull("Order Requests shouldn't be null", trueInterCompReturnObjects);
        Assert.assertEquals("Transfer Orders size should be 1 ", 0, trueInterCompReturnObjects.size());
    }

    @Test
    public void updateInventoryRecordBySalesOrder() throws CMSException {

        SalesItem salesItem = new SalesItem("5c78a513223ea60c4d373675", "26453010455596057111585111668779100014", new SellingPrice(3000, false),
                1, 270, 0.0, 0, "VIAL", "", "R3C376V", "", LocalDate.of(2032, 8, 15),
                null, new HashSet<String>(), Item.ItemType.VACCINATION, true, new ArrayList<MultiCostItem>(), new SellingPriceBigDeci(BigDecimal.TEN, false), false, "");

        SalesItem salesItem2 = new SalesItem("5b55ac7d0550de00210a3339", "26453010455596057111585111668779100015", new SellingPrice(3000, false),
                1, 0, 0.0, 0, "TABLET", "", "E2K118", "", LocalDate.of(2032, 8, 15),
                null, new HashSet<>(), Item.ItemType.DRUG, true, new ArrayList<>(), new SellingPriceBigDeci(BigDecimal.TEN, false), false, "");

        SalesItemAdj salesItemAdj = new SalesItemAdj("5c78a513223ea60c4d373675", 300, 420, 420, "5c78a513223ea60c4d373675");

        BillAdjustment billAdjustment1 = new BillAdjustment();
        billAdjustment1.setPurchaseItemsAdj(List.of(salesItemAdj));
        billAdjustment1.setPackagesAdj(new ArrayList<>());

        SalesOrder salesOrder = SalesOrder.newSalesOrder(7, "123");
        salesOrder.setPurchaseItems(List.of(salesItem, salesItem2));
        salesOrder.setBillAdjustments(List.of(billAdjustment1));

        Case c = new Case();
        c.setSalesOrder(salesOrder);
        c.setClinicId("5b55aabd0550de0021097bdb");
        c.setStatus(Case.CaseStatus.CLOSED); //To Test SO correction case should be closed

        Clinic cl = new Clinic();
        cl.setId("5b55aabd0550de0021097bdb");
        cl.setClinicCode("5b55aabd0550de0021097bdb");

        Inventory existingInventory = new Inventory();
        existingInventory.setItemRefId("5c78a513223ea60c4d373675");
        existingInventory.setBatchNumber("R3C376V");
        existingInventory.setAvailableCount(BigDecimal.valueOf(200));

        Location location1 = new Location();
        location1.setClinicId("5b55aabd0550de0021097bdb");
        location1.setInventory(List.of(existingInventory));

        when(caseRepository.findById(anyString())).thenReturn(Optional.of(c));
        when(clinicRepository.findById(anyString())).thenReturn(Optional.of(cl));
        when(locationService.mapSalesItemToInventory(any(SalesItem.class))).thenAnswer(arg -> {
            SalesItem si = arg.getArgument(0);

            Inventory inventory = new Inventory();

            inventory.setBatchNumber(si.getBatchNo());
            inventory.setItemRefId(si.getItemRefId());
            inventory.setAvailableCount(BigDecimal.valueOf(100));

            return inventory;
        });
        //When doing SO correction
        when(locationService.mapSalesItemAdjToInventory(any(SalesItemAdj.class), any(SalesItem.class))).thenAnswer(arg -> {
            SalesItemAdj sia = arg.getArgument(0);
            SalesItem si = arg.getArgument(1);

            Inventory inventory = new Inventory();

            inventory.setBatchNumber(si.getBatchNo());
            inventory.setItemRefId(si.getItemRefId());
            inventory.setAvailableCount(BigDecimal.valueOf(-150));

            return inventory;
        });
        when(locationService.findLocationByClinicId(anyString())).thenReturn(Optional.of(location1));

        when(locationService.findAndModify(any(Location.class), any(Boolean.class), false)).thenAnswer(arg -> {
            Location loc = arg.getArgument(0);
            location1.setInventory(loc.getInventory());

            assertEquals(1, location1.getInventory().size());
            assertEquals(BigDecimal.valueOf(-150), location1.getInventory().get(0).getAvailableCount());
            //        assertEquals(-200,location1.getInventory().get(1).getAvailableCount());

            return location1;
        });

        orderService.updateInventoryByCaseId("123", true, false);
    }

    @Test
    public void shouldNotBeAbleToReduceInventoryIfDeliveryNoteStatusIsNotConfirmed() throws CMSException {

        String clinicId = "";

        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(null,
                REQUIRE_CLINIC_ID,
                SUPPLIER_ID,
                LocalDate.now(),
                LocalDate.now(),
                DN_NO,
                DeliveryNoteStatus.CONFIRM);

        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);

        deliveryNote.setTransferSendItems(List.of(deliveryItem));

        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(null, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, null, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        goodReceivedNote.setReceivedItems(List.of(deliveryItem));

        Optional<Location> actual = orderService.updateInventoryRecordByDeliveryNote("0001", clinicId, deliveryNote, false);

        Optional<Location> expected = Optional.empty();
        assertEquals(expected, actual);
    }

    @Test
    public void shouldBeAbleToAddORReduceInventoryByDeliveryNote() throws CMSException {

        String clinicId = "123";

        DeliveryNote deliveryNote = MockOrder.mockDeliveryNote(null, REQUIRE_CLINIC_ID, SUPPLIER_ID, LocalDate.now(),
                LocalDate.now(), DN_NO, DeliveryNoteStatus.CONFIRM);

        DeliveryItem deliveryItem = MockOrder.mockDeliveryItem("0001", ITEM_ID, "TABLET", BATCH_NO, 100,
                LocalDate.now().plusYears(1), false, null);

        deliveryNote.setTransferSendItems(new ArrayList<>(List.of(deliveryItem)));

        GoodReceivedNote goodReceivedNote = MockOrder.mockGoodReceivedNote(null, LocalDate.now(), LocalDate.now(),
                SUPPLIER_ID, REQUIRE_CLINIC_ID, null, LocalDate.now(), "DN_NO", null, DeliveryNoteStatus.CONFIRM);
        goodReceivedNote.setReceivedItems(new ArrayList<>(List.of(deliveryItem)));

        goodReceivedNote.setReceivedItems(new ArrayList<>(List.of(deliveryItem)));

        Item item = new Item();
        item.setId(deliveryItem.getItemRefId());
        item.setBaseUom(deliveryItem.getUom());
        item.setInventoried(true);

        Location location1 = new Location(clinicId);

        Inventory existingInv = new Inventory(deliveryItem.getItemRefId(),
                deliveryItem.getBatchNumber(),
                item.getBaseUom(),
                deliveryItem.getExpiryDate(),
                deliveryItem.getManufacturerDate(),
                BigDecimal.valueOf(roundingQuantity(1.0 * 500)), true, BigDecimal.ZERO);

        when(itemService.listItemByClinicId(anyString())).thenReturn(List.of(item));
        when(locationService.mapDeliveryItemToInventory(any(Optional.class), any(DeliveryItem.class), anyBoolean())).thenAnswer((args) -> {

            Optional<DeliveryItem> optDeliveryItem1 = args.getArgument(0);

            if (optDeliveryItem1.isPresent()) {
                DeliveryItem deliveryItem1 = optDeliveryItem1.get();
                Inventory inventory = new Inventory(deliveryItem1.getItemRefId(),
                        deliveryItem1.getBatchNumber(),
                        item.getBaseUom(),
                        deliveryItem1.getExpiryDate(),
                        deliveryItem1.getManufacturerDate(),
                        BigDecimal.valueOf(roundingQuantity(1.0 * deliveryItem1.getQuantity())), true, BigDecimal.ZERO);

                return inventory;
            } else {
                Inventory inventory = new Inventory(deliveryItem.getItemRefId(),
                        deliveryItem.getBatchNumber(),
                        item.getBaseUom(),
                        deliveryItem.getExpiryDate(),
                        deliveryItem.getManufacturerDate(),
                        BigDecimal.valueOf(roundingQuantity(1.0 * deliveryItem.getQuantity())), true, BigDecimal.ZERO);

                return inventory;
            }
        });

        when(locationService.findAndModify(any(Location.class), anyBoolean(), false)).thenAnswer((args) -> {

            Location modifiedLocation = args.getArgument(0);

            int actualCount = existingInv.getAvailableCountInt() + modifiedLocation.getInventory().get(0).getAvailableCountInt();
            int expectedCount = roundingQuantity(400);

            assertEquals(expectedCount, actualCount);

            return modifiedLocation;
        });

        orderService.updateInventoryRecordByDeliveryNote("0001", clinicId, deliveryNote, false);
    }

    @Test
    public void modifyPurchaseOrders() throws CMSException {
        Order po = new Order();
        po.setDiscountType(Order.DiscountType.DOLLAR);
        po.setDiscountAmount(BigDecimal.valueOf(10.0));
        po.setGoodPurchasedItems(Arrays.asList(new GoodOrderedItem("0", "a", "a", "a", 1, new UnitPrice(10, false), "")));

        Order order = new Order();
        order.setGoodPurchasedItems(Arrays.asList(new GoodOrderedItem("0", "a", "a", "a", 1, new UnitPrice(10, false), "")));

        when(orderDatabaseService.findOrderById(any())).thenReturn(Optional.of(order));
        when(orderDatabaseService.saveOrder(any())).thenReturn(order);
        PurchaseRequest purchaseRequest = mock(PurchaseRequest.class);
        when(requestService.createPurchaseRequest(any())).thenReturn(purchaseRequest);

        orderService.modifyPurchaseOrder(po, false);

        ArgumentCaptor<Order> orderArgumentCaptor = ArgumentCaptor.forClass(Order.class);

        verify(orderDatabaseService, atLeast(1)).saveOrder(orderArgumentCaptor.capture());
        Order savedOrder = orderArgumentCaptor.getValue();
        assertEquals(Order.DiscountType.DOLLAR, savedOrder.getDiscountType());
        assertEquals(BigDecimal.valueOf(10.0), savedOrder.getDiscountAmount());
    }

    @Test
    public void modifyPurchaseOrder() {
    }
}
