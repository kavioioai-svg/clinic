package com.ilt.cms.inventory.svc.service.mock;

import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MockLocation {

    public static Location mockLocation(String clinicId) {
        Location location = new Location(clinicId);

        return location;
    }

    public static Inventory mockInventory(String itemId, String itemCode, String batchNo, LocalDate expiryDate, String baseUom, int availableCount) {
        Inventory inventory = new Inventory();
        inventory.setAvailableCount(BigDecimal.valueOf(availableCount));
        inventory.setItemRefId(itemId);
        inventory.setBatchNumber(batchNo);
        inventory.setExpiryDate(expiryDate);
        inventory.setItemCode(itemCode);
        inventory.setBaseUom(baseUom);
        return inventory;

    }
}
