package com.ilt.cms.inventory.svc.service.inventory;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.UomMatrix;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.database.item.UomMatrixDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationInventoryRepository;
import com.ilt.cms.inventory.svc.mapper.LocationMapper;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.mock.MockItem;
import com.ilt.cms.inventory.svc.service.nav.InventoryService;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.lippo.cms.exception.CMSException;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ItemUsageTest {

    private UomMatrixDatabaseService uomMatrixDatabaseService;
    private LocationService locationService;
    private LocationInventoryRepository locationInventoryRepository;
    private DrugItemService drugItemService;
    private UOMMatrixService uomMatrixService;
    private ItemDatabaseService itemDatabaseService;
    private SupplierDatabaseService supplierDatabaseService;
    private InventoryService inventoryService;
    private MongoTemplate mongoTemplate;
    private InventoryTransactionRepository inventoryTransactionRepository;
    private ClinicRepository clinicRepository;
    private CaseRepository caseRepository;
    private InventoryUtilsService inventoryUtilsService;


    @BeforeEach
    public void setUp() throws Exception {
        locationInventoryRepository = mock(LocationInventoryRepository.class);
        uomMatrixDatabaseService = mock(UomMatrixDatabaseService.class);
        drugItemService = mock(DrugItemService.class);
        uomMatrixService = new UOMMatrixService(uomMatrixDatabaseService);
        itemDatabaseService = mock(ItemDatabaseService.class);
        supplierDatabaseService = mock(SupplierDatabaseService.class);
        inventoryService = mock(InventoryService.class);
        mongoTemplate = mock(MongoTemplate.class);
        inventoryTransactionRepository =mock(InventoryTransactionRepository.class);
        clinicRepository = mock(ClinicRepository.class);
        caseRepository = mock(CaseRepository.class);
        inventoryUtilsService = mock(InventoryUtilsService.class);
        locationService = new LocationService(
                locationInventoryRepository,
                drugItemService,
                uomMatrixService,
                itemDatabaseService,
                supplierDatabaseService,
                inventoryService,
                mongoTemplate,
                inventoryTransactionRepository,
                inventoryUtilsService, clinicRepository,
                caseRepository
        );
        when(uomMatrixDatabaseService.findUOMatrixByUomCode(anyString())).thenAnswer(this::mockUomMatrix);
    }

    @Test
    public void testSameUOMItemUsage() throws CMSException {
        final InventoryUsage inventoryUsage = MockItem.mockInventoryUsage(InventoryUsage.InventoryType.DRUG, "1", 1, "BOTTLE", "BOTTLE");
        final Inventory inventory = LocationMapper.mapUsageToInventory(inventoryUsage, locationService.getUOMRatio(inventoryUsage));
        Assert.assertEquals(new BigDecimal(-1), inventory.getAvailableCount());
    }

    @Test
    public void testDifferentUOMItemUsage() throws CMSException {
        final InventoryUsage inventoryUsage = MockItem.mockInventoryUsage(InventoryUsage.InventoryType.DRUG, "1", 5, "BOTTLE100", "CAPSULE");

        final Inventory inventory = LocationMapper.mapUsageToInventory(inventoryUsage, locationService.getUOMRatio(inventoryUsage));
        Assert.assertEquals(new BigDecimal("-500"), inventory.getAvailableCount());
    }

    private Optional<UomMatrix> mockUomMatrix(InvocationOnMock invocation) {
        String uom = invocation.getArgument(0);
        Map<String, BigDecimal> exchangeRatio = new HashMap<>();

        if (uom.equals("CAPSULE")) {
            exchangeRatio.put("BOTTLE100", new BigDecimal("100"));
            exchangeRatio.put("BOX7", new BigDecimal("7"));
            exchangeRatio.put("BOTTLE30", new BigDecimal("30"));
            exchangeRatio.put("BOX90", new BigDecimal("90"));
            exchangeRatio.put("BOX50", new BigDecimal("50"));
            exchangeRatio.put("BOX10", new BigDecimal("10"));
            exchangeRatio.put("CAPSULE", new BigDecimal("1"));
        }
        if(uom.equals("DROP")) {
            exchangeRatio.put("VIAL", new BigDecimal("20"));
            exchangeRatio.put("DROP", new BigDecimal("1"));
        }
        if (uom.equals("BOTTLE")) {
            exchangeRatio.put("BOTTLE", new BigDecimal("1"));
            exchangeRatio.put("BOX10", new BigDecimal("10"));
        }
        if (uom.equals("BOTTLE100")) {
            exchangeRatio.put("CAPSULE", new BigDecimal("100"));
        }

        if(exchangeRatio.size() > 0) {
            UomMatrix uomMatrix = new UomMatrix();
            uomMatrix.setUomCode(uom);
            uomMatrix.setStatus(Status.ACTIVE);
            uomMatrix.setExchangeRatio(exchangeRatio);
            return Optional.of(uomMatrix);
        } else {
            return Optional.empty();
        }
    }
}
