package com.ilt.cms.inventory.svc.service.mock;

import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;

import java.math.BigDecimal;

public class MockLocationInventory {

    public static LocationInventory mockLocationInventory (BigDecimal availableQty, BigDecimal batchPrice) {
        LocationInventory locationInventory = new LocationInventory();
        locationInventory.setAvailableCount(availableQty);
        locationInventory.setBatchPrice(batchPrice);

        return locationInventory;
    }
}
