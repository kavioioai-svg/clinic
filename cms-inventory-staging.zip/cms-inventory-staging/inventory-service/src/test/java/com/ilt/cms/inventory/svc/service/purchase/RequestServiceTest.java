package com.ilt.cms.inventory.svc.service.purchase;

import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemClinicDetailDatabaseService;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.Optional;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class RequestServiceTest {

    private static String PURCHASE_REQUEST_ID = "PR0001";

    @Mock
    private OrderDatabaseService orderDatabaseService;
    @Mock
    private RunningNumberService runningNumberService;
    @Mock
    private DrugItemService itemService;
    @Mock
    private SupplierDatabaseService supplierDatabaseService;
    @Mock
    private ItemClinicDetailDatabaseService itemClinicDetailDatabaseService;
    @Mock
    private LocationService locationService;
    @Mock
    private SystemNotifier systemNotifier;

    @Mock
    private MongoTemplate mongoTemplate;
    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    private RequestService requestService;

    @Mock
    private UOMMatrixService uomMatrixService;

    @Before
    public void setup() {

        MockitoAnnotations.initMocks(this);
        requestService = new RequestService(orderDatabaseService, runningNumberService, itemService,
                supplierDatabaseService, mongoTemplate, systemNotifier, uomMatrixService);
    }

    @Test
    public void shouldDeletePurchaseRequestIfDraftStatus() throws CMSException {

        when(orderDatabaseService.findPurchaseRequestById(PURCHASE_REQUEST_ID)).thenReturn(
                Optional.of(purchaseRequest(RequestStatus.DRAFT)));

        requestService.deletePurchaseRequest(PURCHASE_REQUEST_ID);

        verify(orderDatabaseService).deletePurchaseRequest(PURCHASE_REQUEST_ID);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfRequestedStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.REQUESTED);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfApprovedStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.APPROVED);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfPartiallyApprovedStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.PARTIAL_APPROVED);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfRejectedStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.REJECTED);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfTransferStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.TRANSFER);
    }

    @Test
    public void shouldNotDeletePurchaseRequestIfFailedStatus() throws CMSException {

        shouldNotDeletePurchaseRequest(RequestStatus.FAILED);
    }

    private void shouldNotDeletePurchaseRequest(RequestStatus status) throws CMSException {

        expectedException.expect(CMSException.class);
        expectedException.expectMessage("Not allow to delete with status [" + status + "]");

        when(orderDatabaseService.findPurchaseRequestById(PURCHASE_REQUEST_ID)).thenReturn(
                Optional.of(purchaseRequest(status)));

        requestService.deletePurchaseRequest(PURCHASE_REQUEST_ID);
    }

    private PurchaseRequest purchaseRequest(RequestStatus status) {

        PurchaseRequest purchaseRequest = new PurchaseRequest();
        purchaseRequest.setId(PURCHASE_REQUEST_ID);
        purchaseRequest.setRequestStatus(status);
        return purchaseRequest;
    }
}
