package com.ilt.cms.inventory.svc.service.inventory;

import com.ilt.cms.core.entity.inventory.InventoryTransaction;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationInventoryRepository;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.mock.MockLocationInventory;
import com.ilt.cms.inventory.svc.service.nav.InventoryService;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.lippo.cms.exception.CMSException;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyIterable;
import static org.mockito.Mockito.*;

class LocationServiceTest {

    private LocationService locationService;
    private LocationInventoryRepository locationInventoryRepository;
    private DrugItemService drugItemService;
    private UOMMatrixService uomMatrixService;
    private ItemDatabaseService itemDatabaseService;
    private SupplierDatabaseService supplierDatabaseService;
    private InventoryService inventoryService;
    private MongoTemplate mongoTemplate;
    private InventoryTransactionRepository inventoryTransactionRepository;
    private ClinicRepository clinicRepository = mock(ClinicRepository.class);
    private CaseRepository caseRepository = mock(CaseRepository.class);
    private InventoryUtilsService inventoryUtilsService;


    @BeforeEach
    void setUp() {
        locationInventoryRepository = mock(LocationInventoryRepository.class);
        drugItemService = mock(DrugItemService.class);
        uomMatrixService = mock(UOMMatrixService.class);
        itemDatabaseService = mock(ItemDatabaseService.class);
        supplierDatabaseService = mock(SupplierDatabaseService.class);
        inventoryService = mock(InventoryService.class);
        mongoTemplate = mock(MongoTemplate.class);
        inventoryTransactionRepository = mock(InventoryTransactionRepository.class);
        clinicRepository = mock(ClinicRepository.class);
        caseRepository = mock(CaseRepository.class);
        inventoryUtilsService = mock(InventoryUtilsService.class);
        locationService = new LocationService(
                locationInventoryRepository,
                drugItemService,
                uomMatrixService,
                itemDatabaseService,
                supplierDatabaseService,
                inventoryService,
                mongoTemplate,
                inventoryTransactionRepository,
                inventoryUtilsService, clinicRepository,
                caseRepository
        );
    }

    @Test
    void testSaveLocation() throws CMSException {

        AtomicReference<List<LocationInventory>> list = new AtomicReference<>();

        when(locationInventoryRepository.saveAll(anyIterable())).thenAnswer(i -> {
            List<LocationInventory> argument = i.getArgument(0);
            list.set(argument);
            return argument;
        });
        when(itemDatabaseService.findItemByClinicId(any())).thenReturn(List.of());
        when(locationInventoryRepository.findAllByClinicId("my-clinic")).thenAnswer(i -> {
            return list.get();
        });
        Location location = locationService.saveLocation(Location.createLocation(
                "my-clinic",
                List.of(
                        Inventory.createInventory(
                                "a",
                                "ref-1",
                                "item-1",
                                "desc-1",
                                "b-1",
                                "uom-1",
                                LocalDate.now(),
                                LocalDate.now(),
                                new BigDecimal(100),
                                10, true
                        )
                )
        ));

        Assertions.assertEquals(location.getClinicId(), "my-clinic");
        Assertions.assertEquals(location.getInventory().size(), 1);
        Assertions.assertEquals(location.getInventory().get(0).getItemCode(), "desc-1");

        ArgumentCaptor<List<LocationInventory>> captor = ArgumentCaptor.forClass(List.class);
        verify(locationInventoryRepository, times(1)).saveAll(captor.capture());

        Assertions.assertEquals(captor.getValue().size(), 1);
        Assertions.assertEquals(captor.getValue().get(0).getClinicId(), "my-clinic");
        Assertions.assertEquals(captor.getValue().get(0).getItemCode(), "desc-1");
    }

    @Test
    void testModifyLocation() throws CMSException {
        AtomicReference<List<LocationInventory>> list = new AtomicReference<>();

        when(locationInventoryRepository.saveAll(anyIterable())).thenAnswer(i -> {
            List<LocationInventory> argument = i.getArgument(0);
            list.set(argument);
            return argument;
        });
        when(itemDatabaseService.findItemByClinicId(any())).thenReturn(List.of());
        when(locationInventoryRepository.findAllByClinicId("my-clinic")).thenAnswer(i -> list.get());

        Location location = locationService.modifyLocation("my-clinic", Location.createLocation(
                "my-clinic",
                List.of(
                        Inventory.createInventory(
                                "a",
                                "ref-1",
                                "item-1",
                                "desc-1",
                                "b-1",
                                "uom-1",
                                LocalDate.now(),
                                LocalDate.now(),
                                new BigDecimal(100),
                                10, true
                        )
                )
        ));

        Assertions.assertEquals(location.getClinicId(), "my-clinic");
        Assertions.assertEquals(location.getInventory().size(), 1);
        Assertions.assertEquals(location.getInventory().get(0).getItemCode(), "desc-1");

        ArgumentCaptor<List<LocationInventory>> captor = ArgumentCaptor.forClass(List.class);
        verify(locationInventoryRepository, times(1)).saveAll(captor.capture());
        verify(locationInventoryRepository, times(1)).deleteAllByClinicId("my-clinic");

        Assertions.assertEquals(captor.getValue().size(), 1);
        Assertions.assertEquals(captor.getValue().get(0).getClinicId(), "my-clinic");
        Assertions.assertEquals(captor.getValue().get(0).getItemCode(), "desc-1");
    }

    @Test
    void testFindAndModifyWithoutDifference() throws CMSException {

        when(itemDatabaseService.findItemByClinicId(any())).thenReturn(List.of());
        when(locationInventoryRepository.findAllByClinicId("my-clinic")).thenAnswer(i -> List.of(
                LocationInventory.createLocationInventory(
                        "my-clinic",
                        "ref-1",
                        "item-1",
                        "desc-1",
                        "b-1",
                        "uom-1",
                        LocalDate.now(),
                        LocalDate.now(),
                        new BigDecimal(90),
                        10, true
                )
        ));

        BulkOperations bulkOperations = mock(BulkOperations.class);
        when(mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, LocationInventory.class)).thenReturn(bulkOperations);

        when(bulkOperations.upsert(any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(null);

        List<InventoryTransaction> location = locationService.findAndModify(Location.createLocation(
                "my-clinic",
                List.of(
                        Inventory.createInventory(
                                "a",
                                "ref-1",
                                "item-1",
                                "desc-1",
                                "b-1",
                                "uom-1",
                                LocalDate.now(),
                                LocalDate.now(),
                                new BigDecimal(100),
                                10, true
                        )
                )
        ), false, false);

        Assertions.assertEquals(location.stream().findFirst().get().getClinicId(), "my-clinic");
        Assertions.assertEquals(location.size(), 1);
//        Assertions.assertEquals(location.stream().findFirst().get().getItemCode(), "desc-1");

        ArgumentCaptor<List<Pair<Query, Update>>> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(bulkOperations, times(1)).upsert(updateCaptor.capture());

        Assertions.assertEquals(updateCaptor.getValue().size(), 1);
        Assertions.assertEquals(updateCaptor.getValue().get(0).getFirst().getQueryObject().get("clinicId"), "my-clinic");
        Assertions.assertEquals(updateCaptor.getValue().get(0).getSecond().getUpdateObject().keySet().size(), 1);
        Assertions.assertEquals(updateCaptor.getValue().get(0).getSecond().getUpdateObject().keySet().toArray()[0], "$set");
    }

    @Test
    void testFindAndModifyWithDifference() throws CMSException {

        when(itemDatabaseService.findItemByClinicId(any())).thenReturn(List.of());
        when(locationInventoryRepository.findAllByClinicId("my-clinic")).thenAnswer(i -> List.of(
                LocationInventory.createLocationInventory(
                        "my-clinic",
                        "ref-1",
                        "item-1",
                        "desc-1",
                        "b-1",
                        "uom-1",
                        LocalDate.now(),
                        LocalDate.now(),
                        new BigDecimal(90),
                        10, true
                )
        ));

        BulkOperations bulkOperations = mock(BulkOperations.class);
        when(mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, LocationInventory.class)).thenReturn(bulkOperations);

        when(bulkOperations.upsert(any())).thenReturn(bulkOperations);
        when(bulkOperations.execute()).thenReturn(null);

        List<InventoryTransaction> location = locationService.findAndModify(Location.createLocation(
                "my-clinic",
                List.of(
                        Inventory.createInventory(
                                "a",
                                "ref-1",
                                "item-1",
                                "desc-1",
                                "b-1",
                                "uom-1",
                                LocalDate.now(),
                                LocalDate.now(),
                                new BigDecimal(100),
                                10, true
                        )
                )
        ), true, false);

        Assertions.assertEquals(location.stream().findFirst().get().getClinicId(), "my-clinic");
        Assertions.assertEquals(location.size(), 1);
//        Assertions.assertEquals(location.stream().findFirst().get().getItemCode(), "desc-1");

        ArgumentCaptor<List<Pair<Query, Update>>> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(bulkOperations, times(1)).upsert(updateCaptor.capture());

        Assertions.assertEquals(updateCaptor.getValue().size(), 1);
        Assertions.assertEquals(updateCaptor.getValue().get(0).getFirst().getQueryObject().get("clinicId"), "my-clinic");
        Assertions.assertEquals(updateCaptor.getValue().get(0).getSecond().getUpdateObject().keySet().size(), 2);
        Assertions.assertTrue(updateCaptor.getValue().get(0).getSecond().getUpdateObject().containsKey("$inc"));
    }

    @Test
    @Disabled("Expected value is dynamic")
    public void testDeletingZeroQtyItems() throws CMSException, ParseException {
        doAnswer((args) -> {
            Date actual = args.getArgument(0);
            String expected = "2022-09-05";
            Assert.assertEquals(expected, new SimpleDateFormat("yyyy-MM-dd").format(actual));
            return null;
        }).when(locationInventoryRepository).deleteAllByAvailableCountLessThanEqualAndLastModifiedDateBefore(any(BigDecimal.class), any(Date.class));

        locationService.deleteZeroQuantityItems(3);
    }

    @Test
    void testPurchasePriceOnLocationInventory() throws CMSException {

        LocationInventory existingObj = MockLocationInventory.mockLocationInventory(
                new BigDecimal(100),
                new BigDecimal(10.00) // item price
        );

        LocationInventory newLocationInv =  MockLocationInventory.mockLocationInventory(
                new BigDecimal(20),
                new BigDecimal(5.00)// item price
        );

        BigDecimal averagePrice = locationService.findAveragePrice(newLocationInv, existingObj);

        Assertions.assertEquals(averagePrice.doubleValue(),(new BigDecimal(9.1667).doubleValue()));
    }

    @Test
    void testPurchasePriceOnLocationInventoryMinusValues() throws CMSException {

        LocationInventory existingObj = MockLocationInventory.mockLocationInventory(
                new BigDecimal(-100),
                new BigDecimal(10.4575) // item price
        );

        LocationInventory newLocationInv =  MockLocationInventory.mockLocationInventory(
                new BigDecimal(20),
                new BigDecimal(5.2354)// item price
        );

        BigDecimal averagePrice = locationService.findAveragePrice(newLocationInv, existingObj);

        Assertions.assertEquals(averagePrice.doubleValue(),(new BigDecimal(9.5871).doubleValue()));
    }

    @Test
    void testPurchasePriceOnLocationInventoryZeroValues() throws CMSException {

        LocationInventory existingObj = MockLocationInventory.mockLocationInventory(
                new BigDecimal(0),
                new BigDecimal(10.4575) // item price
        );

        LocationInventory newLocationInv =  MockLocationInventory.mockLocationInventory(
                new BigDecimal(20),
                new BigDecimal(5.2354)// item price
        );

        BigDecimal averagePrice = locationService.findAveragePrice(newLocationInv, existingObj);

        Assertions.assertEquals(averagePrice.doubleValue(),(new BigDecimal(5.2354).doubleValue()));
    }

    @Test
    void testPurchasePriceOnLocationInventoryAllZeroValues() throws CMSException {

        LocationInventory existingObj = MockLocationInventory.mockLocationInventory(
                new BigDecimal(0),
                new BigDecimal(0) // item price
        );

        LocationInventory newLocationInv =  MockLocationInventory.mockLocationInventory(
                new BigDecimal(20),
                new BigDecimal(5.2354)// item price
        );

        BigDecimal averagePrice = locationService.findAveragePrice(newLocationInv, existingObj);

        Assertions.assertEquals(averagePrice.doubleValue(),(new BigDecimal(5.2354).doubleValue()));
    }

    @Test
    void testPurchasePriceOnLocationInventoryNullValues() throws CMSException {

        LocationInventory existingObj = MockLocationInventory.mockLocationInventory(
                new BigDecimal(0),
                null // item price
        );

        LocationInventory newLocationInv =  MockLocationInventory.mockLocationInventory(
                new BigDecimal(20),
                new BigDecimal(5.2354)// item price
        );

        BigDecimal averagePrice = locationService.findAveragePrice(newLocationInv, existingObj);

        Assertions.assertEquals(averagePrice.doubleValue(),(new BigDecimal(5.2354).doubleValue()));
    }



}
