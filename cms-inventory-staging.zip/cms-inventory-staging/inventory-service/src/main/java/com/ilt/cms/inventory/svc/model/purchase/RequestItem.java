package com.ilt.cms.inventory.svc.model.purchase;

import com.ilt.cms.inventory.svc.model.common.UnitPrice;

import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class RequestItem{

    public enum RequestItemStatus {
        PENDING, SUBMITTED, APPROVED, REJECTED;
    }

    private String itemRefId;
    private String supplierId;
    private String uom;
    private int quantity;
    private Integer approvedQuantity;
    private UnitPrice unitPrice;
    private String remark;
    private String cpRemarks;
    private String approvedUom;
    private RequestItemStatus requestItemStatus;
    private Double backOrderQuantityInBaseUOM;

    public boolean checkValidate(){
        return isStringValid(itemRefId, uom, supplierId) && quantity > 0 && unitPrice != null;
    }

    public RequestItem() {
    }

    public RequestItem(String itemRefId, String uom, int quantity, RequestItemStatus status) {
        this.itemRefId = itemRefId;
        this.uom = uom;
        this.quantity = quantity;
        this.requestItemStatus = status;
    }

    public RequestItem(String itemRefId, String supplierId, String uom, int quantity, int approvedQuantity, UnitPrice unitPrice, RequestItemStatus status) {
        this.itemRefId = itemRefId;
        this.supplierId = supplierId;
        this.uom = uom;
        this.quantity = quantity;
        this.approvedQuantity = approvedQuantity;
        this.unitPrice = unitPrice;
        this.requestItemStatus = status;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(UnitPrice unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(int approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public void addApprovedQuantity(int approvedQuantity) {
        if (this.approvedQuantity == null) this.approvedQuantity = 0;
        this.approvedQuantity += approvedQuantity;
    }
    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCpRemarks() {
        return cpRemarks;
    }

    public void setCpRemarks(String cpRemarks) {
        this.cpRemarks = cpRemarks;
    }

    public String getApprovedUom() {
        return approvedUom;
    }

    public void setApprovedUom(String approvedUom) {
        this.approvedUom = approvedUom;
    }

    public Double getBackOrderQuantityInBaseUOM() {
        return backOrderQuantityInBaseUOM;
    }

    public void setBackOrderQuantityInBaseUOM(Double backOrderQuantityInBaseUOM) {
        this.backOrderQuantityInBaseUOM = backOrderQuantityInBaseUOM;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RequestItem that = (RequestItem) o;
        return Objects.equals(itemRefId, that.itemRefId) &&
                Objects.equals(uom, that.uom);
    }

    public RequestItemStatus getRequestItemStatus() {
        return requestItemStatus;
    }

    public RequestItem setRequestItemStatus(RequestItemStatus requestItemStatus) {
        this.requestItemStatus = requestItemStatus;
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemRefId, uom);
    }

    @Override
    public String toString() {
        return "RequestItem{" +
                "itemRefId='" + itemRefId + '\'' +
                ", supplierId='" + supplierId + '\'' +
                ", uom='" + uom + '\'' +
                ", quantity=" + quantity +
                ", approvedQuantity=" + approvedQuantity +
                ", unitPrice=" + unitPrice +
                ", remark='" + remark + '\'' +
                ", cpRemarks='" + cpRemarks + '\'' +
                ", approvedUom='" + approvedUom + '\'' +
                ", requestItemStatus='" + requestItemStatus + '\'' +
                '}';
    }
}
