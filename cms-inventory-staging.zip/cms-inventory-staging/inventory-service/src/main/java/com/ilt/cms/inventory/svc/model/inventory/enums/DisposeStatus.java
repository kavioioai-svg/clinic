package com.ilt.cms.inventory.svc.model.inventory.enums;

public enum DisposeStatus {
    INITIAL, REQUESTED, COMPLETED
}
