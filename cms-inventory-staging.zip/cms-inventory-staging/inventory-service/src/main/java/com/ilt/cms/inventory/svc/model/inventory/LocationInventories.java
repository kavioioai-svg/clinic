package com.ilt.cms.inventory.svc.model.inventory;

import com.lippo.cms.exception.CMSException;

import java.util.ArrayList;
import java.util.List;

public class LocationInventories {

    public static List<LocationInventory> fromLocation(Location location) {
        List<LocationInventory> locationInventories = new ArrayList<>();
        location.getInventory().forEach(inventory -> {
            LocationInventory locationInventory = new LocationInventory();
            locationInventory.setId(inventory.getInventoryId());
            locationInventory.setClinicId(location.getClinicId());
            locationInventory.setItemRefId(inventory.getItemRefId());
            locationInventory.setItemCode(inventory.getItemCode());
            locationInventory.setItemName(inventory.getItemName());
            locationInventory.setBatchNumber(inventory.getBatchNumber() != null ? inventory.getBatchNumber().toUpperCase() : null);
            locationInventory.setBaseUom(inventory.getBaseUom());
            locationInventory.setManufacturerDate(inventory.getManufacturerDate());
            locationInventory.setExpiryDate(inventory.getExpiryDate());
            locationInventory.setAvailableCount(inventory.getAvailableCount());
            locationInventory.setTrackingCode(inventory.isTrackingCode());
            locationInventory.setBatchPrice(inventory.getBatchPrice());
            locationInventories.add(locationInventory);
        });
        return locationInventories;
    }

    public static Location toLocation(List<LocationInventory> locationInventories) throws CMSException {
        Location location = new Location();
        if(locationInventories.size() == 0){
            return location;
        }
        location.setClinicId(locationInventories.get(0).getClinicId());
        locationInventories.forEach(locationInventory -> {
            Inventory inventory = new Inventory();
            inventory.setItemRefId(locationInventory.getItemRefId());
            inventory.setItemCode(locationInventory.getItemCode());
            inventory.setItemName(locationInventory.getItemName());
            inventory.setInventoryId(locationInventory.getId());
            inventory.setBatchNumber(locationInventory.getBatchNumber());
            inventory.setBaseUom(locationInventory.getBaseUom());
            inventory.setManufacturerDate(locationInventory.getManufacturerDate());
            inventory.setExpiryDate(locationInventory.getExpiryDate());
            inventory.setAvailableCount(locationInventory.getAvailableCount());
            inventory.setTrackingCode(locationInventory.isTrackingCode());
            inventory.setBatchPrice(locationInventory.getBatchPrice());
            location.getInventory().add(inventory);
        });
        return location;
    }
}
