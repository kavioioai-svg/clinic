package com.ilt.cms.inventory.svc.service.inventory;

import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.core.entity.inventory.InventoryTransaction;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.system.SystemStore;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.clinic.ClinicDatabaseService;
import com.ilt.cms.database.item.ItemClinicDetailDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.database.store.SystemStoreDatabaseService;
import com.ilt.cms.inventory.svc.db.service.interfaces.StockTakeDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.*;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.model.nav.NavQueue;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.ilt.cms.inventory.svc.observer.NavStockNotification;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.ilt.cms.inventory.svc.service.common.SystemConfigService;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockCountItemEntity;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockTakeSearchDTO;
import com.ilt.cms.inventory.svc.service.nav.NavStockTakeService;
import com.ilt.cms.inventory.svc.util.PurchasePriceCalculator;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.cms.util.Calculations;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus.COMPLETED;
import static com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE;

@Service
public class StockTakeService {
    private static final Logger logger = LoggerFactory.getLogger(StockTakeService.class);
    public static final String STOCK_AUTO_APPROVAL_DETAILS = "STOCK_AUTO_APPROVAL_DETAILS";
    public static final String IS_AUTO_APPROVAL_ENABLED = "IS_AUTO_APPROVAL_ENABLED";
    public static final String AUTO_APPROVAL_LIMIT = "AUTO_APPROVAL_LIMIT";

    private ItemDatabaseService itemDatabaseService;
    private StockTakeDatabaseService stockTakeDatabaseService;
    private UOMMatrixService uomMatrixService;
    private ClinicDatabaseService clinicDatabaseService;
    private ItemClinicDetailDatabaseService itemClinicDetailDatabaseService;
    private RunningNumberService runningNumberService;
    private SystemConfigService systemConfigService;
    private LocationService locationService;
    private SystemNotifier systemNotifier;
    private DrugItemService itemService;
    private RestTemplate restTemplate;
    private InventoryTransactionRepository inventoryTransactionRepository;
    private InventoryUtilsService inventoryUtilsService;
    private NavStockTakeService navStockTakeService;
    private SystemStoreDatabaseService systemStoreDatabaseService;

    @Value("${nav.queue.delete:}")
    private String deleteNavQueue;

    @Value("${cms.inventory.adjustment.approve.threshold:}")
    private BigDecimal threshold;

    @Value("${nav.api.available:false}")
    private boolean isNavAvailable;

    public BigDecimal getThreshold() {
        return threshold;
    }

    public void setThreshold(BigDecimal threshold) {
        this.threshold = threshold;
    }

    public StockTakeService(ItemDatabaseService itemDatabaseService, LocationService locationService,
                            StockTakeDatabaseService stockTakeDatabaseService, UOMMatrixService uomMatrixService,
                            ClinicDatabaseService clinicDatabaseService, ItemClinicDetailDatabaseService itemClinicDetailDatabaseService,
                            RunningNumberService runningNumberService, SystemConfigService systemConfigService, SystemNotifier systemNotifier,
                            DrugItemService itemService, RestTemplate restTemplate,
                            InventoryTransactionRepository inventoryTransactionRepository, SystemStoreDatabaseService systemStoreDatabaseService,
                            InventoryUtilsService inventoryUtilsService, NavStockTakeService navStockTakeService) {
        this.itemDatabaseService = itemDatabaseService;
        this.locationService = locationService;
        this.stockTakeDatabaseService = stockTakeDatabaseService;
        this.uomMatrixService = uomMatrixService;
        this.clinicDatabaseService = clinicDatabaseService;
        this.itemClinicDetailDatabaseService = itemClinicDetailDatabaseService;
        this.runningNumberService = runningNumberService;
        this.systemConfigService = systemConfigService;
        this.systemNotifier = systemNotifier;
        this.itemService = itemService;
        this.restTemplate = restTemplate;
        this.inventoryTransactionRepository = inventoryTransactionRepository;
        this.systemStoreDatabaseService = systemStoreDatabaseService;
        this.inventoryUtilsService = inventoryUtilsService;
        this.navStockTakeService = navStockTakeService;
    }

    public Page<StockTake> listAllStockTake(String clinicId, String nameRegex, String transactionNoRegex, List<StockTakeApproveStatus> stockTakeApproveStatuses,
                                            List<StockTakeStatus> stockTakeStatuses, List<StockCountType> stockCountTypes,
                                            LocalDate startDate, LocalDate endDate,
                                            int page, int size, Sort.Direction direction, String... sortFields) {

        logger.info("listAllStockTake, clinicId[" + clinicId + "], transactionNoRegex[" + transactionNoRegex + "], countName[" + nameRegex + "] stockCountTypes[" + stockCountTypes +
                "], stockTakeApproveStatuses[" + stockTakeApproveStatuses + "], stockTakeStatuses[" + stockTakeStatuses + "], " +
                "startDate[" + startDate + "], endDate[" + endDate + "] page[" + page + "], size[" + size + "], " +
                "direction[" + direction + "], sortFields[" + sortFields + "]");

        if (stockCountTypes.size() == 0) {
            stockCountTypes.add(StockCountType.PARTIAL);
            stockCountTypes.add(StockCountType.FULL);
        }

        Page<StockTake> stockTakePage = stockTakeDatabaseService.findStockTakeByClinicIdAndCountNameLikeAndTransactionNoLikeAndApproveStatusInAndStockTakeStatusInAndCountTypeInAndDateBetween(
                clinicId, nameRegex, transactionNoRegex, stockTakeApproveStatuses, stockTakeStatuses, stockCountTypes,
                LocalDateTime.of(startDate, LocalTime.MIN), LocalDateTime.of(endDate, LocalTime.MAX), page, size, direction, sortFields);

        return stockTakePage;
    }

    public Page<StockCountItemEntity> searchStockTakes(StockTakeSearchDTO searchDTO, Pageable pageable) throws CMSException {
        return stockTakeDatabaseService.searchStockTakes(searchDTO, pageable);
    }

    public Page<StockTake> listAllAdjustment(String clinicId, String itemType, String itemCodeRegex, String itemNameRegex, String transactionNoRegex, String itemRefId,
                                             List<String> stockTakeApproveStatusStrings, int page, int size, Sort.Direction direction, String sortFields) {

        logger.info("listAllAdjustment, clinicId[" + clinicId + "], itemType[" + itemType + "], itemCodeRegex[" + itemCodeRegex + "], itemNameRegex[" + itemNameRegex +
                "], itemRefId[" + itemRefId + "], stockTakeApproveStatusStrings[" + stockTakeApproveStatusStrings + "], page[" + page + "], size[" + size + "], direction[" + direction + "], sortFields[" + sortFields + "]");
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortFields));

        return stockTakeDatabaseService.searchStockAdjustmentsByCriteria(clinicId, itemType, itemCodeRegex, itemNameRegex,
                transactionNoRegex, itemRefId, stockTakeApproveStatusStrings, pageable);
    }

    public Page<StockTake> listAllAdjustment(StockTakeSearchDTO searchDTO, Pageable pageable) {
        return stockTakeDatabaseService.searchStockAdjustmentsByCriteria(searchDTO, pageable);
    }

    public StockTake findStockTakeById(String stockTakeId) throws CMSException {
        logger.info("find stock take by id [" + stockTakeId + "]");
        Optional<StockTake> stockTakeOpt = stockTakeDatabaseService.findStockTakeById(stockTakeId);
        if (stockTakeOpt.isPresent()) {
            StockTake stocktake = stockTakeOpt.filter(stockTake -> stockTake.getCountType() != StockCountType.ADJUSTMENT)
                    .orElseThrow(() -> {
                        logger.error("Can find stockTake by id[{}] but the countType is [{}]", stockTakeId, stockTakeOpt.get().getCountType());
                        return new CMSException(StatusCode.E2000, "Stock take not found");
                    });

            List<String> itemList = stocktake.getStockCountItems()
                    .stream()
                    .map(StockCountItem::getItemRefId)
                    .distinct()
                    .collect(Collectors.toList());

            if (!itemList.isEmpty()) {
                Map<String, List<Inventory>> inventoryDataSet = locationService.findAllByClinicIdAndItemRefId(stocktake.getClinicId(), itemList)
                        .stream()
                        .filter(inventory -> inventory.getBatchPrice() != null && inventory.getBatchPrice().compareTo(BigDecimal.ZERO) != 0)
                        .collect(Collectors.groupingBy(Inventory::getItemRefId,
                                Collectors.mapping(inventory -> inventory, Collectors.toList())));

                for (StockCountItem stockCountItem: stocktake.getStockCountItems()) {
                    if (inventoryDataSet.containsKey(stockCountItem.getItemRefId())) {
                        stockCountItem.setPurchasePrice(PurchasePriceCalculator.getAveragePurchasePrice(inventoryDataSet.get(stockCountItem.getItemRefId())));
                    } else {
                        stockCountItem.setPurchasePrice(BigDecimal.ZERO);
                    }
                }
            }

            return stocktake;
        }
        logger.error("Cannot find stockTake by id[{}]", stockTakeId);
        throw new CMSException(StatusCode.E2000, "Stock take not found");
    }

    public StockTake createStockTake(String clinicId, LocalDate startDate, LocalTime startTime, String countName,
                                     StockCountType stockCountType, String startRange, String endRange,
                                     List<String> itemStockTakeRange) throws CMSException {
        logger.info("createStockTake clinicId[" + clinicId + "], startDate[" + startDate + "], startTime[" + startTime + "], " +
                "countName[" + countName + "], stockCountType[" + stockCountType + "], startRange[" + startRange + "], endRange[" + endRange + "]");
        if (stockCountType == StockCountType.PARTIAL && startRange == null && endRange == null) {
            logger.error("itemRange is null for create stock take");
            throw new CMSException(StatusCode.E1002, "No itemRange");
        }

        if (startRange != null && endRange != null && (startRange.length() > 3 || endRange.length() > 3)) {
            throw new CMSException(StatusCode.E1002, "Value of start range and end range should be within 3 character");
        }
        if (startRange != null && endRange != null) {
            if (startRange.compareTo(endRange) > 0) {
                logger.error("Value of start range[" + startRange + "] should lower than end range[" + endRange + "]");
                throw new CMSException(StatusCode.E1002, "Value of start range should lower than end range");
            }
        }

        List<Item> items = new ArrayList<>();
        if (stockCountType == StockCountType.PARTIAL) {
            if (itemStockTakeRange != null && itemStockTakeRange.size() > 0) {
                items.addAll(itemDatabaseService.findItemsByIds(itemStockTakeRange));
            } else {
                Map<String, Item> subItemMap = new HashMap<>();
                for (String searchRegex : this.convertToRegex(startRange, endRange)) {
                    List<Item> searchedItems = itemDatabaseService.findItem(clinicId, searchRegex, null).stream()
                            .filter(Item::isInventoried)
                            .collect(Collectors.toList());

                    for (Item item : searchedItems) {
                        subItemMap.put(item.getId(), item);
                    }
                }
                items.addAll(subItemMap.values());
            }
        } else if (stockCountType == StockCountType.FULL) {
            items = itemDatabaseService.findItemByClinicId(clinicId).stream()
                    .filter(Item::isInventoried)
                    .filter(item -> item.getStatus().equals(Status.ACTIVE))
                    .collect(Collectors.toList());
        }
        Map<String, Item> itemIdMap = items.stream()
                .collect(Collectors.toMap(Item::getId, n -> n));

        Location location = locationService.findLocationByClinicIdIncludingZeroQtyInventories(clinicId, items)
                .orElse(new Location(clinicId));

        List<Inventory> nonFilterInventories = location.getInventory()
                .stream()
                .filter(inventory -> inventory.getExpiryDate() == null || inventory.getExpiryDate().isAfter(LocalDate.now()))
                .collect(Collectors.toList());

        Set<String> itemIds = nonFilterInventories.stream().map(Inventory::getItemRefId).collect(Collectors.toSet());
        for (Item item : items) {
            if (!itemIds.contains(item.getId())) {
                Inventory inventory = new Inventory(item.getId(), null, item.getBaseUom(), null, null,
                        BigDecimal.ZERO, item.isTrackingCode());
                inventory.setItemName(item.getName());
                inventory.setItemCode(item.getCode());
                nonFilterInventories.add(inventory);
            }
        }

        // filter empty invetories
        List<Inventory> inventories = filterInventories(nonFilterInventories);

        List<StockCountItem> stockCountItems = inventories.stream()
                .map(inventory -> {
                    try {
                        return conventInventoryToStockCountItem(inventory, itemIdMap);
                    } catch (CMSException e) {
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        if (stockCountItems.size() == 0) {
            logger.error("Cannot find any stockCountItem from clinic[{}] countType[{}], start range[{}] and end range[{}]",
                    clinicId, stockCountType, startRange, endRange);
            throw new CMSException(StatusCode.E2000, "stockCountItem not found");
        }
        StockTake stockTake = new StockTake(generateStockTakeName(clinicId, startDate, startTime), startDate, startTime, clinicId,
                stockCountType, startRange != null && stockCountType == StockCountType.PARTIAL ? startRange : null,
                endRange != null && stockCountType == StockCountType.PARTIAL ? endRange : null, countName,
                runningNumberService.generateStockTakeTransactionNumber(),
                IN_PROCESS_FIRST_STOCK_TAKE, StockTakeApproveStatus.NOT_APPROVED);

        stockTake.setStockCountItems(stockCountItems);

        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);
        savedStockTake.setStockCountItems(savedStockTake.getStockCountItems().stream()
                .peek(stockCountItem -> {
                    if (stockCountItem.getItemName() == null) {
                        logger.warn("stock item name is null [" + stockCountItem + "]");
                    }
                })
                .collect(Collectors.toList()));

        return savedStockTake;
    }

    private List<Inventory> filterInventories(List<Inventory> nonFilteredInventories) {
        logger.info("Inventory filter for the stock take started");
        List<Inventory> inventories = new ArrayList<>();
        Map<String, List<Inventory>> itemMap = nonFilteredInventories.stream()
                .collect(Collectors.groupingBy(Inventory::getItemRefId));

        for (Map.Entry<String, List<Inventory>> itemListMap : itemMap.entrySet()) {
            List<Inventory> inventoryList = itemListMap.getValue()
                    .stream()
                    .filter(inventory -> inventory != null && inventory.getAvailableCount().compareTo(BigDecimal.ZERO) > 0).collect(Collectors.toList());

            if (!inventoryList.isEmpty()) {
                logger.info("zero and empty inventory removed as there are ["+inventoryList.size()+"] non empty items in the inventory");
                inventories.addAll(inventoryList);
            } else {
                logger.info("No non empty inventory found");
                inventories.addAll(itemListMap.getValue());
            }
        }

        return  inventories;
    }

    public StockTake getStockTake(String stockTakeId) throws CMSException {

        return stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Stock take not found"));
    }

    public StockTake stopCountStockTake(String stockTakeId, List<StockCountItem> stockCountItems) throws CMSException {

        logger.info("stopCountStockTake for stockTakeId[" + stockTakeId + "], stockCountItems[" + stockCountItems + "]");

        Optional<StockTake> stockTakeOpt = stockTakeDatabaseService.findStockTakeById(stockTakeId);

        if (!stockTakeOpt.isPresent()) {
            logger.error("Stock take[" + stockTakeId + "] not found");
            throw new CMSException(StatusCode.E2000, "Stock take not found");
        }
        StockTake existStockTake = stockTakeOpt.get();

        List<StockCountItem> existStockCountItems = existStockTake.getStockCountItems();

        List<String> newStockCountItemIds = stockCountItems.stream()
                .filter(stockCountItem -> CommonUtils.isStringValid(stockCountItem.getItemRefId()))
                .filter(stockCountItem -> !CommonUtils.isStringValid(stockCountItem.getInventoryId()))
                .map(StockCountItem::getItemRefId)
                .collect(Collectors.toList());

        Map<String, Item> itemIdMap = itemDatabaseService.findItemsByIds(newStockCountItemIds).stream()
                .collect(Collectors.toMap(Item::getId, n -> n));

        for (StockCountItem stockCountItem : stockCountItems) {
            Optional<StockCountItem> stockCountItemOpt = existStockCountItems.stream()
                    .filter(existStockCountItem -> existStockCountItem.getId().equals(stockCountItem.getId()))
                    .findFirst();
            if (stockCountItemOpt.isPresent()) {
                logger.debug("update existStockCountItem[" + stockCountItemOpt.get() + "], from stockCountItem[" + stockCountItem + "]");
                StockCountItem existStockCountItem = stockCountItemOpt.get();
                existStockCountItem.setPurchasePrice(stockCountItem.getPurchasePrice());
                switch (existStockTake.getStockTakeStatus()) {
                    case IN_PROCESS_FIRST_STOCK_TAKE:
                        Item item = itemIdMap.get(stockCountItem.getItemRefId());
                        if (Objects.isNull(existStockCountItem.getBaseUom())) {
                            existStockCountItem.setBaseUom(item.getBaseUom());
                        }
                        existStockCountItem.setBatchNumber(stockCountItem.getBatchNumber() != null ? stockCountItem.getBatchNumber().toUpperCase() : null);
                        existStockCountItem.setExpiryDate(stockCountItem.getExpiryDate());
                        existStockCountItem.setFirstQuantity(stockCountItem.getFirstQuantity());
                        break;
                    case IN_PROCESS_SECOND_STOCK_TAKE:
                        existStockCountItem.setAdjustedQuantity(stockCountItem.getAdjustedQuantity());
                        existStockCountItem.setPurposeOfAdjustmentCode(stockCountItem.getPurposeOfAdjustmentCode());
                        break;
                }
            } else {
                logger.debug("stock take not found for stockCountItemId[" + stockCountItem.getId() + "], add as new item");
                stockCountItem.setId(CommonUtils.idGenerator());
                stockCountItem.setBatchNumber(stockCountItem.getBatchNumber() != null ? stockCountItem.getBatchNumber().toUpperCase() : null);
                Item item = itemIdMap.get(stockCountItem.getItemRefId());
                if (Objects.nonNull(item)) {
                    stockCountItem.setBaseUom(item.getBaseUom());
                } else {
                    logger.error("Cannot find item by id[{}]", stockCountItem.getItemRefId());
                    throw new CMSException(StatusCode.E2000, "New stock item not found");
                }
                existStockCountItems.add(stockCountItem);
            }
        }

        Map<String, Item> itemMap = getItemMap(existStockTake);
        StockCountItem errorItem = new StockCountItem();

        boolean allMatch = false;
        for (StockCountItem stockCountItem : filterSubmitStockCountItem(existStockTake.getStockCountItems())) {

            allMatch = checkStockTakeItemValidate(stockCountItem, itemMap, existStockTake.getStockTakeStatus());
            if (!allMatch) {
                errorItem = stockCountItem;
                break;
            }
        }

        if (!allMatch) {
            logger.error("Not valid in stockCountItem in stockTake[" + existStockTake.getId() + "], status[" + existStockTake.getStockTakeStatus() + "]");
            throw new CMSException(StatusCode.E1002, "Not valid in stockCountItem[" + errorItem.getItemCode() + "], batch[" + errorItem.getBatchNumber() + "], expiry date[" + errorItem.getExpiryDate() + "]");
        }

        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(existStockTake);
        return savedStockTake;
    }

    public StockTake submitStockTakeForReview(String stockTakeId) throws CMSException {

        logger.info("submitStockTakeForReview by stock take id[" + stockTakeId + "]");
        Optional<StockTake> stockTakeOpt = stockTakeDatabaseService.findStockTakeById(stockTakeId);

        if (!stockTakeOpt.isPresent()) {
            logger.error("Stock take[" + stockTakeId + "] not found");
            throw new CMSException(StatusCode.E2000, "Stock take not found");
        }
        StockTake stockTake = stockTakeOpt.get();
        Map<String, Item> itemMap = getItemMap(stockTake);
        switch (stockTake.getStockTakeStatus()) {
            case IN_PROCESS_FIRST_STOCK_TAKE:
                if (filterSubmitStockCountItem(stockTake.getStockCountItems()).stream()
                        .allMatch(stockCountItem -> stockCountItem.checkValidate(StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE,
                                itemMap.get(stockCountItem.getItemRefId())))) {
                    logger.info("Changing status to In progress second stock take for  stock take id[" + stockTakeId + "]");
                    stockTake.setStockTakeStatus(StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE);
                } else {
                    logger.error("invalid in stockCountItem[" + stockTake.getStockCountItems() + "]");
                    throw new CMSException(StatusCode.E1010, "Invalid in stockCountItem");
                }
                break;
            case IN_PROCESS_SECOND_STOCK_TAKE:
                List<StockCountItem> submitStockCountItems = filterSubmitStockCountItem(stockTake.getStockCountItems());
                if (submitStockCountItems.stream()
                        .allMatch(stockCountItem -> stockCountItem.checkValidate(StockTakeStatus.COMPLETED,
                                itemMap.get(stockCountItem.getItemRefId())))) {
                    logger.info("In progress second stock take, submitting as completed for stock take id[" + stockTakeId + "]");

                    submitStockCountItems = submitStockCountItems
                            .stream()
                            .map(stockCountItem -> autoApproveZeroVariance(stockCountItem))
                            .collect(Collectors.toList());

                    stockTake.setStockCountItems(submitStockCountItems);
                    stockTake.setStockTakeStatus(StockTakeStatus.COMPLETED);
                    stockTake.setEndDate(LocalDate.now());
                    stockTake.setEndTime(LocalTime.now());
                    logger.info("Updated stock take details as completed [" + stockTakeId + "]");

                    checkAndApproveStockTake(submitStockCountItems, stockTake);
                } else {
                    logger.error("invalid in stockCountItem[" + stockTake.getStockCountItems() + "]");
                    throw new CMSException(StatusCode.E1010, "Invalid in stockCountItem");
                }
                break;
        }
        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);

        if (savedStockTake.getStockTakeStatus() == StockTakeStatus.COMPLETED) {
            logger.info("Send stock take create notification for stock take id [" + stockTakeId + "]");
            systemNotifier.notify(new NavStockNotification(savedStockTake.getId(), NavStockNotification.NavAction.CREATE_STOCK_TAKE));
        }

        return savedStockTake;
    }

    private static void checkAndApproveStockTake(List<StockCountItem> submitStockCountItems, StockTake stockTake) {
        boolean isAllApproved = submitStockCountItems
                .stream()
                .allMatch(stockCountItem -> StockCountItemStatus.APPROVED.equals(stockCountItem.getStatus()));

        if (isAllApproved) {
            logger.info("Stock take marked as approved for id[" + stockTake.getId() + "]");
            stockTake.setApproveStatus(StockTakeApproveStatus.APPROVED);
            stockTake.setApprovedDate(LocalDate.now());
        }
    }

    private static StockCountItem autoApproveZeroVariance(StockCountItem stockCountItem) {
        double variance = stockCountItem.getAdjustedQuantity() - stockCountItem.getAvailableCount();

        if (variance == 0) {
            stockCountItem.setStatus(StockCountItemStatus.APPROVED);
            stockCountItem.setApprovedDate(LocalDate.now());
        }

        return stockCountItem;
    }

    public void editBatchNumber(String clinicId, String inventoryId, Item item, String batchNo, String newBatchNo, String reason) throws CMSException {

        logger.info("editBatchNumber clinicId[" + clinicId + "], inventoryId[" + inventoryId + "], itemCode[" + item.getCode() + "], " +
                "batchNo[" + batchNo + "], newBatchNo[" + newBatchNo + "], reason[" + reason + "]");

        validateExistingLocationInventoryByBatchNumber(clinicId, item.getId(), newBatchNo);
        validateExistingStockAdjustment(clinicId, item.getId(), newBatchNo);

        LocationInventory existingLocationInventory = locationService.findByClinicIdAndItemIdAndBatchNo(clinicId, item.getId(), batchNo);
        if (existingLocationInventory == null) {
            throw new CMSException(StatusCode.E1007, "Existing Batch Number does not exist");
        }
        existingLocationInventory.setBatchNumber(newBatchNo);
        locationService.saveInventoryLocation(existingLocationInventory);
    }

    public StockTake adjustStockLevel(String clinicId, String countName, String inventoryId, String itemCode, String batchNo, String uom,
                                      LocalDate expiryDate, LocalDate manufacturerDate, int newStockLevel, String purposeOfAdjustmentCode,
                                      String remark, BigDecimal purchasePrice, String newBatchNo) throws CMSException {

        logger.info("adjustStockLevel clinicId[" + clinicId + "], countName[" + countName + "], inventoryId[" + inventoryId + "], itemCode[" + itemCode + "], " +
                "batchNo[" + batchNo + "], uom[" + uom + "], expiryDate[" + expiryDate + "], manufacturerDate[" + manufacturerDate +
                "], newStockLevel[" + newStockLevel + "], purposeOfAdjustmentCode[" + purposeOfAdjustmentCode + "], remark[" + remark + "]");

        String groupName = inventoryUtilsService.getClinicGroupName(clinicId);
        Item item = itemDatabaseService.findItemByCode(itemCode, Set.of(clinicId), Set.of(groupName))
                .filter(Item::isInventoried)
                .orElseThrow(() -> {
                    logger.error("Item not found for clinic[" + clinicId + "] and itemCode[" + itemCode + "]");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });

        validateExistingStockAdjustment(clinicId, item.getId(), batchNo);

        if (StringUtils.isNotEmpty(batchNo) && !Objects.equals(newBatchNo, batchNo)) {
            editBatchNumber(clinicId, inventoryId, item, batchNo, newBatchNo, remark);
        }

        Optional<Location> locationOpt = locationService.findLocationByClinicId(clinicId, new ArrayList<>(Arrays.asList(item)));

        Optional<Inventory> existInventoryOpt = locationOpt.get().getInventory().stream()
                .filter(inventory -> inventory.getItemRefId() != null)
                .filter(inventory -> inventory.getItemRefId().equals(item.getId()))
                .filter(inventory -> (!CommonUtils.isStringValid(inventory.getBatchNumber()) && !CommonUtils.isStringValid(newBatchNo==null?batchNo:newBatchNo))
                        || (CommonUtils.isStringValid(inventory.getBatchNumber()) && inventory.getBatchNumber().equals(newBatchNo==null?batchNo:newBatchNo)))
                .findFirst();

        Inventory existInventory;
        if (!existInventoryOpt.isPresent()) {
            existInventory = existInventoryOpt
                    .orElseGet(() -> {
                        logger.warn("inventory not exist for itemId[" + item.getId() + "], batchNo[" + newBatchNo==null?batchNo:newBatchNo + "]. ");
                        return new Inventory();
                    });
        } else {
            existInventory = existInventoryOpt.get();
        }

        double ratio = uomMatrixService.findReverseRatio(uom, item.getBaseUom());
        double count = newStockLevel * ratio;
        count = count < 0 ? 0 : count;
        StockCountItem stockCountItem = new StockCountItem(CommonUtils.isStringValid(existInventory.getItemRefId()) ? existInventory.getInventoryId() : null,
                item.getCode(), item.getName(), item.getId(), existInventory.getBatchNumber(), existInventory.getBaseUom(),
                existInventory.getExpiryDate(), existInventory.getManufacturerDate(), existInventory.getAvailableCountInt());
        stockCountItem.setBatchNumber(newBatchNo==null?batchNo:newBatchNo);
        stockCountItem.setOldBatchNumber(batchNo);
        stockCountItem.setExpiryDate(expiryDate);
        stockCountItem.setManufacturerDate(manufacturerDate);
        stockCountItem.setBaseUom(item.getBaseUom());
        stockCountItem.setFirstQuantity(count);
        stockCountItem.setAdjustedQuantity(count);
        stockCountItem.setPurposeOfAdjustmentCode(purposeOfAdjustmentCode);
        stockCountItem.setRemark(remark);
        stockCountItem.setPurchasePrice(purchasePrice);

        if (!stockCountItem.checkValidate(StockTakeStatus.COMPLETED, item)) {
            logger.error("Stock count item not validate [" + stockCountItem + "]");
            throw new CMSException(StatusCode.E1002);
        }

        StockTake stockTake = new StockTake(generateStockTakeName(clinicId, LocalDate.now(), LocalTime.now()), LocalDate.now(),
                LocalTime.now(), clinicId, StockCountType.ADJUSTMENT, null, null, countName, runningNumberService.generateStockTakeTransactionNumber(),
                StockTakeStatus.COMPLETED,
                StockTakeApproveStatus.NOT_APPROVED);

        stockTake.addStockCountItem(stockCountItem);
        if (!stockTake.checkValidate()) {
            logger.error("stockTake not valid [" + stockTake + "]");
            throw new CMSException(StatusCode.E1002);
        }
        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);

        systemNotifier.notify(new NavStockNotification(savedStockTake.getId(), NavStockNotification.NavAction.CREATE_STOCK_ADJUSTMENT));

        //Auto Approval Process is initiated
        Optional<SystemStore> stockAutoAutoApproval = systemStoreDatabaseService.findByKey(STOCK_AUTO_APPROVAL_DETAILS);
        if (stockAutoAutoApproval.isPresent() &&  isAutoApprovalAmountMatch(stockAutoAutoApproval.get(), purchasePrice)) {
            logger.info("Stock adjustment Auto Approval Process started for Stock id "+savedStockTake.getId());
            boolean approved = approveAdjustStockItems(savedStockTake.getId(), stockCountItem);

            logger.info("Stock adjustment Auto Approval Process completed and adjustment is  "+ (approved ? "Approved" : "Not Approved"));

        }

        return savedStockTake;
    }

    private boolean isAutoApprovalAmountMatch(SystemStore systemStore, BigDecimal purchasePrice) {
        boolean isAutoApprovalEnabled = Boolean.parseBoolean(((List<Map<String, String>>) systemStore.getValues()).get(0).get(IS_AUTO_APPROVAL_ENABLED));
        if (!isAutoApprovalEnabled) {
            return false;
        }
        BigDecimal approvalLimit = new BigDecimal(((List<Map<String, String>>) systemStore.getValues()).get(0).get(AUTO_APPROVAL_LIMIT));
        if (approvalLimit == null || approvalLimit.compareTo(BigDecimal.ZERO) == 0) {
            return  true;
        }  else if (approvalLimit != null && approvalLimit.compareTo(purchasePrice) >= 0) {
            return true;
        }
        return false;
    }

    private String getClinicGroupName(String clinicId) {
        if (clinicId != null) {
            Optional<Clinic> clinic = clinicDatabaseService.findOne(clinicId);
            if (clinic.isPresent()) {
                return clinic.get().getGroupName();
            }
        }
        return null;
    }

    public boolean approveStockTake(String stockTakeId) throws CMSException {
        logger.info("approveStockTake [" + stockTakeId + "]");
        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("stock take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock take not found");
                });

        if (stockTake.getStockTakeStatus() != StockTakeStatus.COMPLETED) {
            logger.error("Not allow to approve with status[" + stockTake.getStockTakeStatus() + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to approve with status[" + stockTake.getStockTakeStatus() + "]");
        }
        stockTake.setApproveStatus(StockTakeApproveStatus.APPROVED);

        List<String> itemIds = stockTake.getStockCountItems().stream()
                .map(StockCountItem::getItemRefId)
                .distinct()
                .collect(Collectors.toList());

        Map<String, Item> itemMap = itemDatabaseService.findItemsByIds(itemIds)
                .stream()
                .collect(Collectors.toMap(PersistedObject::getId, item -> item));

        Location location = new Location(stockTake.getClinicId());

        List<Inventory> inventories = location.getInventory();
        List<StockCountItem> stockCountItems = stockTake.getStockCountItems();

        for (StockCountItem stockCountItem : stockCountItems) {
            Inventory newInventory = conventStockCountItemToInventory(stockCountItem, itemMap);
            logger.debug("create new Inventory[" + newInventory + "]");
            inventories.add(newInventory);
        }

        //locationService.saveLocation(location);
        List<InventoryTransaction> inventoryTransactionList = locationService.findAndModify(location, true, false);
        locationService.saveInventoryTransactions(inventoryTransactionList, stockTake.getId(), InventoryTransaction.Type.STOCK_TAKE);
        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);

        systemNotifier.notify(new NavStockNotification(savedStockTake.getId(), NavStockNotification.NavAction.CREATE_STOCK_TAKE));

        return true;
    }

    public boolean rejectStockTake(String stockTakeId) throws CMSException {

        logger.info("rejectStockTake [" + stockTakeId + "]");
        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("Stock take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock take not found");
                });

        if (stockTake.getStockTakeStatus() != StockTakeStatus.COMPLETED) {
            logger.error("Not allow to reject with status[" + stockTake.getStockTakeStatus() + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to reject with status[" + stockTake.getStockTakeStatus() + "]");
        }
        stockTake.setApproveStatus(StockTakeApproveStatus.REJECTED);
        stockTakeDatabaseService.saveStockTake(stockTake);

        return true;
    }

    public List<StockCountItemEntity> approveOrRejectStockTake(List<StockCountItemEntity> stockCountItemEntities,
                                                               StockCountItemStatus status) throws CMSException {
        logger.info("Approve Stock Take by Stock Count Items[" + stockCountItemEntities.size() + "]");

        if (status.name().equals(StockCountItemStatus.REJECTED.name()) && !validateStockCountItems(stockCountItemEntities)) {
            logger.error("CP remarks is required");

            throw new CMSException(StatusCode.I5000, "CP remarks is required");
        }

        Set<String> stockTakeIds = stockCountItemEntities.stream().map(StockCountItemEntity::getStockTakeId)
                .collect(Collectors.toSet());

        List<StockTake> stockTakes = stockTakeDatabaseService.findStockTakeByIds(stockTakeIds);

        for (StockTake stockTake : stockTakes) {

            Location location = new Location(stockTake.getClinicId());
            List<Inventory> inventories = new ArrayList<>();

            List<StockCountItem> existingStockCountItems = stockTake.getStockCountItems();

            for (StockCountItem existingStockCountItem : existingStockCountItems) {

                Optional<StockCountItemEntity> incomingStockCountItemEntityOpt = stockCountItemEntities.stream()
                        .filter(stockCountItemEntity -> stockCountItemEntity.getLineId().equals(existingStockCountItem.getId()))
                        .findFirst();

                if (incomingStockCountItemEntityOpt.isPresent()) {

                    if (status.equals(existingStockCountItem.getStatus())) {
                        throw new CMSException(StatusCode.I5000, "Stock count status is already " + status.name());
                    }

                    existingStockCountItem.setCpRemarks(incomingStockCountItemEntityOpt.get().getCpRemarks());
                    existingStockCountItem.setStatus(status);

                    if (StockCountItemStatus.APPROVED.equals(existingStockCountItem.getStatus())) {
                        existingStockCountItem.setApprovedDate(LocalDate.now());
                        Item itemById = itemService.findItemById(existingStockCountItem.getItemRefId());
                        Inventory newInventory = conventStockCountItemToInventory(existingStockCountItem, Map.of(itemById.getId(),
                                itemById));
                        inventories.add(newInventory);
                    } else if (StockCountItemStatus.REJECTED.equals(existingStockCountItem.getStatus())) {
                        existingStockCountItem.setRejectedDate(LocalDate.now());
                    }
                }
            }

            updateStockTakeStatusAccordingToStockCountItemStatus(stockTake, existingStockCountItems);
            updateInventoryAccordingToTakeCountItem(stockTake, location, inventories);
        }

        List<StockTake> savedStockTakes = stockTakeDatabaseService.saveAll(stockTakes);
        List<StockCountItemEntity> updatedStockCountItems = new ArrayList<>();

        for (StockTake stockTake : savedStockTakes) {
            Optional<StockCountItem> stockCountItemOpt = stockTake.getStockCountItems().stream()
                    .filter(stockCountItem -> stockCountItemEntities.stream()
                            .map(StockCountItemEntity::getLineId)
                            .collect(Collectors.toList())
                            .contains(stockCountItem.getId()))
                    .findFirst();

            if (stockCountItemOpt.isPresent()) {
                updatedStockCountItems.add(convertToStockCountItemEntity(stockTake, stockCountItemOpt.get()));
            }
        }

        return updatedStockCountItems;
    }

    private StockCountItemEntity convertToStockCountItemEntity(StockTake stockTake, StockCountItem stockCountItem) {

        StockCountItemEntity stockCountItemEntity = new StockCountItemEntity();
        stockCountItemEntity.setStockTakeId(stockTake.getId());
        stockCountItemEntity.setLineId(stockCountItem.getId());
        stockCountItemEntity.setCpRemarks(stockCountItem.getCpRemarks());
        stockCountItemEntity.setStatus(stockCountItem.getStatus());
        stockCountItemEntity.setStockTakeApproveStatus(stockTake.getApproveStatus());
        stockCountItemEntity.setLastModifiedDate(stockTake.getLastModifiedDate());
        stockCountItemEntity.setLastModifiedBy(stockTake.getLastModifiedBy());
        stockCountItemEntity.setApprovedDate(stockTake.getApprovedDate());
        stockCountItemEntity.setAvailableCount(stockCountItem.getAvailableCount());

        return stockCountItemEntity;
    }

    private void updateStockTakeStatusAccordingToStockCountItemStatus(StockTake stockTake,
                                                                      List<StockCountItem> existingStockCountItems) {
        boolean allApproved = existingStockCountItems.stream().allMatch(stockCountItem ->
                StockCountItemStatus.APPROVED.equals(stockCountItem.getStatus()));

        boolean allRejected = existingStockCountItems.stream().allMatch(stockCountItem ->
                StockCountItemStatus.REJECTED.equals(stockCountItem.getStatus()));

        if (allApproved) {
            stockTake.setApproveStatus(StockTakeApproveStatus.APPROVED);
            stockTake.setApprovedDate(LocalDate.now());
        } else if (allRejected) {
            stockTake.setApproveStatus(StockTakeApproveStatus.REJECTED);
            stockTake.setRejectedDate(LocalDate.now());
        } else {
            stockTake.setApproveStatus(StockTakeApproveStatus.PARTIAL_APPROVED);
        }
    }

    private void updateInventoryAccordingToTakeCountItem(StockTake stockTake, Location location, List<Inventory> inventories) throws CMSException {
        location.setInventory(inventories);

        List<InventoryTransaction> inventoryTransactionList = locationService.findAndModify(location, true, false);

        locationService.saveInventoryTransactions(inventoryTransactionList, stockTake.getId(), InventoryTransaction.Type.STOCK_TAKE);
    }

    private boolean validateStockCountItems(List<StockCountItemEntity> stockCountItemEntities) {

        return stockCountItemEntities.stream().allMatch(stockCountItemEntity ->
                        stockCountItemEntity.getCpRemarks() != null && stockCountItemEntity.getCpRemarks() != "");
    }

    public List<StockCountItemEntity> approveStockCountItemsOfZeroVariance() throws CMSException {
        List<StockTake> stockTakes = stockTakeDatabaseService
                .findAllByStockTakeStatusAndApproveStatusNotIn(StockTakeStatus.COMPLETED,
                        List.of(StockTakeApproveStatus.APPROVED, StockTakeApproveStatus.REJECTED));

        List<StockTake> updatedStockTakes = new ArrayList<>();
        List<StockCountItem> updatedStockCountItems = new ArrayList<>();

        for (StockTake stockTake : stockTakes) {

            List<StockCountItem> stockCountItems = stockTake.getStockCountItems().stream()
                    .filter(stockCountItem ->
                            !(StockCountItemStatus.APPROVED.equals(stockCountItem.getStatus()) ||
                                    StockCountItemStatus.REJECTED.equals(stockCountItem.getStatus())))
                    .map(stockCountItem -> {
                        double variance = stockCountItem.getAdjustedQuantity() - stockCountItem.getAvailableCount();

                        if (variance == 0) {
                            stockCountItem.setStatus(StockCountItemStatus.APPROVED);
                            updatedStockCountItems.add(stockCountItem);

                            if (!updatedStockTakes.stream().anyMatch(stockTake1 -> stockTake1.getId().equals(stockTake.getId()))) {
                                updatedStockTakes.add(stockTake);
                            }
                        }

                        return stockCountItem;
                    }).collect(Collectors.toList());

            stockTake.setStockCountItems(stockCountItems);
            updateStockTakeStatusAccordingToStockCountItemStatus(stockTake, stockTake.getStockCountItems());
        }

        List<StockTake> savedStockTakes = stockTakeDatabaseService.saveAll(updatedStockTakes);

        List<StockCountItemEntity> updatedStockCountItemEntities = new ArrayList<>();

        for (StockTake stockTake : savedStockTakes) {
            Optional<StockCountItem> stockCountItemOpt = stockTake.getStockCountItems().stream()
                    .filter(stockCountItem -> updatedStockCountItems.stream()
                            .map(StockCountItem::getId)
                            .collect(Collectors.toList())
                            .contains(stockCountItem.getId()))
                    .findFirst();

            if (stockCountItemOpt.isPresent()) {
                updatedStockCountItemEntities.add(convertToStockCountItemEntity(stockTake, stockCountItemOpt.get()));
            }
        }

        return updatedStockCountItemEntities;
    }

    public boolean isStockAdjQuantityExceedsLimit(String stockTakeId, String stockCountItemId) throws CMSException {
        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("Stock take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock take[" + stockTakeId + "] not found");
                });

        StockCountItem stockCountItem = stockTake.getStockCountItems()
                .stream()
                .filter(i -> i.getItemRefId().equals(stockCountItemId))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("Stock count item[" + stockCountItemId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock count item[" + stockCountItemId + "] not found");
                });

        return isStockAdjQuantityExceedsLimit(stockCountItem);
    }

    private boolean isStockAdjQuantityExceedsLimit(StockCountItem stockCountItem) throws CMSException {
        Item item = itemService.findItemById(stockCountItem.getItemRefId());

        Double availableCount = stockCountItem.getAvailableCount();
        Double adjustedQuantity = stockCountItem.getAdjustedQuantity();
        double diff = Math.abs(availableCount - adjustedQuantity);

        if (item.getCost() == null) return false;

        BigDecimal costPrice = Calculations.intToBig4Decimal(item.getCost().getPrice());

        BigDecimal amount = new BigDecimal(diff).multiply(costPrice);

        return amount.compareTo(this.threshold) == 1;
    }

    //TODO: validate for the threshold check, If used for update from Nav Scheduler then threshold check should be ignored
    public boolean approveAdjustStockItems(String stockTakeId, StockCountItem stockCountItem) throws CMSException {
        logger.info("Approve Stock Item Adjustment on Stock Take Id of[" + stockTakeId + "]");

        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("stock take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock take not found");
                });

        if (stockTake.getStockTakeStatus() != StockTakeStatus.COMPLETED) {
            logger.error("Not allow to approve with Stock Take Status[" + stockTake.getStockTakeStatus() + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to approve with Stock Take Status[" + stockTake.getStockTakeStatus() + "]");
        }

        if (stockTake.getApproveStatus() == StockTakeApproveStatus.APPROVED || stockTake.getApproveStatus() == StockTakeApproveStatus.REJECTED) {
            logger.error("Stock Take is already " + stockTake.getApproveStatus());
            throw new CMSException(StatusCode.E1010, "Stock Take is already " + stockTake.getApproveStatus());
        }

        stockTake.setApproveStatus(StockTakeApproveStatus.APPROVED);
        stockTake.setApprovedDate(LocalDate.now());

        Location location = new Location(stockTake.getClinicId());
        List<Inventory> inventories = new ArrayList<>();

        List<StockCountItem> stockCountItems = stockTake.getStockCountItems();

        StockCountItem currentStockCountItem = stockCountItems.stream()
                .filter(sc -> sc.getItemRefId().equals(stockCountItem.getItemRefId()))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("Stock Count Item [ " + stockCountItem.getItemRefId() + " ] not found");
                    return new CMSException(StatusCode.E2000, "Stock Count Item [ " + stockCountItem.getItemRefId() + " ] not found");
                });

        currentStockCountItem.setStatus(StockCountItemStatus.APPROVED);
        currentStockCountItem.setApprovedDate(LocalDate.now());
        currentStockCountItem.setExpiryDate(stockCountItem.getExpiryDate());
        currentStockCountItem.setCpRemarks(stockCountItem.getCpRemarks());
        currentStockCountItem.setAdjustedQuantity(stockCountItem.getAdjustedQuantity());
        currentStockCountItem.setPurposeOfAdjustmentCode(stockCountItem.getPurposeOfAdjustmentCode());

        if (isStockAdjQuantityExceedsLimit(currentStockCountItem)) {
            logger.error("Not allow to approve if adjusted quantity cost exceeds limit");
            throw new CMSException(StatusCode.E1010, "Not allow to approve if adjusted quantity cost exceeds limit");
        }
        Item itemById = itemService.findItemById(currentStockCountItem.getItemRefId());
        Inventory newInventory = conventStockCountItemToInventory(currentStockCountItem, Map.of(itemById.getId(), itemById));
        inventories.add(newInventory);

        location.setInventory(inventories);

        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);
        List<InventoryTransaction> inventoryTransactionList = locationService.findAndModify(location, true, false);

        locationService.saveInventoryTransactions(inventoryTransactionList, stockTake.getId(), InventoryTransaction.Type.ADJUSTMENT);

        systemNotifier.notify(new NavStockNotification(savedStockTake.getId(), NavStockNotification.NavAction.CREATE_STOCK_ADJUSTMENT));

        return true;
    }

    public boolean rejectAdjustStockItems(String stockTakeId, StockCountItem stockCountItem) throws CMSException {
        logger.info("Reject Stock Item Adjustment on Stock Take Id of[" + stockTakeId + "]");

        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("Stock Take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock Take not found");
                });

        if (stockTake.getApproveStatus() == StockTakeApproveStatus.APPROVED || stockTake.getApproveStatus() == StockTakeApproveStatus.REJECTED) {
            logger.error("Stock Take is already" + stockTake.getApproveStatus());
            throw new CMSException(StatusCode.E1010, "Stock Take is already " + stockTake.getApproveStatus());
        }

        if (stockTake.getStockTakeStatus() != StockTakeStatus.COMPLETED) {
            logger.error("Not allow to approve with Stock Take Status[" + stockTake.getStockTakeStatus() + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to approve with Stock Take Status[" + stockTake.getStockTakeStatus() + "]");
        }

        stockTake.setApproveStatus(StockTakeApproveStatus.REJECTED);
        stockTake.setRejectedDate(LocalDate.now());

        List<StockCountItem> stockCountItems = stockTake.getStockCountItems();

        Optional<StockCountItem> optStockCountItem = stockCountItems.stream().filter(curr -> curr.getItemRefId().equals(stockCountItem.getItemRefId())).findFirst();

        if (!optStockCountItem.isPresent()) {
            throw new CMSException(StatusCode.E2000, "Stock Count Item[" + stockCountItem.getItemRefId() + "]+ does not exists");
        }

        StockCountItem currentStockCountItem = optStockCountItem.get();
        currentStockCountItem.setStatus(StockCountItemStatus.REJECTED);
        currentStockCountItem.setRejectedDate(LocalDate.now());
        currentStockCountItem.setCpRemarks(stockCountItem.getCpRemarks());
        currentStockCountItem.setPurposeOfAdjustmentCode(stockCountItem.getPurposeOfAdjustmentCode());

        StockTake savedStockTake = stockTakeDatabaseService.saveStockTake(stockTake);

        systemNotifier.notify(new NavStockNotification(savedStockTake.getId(), NavStockNotification.NavAction.CREATE_STOCK_ADJUSTMENT));

        return true;
    }

    public void deleteStockTake(String stockTakeId) throws CMSException {

        logger.info("deleteStockTake [" + stockTakeId + "]");
        StockTake stockTake = stockTakeDatabaseService.findStockTakeById(stockTakeId)
                .orElseThrow(() -> {
                    logger.error("Stock take[" + stockTakeId + "] not found");
                    return new CMSException(StatusCode.E2000, "Stock take not found");
                });

        if (stockTake.getStockTakeStatus() == COMPLETED
                && stockTake.getNavIntegrationResult() != null
                && stockTake.getNavIntegrationResult().getStatus() != NavIntegrationResult.ResultStatus.FAILED) {
            logger.error("Not allow to delete with status[" + stockTake.getStockTakeStatus() + "] and navIntegrationResult status["
                    + stockTake.getNavIntegrationResult().getStatus() + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to delete with status [" + stockTake.getStockTakeStatus() + "]");
        }

        if (stockTake.getCountType() == StockCountType.ADJUSTMENT) {
            deleteNavQueue(stockTakeId);
        }

        stockTakeDatabaseService.deleteStockTake(stockTakeId);
    }

    public void createNavStockTake(String stockTakeId) {

        if (isNavAvailable) {
            logger.info("createNavStockTake [" + stockTakeId + "]");
            navStockTakeService.createNavStockTake(stockTakeId);
        } else {
            logger.info("Nav API is not enabled");
        }
    }

    public void createNavStockAdjustment(String stockTakeId) {
        if (isNavAvailable) {
            logger.info("createNavStockAdjustment [" + stockTakeId + "]");
            navStockTakeService.createNavStockAdjustment(stockTakeId);
        } else {
            logger.info("Nav API is not enabled");
        }
    }

    public List<InventoryDetail> getExpiredStock(String clinicId) {
        if (isNavAvailable) {
            logger.info("getExpiredStock [" + clinicId + "]");
            return navStockTakeService.getExpiredStock(clinicId);
        } else {
            logger.info("Nav API is not enabled");
        }

        return new ArrayList<>();
    }

    public List<InventoryDetail> getDisposedStock(String clinicId) {
        if (isNavAvailable) {
            logger.info("getDisposedStock [" + clinicId + "]");
            return navStockTakeService.getDisposedStock(clinicId);
        } else {
            logger.info("Nav API is not enabled");
        }

        return new ArrayList<>();
    }

    private void deleteNavQueue(String stockTakeId) {
        ParameterizedTypeReference<CmsServiceResponse<StatusCode>> responseType = new ParameterizedTypeReference<>() {
        };
        HttpEntity<String> entity = getCustomHeaderHttpEntity();
        ResponseEntity<CmsServiceResponse<StatusCode>> responseEntity = restTemplate
                .exchange(deleteNavQueue + "/" + NavQueue.ServiceName.STOCK_ADJUSTMENT + "/" + stockTakeId, HttpMethod.POST, entity, responseType);

        CmsServiceResponse<StatusCode> body = responseEntity.getBody();
        if (body != null) {
            StatusCode statusCode = body.getPayload();
        }
    }

    public Page<StockTake> findStockTakesByStockTakeStatusAndApproveStatus(StockTakeStatus stockTakeStatus,
                                                                           StockTakeApproveStatus stockTakeApproveStatus, int page, int size) {

        logger.info("findStockTakesByStockTakeStatusAndApproveStatus stockTakeStatus[" + stockTakeStatus + "], " +
                "stockTakeApproveStatus[" + stockTakeApproveStatus + "], page[" + page + "], size[" + size + "]");
        return stockTakeDatabaseService.findStockTakeByStockTakeStatusOrApproveStatus(stockTakeStatus, stockTakeApproveStatus,
                page, size, Sort.Direction.DESC, "startDate", "startTime");
    }

    private String generateStockTakeName(String clinicId, LocalDate localDate, LocalTime localTime) throws CMSException {

        Optional<Clinic> activeClinicOpt = clinicDatabaseService.findOne(clinicId);
        if (!activeClinicOpt.isPresent()) {
            logger.error("Clinic[" + clinicId + "] not found");
            throw new CMSException(StatusCode.E2000, "Clinic not found");
        }
        return activeClinicOpt.get().getName() + " - " +
                LocalDateTime.of(localDate, localTime).format(DateTimeFormatter.ofPattern("dd MMM yyyy hh:mm:ss a"));
    }

    public void updateInventoryFromNav(List<LocationInventory> inventory, boolean sendingDifference, String stockTakeId) {
        List<InventoryTransaction> inventoryTransactions = locationService.findAndModify(inventory, sendingDifference, false)
                .stream()
                .map(inventoryTransaction -> {
                    inventoryTransaction.setType(InventoryTransaction.Type.ADJUSTMENT);
                    inventoryTransaction.setRefNumber(stockTakeId);
                    return inventoryTransaction;
                }).collect(Collectors.toList());

        inventoryTransactionRepository.saveAll(inventoryTransactions);
    }

    private StockCountItem conventInventoryToStockCountItem(Inventory inventory, Map<String, Item> itemIdMap) throws CMSException {

        Item item = itemIdMap.get(inventory.getItemRefId());
        if (Objects.isNull(item)) {
            logger.error("Item[" + inventory.getItemRefId() + "] not found");
            throw new CMSException(StatusCode.E2000, "Item not found");
        }
        StockCountItem stockCountItem = new StockCountItem(inventory.getInventoryId(), item.getCode(),
                item.getName(), inventory.getItemRefId(),
                inventory.getBatchNumber(), inventory.getBaseUom(), inventory.getExpiryDate(), inventory.getManufacturerDate(),
                inventory.getAvailableCountInt());
        return stockCountItem;
    }

    private Inventory conventStockCountItemToInventory(StockCountItem stockCountItem, Map<String, Item> itemMap) {

        double variance = stockCountItem.getAdjustedQuantity() - stockCountItem.getAvailableCount();
        return new Inventory(stockCountItem.getItemRefId(), stockCountItem.getBatchNumber(),
                stockCountItem.getBaseUom(), stockCountItem.getExpiryDate(), stockCountItem.getManufacturerDate(),
                BigDecimal.valueOf(variance), itemMap.get(stockCountItem.getItemRefId()).isTrackingCode(), stockCountItem.getPurchasePrice());
    }

    private StockTakeApproveStatus mapToStockTakeApproveStatus(String approveStatusStr) {

        StockTakeApproveStatus status = StockTakeApproveStatus.fromName(approveStatusStr);
        if (status == null) {
            logger.debug("Not match any stockTakeApproveStatus[{}]", approveStatusStr);
        }
        return status;
    }

    private void validateExistingStockAdjustment(String clinicId, String itemId, String batchNo) throws CMSException {

        List<StockTake> existingStockAdjustment = stockTakeDatabaseService
                .findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
                        clinicId, StockCountType.ADJUSTMENT, List.of(StockTakeApproveStatus.NOT_APPROVED, StockTakeApproveStatus.FAILED), itemId, batchNo);
        if (!existingStockAdjustment.isEmpty()) {
            throw new CMSException(StatusCode.E1007, "Existing adjustment exist for the same item/batch no");
        }
    }

    private void validateExistingLocationInventoryByBatchNumber(String clinicId, String itemId, String batchNo) throws CMSException {

        LocationInventory existingLocationInventory = locationService.findByClinicIdAndItemIdAndBatchNo(clinicId, itemId, batchNo);
        if (existingLocationInventory != null) {
            throw new CMSException(StatusCode.E1007, "Existing Batch Number exist for the same item/batch no");
        }
    }

    private Map<String, Item> getItemMap(StockTake stockTake) {
        List<String> itemIds = stockTake.getStockCountItems().stream()
                .map(StockCountItem::getItemRefId)
                .collect(Collectors.toList());

        return itemDatabaseService.findItemsByIds(itemIds).stream()
                .collect(Collectors.toMap(Item::getId, o -> o));
    }

    private List<String> convertToRegex(@Nonnull String start, @Nonnull String end) {

        logger.debug("Call convertToRegex[{}], [{}]", start, end);
        List<String> searchRegexs = new ArrayList<>();
        char[] startChars = start.toCharArray();
        char[] endChars = end.toCharArray();

        String startRegex = samePrefixRegex(startChars, endChars, "");
        String rangeRegex = "";
        String endRegex = "";
        if (startRegex.equals("")) {
            startRegex = startRegex(startChars, "");
            rangeRegex = midRegex(startChars, endChars, "");
            endRegex = endRegex(endChars, "");
        }
        logger.debug("startRegex[{}]", startRegex);
        logger.debug("rangeRegex[{}]", rangeRegex);
        logger.debug("endRegex[{}]", endRegex);
        searchRegexs.addAll(List.of(startRegex, rangeRegex, endRegex));
        searchRegexs.removeIf(regex -> regex.equals(""));

        return searchRegexs;
    }

    private String samePrefixRegex(char[] start, char[] end, String regex) {

        for (int i = 0; i < end.length; i++) {
            if (i == 0) {
                if (start[i] != end[i]) {
                    return regex;
                } else {
                    regex += "^[" + start[i] + "]";
                }
            } else {
                if (start.length > i) {
                    regex += "[" + start[i] + "-" + end[i] + "]";
                } else {
                    regex += "[A-" + end[i] + "]";
                }
            }
        }
        return regex;
    }

    private String midRegex(char[] start, char[] end, String regex) {

        char startChar = start[0];
        char endChar = end[0];

        if (startChar == endChar || startChar + 1 == endChar) {
            return regex;
        }
        startChar += 1;
        endChar -= 1;
        regex = "^[" + startChar + "-" + endChar + "]";
        return regex;
    }

    private String startRegex(char[] start, String regex) {

        char letter = start[start.length - 1];

        char[] subStarts = Arrays.copyOfRange(start, 0, start.length - 1);

        if (subStarts.length > 0) {

            regex += this.startRegex(subStarts, regex);
        }
        if (start.length == 1) {
            regex = regex + "^[" + letter + "]";
        } else {
            regex += "[" + letter + "-z]";
        }
        return regex;
    }

    private String endRegex(char[] end, String regex) {

        char letter = end[end.length - 1];
        char[] subEnds = Arrays.copyOfRange(end, 0, end.length - 1);
        if (subEnds.length > 0) {

            regex += this.endRegex(subEnds, regex);
        }
        if (end.length == 1) {
            regex = regex + "^[" + letter + "]";
        } else {
            regex += "[A-" + letter + "]";
        }
        return regex;
    }

    private List<StockCountItem> filterSubmitStockCountItem(List<StockCountItem> stockCountItems) {

        return stockCountItems.stream()
                .filter(stockCountItem -> !(stockCountItem.getFirstQuantity() == null))
                .collect(Collectors.toList());
    }

    private boolean checkStockTakeItemValidate(StockCountItem stockCountItem, Map<String, Item> itemMap, StockTakeStatus stockTakeStatus) {
        Item item = itemMap.get(stockCountItem.getItemRefId());
        boolean isValidate = stockCountItem.checkValidate(stockTakeStatus, item);
        if (!isValidate) {
            logger.debug("ItemType[{}], TrackingCode[{}], StockCountItem[{}] not validate", item.getItemType(), item.isTrackingCode(), stockCountItem);
        }
        return isValidate;
    }

    private HttpEntity<String> getCustomHeaderHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Tenant", TenantContext.getTenantId());

        HttpEntity<String> entity = new HttpEntity<>("body", headers);
        return entity;
    }
}
