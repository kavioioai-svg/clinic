package com.ilt.cms.inventory.svc.model.purchase.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.item.SellingPrice;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class OrderRequest implements Comparable<OrderRequest> {

    @Override
    public int compareTo(OrderRequest o) {

        if (status != null && o.status != null && status.compareTo(o.status) == 0) {
            if (createDate != null && o.createDate != null && createDate.compareTo(o.createDate) == 0) {
                return orderRequestNo.compareTo(o.orderRequestNo);
            } else if (createDate != null && o.createDate != null) {
                return -(createDate.compareTo(o.createDate));
            }
            return 0;

        } else if (status != null && o.status != null) {
            return status.compareTo(o.status);
        } else {
            return 0;
        }

    }

    public enum Filter {
        CREATED_DATE_LESS, CREATED_DATE_MORE, STATUS, ORDER_REQUEST_NO, TRANSFER_PURCHASE_TYPE, CLINIC_ID
    }

    public enum DataType {
        PR, PO, TO
    }

    public enum FilterType {
        PURCHASE_REQUEST_NORMAL, PURCHASE_REQUEST_SPECIAL, TO_PICK, TO_SENT, PURCHASE_ORDER, TRANSFER_ORDER
    }

    public OrderRequest() {
    }

    public OrderRequest(String clinicName, String orderRequestNo, LocalDate createDate,
                        DataType dataType, FilterType filterType, String status, Object data) {
        this.clinicName = clinicName;
        this.orderRequestNo = orderRequestNo;
        this.createDate = createDate;
        this.dataType = dataType;
        this.filterType = filterType;
        this.status = status;
        this.data = data;
    }

    private String clinicName;

    private String orderRequestNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    private DataType dataType;

    private FilterType filterType;

    private String status;

    private Object data;

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getOrderRequestNo() {
        return orderRequestNo;
    }

    public void setOrderRequestNo(String orderRequestNo) {
        this.orderRequestNo = orderRequestNo;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    public FilterType getFilterType() {
        return filterType;
    }

    public void setFilterType(FilterType filterType) {
        this.filterType = filterType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "OrderRequest{" +
                "clinicName='" + clinicName + '\'' +
                ", orderRequestNo='" + orderRequestNo + '\'' +
                ", createDate=" + createDate +
                ", dataType=" + dataType +
                ", filterType=" + filterType +
                ", status='" + status + '\'' +
                ", data=" + data +
                '}';
    }
}
