package com.ilt.cms.inventory.svc.db.repository.spring.inventory;

import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;


import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface StockTakeRepository extends MongoRepository<StockTake, String> {

    Optional<StockTake> findByStockTakeName(String stockTakeName);

    Page<StockTake> findAllByStockTakeStatusOrApproveStatus(String stockTakeStatusStr, String approveStatusStr, Pageable pageable);

    Page<StockTake> findAllByClinicIdAndCountTypeInAndApproveStatusInAndStockCountItemsItemRefIdIn(String clinicId,
                                                                                                   List<StockCountType> stockCountTypes,
                                                                                                   List<StockTakeApproveStatus> stockTakeStatus,
                                                                                                   List<String> itemRefIds, Pageable pageable);

    List<StockTake> findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
            String clinicId, StockCountType stockCountType, List<StockTakeApproveStatus> approveStatus, String itemRefId, String batchNo);

    Optional<StockTake> findByIdAndCountTypeIn(String stockTakeId, List<String> stockCountTypes);

    Page<StockTake> findStockTakeByClinicIdAndTransactionNoLikeAndCountTypeInAndApproveStatusInAndStockCountItemsItemRefIdIn(String clinicId, String transactionNoRegex, List<StockCountType> asList,
                                                                                                                             List<StockTakeApproveStatus> stockTakeApproveStatuses,
                                                                                                                             List<String> itemRefIds,
                                                                                                                             Pageable pageable);


//    Optional<AdjustmentStockTake> findStockAdjustmentByStockAdjId(String stockId);

    Page<StockTake> findAllByIdIn(Collection<String> id, Pageable pageable);

	List<StockTake> findByTransactionNoIn(Collection<String> transactionNo);
    List<StockTake> findByLastModifiedDateBetween(LocalDateTime start, LocalDateTime end);
    List<StockTake> findByLastModifiedDateBetweenAndStockTakeStatus(LocalDateTime start, LocalDateTime end, String stockTakeStatus);

    Page<StockTake> findByLastModifiedDateGreaterThan(LocalDateTime localDateTime, Pageable pageable);
    Page<StockTake> findByLastModifiedDateGreaterThanAndStockTakeStatus(LocalDateTime localDateTime, Pageable pageable, String stockTakeStatus);

    List<StockTake> findAllByIdIn(Set<String> stockTakeIds);

    List<StockTake> findAllByStockTakeStatusAndApproveStatusNotIn(StockTakeStatus stockTakeStatus,
                                                                   List<StockTakeApproveStatus> approveStatuses);
}
