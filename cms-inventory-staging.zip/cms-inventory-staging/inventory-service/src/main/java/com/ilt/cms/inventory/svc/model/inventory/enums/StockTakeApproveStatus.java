package com.ilt.cms.inventory.svc.model.inventory.enums;

import com.ilt.cms.inventory.svc.model.inventory.StockTake;

public enum StockTakeApproveStatus {

    NOT_APPROVED, APPROVED, REJECTED, PARTIAL_APPROVED, FAILED;

    public static StockTakeApproveStatus fromName(String name) {

        try {
            return StockTakeApproveStatus.valueOf(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
