package com.ilt.cms.inventory.svc.db.service.interfaces;

import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface DisposeOffStockDatabaseService {

    DisposeItem saveDisposeItem(DisposeItem disposeItem);

    Optional<DisposeItem> findDisposeItemByIdAndCliniId(String itemId, String clinicId);
    Optional<DisposeItem> findDisposeItemById(String itemId);

    Optional<DisposeItem> findOneByIdAndClinicIdAndBatchNo(String itemId, String clinicId, String batchNo);

    List<DisposeItem> findAll();

    List<DisposeItem> saveAll(List<DisposeItem> disposeItems);

    Page<DisposeItem> findDisposeItems(String clinicId, List<DisposeStatus> disposeStatuses, LocalDateTime startDateTime,
									   LocalDateTime endDateTime, Pageable pageable);
}
