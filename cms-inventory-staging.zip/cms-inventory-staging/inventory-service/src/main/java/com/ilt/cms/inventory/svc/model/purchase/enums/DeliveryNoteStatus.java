package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum DeliveryNoteStatus {
    DRAFT, CONFIRM, CANCEL, FAILED;
}
