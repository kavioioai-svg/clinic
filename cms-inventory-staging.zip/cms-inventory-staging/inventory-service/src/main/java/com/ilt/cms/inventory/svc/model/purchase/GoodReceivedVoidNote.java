package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.lippo.cms.util.CMSConstant;
import com.lippo.commons.util.CommonUtils;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class GoodReceivedVoidNote {

    @Indexed
    private String id;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate grnVoidDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    private String delivererId;

    private String receiverId;

    private String grnVoidNo;

    private List<GoodReturnItem> returnItems;

    private List<DeliveryNote> deliveryNotes;

    private String additionalRemark;

    private GoodReceivedReturnStatus status;

    private String userId;

    private NavIntegrationResult navIntegrationResult;


    public boolean checkValidate() {
        return isStringValid(delivererId, receiverId) &&
                status != null && grnVoidDate != null &&
                returnItems != null && returnItems.size() > 0;
    }

    public void copy(GoodReceivedVoidNote goodReceivedVoidNote) {
        this.grnVoidDate = goodReceivedVoidNote.grnVoidDate;
        this.returnItems = goodReceivedVoidNote.returnItems;
        this.additionalRemark = goodReceivedVoidNote.getAdditionalRemark();
        this.status = goodReceivedVoidNote.status;
    }

    public GoodReceivedVoidNote() {
        this.createDate = LocalDate.now();
        this.status = GoodReceivedReturnStatus.DRAFT;
        this.returnItems = new ArrayList<>();
        this.deliveryNotes = new ArrayList<>();
    }

    public GoodReceivedVoidNote(String delivererId, String receiverId, String grnVoidNo, String additionalRemark) {
        this.createDate = LocalDate.now();
        this.delivererId = delivererId;
        this.receiverId = receiverId;
        this.grnVoidNo = grnVoidNo;
        this.additionalRemark = additionalRemark;
        this.returnItems = new ArrayList<>();
        this.deliveryNotes = new ArrayList<>();
        this.status = GoodReceivedReturnStatus.DRAFT;
    }

    public GoodReceivedVoidNote(LocalDate grnVoidDate, LocalDate createDate, String delivererId, String receiverId,
                                String grnVoidNo, List<GoodReturnItem> returnItems, List<DeliveryNote> deliveryNotes,
                                String additionalRemark, GoodReceivedReturnStatus status) {
        this.id = CommonUtils.idGenerator();
        this.grnVoidDate = grnVoidDate;
        this.createDate = createDate;
        this.delivererId = delivererId;
        this.receiverId = receiverId;
        this.grnVoidNo = grnVoidNo;
        this.returnItems = returnItems;
        this.deliveryNotes = deliveryNotes;
        this.additionalRemark = additionalRemark;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public LocalDate getGrnVoidDate() {
        return grnVoidDate;
    }

    public void setGrnVoidDate(LocalDate grnVoidDate) {
        this.grnVoidDate = grnVoidDate;
    }

    public String getDelivererId() {
        return delivererId;
    }

    public void setDelivererId(String delivererId) {
        this.delivererId = delivererId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getGrnVoidNo() {
        return grnVoidNo;
    }

    public void setGrnVoidNo(String grnNo) {
        this.grnVoidNo = grnNo;
    }

    public List<GoodReturnItem> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(List<GoodReturnItem> returnItems) {
        this.returnItems = returnItems;
    }

    public String getAdditionalRemark() {
        return additionalRemark;
    }

    public void setAdditionalRemark(String additionalRemark) {
        this.additionalRemark = additionalRemark;
    }

    public List<DeliveryNote> getDeliveryNotes() {
        return deliveryNotes;
    }

    public void setDeliveryNotes(List<DeliveryNote> deliveryNotes) {
        this.deliveryNotes = deliveryNotes;
    }

    public GoodReceivedReturnStatus getStatus() {
        return status;
    }

    public void setStatus(GoodReceivedReturnStatus status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean addNewReturnItem(GoodReturnItem returnItem) {
        for (GoodReturnItem returnItem1 : returnItems) {
            if (returnItem1.equals(returnItem)) {
                return true;
            }
        }
        return returnItems.add(returnItem);
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    public Optional<DeliveryNote> getDeliveryNoteByDnId(String dnId) {
        return deliveryNotes
                .stream()
                .filter(deliveryNote -> deliveryNote.getId().equals(dnId))
                .findAny();
    }

    public void deleteDeliveryNote(DeliveryNote deliveryNote) {
        if (deliveryNotes.stream()
                .anyMatch(deliveryNote1 -> deliveryNote1.getDnNo().equals(deliveryNote.getDnNo()))) {
            deliveryNotes.remove(deliveryNote);
        }
    }

    @Override
    public String toString() {
        return "GoodReceivedVoidNote{" +
                "id='" + id + '\'' +
                ", grnVoidDate=" + grnVoidDate +
                ", createDate=" + createDate +
                ", delivererId='" + delivererId + '\'' +
                ", receiverId='" + receiverId + '\'' +
                ", grnVoidNo='" + grnVoidNo + '\'' +
                ", returnItems=" + returnItems +
                ", deliveryNotes=" + deliveryNotes +
                ", additionalRemark='" + additionalRemark + '\'' +
                ", status=" + status +
                ", userId='" + userId + '\'' +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GoodReceivedVoidNote that = (GoodReceivedVoidNote) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(grnVoidDate, that.grnVoidDate) &&
                Objects.equals(createDate, that.createDate) &&
                Objects.equals(delivererId, that.delivererId) &&
                Objects.equals(receiverId, that.receiverId) &&
                Objects.equals(grnVoidNo, that.grnVoidNo) &&
                Objects.equals(returnItems, that.returnItems) &&
                Objects.equals(deliveryNotes, that.deliveryNotes) &&
                Objects.equals(additionalRemark, that.additionalRemark) &&
                status == that.status &&
                Objects.equals(userId, that.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, grnVoidDate, createDate, delivererId, receiverId, grnVoidNo, returnItems, deliveryNotes, additionalRemark, status, userId);
    }
}
