package com.ilt.cms.inventory.svc.mapper;

import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.Item;

public class InventoryMapper {

    public static InventoryUsage mapToInventoryUsage(Item.ItemType type, String itemId, double quantity, String batchNo) {

        if (itemId == null) {
            return null;
        }
        return new InventoryUsage(mapToInventoryType(type), itemId, quantity, batchNo);

    }

    public static InventoryUsage mapToInventoryUsage(Item item) {

        if(item == null){
            return null;
        }
        return new InventoryUsage(mapToInventoryType(item.getItemType()), item.getId(), 0);
    }

    public static InventoryUsage mapToInventoryUsage(Item item, String batchNo) {

        if (item == null) {
            return null;
        }
        return new InventoryUsage(mapToInventoryType(item.getItemType()), item.getId(), 0, batchNo);
    }

    public static InventoryUsage.InventoryType mapToInventoryType(Item.ItemType type) {
        if (type != null && (type == Item.ItemType.DRUG || type == Item.ItemType.VACCINATION)) {
            switch (type) {
                case DRUG:
                    return InventoryUsage.InventoryType.DRUG;
                case VACCINATION:
                    return InventoryUsage.InventoryType.VACCINE;
                default:
                    return null;
            }
        }
        return null;
    }
}
