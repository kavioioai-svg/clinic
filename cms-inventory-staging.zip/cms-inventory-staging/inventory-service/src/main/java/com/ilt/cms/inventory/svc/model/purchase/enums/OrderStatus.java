package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum OrderStatus {
    //APPROVED, REJECTED, COMPLETED
    DRAFT, INITIAL, PARTIAL_RECEIVED, FULL_RECEIVED, REJECTED, DELETED
}
