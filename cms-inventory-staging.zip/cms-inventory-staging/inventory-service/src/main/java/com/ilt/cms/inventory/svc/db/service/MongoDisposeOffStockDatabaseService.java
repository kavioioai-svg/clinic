package com.ilt.cms.inventory.svc.db.service;

import com.ilt.cms.inventory.svc.db.repository.spring.inventory.DisposeOffStockRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.DisposeOffStockDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MongoDisposeOffStockDatabaseService implements DisposeOffStockDatabaseService {

    private DisposeOffStockRepository disposeOffStockRepository;
    private MongoTemplate mongoTemplate;

    public MongoDisposeOffStockDatabaseService(DisposeOffStockRepository disposeOffStockRepository, MongoTemplate mongoTemplate) {
        this.disposeOffStockRepository = disposeOffStockRepository;
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public DisposeItem saveDisposeItem(DisposeItem disposeItem) {
        return disposeOffStockRepository.save(disposeItem);
    }

    @Override
    public Optional<DisposeItem> findDisposeItemByIdAndCliniId(String itemId, String clinicId) {
        return disposeOffStockRepository.findByItemIdAndClinicId(itemId, clinicId);
    }

    @Override
    public Optional<DisposeItem> findDisposeItemById(String itemId) {
        return disposeOffStockRepository.findById(itemId);
    }

    @Override
    public Optional<DisposeItem> findOneByIdAndClinicIdAndBatchNo(String itemId, String clinicId, String batchNo) {
        return disposeOffStockRepository.findByItemIdAndClinicIdAndBatchNo(itemId, clinicId, batchNo);
    }

    @Override
    public List<DisposeItem> findAll() {
        return disposeOffStockRepository.findAll();
    }

    @Override
    public List<DisposeItem> saveAll(List<DisposeItem> disposeItems) {
        return disposeOffStockRepository.saveAll(disposeItems);
    }

    @Override
    public Page<DisposeItem> findDisposeItems(String clinicId, List<DisposeStatus> disposeStatuses, LocalDateTime startDateTime,
                                              LocalDateTime endDateTime, Pageable pageable) {
        Query query = new Query();

        query.addCriteria(Criteria.where("clinicId").is(clinicId));

        if (disposeStatuses != null && !disposeStatuses.isEmpty()) {
            query.addCriteria(Criteria.where("disposeStatus").in(disposeStatuses));
        }

        query.addCriteria(Criteria.where("disposalRequestDate").gte(startDateTime).lte(endDateTime));
        long total = mongoTemplate.count(query, DisposeItem.class);
        return new PageImpl<>(mongoTemplate.find(query.with(pageable), DisposeItem.class), pageable, total);
    }

}
