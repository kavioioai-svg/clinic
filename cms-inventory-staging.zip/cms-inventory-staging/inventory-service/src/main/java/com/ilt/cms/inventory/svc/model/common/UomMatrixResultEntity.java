package com.ilt.cms.inventory.svc.model.common;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UomMatrixResultEntity {
	private String sourceUom;
	private String destinationUom;
	private double reverseRatio;
}
