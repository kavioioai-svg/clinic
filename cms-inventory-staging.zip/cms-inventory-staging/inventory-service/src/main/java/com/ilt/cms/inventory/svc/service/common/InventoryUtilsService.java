package com.ilt.cms.inventory.svc.service.common;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.database.clinic.ClinicDatabaseService;
import com.ilt.cms.repository.spring.ClinicRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class InventoryUtilsService {

    private final ClinicDatabaseService clinicDatabaseService;


    public InventoryUtilsService(ClinicDatabaseService clinicDatabaseService) {
        this.clinicDatabaseService = clinicDatabaseService;
    }

    public String getClinicGroupName(String clinicId) {
        if (clinicId != null) {
            Optional<Clinic> clinic = clinicDatabaseService.findOne(clinicId);
            if (clinic.isPresent()) {
                return clinic.get().getGroupName();
            }
        }
        return null;
    }
}
