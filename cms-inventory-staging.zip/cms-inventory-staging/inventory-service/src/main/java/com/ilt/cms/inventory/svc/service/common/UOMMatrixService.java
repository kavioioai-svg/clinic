package com.ilt.cms.inventory.svc.service.common;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.UomMatrix;
import com.ilt.cms.database.item.UomMatrixDatabaseService;
import com.ilt.cms.inventory.svc.model.common.UomConversionRequest;
import com.ilt.cms.inventory.svc.model.common.UomMatrixResultEntity;
import com.ilt.cms.inventory.svc.model.common.UomMatrixSearchEntity;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.util.UomConvertUtils;
import com.lippo.commons.util.StatusCode;
import org.bouncycastle.cms.CMSRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class UOMMatrixService {
    private static final Logger logger = LoggerFactory.getLogger(UOMMatrixService.class);

    private UomMatrixDatabaseService uomMatrixDatabaseService;

    private final LoadingCache<UOMCache, Map<String, BigDecimal>> uomMatrix;

    class UOMCache {
        String tenantId;
        String uom;

        public UOMCache(String uom) {
            this.uom = uom;
            tenantId = TenantContext.getTenantId();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            UOMCache uomCache = (UOMCache) o;
            return tenantId.equals(uomCache.tenantId) && Objects.equals(uom, uomCache.uom);
        }

        @Override
        public int hashCode() {
            return Objects.hash(tenantId, uom);
        }
    }

    public UOMMatrixService(UomMatrixDatabaseService uomMatrixDatabaseService) {
        this.uomMatrixDatabaseService = uomMatrixDatabaseService;

        uomMatrix = CacheBuilder.newBuilder()
                .expireAfterWrite(5, TimeUnit.MINUTES)
                .build(CacheLoader.from(input -> {
                    try {
                        return findMatrixExchangeRatioMap(((UOMCache)input).uom);
                    } catch (CMSException e) {
                        logger.error("Error loading ratio");
                        throw new RuntimeException(e);
                    }
                }));
    }

    public double convertItemUom(Item item, String sourceUom, String destinationUom, double quantity) throws ExecutionException {

        logger.debug("Convert item[" + item.getId() + "] uom from sourceUom[" + sourceUom + "] to destinationUom[" + destinationUom + "] and quantity[" + quantity + "]");

        String baseUom = item.getBaseUom();

        double ratio = UomConvertUtils.convertUomRatio(baseUom, sourceUom, destinationUom, uomMatrix.get(new UOMCache(baseUom)));

        double returnQuantity = BigDecimal.valueOf(quantity).multiply(BigDecimal.valueOf(ratio)).setScale(2, RoundingMode.HALF_DOWN).doubleValue();
        if (returnQuantity % 1 != 0) {
            logger.warn("Item[{}] Convert Uom Quantity from source uom[{}] to destination uom[{}] with ratio[{}], quantity[{}] return quantity[{}] is not a integer",
                    item.getId(), sourceUom, destinationUom, ratio, quantity, returnQuantity);
        }
        return returnQuantity;
    }

    public double findReverseRatio(String sourceUomCode, String distinctionUomCode) throws CMSException {

        logger.info("findReverseRatio from[" + sourceUomCode + "] to [" + distinctionUomCode + "]");
        if (sourceUomCode.equals(distinctionUomCode)) {
            return 1;
        }

        Optional<UomMatrix> uomMatrixOpt = uomMatrixDatabaseService.findUOMatrixByUomCode(sourceUomCode);
        Optional<UomMatrix> uomMatrixByDistinctionUOMCodeOpt = uomMatrixDatabaseService.findUOMatrixByUomCode(distinctionUomCode);

        UomMatrix sourceUomMatrix = uomMatrixOpt.orElseGet(() -> new UomMatrix());
        UomMatrix distinctionUomMatrix = uomMatrixByDistinctionUOMCodeOpt.orElseGet(() -> new UomMatrix());

        BigDecimal sourceRatio = sourceUomMatrix.getExchangeRatio().get(distinctionUomCode);
        BigDecimal distinctionRatio = distinctionUomMatrix.getExchangeRatio().get(sourceUomCode);
        if (sourceRatio == null && distinctionRatio == null) {
            logger.error("Cannot found ratio from[" + sourceUomCode + "] to [" + distinctionUomCode + "]");
            throw new CMSException(StatusCode.E2000, "Cannot found ratio from[" + sourceUomCode + "] to [" + distinctionUomCode + "]");
        } else if (sourceRatio != null) {
            return sourceRatio.doubleValue();
        } else {
            logger.debug("source[" + sourceUomCode + "] ratio cannot find. Use distinction[" + distinctionUomCode +
                    "] ratio[" + distinctionRatio + "] instead");
            return (new BigDecimal(1)).divide(distinctionRatio, 15, RoundingMode.HALF_UP).doubleValue();
        }

    }

	public List<UomMatrixResultEntity> findReverseRatio(List<UomMatrixSearchEntity> searchEntityList) {
		logger.info("findReverseRatio for multiple codes [" + searchEntityList + "]");

		Set<String> searchUomList = searchEntityList.stream()
			.filter(param -> !param.getSourceUom().equals(param.getDestinationUom()))
			.map(param -> List.of(param.getSourceUom(), param.getDestinationUom()))
			.flatMap(Collection::stream)
			.collect(Collectors.toSet());

		Map<String, UomMatrix> uomMatrixMap = uomMatrixDatabaseService.findUOMatrixByUomCodeIn(List.copyOf(searchUomList))
			.stream()
			.collect(Collectors.toMap(UomMatrix::getUomCode, uomMatrix -> uomMatrix));

		return searchEntityList.stream()
			.map(param -> mapToUomMatrixResultEntity(param, uomMatrixMap))
			.collect(Collectors.toList());
	}

	private UomMatrixResultEntity mapToUomMatrixResultEntity(UomMatrixSearchEntity searchEntity, Map<String, UomMatrix> uomMatrixMap) {
		String sourceUom = searchEntity.getSourceUom();
		String destinationUom = searchEntity.getDestinationUom();
		double reverseRatio;

		if (sourceUom.equals(destinationUom)) {
			reverseRatio = 1;
		} else {
			UomMatrix sourceUomMatrix = uomMatrixMap.computeIfAbsent(sourceUom, matrix -> new UomMatrix());
			UomMatrix destUomMatrix = uomMatrixMap.computeIfAbsent(destinationUom, matrix -> new UomMatrix());

			BigDecimal sourceRatio = sourceUomMatrix.getExchangeRatio().get(destinationUom);
			BigDecimal destinationRatio = destUomMatrix.getExchangeRatio().get(sourceUom);

			if (sourceRatio != null) {
				reverseRatio = sourceRatio.doubleValue();
			} else if (destinationRatio != null) {
				logger.debug("source[" + sourceUom + "] ratio cannot find. Use distinction[" + destinationUom +
					"] ratio[" + destinationRatio + "] instead");
				reverseRatio = (new BigDecimal(1)).divide(destinationRatio, 15, RoundingMode.HALF_UP).doubleValue();
			} else {
				logger.error("Cannot found ratio from[" + sourceUom + "] to [" + destinationUom + "]");
				throw new CMSRuntimeException("Cannot found ratio from [" + sourceUom + "] to [" + destinationUom + "]");
			}
		}
		return new UomMatrixResultEntity(searchEntity.getSourceUom(), searchEntity.getDestinationUom(), reverseRatio);
	}

    private Map<String, BigDecimal> findMatrixExchangeRatioMap(String uomCode) throws CMSException {

        logger.info("findMatrixExchangeRatioMap from[" + uomCode + "]");

        UomMatrix uomMatrix = uomMatrixDatabaseService.findUOMatrixByUomCode(uomCode).orElseThrow(() -> {
            logger.error("Cannot found uom matrix by[" + uomCode + "]");
            return new CMSException(StatusCode.E2000, "UomMatrix not found");
        });

        return uomMatrix.getExchangeRatio();
    }

    public UomMatrix saveUOMMatrix(UomMatrix uomMatrix) throws CMSException {

        logger.info("saveUOMMatrix[" + uomMatrix + "]");

        if (!uomMatrix.checkValidate()) {
            logger.error("uomMatrix[" + uomMatrix + "] not valid");
            throw new CMSException(StatusCode.E1002, "UomMatrix not valid");
        }
        UomMatrix curUomMatrix = uomMatrixDatabaseService.findUOMatrixByUomCode(uomMatrix.getUomCode())
                .orElse(new UomMatrix(uomMatrix.getUomCode(), uomMatrix.getExchangeRatio()));

        curUomMatrix.setExchangeRatio(uomMatrix.getExchangeRatio());
        return uomMatrixDatabaseService.saveUOMatrix(curUomMatrix);
    }

}
