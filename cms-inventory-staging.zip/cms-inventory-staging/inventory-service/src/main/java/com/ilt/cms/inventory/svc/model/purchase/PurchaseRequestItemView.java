package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PurchaseRequestItemView extends PersistedObject {
    private String uId;
    private String requestNo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requiredBeforeDate;
    private String itemRefId;
    private String supplierId;
    private String uom;
    private int quantity;
    private Integer approvedQuantity;
    private UnitPrice unitPrice;
    private String remark;
    private String cpRemarks;
    private String approvedUom;
    private RequestItem.RequestItemStatus requestItemStatus;
    private String requestClinicId;
    private List<LocationInventory> inventories = new ArrayList<>();
    private Item item;
    private BigDecimal currQty;
    private BigDecimal refQty;

    private String baseUom;
    private Double backOrderQuantityInBaseUOM;

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public LocalDate getRequiredBeforeDate() {
        return requiredBeforeDate;
    }

    public void setRequiredBeforeDate(LocalDate requiredBeforeDate) {
        this.requiredBeforeDate = requiredBeforeDate;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Integer getApprovedQuantity() {
        return approvedQuantity;
    }

    public void setApprovedQuantity(Integer approvedQuantity) {
        this.approvedQuantity = approvedQuantity;
    }

    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(UnitPrice unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCpRemarks() {
        return cpRemarks;
    }

    public void setCpRemarks(String cpRemarks) {
        this.cpRemarks = cpRemarks;
    }

    public String getApprovedUom() {
        return approvedUom;
    }

    public void setApprovedUom(String approvedUom) {
        this.approvedUom = approvedUom;
    }

    public RequestItem.RequestItemStatus getRequestItemStatus() {
        return requestItemStatus;
    }

    public void setRequestItemStatus(RequestItem.RequestItemStatus requestItemStatus) {
        this.requestItemStatus = requestItemStatus;
    }

    public void setRequestClinicId(String requestClinicId) {
        this.requestClinicId = requestClinicId;
    }

    public String getRequestClinicId() {
        return requestClinicId;
    }

    public List<LocationInventory> getInventories() {
        return inventories;
    }

    public void setInventories(List<LocationInventory> inventories) {
        this.inventories = inventories;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public BigDecimal getCurrQty() {
        return currQty;
    }

    public void setCurrQty(BigDecimal currQty) {
        this.currQty = currQty;
    }

    public BigDecimal getRefQty() {
        return refQty;
    }

    public void setRefQty(BigDecimal refQty) {
        this.refQty = refQty;
    }

    public String getBaseUom() {
        return baseUom;
    }

    public void setBaseUom(String baseUom) {
        this.baseUom = baseUom;
    }

    public Double getBackOrderQuantityInBaseUOM() {
        return backOrderQuantityInBaseUOM;
    }

    public void setBackOrderQuantityInBaseUOM(Double backOrderQuantityInBaseUOM) {
        this.backOrderQuantityInBaseUOM = backOrderQuantityInBaseUOM;
    }
}
