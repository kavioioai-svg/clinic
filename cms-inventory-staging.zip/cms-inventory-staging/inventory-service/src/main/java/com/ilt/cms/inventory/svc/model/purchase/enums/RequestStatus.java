package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum RequestStatus {
    DRAFT, REQUESTED, APPROVED, PARTIAL_APPROVED, REJECTED, TRANSFER, FAILED;
}
