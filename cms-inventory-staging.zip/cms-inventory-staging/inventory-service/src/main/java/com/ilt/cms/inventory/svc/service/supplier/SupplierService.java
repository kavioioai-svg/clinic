package com.ilt.cms.inventory.svc.service.supplier;

import com.ilt.cms.core.entity.Status;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.database.SupplierDatabaseService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


@Service
public class SupplierService {

    private static final Logger logger = LoggerFactory.getLogger(SupplierService.class);

    private SupplierDatabaseService supplierDatabaseService;

    public SupplierService(SupplierDatabaseService supplierDatabaseService) {
        this.supplierDatabaseService = supplierDatabaseService;
    }

    public List<Supplier> findAll() {

        logger.info("findAll");
        List<Supplier> supplierList = supplierDatabaseService.listAll();
        supplierList.forEach(Supplier::setSupplierPurchaseItems);
        return supplierList;
    }

    public Supplier findSupplierById(String supplierId) throws CMSException {

        logger.info("findSupplierById[" + supplierId + "]");
        Supplier supplier = supplierDatabaseService.findById(supplierId)
                .orElseThrow(() -> {
                    logger.error("Supplier[" + supplierId + "] not found");
                    return new CMSException(StatusCode.E2000, "Supplier not found.");
                });

        supplier.setSupplierPurchaseItems();
        return supplier;
    }

    public List<Supplier> findSupplierByItem(String itemId) {

        logger.info("findSupplierByItem[" + itemId + "]");
        List<Supplier> supplierList = supplierDatabaseService.findByItemId(itemId);
        supplierList.forEach(supplier -> {
            supplier.setSupplierBonusPurchaseItems(Set.of(itemId));
            supplier.setSupplierPurchaseItems(Set.of(itemId));
        });
        return supplierList;
    }

    public List<Supplier> findSupplierByIds(List<String> supplierIds) throws CMSException {

        logger.info("findSupplierById[size=" + supplierIds.size() + "]");
        List<Supplier> supplierList = supplierDatabaseService.findByIdIn(supplierIds);
        supplierList.forEach(Supplier::setSupplierPurchaseItems);
        return supplierList;
    }

    public List<Supplier> findSupplierByItems(List<String> itemIds) {

        logger.info("findSupplierByItems[size=" + itemIds.size() + "]");
        List<Supplier> supplierList = supplierDatabaseService.findByItemIdIn(itemIds);
        supplierList.forEach(Supplier::setSupplierPurchaseItems);
        return supplierList;
    }

	public List<Supplier> listSupplierWithLimitedFieldsByItems(List<String> itemIds, Status status) {
		logger.info("listSupplierWithLimitedFieldsByItems[size=" + itemIds.size() + "]");
		return supplierDatabaseService.findWithLimitedFieldsByItemIds(itemIds, status);
	}

	public List<Supplier> filterSuppliersByItemId(List<Supplier> suppliers, String itemId) {
    	return suppliers.stream()
			.filter(supplier -> {
				List<String> supplierItemIds = supplier.getItems()
					.stream()
					.map(PurchaseItem::getItemId)
					.collect(Collectors.toList());
				return supplierItemIds.contains(itemId);
			})
			.collect(Collectors.toList());
	}

}
