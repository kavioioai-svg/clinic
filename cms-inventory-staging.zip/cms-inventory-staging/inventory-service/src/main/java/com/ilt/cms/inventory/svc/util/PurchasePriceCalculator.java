package com.ilt.cms.inventory.svc.util;

import com.ilt.cms.inventory.svc.model.inventory.Inventory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

public class PurchasePriceCalculator {
    public static BigDecimal getAveragePurchasePrice(List<Inventory> inventories) {
        inventories = inventories.stream()
                .filter(inventory -> inventory.getBatchPrice() != null && inventory.getBatchPrice().compareTo(BigDecimal.ZERO) != 0)
                .collect(Collectors.toList());

        if (inventories.isEmpty()) {
            return BigDecimal.ZERO;
        }

        final BigDecimal totalBatchPrice = inventories.stream()
                .map(inv -> inv.getBatchPrice())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return  totalBatchPrice.divide(new BigDecimal(inventories.size()), 4 , RoundingMode.HALF_UP);
    }

    public static BigDecimal getWeightedAveragePurchasePrice(List<Inventory> inventories) {
        int totalQuantity = inventories.stream()
                .filter(inv -> inv.getBatchPrice() != null)
                .mapToInt(inv -> inv.getAvailableCountInt())
                .sum();

        final BigDecimal totalInventoryValue = inventories.stream()
                .filter(inv -> inv.getBatchPrice() != null)
                .map(inv -> new BigDecimal(inv.getAvailableCountInt()).multiply(inv.getBatchPrice()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return totalQuantity > 0 ? totalInventoryValue.divide(new BigDecimal(totalQuantity),
                4, RoundingMode.HALF_UP) : BigDecimal.ZERO;
    }


}
