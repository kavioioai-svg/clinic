package com.ilt.cms.inventory.svc.model.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UomConversionRequest {
    private String id;
    private String itemRefId;
    private String sourceUom;
    private String destinationUom;
    private double quantity;
}
