package com.ilt.cms.inventory.svc.model.purchase.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class ReturnOrder implements Comparable<ReturnOrder> {

    private String orderId;

    private String purchaseOrderId;

    private String poNo;

    private String grvnNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    private String status;

    private Object data;

    public ReturnOrder() {
    }

    public ReturnOrder(String orderId, String purchaseOrderId, String poNo, String grvnNo,
                       LocalDate createDate, String status, Object data) {
        this.orderId = orderId;
        this.purchaseOrderId = purchaseOrderId;
        this.poNo = poNo;
        this.grvnNo = grvnNo;
        this.createDate = createDate;
        this.status = status;
        this.data = data;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public String getPoNo() {
        return poNo;
    }

    public void setPoNo(String poNo) {
        this.poNo = poNo;
    }

    public String getGrvnNo() {
        return grvnNo;
    }

    public void setGrvnNo(String grvnNo) {
        this.grvnNo = grvnNo;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ReturnOrder{" +
                "orderId='" + orderId + '\'' +
                ", poNo='" + poNo + '\'' +
                ", grvnNo='" + grvnNo + '\'' +
                ", createDate=" + createDate +
                ", status='" + status + '\'' +
                ", data=" + data +
                '}';
    }

    @Override
    public int compareTo(ReturnOrder o) {
        if (status != null && o.status != null && status.compareTo(o.status) == 0) {
            if (createDate != null && o.createDate != null && createDate.compareTo(o.createDate) == 0) {
                return grvnNo.compareTo(o.grvnNo);
            } else if (createDate != null && o.createDate != null) {
                return -(createDate.compareTo(o.createDate));
            }
            return 0;

        } else if (status != null && o.status != null) {
            return status.compareTo(o.status);
        } else {
            return 0;
        }
    }
}
