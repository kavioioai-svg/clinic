package com.ilt.cms.inventory.svc.service.common;

import com.ilt.cms.core.entity.system.MasterDataStore;
import com.ilt.cms.core.entity.system.SystemStore;
import com.ilt.cms.database.store.SystemStoreDatabaseService;
import com.ilt.cms.inventory.svc.model.common.Reason;
import com.ilt.cms.repository.spring.system.MasterDataStoreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SystemConfigService {

    private static final Logger logger = LoggerFactory.getLogger(SystemConfigService.class);

    private static final String STOCK_COUNT_REASON_KEY = "REASON_CODE";
    private static final String RETURN_ORDER_REASON_KEY = "RETURN_REASON_CODE";
    private static final String PURCHASE_REQUEST_JUSTIFICATION = "REASON_CODE";
    private SystemStoreDatabaseService systemStoreDatabaseService;

    private MasterDataStoreRepository masterDataStoreRepository;

    public SystemConfigService(SystemStoreDatabaseService systemStoreDatabaseService, MasterDataStoreRepository masterDataStoreRepository) {
        this.systemStoreDatabaseService = systemStoreDatabaseService;
        this.masterDataStoreRepository = masterDataStoreRepository;
    }

    public List<Reason> listAdjustmentReason() {
        Optional<MasterDataStore> systemStoreOpt = masterDataStoreRepository.findByKey(STOCK_COUNT_REASON_KEY);
        if (systemStoreOpt.isPresent()) {
            return (List<Reason>) systemStoreOpt.get().getValues();
        } else {
            return new ArrayList<>();
        }
    }

    public List<Reason> listReturnPurOrderReason() {
        Optional<MasterDataStore> systemStoreOpt = masterDataStoreRepository.findByKey(RETURN_ORDER_REASON_KEY);
        if (systemStoreOpt.isPresent()) {
            return (List<Reason>) systemStoreOpt.get().getValues();
        } else {
            return new ArrayList<>();
        }
    }

    public List<Reason> listPurchaseRequestJustification() {
        Optional<MasterDataStore> systemStoreOpt = masterDataStoreRepository.findByKey(PURCHASE_REQUEST_JUSTIFICATION);
        if (systemStoreOpt.isPresent()) {
            return (List<Reason>) systemStoreOpt.get().getValues();
        } else {
            return new ArrayList<>();
        }
    }
}
