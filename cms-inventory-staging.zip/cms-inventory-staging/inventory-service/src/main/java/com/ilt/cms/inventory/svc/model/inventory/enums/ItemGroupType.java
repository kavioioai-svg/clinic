package com.ilt.cms.inventory.svc.model.inventory.enums;

public enum ItemGroupType {
    SERVICE,DRUG,CONSUMABLE
}
