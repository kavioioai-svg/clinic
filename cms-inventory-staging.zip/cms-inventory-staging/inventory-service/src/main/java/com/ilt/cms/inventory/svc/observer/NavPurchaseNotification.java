package com.ilt.cms.inventory.svc.observer;

import com.ilt.cms.inventory.svc.model.purchase.DeliveryNote;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedNote;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedVoidNote;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.lippo.cms.notify.CmsNotification;

public class NavPurchaseNotification implements CmsNotification {

    private NavAction action;

    private String clinicId;

    private String orderId;

    private String grvnId;

    private PurchaseRequest purchaseRequest;

    private GoodReceivedNote goodReceivedNote;

    //private GoodReceivedVoidNote goodReceivedVoidNote;
    private Order returnOrder;

    private DeliveryNote deliveryNote;


    public enum NavAction {
        CREATE_PR, CREATE_PUR_GRN, CREATE_TRANSFER_GRN, CREATE_GRVN, CREATE_DN, CREATE_RO_DN
    }

    public NavPurchaseNotification(String clinicId, PurchaseRequest purchaseRequest) {
        this.action = NavAction.CREATE_PR;
        this.clinicId = clinicId;
        this.purchaseRequest = purchaseRequest;
    }

    public NavPurchaseNotification(NavAction action, String clinicId, String orderId, GoodReceivedNote goodReceivedNote) {
        this.action = action;
        this.clinicId = clinicId;
        this.orderId = orderId;
        this.goodReceivedNote = goodReceivedNote;
    }

    public NavPurchaseNotification(String clinicId, String orderId, Order returnOrder) {
        this.action = NavAction.CREATE_GRVN;
        this.clinicId = clinicId;
        this.orderId = orderId;
        this.returnOrder = returnOrder;
    }

    public NavPurchaseNotification(String clinicId, String orderId, String grvnId, DeliveryNote deliveryNote) {
        this.action = NavAction.CREATE_RO_DN;
        this.clinicId = clinicId;
        this.orderId = orderId;
        this.grvnId = grvnId;
        this.deliveryNote = deliveryNote;
    }

    public NavPurchaseNotification(String clinicId, String orderId, DeliveryNote deliveryNote) {
        this.action = NavAction.CREATE_DN;
        this.clinicId = clinicId;
        this.orderId = orderId;
        this.deliveryNote = deliveryNote;
    }

    public NavAction getAction() {
        return action;
    }

    public String getClinicId() {
        return clinicId;
    }

    public String getOrderId() {
        return orderId;
    }

    public PurchaseRequest getPurchaseRequest() {
        return purchaseRequest;
    }

    public GoodReceivedNote getGoodReceivedNote() {
        return goodReceivedNote;
    }


    public Order getReturnOrder() {
        return returnOrder;
    }

    public DeliveryNote getDeliveryNote() {
        return deliveryNote;
    }

    public String getGrvnId() {
        return grvnId;
    }

    @Override
    public String toString() {
        return "NavPurchaseNotification{" +
                "action=" + action +
                ", clinicId='" + clinicId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", grvnId='" + grvnId + '\'' +
                ", purchaseRequest=" + purchaseRequest +
                ", goodReceivedNote=" + goodReceivedNote +
                ", returnOrder=" + returnOrder +
                ", deliveryNote=" + deliveryNote +
                '}';
    }
}
