package com.ilt.cms.inventory.svc.model.nav;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.PersistedObject;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Date;

public class NavQueueFilter {
    private String serviceName;
    private String referenceNo;
    private String status;
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    private String sentOnStart;
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    private String sentOnEnd;

    public String getServiceName() {
        return serviceName;
    }
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    public String getReferenceNo() {
        return referenceNo;
    }
    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getSentOnStart() {
        return sentOnStart;
    }

    public void setSentOnStart(String sentOnStart) {
        this.sentOnStart = sentOnStart;
    }

    public String getSentOnEnd() {
        return sentOnEnd;
    }

    public void setSentOnEnd(String sentOnEnd) {
        this.sentOnEnd = sentOnEnd;
    }
}
