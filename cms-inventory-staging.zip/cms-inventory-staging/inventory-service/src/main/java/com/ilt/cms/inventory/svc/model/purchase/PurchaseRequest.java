package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestType;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class PurchaseRequest extends PersistedObject {

    private String requestClinicId;

    private RequestType requestType;

    @Indexed(unique = true)
    private String requestNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requiredBeforeDate;

    private List<RequestItem> requestItems;

    private String justificationForPurchase;

    private RequestStatus requestStatus;

    private String remark;

    private Boolean isReadByNav;

    private String userName;

    private NavIntegrationResult navIntegrationResult;

    public boolean checkValidate() {
        return isStringValid(requestClinicId, justificationForPurchase) && requestStatus != null && requestType != null;
    }

    public PurchaseRequest() {
        requestType = RequestType.STANDARD;
    }

    public PurchaseRequest(String requestClinicId, String requestNo, LocalDate requestDate, LocalDate requiredBeforeDate,
                           List<RequestItem> requestItems, String justificationForPurchase, RequestStatus requestStatus, String userName) {
        this.requestClinicId = requestClinicId;
        this.requestNo = requestNo;
        this.createDate = LocalDate.now();
        this.requestDate = requestDate;
        this.requiredBeforeDate = requiredBeforeDate;
        this.requestItems = requestItems;
        this.justificationForPurchase = justificationForPurchase;
        this.requestStatus = requestStatus;
        this.userName = userName;
        this.requestType = RequestType.STANDARD;
    }

    public PurchaseRequest(String requestClinicId, String requestNo, LocalDate createDate, LocalDate requestDate, LocalDate requiredBeforeDate,
                           List<RequestItem> requestItems, String justificationForPurchase, RequestStatus requestStatus) {
        this.requestClinicId = requestClinicId;
        this.requestNo = requestNo;
        this.createDate = createDate;
        this.requestDate = requestDate;
        this.requiredBeforeDate = requiredBeforeDate;
        this.requestItems = requestItems;
        this.justificationForPurchase = justificationForPurchase;
        this.requestStatus = requestStatus;
        this.requestType = RequestType.STANDARD;
    }

    public PurchaseRequest(String requestClinicId, RequestType requestType, String requestNo, LocalDate createDate, LocalDate requiredBeforeDate,
                           LocalDate requestDate, List<RequestItem> requestItems, String justificationForPurchase, RequestStatus requestStatus) {
        this.requestClinicId = requestClinicId;
        this.requestType = requestType;
        this.requestNo = requestNo;
        this.createDate = createDate;
        this.requestDate = requestDate;
        this.requiredBeforeDate = requiredBeforeDate;
        this.requestItems = requestItems;
        this.justificationForPurchase = justificationForPurchase;
        this.requestStatus = requestStatus;
    }

    public void copy(PurchaseRequest purchaseRequest) {

        this.userName = purchaseRequest.getUserName();
        this.requiredBeforeDate = purchaseRequest.requiredBeforeDate;
        this.requestItems = purchaseRequest.getRequestItems();
        this.justificationForPurchase = purchaseRequest.getJustificationForPurchase();
        this.requestStatus = purchaseRequest.getRequestStatus();
        this.remark = purchaseRequest.remark;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public String getRequestClinicId() {
        return requestClinicId;
    }

    public void setRequestClinicId(String requestClinicId) {
        this.requestClinicId = requestClinicId;
    }

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public List<RequestItem> getRequestItems() {
        return requestItems;
    }

    public void setRequestItems(List<RequestItem> requestItems) {
        this.requestItems = requestItems;
    }

    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(RequestStatus requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getJustificationForPurchase() {
        return justificationForPurchase;
    }

    public void setJustificationForPurchase(String justificationForPurchase) {
        this.justificationForPurchase = justificationForPurchase;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public LocalDate getRequiredBeforeDate() {
        return requiredBeforeDate;
    }

    public void setRequiredBeforeDate(LocalDate requiredBeforeDate) {
        this.requiredBeforeDate = requiredBeforeDate;
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    @Override
    public String toString() {
        return "PurchaseRequest{" +
                "requestClinicId='" + requestClinicId + '\'' +
                ", requestType=" + requestType +
                ", requestNo='" + requestNo + '\'' +
                ", createDate=" + createDate +
                ", requestDate=" + requestDate +
                ", requiredBeforeDate=" + requiredBeforeDate +
                ", requestItems=" + requestItems +
                ", justificationForPurchase='" + justificationForPurchase + '\'' +
                ", requestStatus=" + requestStatus +
                ", remark='" + remark + '\'' +
                ", isReadByNav=" + isReadByNav +
                ", userName='" + userName + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

    public Boolean getIsReadByNav() {
        return isReadByNav;
    }

    public void setIsReadByNav(Boolean isReadByNav) {
        this.isReadByNav = isReadByNav;
    }

    public boolean addNewRequestItem(RequestItem requestItem) {
        for(RequestItem requestItem1:requestItems){
            if(requestItem.equals(requestItem1)){
                return true;
            }
        }
        return requestItems.add(requestItem);
    }

}
