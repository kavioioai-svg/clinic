package com.ilt.cms.inventory.svc.model.inventory.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class DisposeItemEntity {

    private String clinicId;
    private String disposeItemRefId;
    private String itemName;
    private String itemCode;
    private String batchNo;
    private String remark;
    private DisposeStatus disposeStatus;
    private int quantity;
    private String cpRemark;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate disposalRequestDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate disposedDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;

    public DisposeItemEntity(){

    }

    public DisposeItemEntity(String clinicId, String itemId, String itemName, String itemCode, String batchNo, String remark,
                             DisposeStatus disposeStatus, int quantity, String cpRemark, LocalDate manufacturerDate,
                             LocalDate disposalRequestDate, LocalDate disposedDate, LocalDate expiryDate) {
        this.clinicId = clinicId;
        this.disposeItemRefId = itemId;
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.batchNo = batchNo;
        this.remark = remark;
        this.disposeStatus = disposeStatus;
        this.quantity = quantity;
        this.cpRemark = cpRemark;
        this.manufacturerDate = manufacturerDate;
        this.disposalRequestDate = disposalRequestDate;
        this.disposedDate = disposedDate;
        this.expiryDate = expiryDate;
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public String getDisposeItemRefId() {
        return disposeItemRefId;
    }

    public void setDisposeItemRefId(String disposeItemRefId) {
        this.disposeItemRefId = disposeItemRefId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public DisposeStatus getDisposeStatus() {
        return disposeStatus;
    }

    public void setDisposeStatus(DisposeStatus disposeStatus) {
        this.disposeStatus = disposeStatus;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCpRemark() {
        return cpRemark;
    }

    public void setCpRemark(String cpRemark) {
        this.cpRemark = cpRemark;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public LocalDate getDisposalRequestDate() {
        return disposalRequestDate;
    }

    public void setDisposalRequestDate(LocalDate disposalRequestDate) {
        this.disposalRequestDate = disposalRequestDate;
    }

    public LocalDate getDisposedDate() {
        return disposedDate;
    }

    public void setDisposedDate(LocalDate disposedDate) {
        this.disposedDate = disposedDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "DisposeItemEntity{" +
                "itemId='" + disposeItemRefId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemCode='" + itemCode + '\'' +
                ", batchNo='" + batchNo + '\'' +
                ", remark='" + remark + '\'' +
                ", disposeStatus=" + disposeStatus +
                ", quantity=" + quantity +
                ", cpRemark='" + cpRemark + '\'' +
                ", manufacturerDate=" + manufacturerDate +
                ", disposalRequestDate=" + disposalRequestDate +
                ", disposedDate=" + disposedDate +
                ", expiryDate=" + expiryDate +
                '}';
    }
}
