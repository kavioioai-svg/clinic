package com.ilt.cms.inventory.svc.observer;

import com.ilt.cms.inventory.svc.service.nav.NavStockTakeService;
import com.lippo.cms.notify.CmsNotification;
import com.lippo.cms.notify.CmsNotificationsObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NavStockObserver implements CmsNotificationsObserver {

    private static final Logger logger = LoggerFactory.getLogger(NavStockObserver.class);

    private NavStockTakeService stockTakeService;

    @Value("${nav.api.available:false}")
    private boolean isNavAvailable;

    public NavStockObserver(NavStockTakeService stockTakeService) {
        this.stockTakeService = stockTakeService;
    }

    @Override
    public void notify(CmsNotification notification) {

        if (isNavAvailable && notification instanceof NavStockNotification) {
            NavStockNotification navStockNotification = (NavStockNotification) notification;

            NavStockNotification.NavAction action = navStockNotification.getAction();

            switch (action) {
                case CREATE_STOCK_TAKE:
                    stockTakeService.createNavStockTake(navStockNotification.getStockId());
                    break;
                case CREATE_STOCK_ADJUSTMENT:
                    stockTakeService.createNavStockAdjustment(navStockNotification.getStockId());
                    break;
                case UPDATE_DISPOSE_STOCK:
                    stockTakeService.updateDisposeStock(navStockNotification.getStockId());
                    break;
                default:
                    logger.warn("No action is match:" + action);
            }
        }

    }
}
