package com.ilt.cms.inventory.svc.model.inventory.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AdjustmentStockTake {

    private String inventoryId;

    private String itemCode;

    private String batchNo;

    private String newBatchNo;

    private String uom;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;

    private int newStockLevel;

    private String purposeOfAdjustmentCode;

    private String remark;

    private BigDecimal purchasePrice;

    public AdjustmentStockTake() {
    }

    public AdjustmentStockTake(String itemCode, String batchNo, String uom, LocalDate expiryDate, LocalDate manufacturerDate, int newStockLevel,
                               String purposeOfAdjustmentCode, String remark, BigDecimal purchasePrice) {
        this.itemCode = itemCode;
        this.batchNo = batchNo;
        this.uom = uom;
        this.expiryDate = expiryDate;
        this.manufacturerDate = manufacturerDate;
        this.newStockLevel = newStockLevel;
        this.purposeOfAdjustmentCode = purposeOfAdjustmentCode;
        this.remark = remark;
        this.purchasePrice = purchasePrice;
    }

    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getNewBatchNo() {
        return newBatchNo;
    }

    public void setNewBatchNo(String newBatchNo) {
        this.newBatchNo = newBatchNo;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public int getNewStockLevel() {
        return newStockLevel;
    }

    public void setNewStockLevel(int newStockLevel) {
        this.newStockLevel = newStockLevel;
    }

    public String getPurposeOfAdjustmentCode() {
        return purposeOfAdjustmentCode;
    }

    public void setPurposeOfAdjustmentCode(String purposeOfAdjustmentCode) {
        this.purposeOfAdjustmentCode = purposeOfAdjustmentCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "AdjustmentStockTake{" +
                "inventoryId='" + inventoryId + '\'' +
                ", itemCode='" + itemCode + '\'' +
                ", batchNo='" + batchNo + '\'' +
                ", uom='" + uom + '\'' +
                ", expiryDate=" + expiryDate +
                ", manufacturerDate=" + manufacturerDate +
                ", newStockLevel=" + newStockLevel +
                ", purposeOfAdjustmentCode='" + purposeOfAdjustmentCode + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
