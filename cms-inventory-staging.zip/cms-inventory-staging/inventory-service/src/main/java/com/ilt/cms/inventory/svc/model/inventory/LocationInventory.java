package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.audit.AuditableEntity;
import com.lippo.cms.util.CMSConstant;
import lombok.ToString;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@CompoundIndexes({
        @CompoundIndex(name = "index_unique", unique = true, def = "{'clinicId' : 1, 'itemRefId' : 1, 'batchNumber' : 1 }"),
})
@ToString(callSuper = true)
@AuditableEntity
public class LocationInventory extends PersistedObject {
    private String clinicId;
    private String itemRefId;
    @Transient
    private String itemName;
    @Transient
    private String itemCode;
    private String batchNumber;
    private String baseUom;
    @Field(targetType = FieldType.DECIMAL128)
    private BigDecimal batchPrice;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;
    @Field(targetType = FieldType.DECIMAL128)
    private BigDecimal availableCount = BigDecimal.ZERO;
    @Transient
    private int baseUomQuantity;
    @Transient
    private boolean isTrackingCode;

    public LocationInventory() {

    }


    private LocationInventory(String clinicId, String itemRefId, String itemName, String itemCode, String batchNumber,
                              String baseUom, LocalDate manufacturerDate, LocalDate expiryDate, BigDecimal availableCount,
                              int baseUomQuantity, boolean isTrackingCode) {
        this.clinicId = clinicId;
        this.itemRefId = itemRefId;
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.manufacturerDate = manufacturerDate;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.baseUomQuantity = baseUomQuantity;
        this.isTrackingCode = isTrackingCode;
    }

    public LocationInventory(String clinicId, String itemRefId, String batchNumber, LocalDate expiryDate,
                             BigDecimal availableCount, boolean isTrackingCode) {
        this.clinicId = clinicId;
        this.itemRefId = itemRefId;
        this.batchNumber = batchNumber;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.isTrackingCode = isTrackingCode;
    }

    public static LocationInventory createLocationInventory(String clinicId, String itemRefId, String itemName, String itemCode,
                                                            String batchNumber, String baseUom, LocalDate manufacturerDate,
                                                            LocalDate expiryDate, BigDecimal availableCount, int baseUomQuantity, boolean isTrackingCode) {
        return new LocationInventory(clinicId, itemRefId, itemName, itemCode, batchNumber, baseUom, manufacturerDate, expiryDate,
                availableCount, baseUomQuantity, isTrackingCode);
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getBaseUom() {
        return baseUom;
    }

    public void setBaseUom(String baseUom) {
        this.baseUom = baseUom;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public BigDecimal getAvailableCount() {
        return availableCount;
    }

    public void setAvailableCount(BigDecimal availableCount) {
        this.availableCount = availableCount;
    }

    public int getBaseUomQuantity() {
        return baseUomQuantity;
    }

    public void setBaseUomQuantity(int baseUomQuantity) {
        this.baseUomQuantity = baseUomQuantity;
    }

    public boolean isTrackingCode() {
        return isTrackingCode;
    }

    public void setTrackingCode(boolean trackingCode) {
        isTrackingCode = trackingCode;
    }

    public BigDecimal getBatchPrice() {return batchPrice;}

    public void setBatchPrice(BigDecimal batchPrice) {
        this.batchPrice = batchPrice;
    }
}
