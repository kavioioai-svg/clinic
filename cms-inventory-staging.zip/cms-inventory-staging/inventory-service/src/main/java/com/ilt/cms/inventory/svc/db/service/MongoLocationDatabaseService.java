package com.ilt.cms.inventory.svc.db.service;

import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.LocationDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.mongodb.client.result.UpdateResult;
import org.springframework.cglib.core.Local;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MongoLocationDatabaseService implements LocationDatabaseService {

    private LocationRepository locationRepository;

    public MongoLocationDatabaseService(LocationRepository locationRepository){
        this.locationRepository = locationRepository;
    }

    @Override
    public Location saveLocation(Location location) {
        return locationRepository.save(location);
    }

    @Override
    public Optional<Location> findLocationById(String locationId) {
        return locationRepository.findById(locationId);
    }

    @Override
    public Optional<Location> findLocationByClinicId(String clinicId) {
        return locationRepository.findByClinicId(clinicId);
    }

    @Override
    public List<Location> findAll() {
        return locationRepository.findAll();
    }

    @Override
    public void saveAll(List<Location> locations) {
        locationRepository.saveAll(locations);
    }
}
