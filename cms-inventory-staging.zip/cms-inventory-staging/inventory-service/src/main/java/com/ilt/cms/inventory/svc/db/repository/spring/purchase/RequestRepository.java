package com.ilt.cms.inventory.svc.db.repository.spring.purchase;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;

@Repository
public interface RequestRepository extends MongoRepository<PurchaseRequest, String> {
    List<PurchaseRequest> findAllByRequestClinicId(String requestClinicId, Pageable page);

    List<PurchaseRequest> findAllByRequestNoIn(List<String> requestNumber);
    List<PurchaseRequest> findAllByIdIn(List<String> ids);

    List<PurchaseRequest> findAllByRequestStatusInAndCreatedDateBetweenAndIsReadByNavIsNull(List<RequestStatus> requestStatuses,LocalDate startDate,LocalDate endDate, Sort sort);

    List<PurchaseRequest> findAllByRequestDateBetween(LocalDate startDate, LocalDate endDate, Pageable pageable);
    List<PurchaseRequest> findByLastModifiedDateBetween(LocalDateTime var1, LocalDateTime var2);
    Page<PurchaseRequest> findByLastModifiedDateGreaterThan(LocalDateTime var1, Pageable var2);
}
