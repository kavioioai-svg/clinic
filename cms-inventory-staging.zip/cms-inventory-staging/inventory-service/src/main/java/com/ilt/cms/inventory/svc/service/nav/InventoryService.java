package com.ilt.cms.inventory.svc.service.nav;

import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.item.Item;

import java.util.List;


public interface InventoryService {
    List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> fireInventoryApi(String clinicId, List<Item> items);

    List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> fireNavInventoryApi(String clinicId, List<Item> items);
}
