package com.ilt.cms.inventory.svc.model.util;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Couple<F, S> {

    private F first;
    private S second;

}
