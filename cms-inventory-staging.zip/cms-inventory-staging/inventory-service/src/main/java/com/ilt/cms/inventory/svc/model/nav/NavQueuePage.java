package com.ilt.cms.inventory.svc.model.nav;

import org.springframework.data.domain.PageRequest;

import java.util.ArrayList;
import java.util.List;

public class NavQueuePage<T> {

    private List<NavQueue> content = new ArrayList<>();
    private long totalElements;
    private int totalPages;
    private int pageNumber;

    public NavQueuePage() {
    }

    public NavQueuePage(List<NavQueue> navQueues, long totalElements, int totalPages, int pageNumber) {
        this.content = navQueues;
        this.totalElements = totalElements;
        this.totalPages = totalPages;
        this.pageNumber = pageNumber;
    }

    public List<NavQueue> getContent() {
        return content;
    }
    public void setContent(List<NavQueue> content) {
        this.content = content;
    }
    public long getTotalElements() {
        return totalElements;
    }
    public void setTotalElements(long totalElements) {
        this.totalElements = totalElements;
    }
    public int getTotalPages() {
        return totalPages;
    }
    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }
    public int getPageNumber() {
        return pageNumber;
    }
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }
}
