package com.ilt.cms.inventory.svc.db.repository.spring.purchase;

import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends MongoRepository<Order, String> {

    List<Order> findAllByRequestClinicIdOrClinicFilterClinicsInOrClinicFilterClinicGroupName(String clinicId,
                                                                                             List<String> clinicIds,
                                                                                             String clinicGroupName, Pageable page);

    @Query(value = "{$and : " +
            "[{$or:[{'requestClinicId' : ?0},{'clinicFilter.clinics' : ?0}, {'clinicFilter.clinicGroupName' : ?1}]}, " +
            "{'createDate' : {$gte: ?2, $lte:?3}}]}")
    List<Order> findPurchaseOrderByRequestClinicIdGoodReceivedVoidNotesCreateDateBetween(String clinicId,
                                                                                         String clinicGroupName,
                                                                                         LocalDateTime startTime,
                                                                                         LocalDateTime endTime,
                                                                                         Pageable pageable);

    List<Order> findByOrderTypeAndOrderStatusInAndCreateDateBetween(OrderType orderType, List<OrderStatus> orderStatus,
                                                                    LocalDate startDate, LocalDate endDate, Sort sort);

    List<Order> findByOrderTypeAndReturnStatusInAndCreateDateBetween(OrderType orderType, List<GoodReceivedReturnStatus> orderStatus,
    LocalDate startDate, LocalDate endDate, Sort sort);


    List<Order> findAllBySenderClinicId(String clinicId);

    List<Order> findByRequestId(String requestId);

    List<Order> findAllByIdInAndOrderType(List<String> orderIds, OrderType type);

    List<Order> findAllByOrderTypeAndReturnStatusInAndPurchaseOrderId(OrderType orderType, List<GoodReceivedReturnStatus> status, String purchaseOrderId);

    List<Order> findByOrderTypeAndOrderNoIn(OrderType ordertype, List<String> orderNos);

    List<Order> findByLastModifiedDateBetween(LocalDateTime start, LocalDateTime end);

    Page<Order> findByLastModifiedDateGreaterThan(LocalDateTime localDateTime, Pageable pageable);
}
