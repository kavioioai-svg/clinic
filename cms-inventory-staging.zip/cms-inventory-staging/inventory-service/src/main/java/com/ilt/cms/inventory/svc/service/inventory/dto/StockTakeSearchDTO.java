package com.ilt.cms.inventory.svc.service.inventory.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.List;

public class StockTakeSearchDTO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDateFrom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDateTo;
    private String itemRefId;
    private String itemCode;
    private String itemName;
    private List<String> clinicIds;
    private String stockTakeId;
    private String transactionNo;
    private String stockTakeName;

    //Used for stock take transaction#/stock take name
    private String stockTakeKeyword;

    //Used for stock take approval status
    private String approveStatus;

    //Used for stock count item approval status
    private String status;
    private Sort sort;
    private String commonRegex;


    public LocalDate getStartDateFrom() {
        return startDateFrom;
    }
    public void setStartDateFrom(LocalDate startDateFrom) {
        this.startDateFrom = startDateFrom;
    }
    public LocalDate getStartDateTo() {
        return startDateTo;
    }
    public void setStartDateTo(LocalDate startDateTo) {
        this.startDateTo = startDateTo;
    }

    public String getItemRefId() {
        return itemRefId;
    }
    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }
    public String getItemCode() {
        return itemCode;
    }
    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }
    public String getItemName() {
        return itemName;
    }
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    public List<String> getClinicIds() {
        return clinicIds;
    }
    public void setClinicIds(List<String> clinicIds) {
        this.clinicIds = clinicIds;
    }
    public String getApproveStatus() {
        return approveStatus;
    }
    public void setApproveStatus(String approveStatus) {
        this.approveStatus = approveStatus;
    }
    public String getStockTakeId() {
        return stockTakeId;
    }
    public void setStockTakeId(String stockTakeId) {
        this.stockTakeId = stockTakeId;
    }
    public String getTransactionNo() {
        return transactionNo;
    }
    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo;
    }
    public String getStockTakeName() {
        return stockTakeName;
    }
    public void setStockTakeName(String stockTakeName) {
        this.stockTakeName = stockTakeName;
    }
    public String getStockTakeKeyword() {
        return stockTakeKeyword;
    }
    public void setStockTakeKeyword(String stockTakeKeyword) {
        this.stockTakeKeyword = stockTakeKeyword;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Sort getSort() {
        return sort;
    }
    public void setSort(Sort sort) {
        this.sort = sort;
    }
    public String getCommonRegex() {
        return commonRegex;
    }
    public void setCommonRegex(String commonRegex) {
        this.commonRegex = commonRegex;
    }
}
