package com.ilt.cms.inventory.svc.model.inventory.enums;

public enum StockAlertType {
    INVENTORY_LOW, INVENTORY_HIGH, EXPIRY, INVENTORY_NON_ZERO, EXPIRY_WITHIN_3_MONTH, EXPIRY_WITHIN_6_MONTH
}
