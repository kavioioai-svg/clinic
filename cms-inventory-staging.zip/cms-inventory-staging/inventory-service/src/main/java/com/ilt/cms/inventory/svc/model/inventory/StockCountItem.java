package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.lippo.cms.util.CMSConstant;
import com.lippo.commons.util.CommonUtils;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class StockCountItem {

    public enum StockCountItemRemark {
        DRUG_DISPENSING
    }

    private String id;
    private String inventoryId;
    private String itemRefId;
    private String itemCode;
    private String itemName;
    private String curBatchNumber;
    private String curUom;
    private BigDecimal purchasePrice;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate curExpiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate curManufacturerDate;
    private double availableCount;
    private String batchNumber;
    private String oldBatchNumber;
    private String baseUom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;

    private Double firstQuantity;

    private Double adjustedQuantity;

    private String purposeOfAdjustmentCode;

    private String remark;

    private String cpRemarks;

    private StockCountItemStatus status;


    private LocalDate approvedDate;

    private LocalDate rejectedDate;

    public boolean checkValidate(StockTakeStatus stockTakeStatus, Item item) {

        boolean isBaseInfoValidate;
        if (item.isTrackingCode() && (item.getItemType() == Item.ItemType.CONSUMABLE
                || item.getItemType() == Item.ItemType.DRUG
                || item.getItemType() == Item.ItemType.VACCINATION)) {
            isBaseInfoValidate = isStringValid(id, itemRefId, baseUom) &&
                    ((isStringValid(batchNumber) && expiryDate != null) || (firstQuantity == null || firstQuantity.equals(0.0)))
                    && (isStringValid(curBatchNumber) && availableCount != 0.0 ? batchNumber.equals(curBatchNumber) : true);
        } else {
            isBaseInfoValidate = isStringValid(id, itemRefId, baseUom) && !isStringValid(batchNumber) && expiryDate == null
                    && (availableCount != 0.0 ? !isStringValid(curBatchNumber) : true);
        }

        boolean isQuantityValidate = ((stockTakeStatus == StockTakeStatus.IN_PROCESS_FIRST_STOCK_TAKE) ||
                (stockTakeStatus == StockTakeStatus.IN_PROCESS_SECOND_STOCK_TAKE && Objects.nonNull(firstQuantity)) ||
                (stockTakeStatus == StockTakeStatus.COMPLETED
                        && Objects.nonNull(firstQuantity)
                        && Objects.nonNull(adjustedQuantity)
                        && (!CommonUtils.isStringValid(purposeOfAdjustmentCode)
                        && availableCount != adjustedQuantity ? false : true)));

        return isBaseInfoValidate && isQuantityValidate;

    }

    public StockCountItem() {
        if(this.id == null) {
            this.id = CommonUtils.idGenerator();
        }
    }

    public StockCountItem(String inventoryId, String itemCode, String itemName, String itemRefId,
                          String curBatchNumber, String curUom, LocalDate curExpiryDate, LocalDate curManufacturerDate, int availableCount) {
        this.id = CommonUtils.idGenerator();
        this.inventoryId = inventoryId;
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.itemRefId = itemRefId;
        this.curBatchNumber = curBatchNumber;
        this.curUom = curUom;
        this.curExpiryDate = curExpiryDate;
        this.curManufacturerDate = curManufacturerDate;
        this.batchNumber = curBatchNumber;
        this.baseUom = curUom;
        this.expiryDate = curExpiryDate;
        this.manufacturerDate = curManufacturerDate;
        this.availableCount = availableCount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCurBatchNumber() {
        return curBatchNumber;
    }

    public void setCurBatchNumber(String curBatchNumber) {
        this.curBatchNumber = curBatchNumber;
    }

    public String getCurUom() {
        return curUom;
    }

    public void setCurUom(String curUom) {
        this.curUom = curUom;
    }

    public LocalDate getCurExpiryDate() {
        return curExpiryDate;
    }

    public void setCurExpiryDate(LocalDate curExpiryDate) {
        this.curExpiryDate = curExpiryDate;
    }

    public double getAvailableCount() {
        return availableCount;
    }

    public void setAvailableCount(double availableCount) {
        this.availableCount = availableCount;
    }

    public Double getFirstQuantity() {
        return firstQuantity;
    }

    public void setFirstQuantity(Double firstQuantity) {
        this.firstQuantity = firstQuantity;
    }

    public Double getAdjustedQuantity() {
        return adjustedQuantity;
    }

    public void setAdjustedQuantity(Double adjustedQuantity) {
        this.adjustedQuantity = adjustedQuantity;
    }

    public String getPurposeOfAdjustmentCode() {
        return purposeOfAdjustmentCode;
    }

    public void setPurposeOfAdjustmentCode(String purposeOfAdjustmentCode) {
        this.purposeOfAdjustmentCode = purposeOfAdjustmentCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getOldBatchNumber() {
        return oldBatchNumber;
    }

    public void setOldBatchNumber(String oldBatchNumber) {
        this.oldBatchNumber = oldBatchNumber;
    }

    public String getBaseUom() {
        return baseUom;
    }

    public void setBaseUom(String baseUom) {
        this.baseUom = baseUom;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public LocalDate getCurManufacturerDate() {
        return curManufacturerDate;
    }

    public void setCurManufacturerDate(LocalDate curManufacturerDate) {
        this.curManufacturerDate = curManufacturerDate;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public String getCpRemarks() {
        return cpRemarks;
    }

    public void setCpRemarks(String cpRemarks) {
        this.cpRemarks = cpRemarks;
    }

    public StockCountItemStatus getStatus() {
        return status;
    }

    public void setStatus(StockCountItemStatus status) {
        this.status = status;
    }

    public LocalDate getApprovedDate() {
        return approvedDate;
    }
    public void setApprovedDate(LocalDate approvedDate) {
        this.approvedDate = approvedDate;
    }
    public LocalDate getRejectedDate() {
        return rejectedDate;
    }
    public void setRejectedDate(LocalDate rejectedDate) {
        this.rejectedDate = rejectedDate;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }
    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "StockCountItem{" +
                "id='" + id + '\'' +
                ", inventoryId='" + inventoryId + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", itemCode='" + itemCode + '\'' +
                ", itemName='" + itemName + '\'' +
                ", curBatchNumber='" + curBatchNumber + '\'' +
                ", curUom='" + curUom + '\'' +
                ", curExpiryDate=" + curExpiryDate +
                ", curManufacturerDate=" + curManufacturerDate +
                ", availableCount=" + availableCount +
                ", batchNumber='" + batchNumber + '\'' +
                ", baseUom='" + baseUom + '\'' +
                ", expiryDate=" + expiryDate +
                ", manufacturerDate=" + manufacturerDate +
                ", firstQuantity=" + firstQuantity +
                ", adjustedQuantity=" + adjustedQuantity +
                ", purposeOfAdjustmentCode='" + purposeOfAdjustmentCode + '\'' +
                ", remark='" + remark + '\'' +
                ", cpRemarks='" + cpRemarks + '\'' +
                ", status=" + status +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StockCountItem that = (StockCountItem) o;
        return Double.compare(that.availableCount, availableCount) == 0 &&
                Objects.equals(id, that.id) &&
                Objects.equals(inventoryId, that.inventoryId) &&
                Objects.equals(itemRefId, that.itemRefId) &&
                Objects.equals(itemCode, that.itemCode) &&
                Objects.equals(itemName, that.itemName) &&
                Objects.equals(curBatchNumber, that.curBatchNumber) &&
                Objects.equals(curUom, that.curUom) &&
                Objects.equals(curExpiryDate, that.curExpiryDate) &&
                Objects.equals(curManufacturerDate, that.curManufacturerDate) &&
                Objects.equals(batchNumber, that.batchNumber) &&
                Objects.equals(baseUom, that.baseUom) &&
                Objects.equals(expiryDate, that.expiryDate) &&
                Objects.equals(manufacturerDate, that.manufacturerDate) &&
                Objects.equals(firstQuantity, that.firstQuantity) &&
                Objects.equals(adjustedQuantity, that.adjustedQuantity) &&
                Objects.equals(purposeOfAdjustmentCode, that.purposeOfAdjustmentCode) &&
                Objects.equals(remark, that.remark);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, inventoryId, itemRefId, itemCode, itemName, curBatchNumber, curUom, curExpiryDate,
                curManufacturerDate, availableCount, batchNumber, baseUom, expiryDate, manufacturerDate, firstQuantity, adjustedQuantity, purposeOfAdjustmentCode, remark);
    }
}
