package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.item.Item;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class DeliveryItem {

    protected String lineNo;
    protected String itemRefId;
    protected String uom;
    protected String batchNumber;
    protected int quantity;

    @Field(targetType = FieldType.DECIMAL128)
    protected BigDecimal purchasePrice;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    protected LocalDate receiptDate;
    protected String invoiceNo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    protected LocalDate expiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    protected LocalDate manufacturerDate;
    private String comment;

    public boolean checkValidate(Item item) {
        if (Objects.nonNull(item) && item.getId().equals(itemRefId) &&
                (item.isTrackingCode() && (item.getItemType() == Item.ItemType.CONSUMABLE
                        || item.getItemType() == Item.ItemType.DRUG
                        || item.getItemType() == Item.ItemType.VACCINATION))
        ) {
            return isStringValid(lineNo, itemRefId, uom, batchNumber) && expiryDate != null && quantity > 0;
        } else {
            return isStringValid(lineNo, itemRefId, uom) && !isStringValid(batchNumber) && expiryDate == null && quantity > 0;
        }
    }


    public DeliveryItem() {
    }

    public DeliveryItem(String lineNo, String itemRefId, String uom, String batchNumber, int quantity, LocalDate receiptDate,
                        String invoiceNo, LocalDate expiryDate, LocalDate manufacturerDate, String comment, BigDecimal purchasePrice) {
        this.lineNo = lineNo;
        this.itemRefId = itemRefId;
        this.uom = uom;
        this.batchNumber = batchNumber;
        this.quantity = quantity;
        this.receiptDate = receiptDate;
        this.invoiceNo = invoiceNo;
        this.expiryDate = expiryDate;
        this.manufacturerDate = manufacturerDate;
        this.comment = comment;
        this.purchasePrice = purchasePrice;
    }

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public String toString() {
        return "DeliveryItem{" +
                ", lineNo='" + lineNo + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", uom='" + uom + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                ", quantity=" + quantity +
                ", receiptDate=" + receiptDate +
                ", invoiceNo='" + invoiceNo + '\'' +
                ", expiryDate=" + expiryDate +
                ", manufacturerDate=" + manufacturerDate +
                ", comment='" + comment + '\'' +
                '}';
    }
}
