package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.file.FileMetaData;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.lippo.cms.util.CMSConstant;
import com.lippo.commons.util.CommonUtils;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class GoodReceivedNote {

    @Indexed
    private String id;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate grnDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    private String delivererId;

    private String receiverId;

    private String grnNo;

    private List<DeliveryItem> receivedItems;

    private List<DeliveryItem> previousReceivedItems;

    private String additionalRemark;

    private DeliveryNoteStatus status;

    private List<FileMetaData> fileMetaData = new ArrayList<>();

    private NavIntegrationResult navIntegrationResult;

    private String userId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate dnDate;

    private String dnNo;
    @Transient
    private String prNo;

    @Transient
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate prDate;

    public boolean checkValidate() {

        return isStringValid(delivererId, dnNo) && receivedItems != null && dnDate != null && receivedItems.size() > 0 && status != null;
    }

    public void copy(GoodReceivedNote goodReceivedNote) {

        this.grnDate = goodReceivedNote.grnDate;
        this.dnDate = goodReceivedNote.dnDate;
        this.dnNo = goodReceivedNote.dnNo;
        this.receivedItems = goodReceivedNote.receivedItems;
        this.additionalRemark = goodReceivedNote.additionalRemark;
        this.status = goodReceivedNote.status;
        this.userId = goodReceivedNote.userId;
    }

    public GoodReceivedNote() {

        this.receivedItems = new ArrayList<>();
        this.status = DeliveryNoteStatus.DRAFT;
    }

    public GoodReceivedNote(LocalDate createDate, LocalDate grnDate, String delivererId, String receiverId, String grnNo, LocalDate dnDate, String dnNo, String additionalRemark, DeliveryNoteStatus status) {

        this.id = CommonUtils.idGenerator();
        this.createDate = createDate;
        this.grnDate = grnDate;
        this.delivererId = delivererId;
        this.receiverId = receiverId;
        this.dnDate = dnDate;
        this.dnNo = dnNo;
        this.grnNo = grnNo;
        this.additionalRemark = additionalRemark;
        this.receivedItems = new ArrayList<>();
        this.status = status;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public LocalDate getGrnDate() {
        return grnDate;
    }

    public void setGrnDate(LocalDate grnDate) {
        this.grnDate = grnDate;
    }

    public String getDelivererId() {
        return delivererId;
    }

    public void setDelivererId(String delivererId) {
        this.delivererId = delivererId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getGrnNo() {
        return grnNo;
    }

    public void setGrnNo(String grnNo) {
        this.grnNo = grnNo;
    }

    public List<DeliveryItem> getReceivedItems() {
        return receivedItems;
    }

    public void setReceivedItems(List<DeliveryItem> receivedItems) {
        this.receivedItems = receivedItems;
    }

    public List<DeliveryItem> getPreviousReceivedItems() {
        return previousReceivedItems;
    }

    public void setPreviousReceivedItems(List<DeliveryItem> previousReceivedItems) {
        this.previousReceivedItems = previousReceivedItems;
    }

    public String getAdditionalRemark() {
        return additionalRemark;
    }

    public void setAdditionalRemark(String additionalRemark) {
        this.additionalRemark = additionalRemark;
    }

    public DeliveryNoteStatus getStatus() {
        return status;
    }

    public void setStatus(DeliveryNoteStatus status) {
        this.status = status;
    }

    public LocalDate getDnDate() {
        return dnDate;
    }

    public void setDnDate(LocalDate dnDate) {
        this.dnDate = dnDate;
    }

    public String getDnNo() {
        return dnNo;
    }

    public void setDnNo(String dnNo) {
        this.dnNo = dnNo;
    }

    public List<FileMetaData> getFileMetaData() {
        return fileMetaData;
    }

    public void setFileMetaData(List<FileMetaData> fileMetaData) {
        this.fileMetaData = fileMetaData;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPrNo() {
        return prNo;
    }

    public void setPrNo(String prNo) {
        this.prNo = prNo;
    }

    public LocalDate getPrDate() {
        return prDate;
    }

    public void setPrDate(LocalDate prDate) {
        this.prDate = prDate;
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    @Override
    public String toString() {
        return "GoodReceivedNote{" +
                "id='" + id + '\'' +
                ", grnDate=" + grnDate +
                ", createDate=" + createDate +
                ", delivererId='" + delivererId + '\'' +
                ", receiverId='" + receiverId + '\'' +
                ", grnNo='" + grnNo + '\'' +
                ", receivedItems=" + receivedItems +
                ", additionalRemark='" + additionalRemark + '\'' +
                ", status=" + status +
                ", fileMetaData=" + fileMetaData +
                ", userId='" + userId + '\'' +
                ", dnDate=" + dnDate +
                ", dnNo='" + dnNo + '\'' +
                ", prNo='" + prNo + '\'' +
                ", prDate=" + prDate +
                '}';
    }


}
