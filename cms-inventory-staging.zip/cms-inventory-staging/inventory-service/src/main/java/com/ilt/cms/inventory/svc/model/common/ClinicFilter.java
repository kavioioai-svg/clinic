package com.ilt.cms.inventory.svc.model.common;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClinicFilter {
    private Set<String> clinics;

    private String clinicGroupName;

    public ClinicFilter() {
        this.clinics = new HashSet<>();
    }

    public ClinicFilter(Set<String> clinics, String clinicGroupName) {
        this.clinics = clinics;
        this.clinicGroupName = clinicGroupName;
    }

    public Set<String> getClinics() {
        return clinics;
    }

    public void setClinics(Set<String> clinics) {
        this.clinics = clinics;
    }

    public String getClinicGroupName() {
        return clinicGroupName;
    }

    public void setClinicGroupName(String clinicGroupName) {
        this.clinicGroupName = clinicGroupName;
    }

    @Override
    public String toString() {
        return "ClinicFilter{" +
                "clinics=" + clinics +
                ", clinicGroupName='" + clinicGroupName + '\'' +
                '}';
    }
}
