package com.ilt.cms.inventory.svc.mapper;

import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import com.ilt.cms.inventory.svc.model.inventory.api.DisposeItemEntity;

import java.util.Map;

public class DisposeItemMapper {

    public static DisposeItemEntity mapToDisposeItemEntity(DisposeItem disposeItem, Item item) {
        return new DisposeItemEntity(disposeItem.getClinicId(), disposeItem.getItemId(), item.getName(), item.getCode(), disposeItem.getBatchNo(),
                disposeItem.getRemark(), disposeItem.getDisposeStatus(), disposeItem.getQuantity(),
                disposeItem.getCpRemark(), disposeItem.getManufacturerDate(), disposeItem.getDisposalRequestDate(),
                disposeItem.getDisposedDate(), disposeItem.getExpiryDate());
    }
}
