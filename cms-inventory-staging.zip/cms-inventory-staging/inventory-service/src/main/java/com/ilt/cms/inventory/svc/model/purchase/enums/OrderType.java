package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum OrderType {
    PURCHASE, TRANSFER, RETURN
}
