package com.ilt.cms.inventory.svc.model.nav;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.deser.std.DateDeserializers;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.casem.FailedNavSync;
import com.ilt.cms.inventory.svc.model.nav.NavQueueRecordStatus;
import com.lippo.cms.util.CMSConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Transient;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class NavQueue extends PersistedObject {
    private String serviceName;
    private String param1;
    private String param2;
    private NavQueueRecordStatus recordStatus;
    private String navResponse;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_ALT_DATE_FORMAT_WITH_MINUTES)
    @DateTimeFormat(pattern = CMSConstant.JSON_ALT_DATE_FORMAT_WITH_MINUTES)
    private LocalDateTime sentOn;

    @Transient
    private String sentOnStr;

    private String referenceNo;
    private String requestPayload;
    private String responsePayload;

    public enum ServiceName {
        GOOD_RECEIVED_NOTE,
        PURCHASE_RETURN_ORDER,
        TRANSFER_SHIPMENT,
        PURCHASE_RETURN_DELIVERY_ORDER,
        TRANSFER_RECEIPT,
        STOCK_TAKE,
        STOCK_ADJUSTMENT,
        SALES_ORDER_SAVE,
        SALES_ORDER_UPDATE,
        SALES_ORDER_CORRECTION,
        SALES_ORDER_REFUND,
        CLAIMS,
        PURCHASE_REQUEST_SAVE
    }

    public NavQueue(String serviceName, String param1) {
        this.serviceName = serviceName;
        this.param1 = param1;
    }

    public NavQueue(String serviceName, String param1, String param2) {
        this.serviceName = serviceName;
        this.param1 = param1;
        this.param2 = param2;
    }

}
