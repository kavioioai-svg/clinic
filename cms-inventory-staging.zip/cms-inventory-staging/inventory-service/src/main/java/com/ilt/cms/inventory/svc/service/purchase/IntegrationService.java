package com.ilt.cms.inventory.svc.service.purchase;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedVoidNote;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.OrderRequestFilter;
import com.ilt.cms.inventory.svc.model.purchase.api.ReturnOrder;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.common.OrderResult;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestType;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.gst.service.GstUtilsService;
import com.lippo.cms.util.CMSConstant;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.lippo.commons.util.CommonUtils.isStringValid;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

@Service
public class IntegrationService {

    private static final Logger logger = LoggerFactory.getLogger(IntegrationService.class);
    private static List<String> statusSortOrder = Arrays.asList("DRAFT", "FAILED", "INITIAL", "PARTIAL_RECEIVED", "REQUESTED",
            "APPROVED", "PARTIAL_APPROVED", "REJECTED", "FULL_RECEIVED", "TRANSFER", "DELETED");

    private final OrderService orderService;
    private final ClinicRepository clinicRepository;
    private final RequestService requestService;
    private final MongoTemplate mongoTemplate;
    private final GstUtilsService gstUtilsService;

    public IntegrationService(OrderService orderService, ClinicRepository clinicRepository, RequestService requestService,
                              MongoTemplate mongoTemplate, GstUtilsService gstUtilsService) {

        this.orderService = orderService;
        this.clinicRepository = clinicRepository;
        this.requestService = requestService;
        this.mongoTemplate = mongoTemplate;
        this.gstUtilsService = gstUtilsService;
    }

    public Map<String, Object> listOrderRequests(String clinicId, Map<OrderRequest.Filter, String> filterMap, int page, int size) throws CMSException {

        logger.info("List orderRequests clinicId[" + clinicId + "], filerMap[" + filterMap + "], page[" + page + "], size[" + size + "]");
        List<OrderRequest> list = new ArrayList<>();

        String type = filterMap.get(OrderRequest.Filter.TRANSFER_PURCHASE_TYPE);
        if (type == null) {
            type = "NOT DEFINE";
        }
        List<Clinic> clinics = clinicRepository.findAll().stream()
                .filter(clinic -> clinic.getName() != null)
                .collect(Collectors.toList());

        logger.debug("clinics[" + clinics.size() + "]");
        Map<String, String> clinicMap = clinics.stream()
                .collect(Collectors.toMap(Clinic::getId, Clinic::getName));

        List<OrderRequest> toPickORs = new ArrayList<>();
        List<OrderRequest> toSendORs = new ArrayList<>();
        List<OrderRequest> purchaseOrderORs = new ArrayList<>();
        List<OrderRequest> requestNormalORs = new ArrayList<>();
        List<OrderRequest> requestSpecialORs = new ArrayList<>();
        //if (clinicId != null) {
        switch (type) {
            case "TO_PICK":
                toPickORs = mapToPickToOrderRequest(clinicId, clinicMap);
                break;
            case "TO_SENT":
                toSendORs = mapToSentToOrderRequest(clinicId, clinicMap);
                break;
            case "TO":
                toPickORs = mapToPickToOrderRequest(clinicId, clinicMap);
                toSendORs = mapToSentToOrderRequest(clinicId, clinicMap);
                break;
            case "PURCHASE_ORDER":
                purchaseOrderORs = mapToPurchaseOrderToOrderRequest(clinicId, clinicMap);
                break;
            case "PO_TO":
                purchaseOrderORs = mapToPurchaseOrderToOrderRequest(clinicId, clinicMap);
                toPickORs = mapToPickToOrderRequest(clinicId, clinicMap);
                toSendORs = mapToSentToOrderRequest(clinicId, clinicMap);
                break;
            case "REQUEST_NORMAL":
                requestNormalORs = mapRequestNormalToOrderRequest(clinicId, clinicMap);
                break;
            case "REQUEST_SPECIAL":
                requestSpecialORs = mapRequestSpecialToOrderRequest(clinicId, clinicMap);
                break;
            default:
                toPickORs = mapToPickToOrderRequest(clinicId, clinicMap);
                toSendORs = mapToSentToOrderRequest(clinicId, clinicMap);
                purchaseOrderORs = mapToPurchaseOrderToOrderRequest(clinicId, clinicMap);
                requestNormalORs = mapRequestNormalToOrderRequest(clinicId, clinicMap);
                requestSpecialORs = mapRequestSpecialToOrderRequest(clinicId, clinicMap);
        }
        //}
        list.addAll(toPickORs);
        list.addAll(toSendORs);
        list.addAll(requestNormalORs);
        list.addAll(requestSpecialORs);
        list.addAll(purchaseOrderORs);

        Set<String> sortOrderMissedStatusList = list.stream()
                .map(OrderRequest::getStatus)
                .filter(status -> !statusSortOrder.contains(status))
                .collect(Collectors.toSet());
        statusSortOrder.addAll(sortOrderMissedStatusList);

        List<OrderRequest> orderRequests = list.stream()
                .filter(orderRequest -> isMatch(orderRequest, filterMap))
                .filter(orderRequest -> !(!orderRequest.getDataType().equals(OrderRequest.DataType.PR) &&
                        orderRequest.getStatus().equals(OrderStatus.DRAFT.name())))
                .collect(Collectors.toList());

        logger.info("Return [" + orderRequests.size() + "] records");

        return mapToPageData(orderRequests, page, size);
    }

    public Map<String, Object> listOrderRequests(OrderRequestFilter orderRequestFilter, int page, int size) throws CMSException {
        OrderRequestFilter.TransferPurchaseType type = orderRequestFilter.getTransferPurchaseType();
        LocalDate createDateMore = orderRequestFilter.getCreateDateMore();
        LocalDate createDateLess = orderRequestFilter.getCreateDateLess();
        String requestClinicId = orderRequestFilter.getRequestClinicId();
        String orderNo = orderRequestFilter.getOrderNo();
        List<String> prNos = orderRequestFilter.getPrNos();
        OrderStatus status = orderRequestFilter.getOrderStatus();
        String vendorId = orderRequestFilter.getVendorId();
        String itemRefId = orderRequestFilter.getItemRefId();

        Pageable pageable = PageRequest.of(page, size, Sort.by("orderDate").descending());

        Criteria criteria = new Criteria();

        if (createDateMore != null && createDateLess != null) {
            criteria.and("orderDate").gte(createDateMore).lte(createDateLess);
        } else if (createDateMore != null) {
            criteria.and("orderDate").gte(createDateMore);
        } else {
            criteria.and("orderDate").lte(createDateLess);
        }

        if (status != null) {
            criteria.and("orderStatus").is(status);
        } else {
            criteria.and("orderStatus").ne(OrderStatus.DELETED);
        }

        if (type != null) {
            if (type.equals(OrderRequestFilter.TransferPurchaseType.PURCHASE_ORDER)) {
                criteria.and("orderType").is(OrderType.PURCHASE);
            } else {
                criteria.and("orderType").is(OrderType.TRANSFER);
            }
        } else {
            criteria.orOperator(Criteria.where("orderType").is(OrderType.PURCHASE),
                    Criteria.where("orderType").is(OrderType.TRANSFER));
        }

        if (Objects.nonNull(orderNo)) {
            criteria.and("orderNo").is(orderNo);
        }

        if (Objects.nonNull(requestClinicId)) {
            criteria.and("requestClinicId").is(requestClinicId);
        }

        if (Objects.nonNull(prNos) && prNos.size() > 0) {
            criteria.and("goodPurchasedItems.purchaseRequestNo").in(prNos);
        }

        if (Objects.nonNull(vendorId)) {
            criteria.and("supplierId").is(vendorId);
        }

        Criteria itemCriteria = new Criteria();

        if(itemRefId != null) {
            itemCriteria.orOperator(Criteria.where("goodPurchasedItems.itemRefId").is(itemRefId),
                    Criteria.where("transferRequestItems.itemRefId").is(itemRefId));
        }


        MatchOperation matchOperation = Aggregation.match(criteria);
        MatchOperation ItemMatchOperation = Aggregation.match(itemCriteria);
        ProjectionOperation projectionOperation = Aggregation.project(
                "id",
                "requestId",
                "requestDate",
                "requestNo",
                "requestClinicId",
                "orderType",
                "orderNo",
                "createDate",
                "orderDate",
                "completeDate",
                "goodReceivedNotes",
                "orderStatus",
                "returnStatus",
                "supplierId",
                "interCompanyTransferOrderNo",
                "clinicFilter",
                "goodPurchasedItems",
                "transferRequestItems",
                "returnItems",
                "senderClinicId",
                "deliveryNotes",
                "remark",
                "cPTransfer",
                "blanketPO",
                "interComp",
                "navIntegrationResult",
                "purchaseOrderId",
                "discountType",
                "discountAmount",
                "gstAmount",
                "gstPercentage",
                "gstEnabled"
        ).and("requestClinic.name").as("requestClinicName");
        AddFieldsOperation addClinicObjId = new AddFieldsOperation("requestClinicIdObj", new Document("$toObjectId", "$requestClinicId"));
        LookupOperation clinicLookupOperation = Aggregation.lookup("clinic", "requestClinicIdObj", "_id", "requestClinic");
        UnwindOperation clinicUnWindOperation = Aggregation.unwind("requestClinic");
        SkipOperation skipOperation = new SkipOperation((long) pageable.getPageNumber() * pageable.getPageSize());
        LimitOperation limitOperation = new LimitOperation(pageable.getPageSize());
        SortOperation sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, "createdDate"));

        TypedAggregation<Order> typedAggregation = newAggregation(
                Order.class,
                matchOperation,
                ItemMatchOperation,
                addClinicObjId,
                clinicLookupOperation,
                clinicUnWindOperation,
                sortOperation,
                skipOperation,
                limitOperation,
                projectionOperation);

        AggregationResults<OrderResult> orderResults = mongoTemplate.aggregate(
                typedAggregation,
                "order",
                OrderResult.class);

        TypedAggregation<Order> totalCountAggregation = newAggregation(
                Order.class,
                matchOperation,
                ItemMatchOperation,
                group()
                        .addToSet(Aggregation.ROOT).as("documents")
                        .count().as("count"));

        AggregationResults<IntegrationService.NumberOfResults> totalCount = mongoTemplate.aggregate(
                totalCountAggregation,
                "order",
                IntegrationService.NumberOfResults.class);

        List<IntegrationService.NumberOfResults> totalCountMappedResults = totalCount.getMappedResults();
        int total = !totalCountMappedResults.isEmpty() ? totalCountMappedResults.get(0).getCount() : 0;

        List<OrderRequest> orderRequests = orderResults.getMappedResults().stream()
                .filter(orderResult -> !orderResult.isInterComp())
                .map(orderResult -> {
                    int sum = orderResult.getGoodPurchasedItems().stream()
                            .filter(goodPurchasedItem -> goodPurchasedItem.getUnitPrice() != null)
                            .mapToInt(goodPurchasedItem -> goodPurchasedItem.getUnitPrice().getPrice() * goodPurchasedItem.getQuantity())
                            .sum();
                    if (orderResult.getDiscountType() == Order.DiscountType.PERCENTAGE) {
                        orderResult.setCalculatedDiscount(sum * orderResult.getDiscountAmount().intValue() / 100);
                    } else if (orderResult.getDiscountType() == Order.DiscountType.DOLLAR) {
                        orderResult.setCalculatedDiscount(orderResult.getDiscountAmount().multiply(BigDecimal.valueOf(100)).intValue());
                    } else {
                        orderResult.setCalculatedDiscount(0);
                    }
                    double gst = orderResult.getGstPercentage().doubleValue();
                    sum = sum - orderResult.getCalculatedDiscount();
                    orderResult.setTotalPrice((int) (sum + (sum * gst / 100)));
                    return orderResult;
                })
                .map(orderResult -> new OrderRequest(orderResult.getRequestClinicName(),
                        orderResult.getOrderNo(), orderResult.getCreateDate(),
                        orderResult.getOrderType() == OrderType.PURCHASE ? OrderRequest.DataType.PO : OrderRequest.DataType.TO,
                        orderResult.getOrderType() == OrderType.PURCHASE ? OrderRequest.FilterType.PURCHASE_ORDER : OrderRequest.FilterType.TRANSFER_ORDER, //ToDo - Check filter the usege in FE
                        orderResult.getOrderStatus().name(), orderResult))
                .collect(Collectors.toList());

//        orderRequests = orderRequests.stream()
//                .sorted(Comparator.comparing((OrderRequest orderRequest) -> statusSortOrder.indexOf(orderRequest.getStatus()))
//                        .thenComparing(OrderRequest::getCreateDate, Comparator.nullsFirst(Comparator.reverseOrder())))
//                .collect(Collectors.toList());

        logger.info("Return [" + orderRequests.size() + "] records");

        Map<String, Object> dataMap = new HashMap<>();

        int lastPageSize = total % size;
        int totalPage = total / size + (lastPageSize == 0 ? 0 : 1);

        dataMap.put(CMSConstant.PAYLOAD_KEY_CONTENT, orderRequests);
        dataMap.put(CMSConstant.PAYLOAD_KEY_PAGE_NUMBER, page);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_PAGES, totalPage);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_ELEMENTS, total);

        return dataMap;
    }

    public Map<String, Object> listReturnOrder(String clinicId, SearchPurchaseReturnOrderContainer searchPurchaseReturnOrderContainer, int page, int size) throws CMSException {

        logger.info("ListReturnOrder [" + searchPurchaseReturnOrderContainer + "]");
        List<Order> returnOrders = orderService.listOrderByReturnOrderDateAndFilter(
                clinicId, searchPurchaseReturnOrderContainer.getStartDate(),
                searchPurchaseReturnOrderContainer.getEndDate(), searchPurchaseReturnOrderContainer.getRequestStatus(),
                searchPurchaseReturnOrderContainer.getNumber());

        List<String> orderIds = returnOrders.stream()
                .map(Order::getPurchaseOrderId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());

        Map<String, Order> purchaseOrderIdMap = orderService.findPurchaseOrderByIds(orderIds).stream()
                .collect(Collectors.toMap(Order::getId, o -> o));

        List<ReturnOrder> returnOrderContainers = returnOrders.stream()
                .map(order -> mapToReturnOrder(order,
                        Objects.nonNull(order.getPurchaseOrderId()) ? purchaseOrderIdMap.get(order.getPurchaseOrderId()) : null))
                .collect(Collectors.toList());

        return mapToPageData(returnOrderContainers, page, size);
    }

    public Map<String, Object> listReturnOrders(SearchPurchaseReturnOrderContainer search, int page, int size) throws CMSException {

        logger.info("ListReturnOrder [" + search + "]");
        List<Order> returnOrders = orderService.listReturnOrders(search, page, size);

        List<String> orderIds = returnOrders.stream()
                .map(Order::getPurchaseOrderId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());

        Map<String, Order> purchaseOrderIdMap = orderService.findPurchaseOrderByIds(orderIds).stream()
                .collect(Collectors.toMap(Order::getId, o -> o));

        List<ReturnOrder> returnOrderContainers = returnOrders.stream()
                .map(order -> mapToReturnOrder(order,
                        Objects.nonNull(order.getPurchaseOrderId()) ? purchaseOrderIdMap.get(order.getPurchaseOrderId()) : null))
                .collect(Collectors.toList());

        return mapToPageData(returnOrderContainers, page, size);
    }

    private ReturnOrder mapToReturnOrder(Order returnOrder, Order purchaseOrder) {

        String purchaseOrderId = null;
        String purchaseOrderNo = null;
        if (Objects.nonNull(purchaseOrder)) {
            purchaseOrderId = purchaseOrder.getId();
            purchaseOrderNo = purchaseOrder.getOrderNo();
        }
        ReturnOrder returnOrderContainer = new ReturnOrder(returnOrder.getId(), purchaseOrderId, purchaseOrderNo,
                returnOrder.getOrderNo(), returnOrder.getCreateDate(), returnOrder.getReturnStatus().name(), returnOrder);
        return returnOrderContainer;
    }

    private List<ReturnOrder> mapToReturnOrderList(String purchaseOrderId, Map<String, GoodReceivedVoidNote> goodReceivedVoidNoteMap, Order order) {

        List<ReturnOrder> orders = new ArrayList<>();
        goodReceivedVoidNoteMap.entrySet().forEach(e -> {
            String grvnNo = e.getKey();
            GoodReceivedVoidNote goodReceivedVoidNote = e.getValue();

            ReturnOrder returnOrder = new ReturnOrder(purchaseOrderId, goodReceivedVoidNote.getId(), order.getOrderNo(), grvnNo, goodReceivedVoidNote.getCreateDate(), goodReceivedVoidNote.getStatus().name(), goodReceivedVoidNote);
            orders.add(returnOrder);
        });
        return orders;
    }

    private boolean isMatch(OrderRequest orderRequest, Map<OrderRequest.Filter, String> filterMap) {

        List<Boolean> isMatchs = new ArrayList<>();
        filterMap.entrySet().stream().forEach(map -> {
            switch (map.getKey()) {
                case STATUS:
                    isMatchs.add(map.getValue().equals(orderRequest.getStatus()));
                    break;
                case ORDER_REQUEST_NO:
                    isMatchs.add(map.getValue().equals(orderRequest.getOrderRequestNo()));
                    break;
                case CREATED_DATE_LESS:
                    if (orderRequest.getCreateDate() == null) {
                        isMatchs.add(true);
                        break;
                    }
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CMSConstant.JSON_DATE_FORMAT);
                    LocalDate date = LocalDate.parse(map.getValue(), formatter);
                    if (orderRequest.getFilterType() == OrderRequest.FilterType.PURCHASE_REQUEST_NORMAL ||
                            orderRequest.getFilterType() == OrderRequest.FilterType.PURCHASE_REQUEST_SPECIAL) {
                        PurchaseRequest purchaseRequest = (PurchaseRequest) orderRequest.getData();
                        if (Objects.nonNull(purchaseRequest.getRequestDate())) {
                            isMatchs.add(purchaseRequest.getRequestDate().isBefore(date) || purchaseRequest.getRequestDate().isEqual(date));
                        } else {
                            isMatchs.add(orderRequest.getCreateDate().isBefore(date) || orderRequest.getCreateDate().isEqual(date));
                        }
                    } else {
                        isMatchs.add(orderRequest.getCreateDate().isBefore(date) || orderRequest.getCreateDate().isEqual(date));
                    }
                    break;
                case CREATED_DATE_MORE:
                    if (orderRequest.getCreateDate() == null) {
                        isMatchs.add(true);
                        break;
                    }
                    formatter = DateTimeFormatter.ofPattern(CMSConstant.JSON_DATE_FORMAT);
                    date = LocalDate.parse(map.getValue(), formatter);
                    if (orderRequest.getFilterType() == OrderRequest.FilterType.PURCHASE_REQUEST_NORMAL ||
                            orderRequest.getFilterType() == OrderRequest.FilterType.PURCHASE_REQUEST_SPECIAL) {
                        PurchaseRequest purchaseRequest = (PurchaseRequest) orderRequest.getData();
                        if (Objects.nonNull(purchaseRequest.getRequestDate())) {
                            isMatchs.add(purchaseRequest.getRequestDate().isAfter(date) || purchaseRequest.getRequestDate().isEqual(date));
                        } else {
                            isMatchs.add(orderRequest.getCreateDate().isAfter(date) || orderRequest.getCreateDate().isEqual(date));
                        }
                    } else {
                        isMatchs.add(orderRequest.getCreateDate().isAfter(date) || orderRequest.getCreateDate().isEqual(date));
                    }
                    break;
            }
        });
        return isMatchs.stream().allMatch(b -> b);
    }

    private OrderRequest mapOrderRequest(Map<String, String> clinicNameMap, Order order, OrderRequest.DataType dataType, OrderRequest.FilterType filterType) {

        OrderRequest orderRequest = new OrderRequest(clinicNameMap.get(order.getRequestClinicId()), order.getOrderNo(),
                order.getCreateDate() != null ? order.getCreateDate() : order.getCreatedDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
            dataType, filterType,
            order.getOrderStatus().name(), order);

        return orderRequest;
    }

    private OrderRequest mapOrderRequest(Map<String, String> clinicNameMap, PurchaseRequest request, OrderRequest.DataType dataType, OrderRequest.FilterType filterType) {

        OrderRequest orderRequest = new OrderRequest(clinicNameMap.get(request.getRequestClinicId()), request.getRequestNo(),
                request.getCreateDate() != null ? request.getCreateDate() : request.getCreatedDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
                dataType, filterType,
                request.getRequestStatus().name(), request);
        return orderRequest;
    }

    private List<OrderRequest> mapToPickToOrderRequest(String clinicId, Map<String, String> clinicMap) throws CMSException {
        List<Order> orders;
        if (clinicId != null) {
            orders = orderService.listOrderByClinicIdOrClinicGroupName(clinicId).stream()
                    .filter(order -> order.getOrderType() == OrderType.TRANSFER)
                    .filter(order -> !order.isInterComp())
                    .collect(Collectors.toList());
        } else {
            orders = orderService.listAllTransferOrder()
                    .stream()
                    .filter(order -> !order.isInterComp())
                    .collect(Collectors.toList());
        }
        List<OrderRequest> orderRequests = orders.stream()
                .map(order -> mapOrderRequest(clinicMap, order,
                        order.getOrderType() == OrderType.PURCHASE ? OrderRequest.DataType.PO : OrderRequest.DataType.TO,
                        OrderRequest.FilterType.TO_PICK))
                .collect(Collectors.toList());
        return orderRequests;
    }

    private List<OrderRequest> mapToSentToOrderRequest(String clinicId, Map<String, String> clinicMap) {
        List<Order> orders;
        if (clinicId != null) {
            orders = orderService.listOrderBySenderClinicId(clinicId).stream()
                    .filter(order -> order.getOrderType() == OrderType.TRANSFER)
                    .collect(Collectors.toList());
        } else {
            orders = orderService.listAllTransferOrder();
        }
        List<OrderRequest> orderRequests = orders.stream()
                .map(order -> mapOrderRequest(clinicMap, order,
                        order.getOrderType() == OrderType.PURCHASE ? OrderRequest.DataType.PO : OrderRequest.DataType.TO,
                        OrderRequest.FilterType.TO_SENT))
                .collect(Collectors.toList());
        return orderRequests;
    }

    private List<OrderRequest> mapToPurchaseOrderToOrderRequest(String clinicId, Map<String, String> clinicMap) throws CMSException {
        List<Order> orders;
        if (clinicId != null) {
            orders = orderService.listOrderByClinicIdOrClinicGroupName(clinicId).stream()
                    .filter(order -> order.getOrderType() == OrderType.PURCHASE)
                    .collect(Collectors.toList());
        } else {
            orders = orderService.listAllPurchaseOrder();
        }
        List<OrderRequest> orderRequests = orders.stream()
                .map(order -> mapOrderRequest(clinicMap, order,
                        order.getOrderType() == OrderType.PURCHASE ? OrderRequest.DataType.PO : OrderRequest.DataType.TO,
                        OrderRequest.FilterType.PURCHASE_ORDER))
                .collect(Collectors.toList());
        return orderRequests;
    }

    private List<OrderRequest> mapRequestNormalToOrderRequest(String clinicId, Map<String, String> clinicMap) {

        List<PurchaseRequest> purchaseRequests;
        if (clinicId != null) {
            purchaseRequests = requestService.listPurchaseRequestByClinicId(clinicId).stream()
                    .filter(purchaseRequest -> purchaseRequest.getRequestType() == RequestType.STANDARD)
                    .collect(Collectors.toList());
            logger.debug("Found [" + purchaseRequests.size() + "] request");
        } else {
            purchaseRequests = requestService.listPurchaseRequest();
            logger.debug("Found [" + purchaseRequests.size() + "] request");
        }
        List<OrderRequest> orderRequests = purchaseRequests.stream()
                .map(purchaseRequest -> mapOrderRequest(clinicMap, purchaseRequest, OrderRequest.DataType.PR, OrderRequest.FilterType.PURCHASE_REQUEST_NORMAL))
                .collect(Collectors.toList());
        return orderRequests;
    }

    private List<OrderRequest> mapRequestSpecialToOrderRequest(String clinicId, Map<String, String> clinicMap) {

        List<PurchaseRequest> purchaseRequests;
        if (clinicId != null) {
            purchaseRequests = requestService.listPurchaseRequestByClinicId(clinicId).stream()
                    .filter(purchaseRequest -> purchaseRequest.getRequestType() == RequestType.LOOSE)
                    .collect(Collectors.toList());
            logger.debug("Found [" + purchaseRequests.size() + "] request");
        } else {
            purchaseRequests = requestService.listPurchaseRequest();
            logger.debug("Found [" + purchaseRequests.size() + "] request");
        }
        List<OrderRequest> orderRequests = purchaseRequests.stream()
                .map(purchaseRequest -> mapOrderRequest(clinicMap, purchaseRequest, OrderRequest.DataType.PR, OrderRequest.FilterType.PURCHASE_REQUEST_SPECIAL))
                .collect(Collectors.toList());
        return orderRequests;
    }

    private Map<String, Object> mapToPageData(List<? extends Object> dataList, int page, int size) {
        Map<String, Object> dataMap = new HashMap<>();

        int listSize = dataList.size();
        int startIndex;
        int endIndex;
        int lastPageSize = listSize % size;
        int totalPage = listSize / size + (lastPageSize == 0 ? 0 : 1);
        startIndex = page * size;
        endIndex = (startIndex + size) >= listSize ? listSize : startIndex + size;
        List<? extends Object> returnObjects;
        if (startIndex >= listSize) {
            logger.warn("return empty content due to startIndex[" + startIndex + "] greater than lastPageSize[" + lastPageSize + "]");
            returnObjects = new ArrayList<>();
        } else {
            returnObjects = dataList.subList(startIndex, endIndex);
        }
        logger.debug("startIndex[" + startIndex + "], endIndex[" + endIndex + "], lastPageSize[" + lastPageSize + "], totalPage[" +
                totalPage + "], listSize[" + listSize + "]");
        dataMap.put(CMSConstant.PAYLOAD_KEY_CONTENT, returnObjects);
        dataMap.put(CMSConstant.PAYLOAD_KEY_PAGE_NUMBER, page);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_PAGES, totalPage);
        dataMap.put(CMSConstant.PAYLOAD_KEY_TOTAL_ELEMENTS, listSize);
        return dataMap;
    }

    private static class NumberOfResults {
        private int count;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }
    }
}
