package com.ilt.cms.inventory.svc.model.purchase.api;

import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Builder
@Data
public class GoodOrderedItemPrint {

    private String lineNo;
    private String receiverClinicId; //for BPO indicate receive item clinic
    private String itemRefId;
    private String itemName;
    private String supplierId;
    private String uom;
    private String packSize;
    private int quantity;
    private BigDecimal unitPrice;
    private boolean taxIncluded;
    private String additionalDescription;
    private String fromClinicCode;
    private Boolean isBonusItem;
    private BigDecimal totalPrice;

    private String purchaseRequestId;

    private String remark;

    private String cpRemarks;

}
