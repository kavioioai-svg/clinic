package com.ilt.cms.inventory.svc.model.common;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UomMatrixSearchEntity {
	private String sourceUom;
	private String destinationUom;
}
