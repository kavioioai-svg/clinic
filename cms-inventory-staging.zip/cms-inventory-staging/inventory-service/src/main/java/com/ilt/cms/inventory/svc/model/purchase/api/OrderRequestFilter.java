package com.ilt.cms.inventory.svc.model.purchase.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.lippo.cms.util.CMSConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderRequestFilter {

    @JsonProperty("CREATED_DATE_LESS")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDateLess;

    @JsonProperty("CREATED_DATE_MORE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDateMore;

    @JsonProperty("TRANSFER_PURCHASE_TYPE")
    private TransferPurchaseType transferPurchaseType;

    @JsonProperty("STATUS")
    private OrderStatus orderStatus;

    @JsonProperty("ORDER_REQUEST_NO")
    private String orderNo;

    @JsonProperty("CLINIC_ID")
    private String requestClinicId;

    @JsonProperty("PR_NOS")
    private List<String> prNos;

    @JsonProperty("VENDOR_ID")
    private String vendorId;

    @JsonProperty("ITEMREF_ID")
    private String itemRefId;

    public enum TransferPurchaseType {
        PURCHASE_ORDER, TRANSFER_ORDER
    }
}
