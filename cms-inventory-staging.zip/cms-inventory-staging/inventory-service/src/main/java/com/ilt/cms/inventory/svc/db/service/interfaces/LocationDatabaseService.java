package com.ilt.cms.inventory.svc.db.service.interfaces;

import java.util.List;
import java.util.Optional;

import com.ilt.cms.inventory.svc.model.inventory.Location;

public interface LocationDatabaseService {

    Location saveLocation(Location location);

    Optional<Location> findLocationById(String locationId);

    Optional<Location> findLocationByClinicId(String clinicId);

    //List<Location> findLocationByClinicIdAndItemIds(int page, int size, String clinicId, List<String> itemIds);

    //List<Location> findLocationByLocationIdAndInventory(String locationId, String itemRefId);
    
    List<Location> findAll();

    void saveAll(List<Location> locations);
}
