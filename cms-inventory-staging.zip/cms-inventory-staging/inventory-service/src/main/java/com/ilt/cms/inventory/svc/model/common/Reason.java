package com.ilt.cms.inventory.svc.model.common;

public class Reason {

    public Reason() {
    }

    public Reason(String code, String instruct, String description, boolean billAdjustmentIdentifier) {
        this.code = code;
        this.instruct = instruct;
        this.description = description;
        this.billAdjustmentIdentifier = billAdjustmentIdentifier;
    }

    public Reason(String code, String instruct, String description) {
        this.code = code;
        this.instruct = instruct;
        this.description = description;
    }

    private String code;

    private String instruct;

    private String description;

    private  Boolean billAdjustmentIdentifier;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInstruct() {
        return instruct;
    }

    public void setInstruct(String instruct) {
        this.instruct = instruct;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getBillAdjustmentIdentifier() {return billAdjustmentIdentifier;}

    public void setBillAdjustmentIdentifier(Boolean billAdjustmentIdentifier) {
        this.billAdjustmentIdentifier = billAdjustmentIdentifier;
    }

    @Override
    public String toString() {
        return "ReturnReason{" +
                "code='" + code + '\'' +
                ", instruct='" + instruct + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
