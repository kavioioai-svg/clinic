package com.ilt.cms.inventory.svc.mapper;

import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;

import java.math.BigDecimal;

import static com.lippo.cms.util.Calculations.roundingQuantity;

public class LocationMapper {

    public static Inventory mapToInventory(ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData) {
        Inventory inventory = new Inventory();
        inventory.setItemRefId(inventoryData.getItemId());
        inventory.setBatchNumber(inventoryData.getBatchNo());
        inventory.setBaseUom(inventoryData.getBaseUom());
        inventory.setBaseUomQuantity(inventoryData.getBaseUomQuantity());
        //inventory.setAvailableCount(roundingQuantity(inventoryData.getRemainingQuantity()));
        inventory.setAvailableCount(BigDecimal.valueOf(roundingQuantity(inventoryData.getRemainingQuantity())));
        inventory.setExpiryDate(inventoryData.getExpireDate());
        return inventory;
    }

    public static Inventory mapUsageToInventory(InventoryUsage usage, double conversionRatio) {
        Inventory inventory = new Inventory();
        inventory.setItemRefId(usage.getItemId());
        inventory.setBatchNumber(usage.getBatchNo());
        inventory.setBaseUom(usage.getBaseUom());
        inventory.setAvailableCount(new BigDecimal(usage.getQuantity() * -1 * conversionRatio));
        inventory.setTrackingCode(usage.isTrackingCode());
        return inventory;
    }
}