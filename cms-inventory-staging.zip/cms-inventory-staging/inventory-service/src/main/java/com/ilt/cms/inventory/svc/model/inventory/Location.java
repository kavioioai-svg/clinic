package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.inventory.svc.model.nav.NavQueueRecordStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Location {

    @Indexed(unique = true)
    private String clinicId;
    private List<Inventory> inventory;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_ALT_DATE_FORMAT_WITH_MINUTES)
    @DateTimeFormat(pattern = CMSConstant.JSON_ALT_DATE_FORMAT_WITH_MINUTES)
    private Date syncedOn;

    public Location() {
        this.inventory = new ArrayList<>();
    }

    public Location(String clinicId) {
        this.clinicId = clinicId;
        this.inventory = new ArrayList<>();
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public List<Inventory> getInventory() {
        return inventory;
    }

    public void setInventory(List<Inventory> inventory) {
        this.inventory = inventory;
    }

    public Date getSyncedOn() {
        return syncedOn;
    }

    public void setSyncedOn(Date syncedOn) {
        this.syncedOn = syncedOn;
    }

    @Override
    public String toString() {
        return "Location{" +
                "clinicId='" + clinicId + '\'' +
                ", inventory=" + inventory +
                '}';
    }

    private Location(String clinicId, List<Inventory> inventory) {
        this.clinicId = clinicId;
        this.inventory = inventory;
    }

    public static Location createLocation(String clinicId, List<Inventory> inventory) {
        return new Location(clinicId, inventory);
    }
}
