package com.ilt.cms.inventory.svc.model.purchase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class DeliveryNote {

    @Indexed
    private String id;

    private String delivererId;

    private String receiverId;

    private String courier;

    private String trackingNo;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate sendDate;

    private String dnNo;

    private List<DeliveryItem> transferSendItems;

    private String additionalRemark;

    private DeliveryNoteStatus status;

    private String userId;

    private NavIntegrationResult navIntegrationResult;

    private List<DeliveryItem> previousTransferSendItems;

    public boolean checkValidate() {
        return isStringValid(delivererId, receiverId)
                && status != null
                && sendDate != null && transferSendItems != null && transferSendItems.size() > 0;
    }

    public void copy(DeliveryNote deliveryNote){
        this.courier = deliveryNote.courier;
        this.trackingNo = deliveryNote.trackingNo;
        this.transferSendItems = deliveryNote.transferSendItems;
        this.additionalRemark = deliveryNote.additionalRemark;
        this.status = deliveryNote.status;
        this.userId = deliveryNote.userId;
    }

    public DeliveryNote() {
        this.transferSendItems = new ArrayList<>();
        this.status = DeliveryNoteStatus.DRAFT;
    }

    public DeliveryNote(String delivererId, String receiverId, LocalDate createDate,
                        LocalDate deliveryDate, String dnNo, DeliveryNoteStatus status) {
        this.delivererId = delivererId;
        this.receiverId = receiverId;
        this.createDate = createDate;
        this.sendDate = deliveryDate;
        this.dnNo = dnNo;
        this.transferSendItems = new ArrayList<>();
        this.status = status;
    }

    public DeliveryNote(DeliveryNoteStatus status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDelivererId() {
        return delivererId;
    }

    public void setDelivererId(String delivererId) {
        this.delivererId = delivererId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getCourier() {
        return courier;
    }

    public void setCourier(String courier) {
        this.courier = courier;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public LocalDate getSendDate() {
        return sendDate;
    }

    public void setSendDate(LocalDate sendDate) {
        this.sendDate = sendDate;
    }

    public String getDnNo() {
        return dnNo;
    }

    public void setDnNo(String dnNo) {
        this.dnNo = dnNo;
    }

    public List<DeliveryItem> getTransferSendItems() {
        return transferSendItems;
    }

    public void setTransferSendItems(List<DeliveryItem> transferSendItems) {
        this.transferSendItems = transferSendItems;
    }

    public String getAdditionalRemark() {
        return additionalRemark;
    }

    public void setAdditionalRemark(String additionalRemark) {
        this.additionalRemark = additionalRemark;
    }

    public DeliveryNoteStatus getStatus() {
        return status;
    }

    public void setStatus(DeliveryNoteStatus status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    public List<DeliveryItem> getPreviousTransferSendItems() {
        return previousTransferSendItems;
    }

    public void setPreviousTransferSendItems(List<DeliveryItem> previousTransferSendItems) {
        this.previousTransferSendItems = previousTransferSendItems;
    }

    @Override
    public String toString() {
        return "DeliveryNote{" +
                "id='" + id + '\'' +
                ", delivererId='" + delivererId + '\'' +
                ", receiverId='" + receiverId + '\'' +
                ", courier='" + courier + '\'' +
                ", trackingNo='" + trackingNo + '\'' +
                ", createDate=" + createDate +
                ", sendDate=" + sendDate +
                ", dnNo='" + dnNo + '\'' +
                ", transferSendItems=" + transferSendItems +
                ", additionalRemark='" + additionalRemark + '\'' +
                ", status=" + status +
                ", userId='" + userId + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeliveryNote that = (DeliveryNote) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(delivererId, that.delivererId) &&
                Objects.equals(receiverId, that.receiverId) &&
                Objects.equals(courier, that.courier) &&
                Objects.equals(trackingNo, that.trackingNo) &&
                Objects.equals(createDate, that.createDate) &&
                Objects.equals(sendDate, that.sendDate) &&
                Objects.equals(dnNo, that.dnNo) &&
                Objects.equals(transferSendItems, that.transferSendItems) &&
                Objects.equals(additionalRemark, that.additionalRemark) &&
                status == that.status &&
                Objects.equals(userId, that.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, delivererId, receiverId, courier, trackingNo, createDate, sendDate, dnNo, transferSendItems, additionalRemark, status, userId);
    }
}
