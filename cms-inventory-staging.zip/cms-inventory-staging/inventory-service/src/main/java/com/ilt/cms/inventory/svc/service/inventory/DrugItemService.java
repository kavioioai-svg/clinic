package com.ilt.cms.inventory.svc.service.inventory;

import com.ilt.cms.core.entity.item.DrugItem;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class DrugItemService {

    private static final Logger logger = LoggerFactory.getLogger(DrugItemService.class);

    private ItemDatabaseService itemDatabaseService;

    private SupplierDatabaseService supplierDatabaseService;

    private InventoryUtilsService inventoryUtilsService;

    public DrugItemService(ItemDatabaseService itemDatabaseService, SupplierDatabaseService supplierDatabaseService,
                           InventoryUtilsService inventoryUtilsService) {
        this.itemDatabaseService = itemDatabaseService;
        this.supplierDatabaseService = supplierDatabaseService;
        this.inventoryUtilsService = inventoryUtilsService;
    }

    public Item findItemById(String itemRefId) throws CMSException {

        Item item = itemDatabaseService.findItemByItemId(itemRefId)
                .orElseThrow(() -> {
                    logger.error("Item[" + itemRefId + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });

        return item;
    }

    public List<Item> findItemByIds(List<String> itemIds){
        return itemDatabaseService.findItemsByIds(itemIds);
    }

    public List<Item> findItem(String itemNameRegex, String itemCodeRegex, List<String> supplierIds) {

        List<Item> items = itemDatabaseService.findItemAndSupplier(itemNameRegex, itemCodeRegex, supplierIds);
        List<Item> drugItems = items.stream()
                .filter(item -> item instanceof DrugItem)
                .map(item -> (DrugItem) item)
                .collect(Collectors.toList());

        return drugItems;
    }

    public Item findItemByClinicIdAndItemCode(String clinicId, String itemCode) throws CMSException {

        Item item = itemDatabaseService.findByClinicIdAndCode(clinicId, itemCode)
                .orElseThrow(() -> {
                    logger.error("Item[" + clinicId + "] and itemCode[" + itemCode + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });

        return item;
    }

    public Item createItem(Item drugItem) {
        return itemDatabaseService.saveItem(drugItem);
    }

    public List<Item> listItemByClinicId(String clinicId) {
        final String clinicGroupName = inventoryUtilsService.getClinicGroupName(clinicId);
        return itemDatabaseService.findAll(Set.of(clinicId), Set.of(clinicGroupName));
    }

    public List<Item> listAllItems() {
        return itemDatabaseService.findAllActive();
    }

    public List<Item> listSupplierItem(String clinicId, String supplierId) throws CMSException {
        List<String> itemIds = supplierDatabaseService.findById(supplierId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Supplier not found"))
                .getItems()
                .stream()
                .map(PurchaseItem::getItemId)
                .collect(Collectors.toList());
        List<Item> items = itemDatabaseService.findItemByClinicId(clinicId);
        return items.stream().filter(item -> itemIds.contains(item.getId())).collect(Collectors.toList());
    }


}
