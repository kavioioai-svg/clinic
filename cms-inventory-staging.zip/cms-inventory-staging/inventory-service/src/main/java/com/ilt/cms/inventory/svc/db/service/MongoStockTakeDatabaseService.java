package com.ilt.cms.inventory.svc.db.service;

import com.ilt.cms.inventory.svc.db.repository.spring.inventory.StockTakeRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.StockTakeDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockCountItemEntity;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockTakeSearchDTO;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

@Service
public class MongoStockTakeDatabaseService implements StockTakeDatabaseService {

    private static final Logger logger = LoggerFactory.getLogger(MongoStockTakeDatabaseService.class);

    private StockTakeRepository stockTakeRepository;

    private MongoTemplate mongoTemplate;

    public MongoStockTakeDatabaseService(StockTakeRepository stockTakeRepository, MongoTemplate mongoTemplate) {
        this.stockTakeRepository = stockTakeRepository;
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public StockTake saveStockTake(StockTake stockTake) {
        return stockTakeRepository.save(stockTake);
    }

    @Override
    public void deleteStockTake(String stockTakeId) {
        stockTakeRepository.deleteById(stockTakeId);
    }

    @Override
    public Page<StockTake> findStockTakeByClinicIdAndCountTypeInAndApproveStatusInAndStockCountItemsItemRedIdIn(String clinicId,
                                                                                                                List<StockCountType> stockCountTypes,
                                                                                                                List<StockTakeApproveStatus> approveStatus,
                                                                                                                List<String> itemRefIds,
                                                                                                                int page, int size,
                                                                                                                Sort.Direction direction,
                                                                                                                String... sortFields) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortFields));
        return stockTakeRepository.findAllByClinicIdAndCountTypeInAndApproveStatusInAndStockCountItemsItemRefIdIn(clinicId, stockCountTypes, approveStatus, itemRefIds, pageable);
    }

    @Override
    public Optional<StockTake> findStockTakeById(String stockTakeId) {
        return stockTakeRepository.findById(stockTakeId);
    }

    public Optional<StockTake> findStockTakeByIdAndStockCountTypeIn(String stockTakeId, List<String> stockCountTypes) {
        return stockTakeRepository.findByIdAndCountTypeIn(stockTakeId, stockCountTypes);
    }

    @Override
    public Optional<StockTake> findStockTakeByStockTakeName(String stockTakeName) {
        return stockTakeRepository.findByStockTakeName(stockTakeName);
    }

    @Override
    public Page<StockTake> findStockTakeByStockTakeStatusOrApproveStatus(StockTakeStatus stockTakeStatus,
                                                                         StockTakeApproveStatus stockTakeApproveStatus,
                                                                         int page, int size, Sort.Direction direction, String... sortFields) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortFields));
        String stockTakeStatusStr = stockTakeStatus == null ? null : stockTakeStatus.name();
        String approveStatusStr = stockTakeApproveStatus == null ? null : stockTakeApproveStatus.name();
        return stockTakeRepository.findAllByStockTakeStatusOrApproveStatus(stockTakeStatusStr, approveStatusStr, pageable);
    }

    @Override
    public List<StockTake> findAll() {
        return stockTakeRepository.findAll();
    }

    @Override
    public List<StockTake> saveAll(List<StockTake> savableOrders) {
        return stockTakeRepository.saveAll(savableOrders);
    }

    @Override
    public List<StockTake> findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
            String clinicId, StockCountType stockCountType, List<StockTakeApproveStatus> approveStatus, String itemRefId, String batchNo) {

        return stockTakeRepository.findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
                clinicId, stockCountType, approveStatus, itemRefId, batchNo);
    }

    @Override
    public Page<StockTake> findStockTakeByClinicIdAndCountNameLikeAndTransactionNoLikeAndApproveStatusInAndStockTakeStatusInAndCountTypeInAndDateBetween(String clinicId,
                                                                                                                                                         String countNameRegex,
                                                                                                                                                         String transactionNoRegex,
                                                                                                                                                         List<StockTakeApproveStatus> stockTakeApproveStatuses,
                                                                                                                                                         List<StockTakeStatus> stockTakeStatuses,
                                                                                                                                                         List<StockCountType> stockCountTypes,
                                                                                                                                                         LocalDateTime startDateTime,
                                                                                                                                                         LocalDateTime endDateTime,
                                                                                                                                                         int page, int size, Sort.Direction direction, String... sortFields) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortFields));

        Query query = new Query().with(pageable);

        query.addCriteria(Criteria.where("clinicId").is(clinicId));
        if (CommonUtils.isStringValid(countNameRegex)) {
            query.addCriteria(Criteria.where("countName").regex(countNameRegex));
        }
        if (CommonUtils.isStringValid(transactionNoRegex)) {
            query.addCriteria(Criteria.where("transactionNo").regex(transactionNoRegex));
        }
        if (stockTakeApproveStatuses != null && !stockTakeApproveStatuses.isEmpty()) {
            query.addCriteria(Criteria.where("approveStatus").in(stockTakeApproveStatuses));
        }
        if (stockTakeStatuses != null && !stockTakeStatuses.isEmpty()) {
            query.addCriteria(Criteria.where("stockTakeStatus").in(stockTakeStatuses));
        }
        if (stockCountTypes != null && !stockCountTypes.isEmpty()) {
            query.addCriteria(Criteria.where("countType").in(stockCountTypes));
        }
        query.addCriteria(Criteria.where("startDate").gte(startDateTime).lte(endDateTime));
        query.fields().exclude("stockCountItems");

        List<StockTake> stockTakes = mongoTemplate.find(query, StockTake.class);

        return PageableExecutionUtils.getPage(
                stockTakes,
                pageable,
                () -> mongoTemplate.count(query.limit(-1).skip(-1), StockTake.class));
    }

    @Override
    public Page<StockTake> searchStockAdjustmentsByCriteria(String clinicId, String itemType, String itemCodeRegex, String itemNameRegex,
                                                            String transactionNoRegex, String itemRefId, List<String> stockTakeApproveStatusStrings, Pageable pageable) {
        Criteria clinicCriteria = Criteria.where("clinicId").is(clinicId)
                .andOperator(Criteria.where("countType").is(StockCountType.ADJUSTMENT.name()), Criteria.where("approveStatus").in(stockTakeApproveStatusStrings));
        LookupOperation itemLookUp = Aggregation.lookup("item", "itemObj", "_id", "items");
        UnwindOperation stockCountItemsUnwind = Aggregation.unwind("stockCountItems");
        ProjectionOperation projectionOperation = Aggregation.project("id", "startDate");
        UnwindOperation itemsUnwindOperation = Aggregation.unwind("items");
//        SkipOperation skipOperation = Aggregation.skip((long) pageable.getPageNumber() * pageable.getPageSize());
        AggregationOperation itemObjDocument = aoc -> new Document("$addFields", new Document("itemObj", new Document("$toObjectId", "$stockCountItems.itemRefId")));
        SortOperation sortOperation = Aggregation.sort(pageable.getSort());
//        LimitOperation limitOperation = Aggregation.limit(pageable.getPageSize());
        Criteria criteria = null;
        if (CommonUtils.isStringValid(transactionNoRegex)) {
            criteria = Criteria.where("transactionNo").regex(".*" + transactionNoRegex.trim() + ".*", "i");
        } else if (CommonUtils.isStringValid(itemNameRegex)) {
            criteria = Criteria.where("stockCountItems.itemName").regex(".*" + itemNameRegex.trim() + ".*", "i");
        } else if (CommonUtils.isStringValid(itemCodeRegex)) {
            criteria = Criteria.where("stockCountItems.itemCode").regex(".*" + itemCodeRegex.trim() + ".*", "i");
        } else if (CommonUtils.isStringValid(itemRefId)) {
            criteria = Criteria.where("stockCountItems.itemRefId").is(itemRefId.trim());
        }

        TypedAggregation<StockTake> typedAggregation = getStockTakeTypedAggregation(itemType, clinicCriteria, itemLookUp, stockCountItemsUnwind,
                projectionOperation, itemsUnwindOperation, null, itemObjDocument, sortOperation, null, criteria);

        final AggregationResults<Map> stockTakeMaps = mongoTemplate.aggregate(typedAggregation, "stockTake", Map.class);
        final List<String> collect = stockTakeMaps.getMappedResults()
                .stream()
                .map(map -> map.containsKey("_id") ? map.get("_id").toString() : "")
                .filter(CommonUtils::isStringValid)
                .collect(Collectors.toList());

        return stockTakeRepository.findAllByIdIn(collect, pageable);
    }

    private TypedAggregation<StockTake> getStockTakeTypedAggregation(String itemType, Criteria clinicCriteria,
                                                                     LookupOperation itemLookUp, UnwindOperation stockCountItemsUnwind,
                                                                     ProjectionOperation projectionOperation, UnwindOperation itemsUnwindOperation,
                                                                     SkipOperation skipOperation, AggregationOperation itemObjDocument,
                                                                     SortOperation sortOperation,
                                                                     LimitOperation limitOperation, Criteria criteria) {
        TypedAggregation<StockTake> typedAggregation;
        if (!itemType.equals("ALL")) {
            Criteria itemTypeCriteria = Criteria.where("items.itemType").is(itemType.trim());
            if (criteria != null) {
                itemTypeCriteria.andOperator(criteria);
            }
            MatchOperation itemTypeMatchOperation = Aggregation.match(itemTypeCriteria);
            if (limitOperation != null && skipOperation != null) {
                typedAggregation = newAggregation(StockTake.class,
                        Aggregation.match(clinicCriteria), stockCountItemsUnwind, itemObjDocument,
                        itemLookUp, itemsUnwindOperation,
                        itemTypeMatchOperation, projectionOperation,
                        sortOperation, skipOperation, limitOperation);
            } else {
                typedAggregation = newAggregation(StockTake.class,
                        Aggregation.match(clinicCriteria), stockCountItemsUnwind, itemObjDocument,
                        itemLookUp, itemsUnwindOperation,
                        itemTypeMatchOperation, projectionOperation,
                        sortOperation);
            }
        } else {
            if (criteria != null) {
                MatchOperation matchOperation = Aggregation.match(criteria);
                if (limitOperation != null && skipOperation != null) {
                    typedAggregation = newAggregation(StockTake.class,
                            Aggregation.match(clinicCriteria),
                            matchOperation, projectionOperation,
                            sortOperation, skipOperation, limitOperation);
                } else {
                    typedAggregation = newAggregation(StockTake.class,
                            Aggregation.match(clinicCriteria),
                            matchOperation, projectionOperation,
                            sortOperation);
                }
            } else {
                if (limitOperation != null && skipOperation != null) {
                    typedAggregation = newAggregation(StockTake.class,
                            Aggregation.match(clinicCriteria), projectionOperation,
                            sortOperation, skipOperation, limitOperation);
                } else {
                    typedAggregation = newAggregation(StockTake.class,
                            Aggregation.match(clinicCriteria), projectionOperation,
                            sortOperation);
                }
            }
        }
        return typedAggregation;
    }

    public Page<StockTake> searchStockAdjustmentsByCriteria(StockTakeSearchDTO searchDTO, Pageable pageable) {
        LocalDate dateFrom = searchDTO.getStartDateFrom();
        LocalDate dateTo = searchDTO.getStartDateTo();
        String approveStatus = searchDTO.getApproveStatus();
        String itemName = searchDTO.getItemName();
        String itemCode = searchDTO.getItemCode();
        List<String> clinicIds = searchDTO.getClinicIds();
        String commonRegex = searchDTO.getCommonRegex();

        Criteria stockTakeCriteria;
        Criteria stockCountItemCriteria = null;
        if (Objects.isNull(approveStatus) || approveStatus.equals("ALL")) {
            stockTakeCriteria = Criteria.where("countType").is(StockCountType.ADJUSTMENT.name())
                    .andOperator(Criteria.where("startDate").gte(dateFrom).lte(dateTo));
        } else {
            stockTakeCriteria = Criteria.where("countType").is(StockCountType.ADJUSTMENT.name())
                    .andOperator(Criteria.where("startDate").gte(dateFrom).lte(dateTo), Criteria.where("approveStatus").is(approveStatus));
        }

        UnwindOperation stockCountItemsUnwind = Aggregation.unwind("stockCountItems");
        SortOperation sortOperation = Aggregation.sort(pageable.getSort());

        if (CommonUtils.isStringValid(itemName)) {
            stockCountItemCriteria = Criteria.where("stockCountItems.itemName").regex(".*" + itemName.trim() + ".*", "i");
        } else if (CommonUtils.isStringValid(itemCode)) {
            stockCountItemCriteria = Criteria.where("stockCountItems.itemCode").regex(".*" + itemCode.trim() + ".*", "i");
        } else if (CommonUtils.isStringValid(commonRegex)) {
            Criteria criteria = new Criteria();
            criteria.orOperator(Criteria.where("stockCountItems.itemName").regex(".*" + commonRegex.trim() + ".*", "i"),
                    Criteria.where("stockCountItems.itemCode").regex(".*" + commonRegex.trim() + ".*", "i"));
            stockCountItemCriteria = criteria;
        }

        TypedAggregation<StockTake> typedAggregation = getStockTakeTypedAggregationByCriteria(clinicIds, stockTakeCriteria, stockCountItemsUnwind, sortOperation, stockCountItemCriteria);

        AggregationResults<Map> stockTakeMaps = mongoTemplate.aggregate(typedAggregation, "stockTake", Map.class);
        List<String> collect = stockTakeMaps.getMappedResults()
                .stream()
                .map(map -> map.containsKey("_id") ? map.get("_id").toString() : "")
                .filter(CommonUtils::isStringValid)
                .collect(Collectors.toList());

        Page<StockTake> stockTakePage = stockTakeRepository.findAllByIdIn(collect, pageable);

        return stockTakePage;
    }

    @Override
    public Page<StockCountItemEntity> searchStockTakes(StockTakeSearchDTO search, Pageable pageable) throws CMSException {

        boolean areParamValid = validateSearchStockTakeParameters(search);
        if (!areParamValid) {
            logger.debug("Stock take search parameters are invalid");

            throw new CMSException(StatusCode.E1002, "Invalid parameters");
        }

        Criteria criteria = createStockTakeSearchCriteria(search);

        MatchOperation matchOperation = Aggregation.match(criteria);
        UnwindOperation countItemUnwind = Aggregation.unwind("$stockCountItems");
        AddFieldsOperation addFieldsOperation = Aggregation.addFields()
                .addFieldWithValue("stockCountItems.stockTakeId","$_id")
                .addFieldWithValue("stockCountItems.stockTakeName", "$stockTakeName")
                .addFieldWithValue("stockCountItems.transactionNo", "$transactionNo")
                .addFieldWithValue("stockCountItems.startDate", "$startDate")
                .addFieldWithValue("stockCountItems.endDate", "$endDate")
                .addFieldWithValue("stockCountItems.endTime", "$endTime")
                .addFieldWithValue("stockCountItems.clinicId", "$clinicId")
                .addFieldWithValue("clinicIdObj", new Document("$toObjectId", "$clinicId"))
                .addFieldWithValue("stockCountItems.countType", "$countType")
                .addFieldWithValue("stockCountItems.countName", "$countName")
                .addFieldWithValue("stockCountItems.stockTakeStatus", "$stockTakeStatus")
                .addFieldWithValue("stockCountItems.stockTakeApproveStatus", "$approveStatus")
                .addFieldWithValue("stockCountItems.lastModifiedDate", "$lastModifiedDate")
                .addFieldWithValue("stockCountItems.lastModifiedBy", "$lastModifiedBy")
                .addFieldWithValue("stockCountItems.lineId", "$stockCountItems._id")
                .build();
        LookupOperation clinicLookupOperation = Aggregation.lookup("clinic","clinicIdObj","_id","clinic");
        UnwindOperation clinicUnwindOperation = Aggregation.unwind("clinic");
        AddFieldsOperation addClinicFieldsOperation = Aggregation.addFields()
                .addFieldWithValue("stockCountItems.clinicCode","$clinic.clinicCode")
                .addFieldWithValue("stockCountItems.clinicName","$clinic.name")
                .build();
        ReplaceRootOperation replaceRootOperation = Aggregation.replaceRoot("$stockCountItems");
        SkipOperation skipOperation = new SkipOperation((long) pageable.getPageNumber() * pageable.getPageSize());
        LimitOperation limitOperation = new LimitOperation(pageable.getPageSize());

        Sort sort = Sort.by(Sort.Direction.DESC, "startDate");

        SortOperation sortOperation = Aggregation.sort(sort);

        CountOperation countOperation = new CountOperation("count");

        AggregationResults<StockCountItemEntity> result = mongoTemplate.aggregate(
                Aggregation.newAggregation(countItemUnwind,
                        matchOperation,
                        addFieldsOperation,
                        clinicLookupOperation,
                        Aggregation.unwind("$clinic"),
                        addClinicFieldsOperation,
                        replaceRootOperation,
                        sortOperation,
                        skipOperation,
                        limitOperation),
                StockTake.class,
                StockCountItemEntity.class);

        AggregationResults<MongoStockTakeDatabaseService.ResultCount> totalCount = mongoTemplate.aggregate(
                Aggregation.newAggregation(countItemUnwind, matchOperation, countOperation),
                StockTake.class,
                MongoStockTakeDatabaseService.ResultCount.class);

        long total = 0;
        if (totalCount.getMappedResults().size() > 0) {
            total = totalCount.getMappedResults().get(0).getCount();
        }

        List<StockCountItemEntity> collect = result.getMappedResults().stream().map(stockCountItemEntity -> {
            if (stockCountItemEntity.getStatus() == null) {
                stockCountItemEntity.setStatus(StockCountItemStatus.REQUESTED);
            }
            return stockCountItemEntity;
        }).collect(Collectors.toList());

        return new PageImpl<>(
                collect,
                PageRequest.of(pageable.getPageNumber(), pageable.getPageSize()),
                total
        );
    }

    @Override
    public List<StockTake> findStockTakeByIds(Set<String> stockTakeIds) {

        return stockTakeRepository.findAllByIdIn(stockTakeIds);
    }

    @Override
    public List<StockTake> findAllByStockTakeStatusAndApproveStatusNotIn(StockTakeStatus stockTakeStatus, List<StockTakeApproveStatus> approveStatuses) {

        return stockTakeRepository.findAllByStockTakeStatusAndApproveStatusNotIn(stockTakeStatus, approveStatuses);
    }

    private Criteria createStockTakeSearchCriteria(StockTakeSearchDTO search) {

        List<String> clinicIds = search.getClinicIds();
        LocalDate dateFrom = search.getStartDateFrom();
        LocalDate dateTo = search.getStartDateTo();
        String approveStatus = search.getApproveStatus();
        String lineItemApproveStatus = search.getStatus();
        String keyword = search.getStockTakeKeyword();
        String itemRefId = search.getItemRefId();

        Criteria criteria = new Criteria("stockTakeStatus").is(StockTakeStatus.COMPLETED);
        criteria.and("countType").ne(StockCountType.ADJUSTMENT);
        criteria.and("clinicId").in(clinicIds);
        criteria.andOperator(Criteria.where("startDate").gte(dateFrom.atStartOfDay())
                .lte(dateTo.atTime(23,59,59)));

        if (keyword != null) {
            criteria.orOperator(Criteria.where("transactionNo").regex(keyword),
                    Criteria.where("stockTakeName").regex(keyword));
        }

        List<StockCountItemStatus> lineItemStatusList = List.of(
                StockCountItemStatus.APPROVED,
                StockCountItemStatus.REJECTED);

        if (approveStatus != null && !approveStatus.equals("")) {
            criteria.and("approveStatus").is(approveStatus);
        }

        if(lineItemApproveStatus != null && lineItemApproveStatus.equals("REQUESTED")){
            criteria.and("stockCountItems.status").nin(lineItemStatusList);
        }else if (lineItemApproveStatus != null && !lineItemApproveStatus.equals("")) {
            criteria.and("stockCountItems.status").is(lineItemApproveStatus);
        }

        if (itemRefId != null) {
            criteria.and("stockCountItems.itemRefId").is(itemRefId);
        }

        return criteria;
    }

    public boolean validateSearchStockTakeParameters(StockTakeSearchDTO search) {

        return search.getClinicIds().size() > 0
                && search.getStartDateFrom() != null && search.getStartDateTo().compareTo(LocalDate.now()) <= 0
                && search.getStartDateTo() != null && search.getStartDateTo().compareTo(LocalDate.now()) <= 0
                && (search.getStockTakeKeyword() == null || !search.getStockTakeKeyword().equals(""))
                && (search.getApproveStatus() == null || StockTakeApproveStatus.fromName(search.getApproveStatus()) != null);
    }

    private TypedAggregation<StockTake> getStockTakeTypedAggregationByCriteria(List<String> clinicIds, Criteria stockTakeCriteria,
                                                                               UnwindOperation stockCountItemsUnwind,
                                                                               SortOperation sortOperation, Criteria stockCountItemCriteria) {

        MatchOperation stockTakeMatchOperation = Aggregation.match(stockTakeCriteria);
        TypedAggregation<StockTake> typedAggregation;

        if (Objects.nonNull(clinicIds) && clinicIds.size() > 0) {
            Criteria clinicIdCriteria = Criteria.where("clinicId").in(clinicIds);
            if (stockCountItemCriteria != null) {
                clinicIdCriteria.andOperator(stockCountItemCriteria);
            }

            MatchOperation clinicIdMatchOperation = Aggregation.match(clinicIdCriteria);
            typedAggregation = newAggregation(StockTake.class,
                    stockTakeMatchOperation, stockCountItemsUnwind,
                    clinicIdMatchOperation,
                    sortOperation);
        } else {
            if (stockCountItemCriteria != null) {
                MatchOperation stockCountItemMatchOperation = Aggregation.match(stockCountItemCriteria);

                typedAggregation = newAggregation(StockTake.class,
                        stockTakeMatchOperation,
                        stockCountItemMatchOperation,
                        sortOperation);
            } else {
                typedAggregation = newAggregation(StockTake.class,
                        stockTakeMatchOperation,
                        sortOperation);
            }
        }

        return typedAggregation;
    }

    private static class ResultCount {

        private long count;

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }
    }
}
