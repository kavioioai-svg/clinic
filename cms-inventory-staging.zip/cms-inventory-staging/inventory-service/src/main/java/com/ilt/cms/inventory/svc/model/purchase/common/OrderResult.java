package com.ilt.cms.inventory.svc.model.purchase.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.inventory.svc.model.common.ClinicFilter;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.lippo.cms.util.CMSConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderResult {
    private String id;
    private String requestId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private String requestNo;

    private String requestClinicId;
    private String requestClinicName;
    private OrderType orderType;
    private String orderNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate orderDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate completeDate;

    private List<GoodReceivedNote> goodReceivedNotes = new ArrayList<>();
    private OrderStatus orderStatus;
    private GoodReceivedReturnStatus returnStatus;
    private String supplierId;
    private ClinicFilter clinicFilter;
    private List<GoodOrderedItem> goodPurchasedItems = new ArrayList<>();
    private List<TransferRequestItem> transferRequestItems = new ArrayList<>();
    private List<GoodReturnItem> returnItems = new ArrayList<>();
    private String senderClinicId;
    private List<DeliveryNote> deliveryNotes = new ArrayList<>();
    private String remark;
    private boolean cPTransfer;
    private String blanketPO;
    private boolean interComp;
    private NavIntegrationResult navIntegrationResult;
    private String purchaseOrderId;
    private int totalPrice;
    private Order.DiscountType discountType;
    private BigDecimal discountAmount;
    private int calculatedDiscount;
    private BigDecimal gstAmount;
    private BigDecimal gstPercentage;
    private Boolean gstEnabled;

    public BigDecimal getGstPercentage() {
        if (gstPercentage == null) {
            return BigDecimal.ZERO;
        }
        return gstPercentage;
    }
}
