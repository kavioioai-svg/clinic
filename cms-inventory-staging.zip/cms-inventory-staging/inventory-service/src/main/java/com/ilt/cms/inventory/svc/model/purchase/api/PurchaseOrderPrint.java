package com.ilt.cms.inventory.svc.model.purchase.api;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.inventory.svc.model.purchase.GoodOrderedItem;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import lombok.Builder;

import java.math.BigDecimal;
import java.util.List;

@Builder
public class PurchaseOrderPrint {

    private Order order;
    private Supplier supplier;
    private Clinic requestedClinic;
    List<ContactPerson> contactPerson;
    List<GoodOrderedItemPrint> goodOrderedItems;
    private BigDecimal subTotal;
    private BigDecimal gst;
    private BigDecimal total;
    private String logo;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Clinic getRequestedClinic() {
        return requestedClinic;
    }

    public void setRequestedClinic(Clinic requestedClinic) {
        this.requestedClinic = requestedClinic;
    }

    public List<ContactPerson> getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(List<ContactPerson> contactPerson) {
        this.contactPerson = contactPerson;
    }

    public List<GoodOrderedItemPrint> getGoodOrderedItems() {
        return goodOrderedItems;
    }

    public void setGoodOrderedItems(List<GoodOrderedItemPrint> goodOrderedItems) {
        this.goodOrderedItems = goodOrderedItems;
    }

    public BigDecimal getSubTotal() {
        return subTotal;
    }
    public void setSubTotal(BigDecimal subTotal) {
        this.subTotal = subTotal;
    }

    public BigDecimal getGst() {
        return gst;
    }
    public void setGst(BigDecimal gst) {
        this.gst = gst;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }
}
