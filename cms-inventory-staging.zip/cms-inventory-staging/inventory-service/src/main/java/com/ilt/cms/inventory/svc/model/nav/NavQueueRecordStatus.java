package com.ilt.cms.inventory.svc.model.nav;

public enum NavQueueRecordStatus {
    QUEUED,
    FIRED,
    SUCCESS,
    FAILED
}
