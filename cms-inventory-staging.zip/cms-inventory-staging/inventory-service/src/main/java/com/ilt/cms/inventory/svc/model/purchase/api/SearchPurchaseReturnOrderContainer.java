package com.ilt.cms.inventory.svc.model.purchase.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Map;

public class SearchPurchaseReturnOrderContainer {

    public SearchPurchaseReturnOrderContainer() {
    }

    public SearchPurchaseReturnOrderContainer(LocalDate startDate, LocalDate endDate, String requestStatus, String number) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.requestStatus = requestStatus;
        this.number = number;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;

    private String requestStatus;

    private String number;

    private String clinicId;

    private String orderNo;

    private String prNo;

    private String receiverClinicId;

    private String supplierId;

    private String itemRefId;

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getClinicId() {
        return clinicId;
    }
    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }
    public String getOrderNo() {
        return orderNo;
    }
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    public String getPrNo() {
        return prNo;
    }
    public void setPrNo(String prNo) {
        this.prNo = prNo;
    }

    public String getReceiverClinicId() {
        return receiverClinicId;
    }
    public void setReceiverClinicId(String receiverClinicId) {
        this.receiverClinicId = receiverClinicId;
    }

    public String getSupplierId() {
        return supplierId;
    }
    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getItemRefId() {
        return itemRefId;
    }
    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    @Override
    public String toString() {
        return "SearchPurchaseReturnOrderContainer{" +
                "startDate=" + startDate +
                ", endDate=" + endDate +
                ", requestStatus='" + requestStatus + '\'' +
                ", number='" + number + '\'' +
                ", clinicId='" + clinicId + '\'' +
                ", orderNo='" + orderNo + '\'' +
                ", prNo='" + prNo + '\'' +
                ", receiverClinicId='" + receiverClinicId + '\'' +
                ", supplierId='" + supplierId + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                '}';
    }
}
