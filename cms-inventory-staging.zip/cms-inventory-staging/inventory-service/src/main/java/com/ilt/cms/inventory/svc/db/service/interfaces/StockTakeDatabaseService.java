package com.ilt.cms.inventory.svc.db.service.interfaces;

import com.ilt.cms.inventory.svc.model.inventory.StockTake;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockCountItemEntity;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockTakeEntity;
import com.ilt.cms.inventory.svc.service.inventory.dto.StockTakeSearchDTO;
import com.lippo.cms.exception.CMSException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface StockTakeDatabaseService {
    StockTake saveStockTake(StockTake stockTake);

    void deleteStockTake(String stockTakeId);

    Page<StockTake> findStockTakeByClinicIdAndCountTypeInAndApproveStatusInAndStockCountItemsItemRedIdIn(String clinicId,
                                                                                                         List<StockCountType> stockCountTypes,
                                                                                                         List<StockTakeApproveStatus> approveStatus,
                                                                                                         List<String> itemRefIds,
                                                                                                         int page, int size,
                                                                                                         Sort.Direction direction,
                                                                                                         String... sortFields);

    Optional<StockTake> findStockTakeById(String stockTakeId);

    Optional<StockTake> findStockTakeByStockTakeName(String stockTakeName);

    Page<StockTake> findStockTakeByStockTakeStatusOrApproveStatus(StockTakeStatus stockTakeStatus,
                                                                  StockTakeApproveStatus stockTakeApproveStatus,
                                                                  int page, int size, Sort.Direction direction, String... sorFields);

    List<StockTake> findAll();

    List<StockTake> saveAll(List<StockTake> savableOrders);

    List<StockTake> findStockTakeByClinicIdAndCountTypeAndApproveStatusInAndStockCountItemsItemRefIdAndStockCountItemsCurBatchNumber(
            String clinicId, StockCountType stockCountType, List<StockTakeApproveStatus> approveStatus, String itemRefId, String batchNo);

    Page<StockTake> findStockTakeByClinicIdAndCountNameLikeAndTransactionNoLikeAndApproveStatusInAndStockTakeStatusInAndCountTypeInAndDateBetween(String clinicId,
                                                                                                                                                  String nameRegex,
                                                                                                                                                  String transactionNoRegex,
                                                                                                                                                  List<StockTakeApproveStatus> stockTakeApproveStatuses,
                                                                                                                                                  List<StockTakeStatus> stockTakeStatuses,
                                                                                                                                                  List<StockCountType> stockCountTypes,
                                                                                                                                                  LocalDateTime startDateTime, LocalDateTime endDateTime,
                                                                                                                                                  int page, int size, Sort.Direction direction,
                                                                                                                                                  String[] sortFields);

    Page<StockTake> searchStockAdjustmentsByCriteria(String clinicId, String itemType, String itemCodeRegex, String itemNameRegex,
                                                     String transactionNoRegex, String itemRefId, List<String> stockTakeApproveStatusStrings, Pageable pageable);

    Page<StockTake> searchStockAdjustmentsByCriteria(StockTakeSearchDTO searchDTO, Pageable pageable);

    Page<StockCountItemEntity> searchStockTakes(StockTakeSearchDTO criteria, Pageable pageable) throws CMSException;

    List<StockTake> findStockTakeByIds(Set<String> stockTakeIds);

    List<StockTake> findAllByStockTakeStatusAndApproveStatusNotIn(StockTakeStatus stockTakeStatus,
                                                                  List<StockTakeApproveStatus> approveStatuses);
}
