package com.ilt.cms.inventory.svc.model.purchase.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.audit.AuditableEntity;
import com.ilt.cms.inventory.svc.model.common.ClinicFilter;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.lippo.cms.util.CMSConstant;
import lombok.Getter;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.lippo.commons.util.CommonUtils.isStringValid;

@AuditableEntity
public class Order extends PersistedObject {

    /**
     * It is use for transferOrder & purchaseOrder, don't use in returnOrder
     */
    private String requestId;

    /**
     * It is use for transferOrder & purchaseOrder, don't use in returnOrder
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDate;

    /**
     * It is use for transferOrder & purchaseOrder, don't use in returnOrder
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private String requestNo;

    private String requestClinicId;

    private OrderType orderType;

    @Indexed(unique = true)
    private String orderNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate orderDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate completeDate;

    private List<GoodReceivedNote> goodReceivedNotes = new ArrayList<>();

    private OrderStatus orderStatus;

    private GoodReceivedReturnStatus returnStatus;

    private String supplierId;

    private String interCompanyTransferOrderNo;

    /**
     * It is use for PurchaseOrder, don't use in transferOrder & returnOrder
     */
    private ClinicFilter clinicFilter = new ClinicFilter();

    /**
     * It is use for PurchaseOrder, don't use in transferOrder & returnOrder
     */
    private List<GoodOrderedItem> goodPurchasedItems = new ArrayList<>();

    //private List<GoodReceivedVoidNote> goodReceivedVoidNotes = new ArrayList<>();


    /**
     * It is use for transferOrder, don't use in purchaseOrder & returnOrder
     */
    private List<TransferRequestItem> transferRequestItems = new ArrayList<>();

    /**
     * It is user for returnOrder, don't use in purchaseOrder & transferOrder
     */
    private List<GoodReturnItem> returnItems = new ArrayList<>();
    /**
     * It is use for transferOrder, don't use in purchaseOrder
     */
    private String senderClinicId;
    /**
     * It is use for transferOrder & returnOrder to delivery order, don't use in purchaseOrder
     */
    private List<DeliveryNote> deliveryNotes = new ArrayList<>();

    private String remark;

    private boolean cPTransfer;

    private String blanketPO;

    private boolean interComp;

    /**
     * It is use for returnOrder, don't use in purchaseOrder & transferOrder
     */
    private NavIntegrationResult navIntegrationResult;

    /**
     * It is user for returnOrder with PO, don't use in purchaseOrder & transferOrder
     */
    private String purchaseOrderId;

    @Transient
    private String poNo;

    @Transient
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate poDate;

    private BigDecimal gstAmount;
    private BigDecimal gstPercentage;
    private Boolean gstEnabled;

    private DiscountType discountType;
    private BigDecimal discountAmount;

    public Order() {
    }

    public Order(String requestId, LocalDate requestDate, String requestNo, String requestClinicId, OrderType orderType,
                 String orderNo, LocalDate createDate, LocalDate orderDate, LocalDate completeDate, List<GoodReceivedNote> goodReceivedNotes,
                 OrderStatus orderStatus, GoodReceivedReturnStatus returnStatus, String supplierId,
                 ClinicFilter clinicFilter, List<GoodOrderedItem> goodPurchasedItems, List<TransferRequestItem> transferRequestItems,
                 List<GoodReturnItem> returnItems, String senderClinicId, List<DeliveryNote> deliveryNotes, String remark,
                 boolean cPTransfer, String blanketPO, NavIntegrationResult navIntegrationResult, String purchaseOrderId) {
        this.requestId = requestId;
        this.requestDate = requestDate;
        this.requestNo = requestNo;
        this.requestClinicId = requestClinicId;
        this.orderType = orderType;
        this.orderNo = orderNo;
        this.createDate = createDate;
        this.orderDate = orderDate;
        this.completeDate = completeDate;
        this.goodReceivedNotes = goodReceivedNotes;
        this.orderStatus = orderStatus;
        this.returnStatus = returnStatus;
        this.supplierId = supplierId;
        this.clinicFilter = clinicFilter;
        this.goodPurchasedItems = goodPurchasedItems;
        this.transferRequestItems = transferRequestItems;
        this.returnItems = returnItems;
        this.senderClinicId = senderClinicId;
        this.deliveryNotes = deliveryNotes;
        this.remark = remark;
        this.cPTransfer = cPTransfer;
        this.blanketPO = blanketPO;
        this.navIntegrationResult = navIntegrationResult;
        this.purchaseOrderId = purchaseOrderId;
    }

    public boolean checkValidate() {
        if (this.orderType == OrderType.PURCHASE) {
            return isStringValid(requestClinicId, supplierId) && goodPurchasedItems != null && goodPurchasedItems.size() > 0;
        } else if (this.orderType == OrderType.TRANSFER) {
            return isStringValid(requestClinicId, senderClinicId) && transferRequestItems != null && transferRequestItems.size() > 0;
        } else {
            return isStringValid(requestClinicId) && returnItems != null && returnItems.size() > 0;
        }

    }

    public void copy(Order order) {
        if (this.orderType == OrderType.PURCHASE) {
            this.goodPurchasedItems = order.goodPurchasedItems;
        } else if (this.orderType == OrderType.TRANSFER) {
            this.transferRequestItems = order.transferRequestItems;
        } else {
            this.returnItems = order.returnItems;
        }
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestClinicId() {
        return requestClinicId;
    }

    public void setRequestClinicId(String requestClinicId) {
        this.requestClinicId = requestClinicId;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public LocalDate getCompleteDate() {
        return completeDate;
    }

    public void setCompleteDate(LocalDate completeDate) {
        this.completeDate = completeDate;
    }

    public List<GoodReceivedNote> getGoodReceivedNotes() {
        return goodReceivedNotes;
    }

    public void setGoodReceivedNotes(List<GoodReceivedNote> goodReceivedNotes) {
        this.goodReceivedNotes = goodReceivedNotes;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public ClinicFilter getClinicFilter() {
        if (clinicFilter == null) {
            clinicFilter = new ClinicFilter();
        }
        return clinicFilter;
    }

    public void setClinicFilter(ClinicFilter clinicFilter) {
        this.clinicFilter = clinicFilter;
    }

    public List<GoodOrderedItem> getGoodPurchasedItems() {
        return goodPurchasedItems;
    }

    public void setGoodPurchasedItems(List<GoodOrderedItem> goodPurchasedItems) {
        this.goodPurchasedItems = goodPurchasedItems;
    }

    public List<TransferRequestItem> getTransferRequestItems() {
        return transferRequestItems;
    }

    public void setTransferRequestItems(List<TransferRequestItem> transferRequestItems) {
        this.transferRequestItems = transferRequestItems;
    }

    public String getSenderClinicId() {
        return senderClinicId;
    }

    public void setSenderClinicId(String senderClinicId) {
        this.senderClinicId = senderClinicId;
    }

    public GoodReceivedReturnStatus getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(GoodReceivedReturnStatus returnStatus) {
        this.returnStatus = returnStatus;
    }

    public List<GoodReturnItem> getReturnItems() {
        return returnItems;
    }

    public void setReturnItems(List<GoodReturnItem> returnItems) {
        this.returnItems = returnItems;
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    public List<DeliveryNote> getDeliveryNotes() {
        return deliveryNotes;
    }

    public void setDeliveryNotes(List<DeliveryNote> deliveryNotes) {
        this.deliveryNotes = deliveryNotes;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public String getBlanketPO() {
        return blanketPO;
    }

    public void setBlanketPO(String blanketPO) {
        this.blanketPO = blanketPO;
    }

    public boolean addNewGoodPurchasedItem(GoodOrderedItem goodOrderedItem) {
        for (GoodOrderedItem goodOrderedItem1 : goodPurchasedItems) {
            if (goodOrderedItem1.equals(goodOrderedItem)) {
                return true;
            }
        }
        return goodPurchasedItems.add(goodOrderedItem);
    }

    public boolean addNewTransferItem(TransferRequestItem transferRequestItem) {
        for (TransferRequestItem transferRequestItem1 : transferRequestItems) {
            if (transferRequestItem.equals(transferRequestItem1)) {
                return true;
            }
        }
        return transferRequestItems.add(transferRequestItem);
    }


    public boolean iscPTransfer() {
        return cPTransfer;
    }

    public void setcPTransfer(boolean cPTransfer) {
        this.cPTransfer = cPTransfer;
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public String getPoNo() {
        return poNo;
    }

    public void setPoNo(String poNo) {
        this.poNo = poNo;
    }

    public LocalDate getPoDate() {
        return poDate;
    }

    public void setPoDate(LocalDate poDate) {
        this.poDate = poDate;
    }

    public Optional<GoodReceivedNote> getGoodReceivedNoteByGrnId(String grnId) {
        return goodReceivedNotes
                .stream()
                .filter(goodReceivedNote -> goodReceivedNote.getId().equals(grnId))
                .findAny();
    }

    public void deleteGoodReceivedNote(GoodReceivedNote goodReceivedNote) {
        if (goodReceivedNotes.stream()
                .anyMatch(goodReceivedNote1 -> goodReceivedNote1.getId().equals(goodReceivedNote.getId()))) {
            goodReceivedNotes.remove(goodReceivedNote);
        }
    }

    public Optional<DeliveryNote> getDeliveryNoteByDnId(String dnId) {
        return deliveryNotes
                .stream()
                .filter(goodReceivedVoidNote -> goodReceivedVoidNote.getId().equals(dnId))
                .findAny();
    }

    public void deleteDeliveryNote(DeliveryNote deliveryNote) {
        if (deliveryNotes.stream()
                .anyMatch(goodReceivedNote1 -> goodReceivedNote1.getId().equals(deliveryNote.getId()))) {
            deliveryNotes.remove(deliveryNote);
        }
    }

    public boolean isInterComp() {
        return interComp;
    }

    public void setInterComp(boolean interComp) {
        this.interComp = interComp;
    }
    public boolean addNewReturnItem(GoodReturnItem returnItem) {
        for (GoodReturnItem returnItem1 : returnItems) {
            if (returnItem1.equals(returnItem)) {
                return true;
            }
        }
        return returnItems.add(returnItem);
    }

    public String getInterCompanyTransferOrderNo() {
        return interCompanyTransferOrderNo;
    }

    public void setInterCompanyTransferOrderNo(String interCompanyTransferOrderNo) {
        this.interCompanyTransferOrderNo = interCompanyTransferOrderNo;
    }

    public void setGstAmount(BigDecimal gstAmount) {
        this.gstAmount = gstAmount;
    }

    public BigDecimal getGstAmount() {
        return gstAmount;
    }

    public BigDecimal getGstPercentage() {
        if (gstPercentage == null) return BigDecimal.ZERO;
        return gstPercentage;
    }

    public void setGstPercentage(BigDecimal gstPercentage) {
        this.gstPercentage = gstPercentage;
    }

    public DiscountType getDiscountType() {
        return discountType;
    }

    public void setDiscountType(DiscountType discountType) {
        this.discountType = discountType;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public Boolean getGstEnabled() {
        return gstEnabled;
    }

    public void setGstEnabled(Boolean gstEnabled) {
        this.gstEnabled = gstEnabled;
    }

    @Override
    public String toString() {
        return "Order{" +
                "requestId='" + requestId + '\'' +
                ", requestDate=" + requestDate +
                ", requestNo='" + requestNo + '\'' +
                ", requestClinicId='" + requestClinicId + '\'' +
                ", orderType=" + orderType +
                ", orderNo='" + orderNo + '\'' +
                ", createDate=" + createDate +
                ", orderDate=" + orderDate +
                ", completeDate=" + completeDate +
                ", goodReceivedNotes=" + goodReceivedNotes +
                ", orderStatus=" + orderStatus +
                ", returnStatus=" + returnStatus +
                ", supplierId='" + supplierId + '\'' +
                ", interCompanyTransferOrderNo='" + interCompanyTransferOrderNo + '\'' +
                ", clinicFilter=" + clinicFilter +
                ", goodPurchasedItems=" + goodPurchasedItems +
                ", transferRequestItems=" + transferRequestItems +
                ", returnItems=" + returnItems +
                ", senderClinicId='" + senderClinicId + '\'' +
                ", deliveryNotes=" + deliveryNotes +
                ", remark='" + remark + '\'' +
                ", cPTransfer=" + cPTransfer +
                ", blanketPO='" + blanketPO + '\'' +
                ", interComp=" + interComp +
                ", navIntegrationResult=" + navIntegrationResult +
                ", purchaseOrderId='" + purchaseOrderId + '\'' +
                ", poNo='" + poNo + '\'' +
                ", poDate=" + poDate +
                ", gstAmount=" + gstAmount +
                ", discountType=" + discountType +
                ", discountAmount=" + discountAmount +
                ", id='" + id + '\'' +
                ", gstPercentage=" + gstPercentage +
                ", gstEnabled=" + gstEnabled +
                '}';
    }

    public enum DiscountType {
        PERCENTAGE, DOLLAR
    }
}
