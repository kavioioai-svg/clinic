package com.ilt.cms.inventory.svc.db.repository.spring.inventory;

import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface DisposeOffStockRepository extends MongoRepository<DisposeItem, String> {

    Optional<DisposeItem> findByItemIdAndClinicIdAndBatchNo(String itemId, String clinicId, String batchNo);

    Optional<DisposeItem> findByItemIdAndClinicId(String itemId, String clinicId);

	List<DisposeItem> findByLastModifiedDateBetween(LocalDateTime start, LocalDateTime end);

	Page<DisposeItem> findByLastModifiedDateGreaterThan(LocalDateTime localDateTime, Pageable pageable);
}