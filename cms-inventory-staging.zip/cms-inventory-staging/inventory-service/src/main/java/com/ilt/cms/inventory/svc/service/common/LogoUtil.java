package com.ilt.cms.inventory.svc.service.common;

import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.system.SystemStore;
import com.ilt.cms.database.store.SystemStoreDatabaseService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class LogoUtil {

    private final SystemStoreDatabaseService systemStoreDatabaseService;

    public LogoUtil(SystemStoreDatabaseService systemStoreDatabaseService) {
        this.systemStoreDatabaseService = systemStoreDatabaseService;
    }

    public String getClinicLogoInBase64(Clinic clinic, ClinicLogoType logoType) {

        Optional<SystemStore> clinicLogoStoreOpt = systemStoreDatabaseService.findByKey(clinic.getClinicLogo());

        String encodedClinicLogo = null;
        if (clinicLogoStoreOpt.isPresent()) {
            SystemStore clinicLogoStore = clinicLogoStoreOpt.get();
            encodedClinicLogo = ((List<Map<String, String>>) clinicLogoStore.getValues()).get(0).get(logoType.toString());
        }
        return encodedClinicLogo;
    }

    public enum ClinicLogoType {
        BLACK_AND_WHITE, COLOR, COLOR_ON_BACKGROUND
    }
}
