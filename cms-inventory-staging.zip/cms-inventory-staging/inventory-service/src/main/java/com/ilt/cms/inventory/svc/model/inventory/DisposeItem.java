package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.audit.AuditableEntity;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Objects;

@AuditableEntity
public class DisposeItem extends PersistedObject {

    private String entryNo;

    private String itemId;

    private String clinicId;

    private String cpRemark;

    private String remark;

    private DisposeStatus disposeStatus;

    private int quantity;

    private String batchNo;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate disposalRequestDate;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern= CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate disposedDate;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public LocalDate getDisposalRequestDate() {
        return disposalRequestDate;
    }

    public void setDisposalRequestDate(LocalDate disposalRequestDate) {
        this.disposalRequestDate = disposalRequestDate;
    }

    public LocalDate getDisposedDate() {
        return disposedDate;
    }

    public void setDisposedDate(LocalDate disposedDate) {
        this.disposedDate = disposedDate;
    }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public DisposeStatus getDisposeStatus() {
        return disposeStatus;
    }

    public void setDisposeStatus(DisposeStatus disposeStatus) {
        this.disposeStatus = disposeStatus;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getCpRemark() {
        return cpRemark;
    }

    public void setCpRemark(String cpRemark) {
        this.cpRemark = cpRemark;
    }

    public String getEntryNo() { return entryNo; }

    public void setEntryNo(String entryNo) { this.entryNo = entryNo;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DisposeItem that = (DisposeItem) o;
        return itemId.equals(that.itemId) && clinicId.equals(that.clinicId) && Objects.equals(batchNo, that.batchNo);
    }
    @Override
    public int hashCode() {
        return Objects.hash(itemId, clinicId, batchNo);
    }
}
