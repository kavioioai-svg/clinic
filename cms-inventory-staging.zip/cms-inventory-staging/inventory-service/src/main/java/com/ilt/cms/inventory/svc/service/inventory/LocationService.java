package com.ilt.cms.inventory.svc.service.inventory;

import ca.uhn.hl7v2.util.StringUtil;
import com.ilt.cms.core.entity.Clinic;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.casem.Case;
import com.ilt.cms.core.entity.casem.SalesItem;
import com.ilt.cms.core.entity.casem.SalesItemAdj;
import com.ilt.cms.core.entity.inventory.InventoryTransaction;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.medical.DispatchItem;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.inventory.LocationInventoryRepository;
import com.ilt.cms.inventory.svc.mapper.LocationMapper;
import com.ilt.cms.inventory.svc.model.inventory.*;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockAlertType;
import com.ilt.cms.inventory.svc.model.purchase.DeliveryItem;
import com.ilt.cms.inventory.svc.model.purchase.GoodReturnItem;
import com.ilt.cms.inventory.svc.service.common.InventoryUtilsService;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.dto.BillAdjustmentUpdate;
import com.ilt.cms.inventory.svc.service.nav.InventoryService;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class LocationService {

    private static final Logger logger = LoggerFactory.getLogger(LocationService.class);

    private final SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    private static final String CLINIC_ID = "clinicId";
    private static final String BATCH_NUMBER = "batchNumber";
    private static final String ITEM_REF_ID = "itemRefId";
    private static final String AVAILABLE_COUNT = "availableCount";

    private final LocationInventoryRepository locationInventoryRepository;
    private final InventoryTransactionRepository inventoryTransactionRepository;

    private final DrugItemService drugItemService;

    private final UOMMatrixService uomMatrixService;

    private final ItemDatabaseService itemDatabaseService;

    private final SupplierDatabaseService supplierDatabaseService;

    private final InventoryService inventoryService;
    private final InventoryUtilsService inventoryUtilsService;

    @Value("${use.nav.inventory:false}")
    private boolean useNavInventory;

    private final MongoTemplate mongoTemplate;
    private final ClinicRepository clinicRepository;
    private final CaseRepository caseRepository;

    public LocationService(LocationInventoryRepository locationInventoryRepository, DrugItemService drugItemService,
                           UOMMatrixService uomMatrixService, ItemDatabaseService itemDatabaseService,
                           SupplierDatabaseService supplierDatabaseService, InventoryService inventoryService,
                           MongoTemplate mongoTemplate, InventoryTransactionRepository inventoryTransactionRepository,
                           InventoryUtilsService inventoryUtilsService, ClinicRepository clinicRepository,
                           CaseRepository caseRepository) {
        this.locationInventoryRepository = locationInventoryRepository;
        this.drugItemService = drugItemService;
        this.uomMatrixService = uomMatrixService;
        this.itemDatabaseService = itemDatabaseService;
        this.supplierDatabaseService = supplierDatabaseService;
        this.inventoryService = inventoryService;
        this.mongoTemplate = mongoTemplate;
        this.inventoryTransactionRepository = inventoryTransactionRepository;
        this.inventoryUtilsService = inventoryUtilsService;
        this.clinicRepository = clinicRepository;
        this.caseRepository = caseRepository;
    }

    public Location saveLocation(Location location) throws CMSException {

        logger.info("saveLocation[" + location + "] useNavInventory[" + useNavInventory + "]");
        if (useNavInventory) {
            return location;
        }

        locationInventoryRepository.saveAll(LocationInventories.fromLocation(location));
        return findLocationByClinicId(location.getClinicId()).get();
    }

    public Location modifyLocation(String locationId, Location location) throws CMSException {

        logger.info("ModifyLocation to location[" + locationId + "] and useNavInventory[" + useNavInventory + "]");
        if (useNavInventory) {
            logger.info("useNavInventory [" + useNavInventory + "]");
            return location;
        }

        locationInventoryRepository.deleteAllByClinicId(locationId);

        return saveLocation(location);
    }

    public List<InventoryTransaction> findAndModify(Location location, final boolean sendingDifference, boolean updatePurchasePrice) throws CMSException {

        if (location.getInventory() == null || location.getInventory().isEmpty()) {
            logger.info("No inventory information available to save[" + location + "]");
            return new ArrayList<>();
        }

        logger.info("findAndModify location[" + location + "] useNavInventory[" + useNavInventory + "]");

        List<LocationInventory> locationInventories = LocationInventories.fromLocation(location);
        return findAndModify(locationInventories, sendingDifference, updatePurchasePrice);
    }

    public List<InventoryTransaction> findAndModify(List<LocationInventory> locationInventories, boolean sendingDifference, boolean updatePurchasePrice) {
        Date currDate = new Date();
        if (locationInventories == null || locationInventories.isEmpty()) {
            logger.info("No inventory information available to save[" + locationInventories + "]");
            return new ArrayList<>();
        }
        return locationInventories
                .stream()
                .map(locationInventory -> {
                    Criteria criteria = Criteria.where(CLINIC_ID).is(locationInventory.getClinicId())
                            .and(ITEM_REF_ID).is(locationInventory.getItemRefId());
                    if (locationInventory.isTrackingCode()) {
                        criteria.and(BATCH_NUMBER).is(locationInventory.getBatchNumber());
                    }
                    logger.info("Inventory information to be  saved [" + locationInventory + "]");
                    Update updateObject = createUpdateObject(locationInventory, sendingDifference, currDate, locationInventory.isTrackingCode());
                    LocationInventory updatedInv = mongoTemplate.findAndModify(new Query(criteria), updateObject,
                            new FindAndModifyOptions().upsert(true), LocationInventory.class);
                    logger.info("Inventory database record before updating quantity [" + updatedInv + "]");

                    return mapInventoryTransactionAndUpdatePurchasePrice(locationInventory, updatedInv, sendingDifference, updatePurchasePrice);
                })
                .collect(Collectors.toList());
    }

    private InventoryTransaction mapInventoryTransactionAndUpdatePurchasePrice(LocationInventory locationInventory, LocationInventory updatedInv,
                                                                               boolean sendingDifferance, boolean updatePurchasePrice) {
        InventoryTransaction inventoryTransaction = new InventoryTransaction();
        inventoryTransaction.setDelta(locationInventory.getAvailableCount());
        inventoryTransaction.setItemRefId(updatedInv != null ? updatedInv.getItemRefId() : locationInventory.getItemRefId());
        InventoryTransaction.TransactionType transactionType = locationInventory.getAvailableCount().compareTo(BigDecimal.ZERO) > 0 ?
                InventoryTransaction.TransactionType.POSITIVE_ADJMT : InventoryTransaction.TransactionType.NEGATIVE_ADJMT;
        inventoryTransaction.setTransactionType(transactionType);
        inventoryTransaction.setBatchNumber(updatedInv != null ? updatedInv.getBatchNumber() : locationInventory.getBatchNumber());
        inventoryTransaction.setClinicId(updatedInv != null ? updatedInv.getClinicId() : locationInventory.getClinicId());
        BigDecimal purchasePrice = BigDecimal.ZERO;
        if (updatedInv != null) {
            inventoryTransaction.setPreviousCount(updatedInv.getAvailableCount());
            if (updatePurchasePrice) {
                BigDecimal averagePrice = findAveragePrice(locationInventory, updatedInv);
                updatePurchasePrice(locationInventory, averagePrice);
                purchasePrice = averagePrice;
            } else {
                purchasePrice = updatedInv.getBatchPrice();
            }
        }

        inventoryTransaction.setReplacedEntity(!sendingDifferance);
        inventoryTransaction.setBatchPrice((locationInventory.getBatchPrice() == null ? ((purchasePrice == null || purchasePrice.compareTo(BigDecimal.ZERO) == 0) ? BigDecimal.ZERO  : purchasePrice ): locationInventory.getBatchPrice()));
        return inventoryTransaction;
    }

    public BigDecimal findAveragePrice(LocationInventory locationInventory, LocationInventory updatedInv) {
        if (updatedInv.getBatchPrice() == null || updatedInv.getAvailableCount() == null || updatedInv.getAvailableCount().compareTo(BigDecimal.ZERO) == 0) {
            return locationInventory.getBatchPrice();
        }

        BigDecimal totalInventoryValue = updatedInv.getAvailableCount().abs().multiply(updatedInv.getBatchPrice()).add(
                locationInventory.getAvailableCount().multiply(locationInventory.getBatchPrice()));
        return totalInventoryValue.divide(updatedInv.getAvailableCount().abs().add(locationInventory.getAvailableCount()), 4, RoundingMode.HALF_UP);
    }

    private void updatePurchasePrice(LocationInventory locationInventory, BigDecimal averagePrice) {
        Criteria criteria = Criteria.where(CLINIC_ID).is(locationInventory.getClinicId())
                .and(ITEM_REF_ID).is(locationInventory.getItemRefId());
        if (locationInventory.isTrackingCode()) {
            criteria.and(BATCH_NUMBER).is(locationInventory.getBatchNumber());
        }
        mongoTemplate.updateFirst(new Query(criteria), new Update().set("batchPrice", averagePrice),
                LocationInventory.class);
    }

    private static Update createUpdateObject(LocationInventory locationInventory, boolean sendingDifference, Date currentDate, boolean trackingCode) {
        Update update = new Update()
                .set(CLINIC_ID, locationInventory.getClinicId())
                .set(ITEM_REF_ID, locationInventory.getItemRefId())
                .set("lastModifiedDate", currentDate)
                .setOnInsert("createdDate", currentDate);

        if (trackingCode) {
            update.set(BATCH_NUMBER, locationInventory.getBatchNumber());
            setIfNotNull(locationInventory.getExpiryDate(), update, "expiryDate");
        }
        setIfNotNull(locationInventory.getManufacturerDate(), update, "manufacturerDate");
        setIfNotNull(locationInventory.getBaseUom(), update, "baseUom");
        setIfNotNull(locationInventory.getBatchPrice(), update, "batchPrice");

        if (sendingDifference) {
            update.inc("availableCount", locationInventory.getAvailableCount());
        } else {
            update.set("availableCount", locationInventory.getAvailableCount());
        }
        return update;
    }

    private static void setIfNotNull(String string, Update update, String field) {
        if (CommonUtils.isStringValid(string)) {
            update.set(field, string);
        }
    }

    private static void setIfNotNull(Object obj, Update update, String field) {
        if (obj != null) {
            update.set(field, obj);
        }
    }

    public Optional<Location> findLocationByClinicId(String clinicId) throws CMSException {

        logger.info("findLocationByClinicId by clinic[" + clinicId + "] and useNavInventory[" + useNavInventory + "]");
        String clinicGroupName = inventoryUtilsService.getClinicGroupName(clinicId);
        List<Item> inventoriedItems = itemDatabaseService.findAll(Set.of(clinicId), Set.of(clinicGroupName))
                .stream()
                .filter(Item::isInventoried)
                .collect(Collectors.toList());

        return findLocationByClinicId(clinicId, inventoriedItems);
    }

    public Optional<Location> findLocationByClinicIdIncludingZeroQtyInventories(String clinicId, List<Item> items) throws CMSException {

        logger.info("findLocationByClinicId by clinic[" + clinicId + "] and items size[" + items.size() + "] and useNavInventory[" + useNavInventory + "]");
        if (useNavInventory) {
            return findLocationByClinicIdIfNavAvailable(clinicId, items);
        } else {
            List<LocationInventory> allByClinicId = locationInventoryRepository.findAllByClinicId(clinicId);
            return Optional.of(LocationInventories.toLocation(allByClinicId));
        }
    }

    public Optional<Location> findLocationByClinicId(String clinicId, List<Item> items) throws CMSException {

        logger.info("findLocationByClinicId by clinic[" + clinicId + "] and items size[" + items.size() + "] and useNavInventory[" + useNavInventory + "]");
        if (useNavInventory) {
            return findLocationByClinicIdIfNavAvailable(clinicId, items);
        } else {
            List<LocationInventory> allByClinicId = locationInventoryRepository
                    .findAllByClinicIdAndAvailableCountIsGreaterThanAndItemRefIdIn(clinicId, BigDecimal.ZERO, items.stream()
                            .map(PersistedObject::getId)
                            .collect(Collectors.toList()));
            return Optional.of(LocationInventories.toLocation(allByClinicId));
        }
    }

    public Optional<Location> findLocationByClinicIdIfNavAvailable(String clinicId, List<Item> items) {
        List<Inventory> inventories = new ArrayList<>();
        List<Item> inventoriedItems = items.stream()
                .filter(Item::isInventoried)
                .collect(Collectors.toList());

        Map<String, List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData>> inventoryDataListMap = inventoryService.fireNavInventoryApi(clinicId, inventoriedItems)
                .stream()
                .collect(Collectors.groupingBy(ItemChargeDetail.ItemChargeDetailResponse.InventoryData::getItemId));

        inventoriedItems.forEach(item -> {
            if (!inventoryDataListMap.containsKey(item.getId())) {
                ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData1 = new ItemChargeDetail.ItemChargeDetailResponse.InventoryData();
                inventoryData1.setItemId(item.getId());
                inventoryData1.setBaseUom(item.getBaseUom());
                inventories.add(LocationMapper.mapToInventory(inventoryData1));
            } else {
                for (ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData1 : inventoryDataListMap.get(item.getId())) {
                    inventories.add(LocationMapper.mapToInventory(inventoryData1));
                }
            }
        });

        Location location = new Location(clinicId);
        location.setInventory(inventories);
        return Optional.of(location);
    }

    public Map<String, Double> findInventoryQuantityByClinicIdAndItemCodeAndUom(String clinicId, Map<String, String> itemUomMap) throws CMSException {

        logger.info("find inventory clinicId[" + clinicId + "], itemUomMap[" + itemUomMap + "], useNavInventory[" + useNavInventory + "]");

        List<Item> items = drugItemService.listItemByClinicId(clinicId).stream()
                .filter(item -> itemUomMap.containsKey(item.getId()))
                .collect(Collectors.toList());

        Location location = findLocationByClinicId(clinicId, items)
                .orElse(new Location(clinicId));
        LocalDate now = LocalDate.now();
        Collector<Inventory, ?, Double> sumByAvailableQtyInUom = Collectors.summingDouble(value -> {
            double ratio;
            try {
                ratio = uomMatrixService.findReverseRatio(value.getBaseUom(), itemUomMap.get(value.getItemRefId()));
            } catch (CMSException e) {
                logger.error("Find ratio error, baseUom[" + value.getBaseUom() + "], new uom[" + itemUomMap.get(value.getItemRefId()) + "]");
                throw new RuntimeException("Find ratio error[" + e.getMessage() + "] for item[" + value.getItemCode() + "]");
            }
            return (1 / ratio) * value.getAvailableCount().doubleValue();
        });

        Map<String, Double> itemCount = new HashMap<>(location.getInventory()
                .stream()
                .filter(inventory -> inventory.getExpiryDate() == null || inventory.getExpiryDate().isAfter(now))
                .collect(Collectors.groupingBy(Inventory::getItemRefId, sumByAvailableQtyInUom)));
        items.forEach(item -> itemCount.putIfAbsent(item.getId(), 0d));
        return itemCount;
    }

    public List<Inventory> listInventoryByItemId(String clinicId, List<String> itemIds) throws CMSException {
        //TODO: Remove use of inventory and Location as they are no longer persistent objects
        logger.info("listInventoryByItemId, clinic[" + clinicId + "], itemIds[" + itemIds + "], useNavInventory[" + useNavInventory + "]");
        if (useNavInventory) {
            List<Item> items = itemDatabaseService.findItemsByIds(itemIds);
            if (items != null && items.size() > 0) {
                List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> inventoryDataList =
                        inventoryService.fireNavInventoryApi(clinicId, items);
                logger.debug("inventoryDataList retrieved size[{}]", inventoryDataList.size());

                return inventoryDataList.stream()
                        .map(inventoryData -> LocationMapper.mapToInventory(inventoryData))
                        .collect(Collectors.toList());
            }
            logger.warn("Cannot find Item by ids[" + itemIds + "]");
            return Collections.emptyList();
        } else {
            Map<String, Item> items = itemDatabaseService.findItemsByIds(itemIds)
                    .stream()
                    .collect(Collectors.toMap(Item::getId, item -> item));
            Location location = findLocationByClinicId(clinicId)
                    .orElseGet(() -> new Location(clinicId));
            return location.getInventory().stream()
                    .filter(inventory -> itemIds.contains(inventory.getItemRefId()) &&
                            (inventory.getExpiryDate() == null || inventory.getExpiryDate().isAfter(LocalDate.now())))
                    .map(inventory -> mapInventoryDetails(inventory, items.get(inventory.getItemRefId())))
                    .collect(Collectors.toList());
        }
    }

    public Inventory searchInventoryByItemCode(String clinicId, String itemCode, String batchNo) throws CMSException {

        logger.info("searchInventoryByItemCode, clinicId[" + clinicId + "], itemCode[" + itemCode + "], batchNo[" + batchNo + "]");
        Item item = itemDatabaseService.findByClinicIdAndCode(clinicId, itemCode)
                .orElseThrow(() -> {
                    logger.error("Item[" + itemCode + "] not found for clinic[" + clinicId + "]");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });

        if (!item.isInventoried()) {
            logger.error("Not allow item[" + itemCode + "] to store inventory");
            throw new CMSException(StatusCode.E1010, "Not allow item to store inventory");
        }

        if (useNavInventory) {

            List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> inventoryDataList = inventoryService.fireNavInventoryApi(clinicId, Arrays.asList(item));
            List<Inventory> inventories = inventoryDataList.stream()
                    .filter(inventoryData -> inventoryData.getBatchNo().equals(batchNo))
                    .map(inventoryData -> LocationMapper.mapToInventory(inventoryData))
                    .collect(Collectors.toList());
//            int availableCount = inventories.stream().collect(Collectors.summingInt(Inventory::getAvailableCount));
            int availableCount = inventories.stream().collect(Collectors.summingInt(inventory -> inventory.getAvailableCountInt()));
//            Inventory inventory = inventories.stream().findFirst().orElseGet(() -> new Inventory(item.getId(), batchNo, item.getBaseUom(), null, null,
//                    0));
//            inventory.setAvailableCount(availableCount);
            Inventory inventory = inventories.stream().findFirst().orElseGet(() -> new Inventory(item.getId(), batchNo, item.getBaseUom(), null, null,
                    BigDecimal.ZERO, item.isTrackingCode()));
            inventory.setAvailableCount(BigDecimal.valueOf(availableCount));
            inventory.setItemName(item.getName());
            inventory.setItemCode(item.getCode());
            return inventory;
        } else {

            Optional<Location> locationOpt = findLocationByClinicId(clinicId);
            if (locationOpt.isPresent()) {
                Location location = locationOpt.get();
                Optional<Inventory> inventoryOpt = location.getInventory().stream()
                        .filter(inventory -> inventory.getItemRefId().equals(item.getId())
                                && inventory.getBatchNumber().equals(batchNo))
                        .findFirst();
                if (inventoryOpt.isPresent()) {
                    inventoryOpt.get().setItemCode(item.getCode());
                    inventoryOpt.get().setItemName(item.getName());
                    return inventoryOpt.get();
                }
            }

            return new Inventory(item.getId(), batchNo, item.getBaseUom(), null, null,
                    BigDecimal.ZERO, item.isTrackingCode());
        }
    }

    public List<Inventory> searchInventory(String clinicId, String itemType, String stockAlert, String itemNameRegex,
                                           String supplierNameRegex, String itemCodeRegex, String commonRegex) throws CMSException {
        logger.info("search inventory by clinicId[" + clinicId + "], itemType[" + itemType + "]," +
                " stockAlert[" + stockAlert + "], itemNameRegex[" + itemNameRegex + "], " +
                "supplierNameRegex[" + supplierNameRegex + "], itemCodeRegex[" + itemCodeRegex + "]");

        List<Item> items;
        List<Inventory> inventories = new ArrayList<>();

		boolean searchByAnything = CommonUtils.isStringValid(commonRegex);
		boolean searchByCode = CommonUtils.isStringValid(itemCodeRegex);
        boolean searchByName = CommonUtils.isStringValid(itemNameRegex);
        boolean searchByVendor = CommonUtils.isStringValid(supplierNameRegex);

        String groupName = inventoryUtilsService.getClinicGroupName(clinicId);

        if (searchByAnything) {
            List<Item> allItems = itemDatabaseService.findInventoriedActiveItemByNameAndCodeRegEx(List.of(clinicId), commonRegex, List.of(groupName));
            items = allItems.stream()
                .filter(item -> itemType.equals("ALL") || itemType.equals(item.getItemType().name()))
				.collect(Collectors.toList());
            if (items.isEmpty()) {
                supplierNameRegex = commonRegex;
                items = allItems;
            }
		} else if (searchByCode) {
            items = itemDatabaseService.findInventoriedActiveItemByCodeRegEx(List.of(clinicId), itemCodeRegex, List.of(groupName)).stream()
                    .filter(item -> itemType.equals("ALL") || item.getCode().equals(itemCodeRegex))
                    .collect(Collectors.toList());
        } else if (searchByName) {
            items = itemDatabaseService.findInventoriedActiveItemByNameRegEx(List.of(clinicId), itemNameRegex, List.of(groupName)).stream()
                    .filter(item -> itemType.equals("ALL") || item.getName().equals(itemNameRegex))
                    .collect(Collectors.toList());
        } else {
            items = itemDatabaseService.findInventoriedActiveItems(List.of(clinicId), List.of(groupName)).stream()
                    .filter(item -> itemType.equals("ALL") || itemType.equals(item.getItemType().name()))
                    .collect(Collectors.toList());
        }

        if (items.isEmpty() && searchByAnything && searchByVendor) {
            items = itemDatabaseService.findInventoriedActiveItems(List.of(clinicId), List.of(groupName)).stream()
                    .filter(item -> itemType.equals("ALL") || itemType.equals(item.getItemType().name()))
                    .collect(Collectors.toList());
        }

        logger.debug("item total size[" + items.size() + "]");
        if (items.isEmpty()) {
            return inventories;
        }

        if (supplierNameRegex != null) {
            List<Supplier> suppliers = supplierDatabaseService.findAllByNameRegex(supplierNameRegex);
            logger.debug("suppliers size [" + suppliers.size() + "] for supplierNameRegex[" + supplierNameRegex + "]");
            List<String> supplierIds = suppliers.stream()
                    .map(Supplier::getId)
                    .collect(Collectors.toList());

            if (supplierIds.size() > 0) {
                List<Item> supplierItems = new ArrayList<>();
                List<PurchaseItem> purchaseItems = suppliers.stream()
                        .flatMap(supplier -> supplier.getItems().stream())
                        .collect(Collectors.toList());
                for (Item item : items) {
                    purchaseItems.stream()
                            .filter(purchaseItem -> purchaseItem.getItemId().equals(item.getId()))
                            .findFirst().ifPresentOrElse(
                                    purchaseItem -> {
                                        supplierItems.add(item);
                                    },
                                    () -> {
                                        logger.debug("item[" + item.getId() + "] is not in supplier purchaseItems list");
                                    }
                            );
                }
                logger.info("Filter supplier item size [" + items.size() + "]");
                items = supplierItems;
            } else {
                items = new ArrayList<>();
            }
        }

        logger.debug("item total size[" + items.size() + "]");
        if (items.isEmpty()) {
            return inventories;
        }

        if (useNavInventory) {
            Map<String, List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData>> inventoryDataListMap = inventoryService.fireNavInventoryApi(clinicId, items)
                    .stream()
                    .collect(Collectors.groupingBy(ItemChargeDetail.ItemChargeDetailResponse.InventoryData::getItemId));

            for (Item item : items) {
                if (!inventoryDataListMap.containsKey(item.getId())) {
                    ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData1 = new ItemChargeDetail.ItemChargeDetailResponse.InventoryData();
                    inventoryData1.setItemId(item.getId());
                    inventories.add(LocationMapper.mapToInventory(inventoryData1));
                } else {
                    for (ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData1 : inventoryDataListMap.get(item.getId())) {
                        inventories.add(LocationMapper.mapToInventory(inventoryData1));
                    }
                }
            }
        } else {
            Location location = findLocationByClinicId(clinicId)
                    .orElse(new Location(clinicId));
            inventories = location.getInventory();

            Set<String> itemIds = inventories.stream().map(Inventory::getItemRefId).collect(Collectors.toSet());

            for (Item item : items) {
                if (!itemIds.contains(item.getId())) {
                    Inventory inventory = new Inventory(item.getId(), null, item.getBaseUom(), null, null,
                            BigDecimal.ZERO, item.isTrackingCode());
                    inventory.setItemName(item.getName());
                    inventory.setItemCode(item.getCode());
                    inventories.add(inventory);
                }
            }

            inventories = inventories.stream()
                    .peek(i -> i.setBaseUomQuantity(i.getAvailableCountInt()))
                    .collect(Collectors.toList());
        }

        LocalDate navDefaultDate = LocalDate.of(0000, 12, 31);
        if (StockAlertType.EXPIRY.name().equals(stockAlert)) {
            inventories = inventories.stream()
                    .filter(inventory -> {
                        return inventory.getExpiryDate() != null
                                && inventory.getExpiryDate().isBefore(LocalDate.now()) && !inventory.getExpiryDate().equals(navDefaultDate);
                    })
                    .collect(Collectors.toList());
        }
        if (StockAlertType.INVENTORY_NON_ZERO.name().equals(stockAlert)) {

            inventories = inventories.stream()
//                    .filter(inventory -> inventory.getAvailableCount() > 0)
                    .filter(inventory -> inventory.getAvailableCount().compareTo(BigDecimal.ZERO) > 0)
                    .collect(Collectors.toList());
        }
        if (StockAlertType.EXPIRY_WITHIN_3_MONTH.name().equals(stockAlert)) {

            inventories = inventories.stream()
                    .filter(inventory -> inventory.getExpiryDate() != null
                            && inventory.getExpiryDate().isBefore(LocalDate.now().plusMonths(3))
                            && inventory.getExpiryDate().isAfter(LocalDate.now().minusDays(1))
                            && !inventory.getExpiryDate().equals(navDefaultDate))
                    .collect(Collectors.toList());
        }
        if (StockAlertType.EXPIRY_WITHIN_6_MONTH.name().equals(stockAlert)) {

            inventories = inventories.stream()
                    .filter(inventory -> inventory.getExpiryDate() != null
                            && inventory.getExpiryDate().isBefore(LocalDate.now().plusMonths(6))
                            && inventory.getExpiryDate().isAfter(LocalDate.now().minusDays(1))
                            && !inventory.getExpiryDate().equals(navDefaultDate))
                    .collect(Collectors.toList());
        }

        return prepareDrugInventory(inventories, items);
    }

    private List<Inventory> prepareDrugInventory(List<Inventory> inventories, List<Item> items) {

        List<Inventory> searchInventories = items.stream().flatMap(item ->
                        inventories.stream()
                                .filter(i -> Objects.equals(item.getId(), i.getItemRefId())))
                .collect(Collectors.toList());

        searchInventories.forEach(
                inventory -> {
                    Optional<Item> drugItemOpt = items.stream()
                            .filter(drugItem -> inventory.getItemRefId().equals(drugItem.getId()))
                            .findFirst();
                    if (drugItemOpt.isPresent()) {
                        inventory.setItemName(drugItemOpt.get().getName());
                        inventory.setItemCode(drugItemOpt.get().getCode());
                    }
                }
        );

        Comparator<Inventory> compareInventory = Comparator
                .comparing(Inventory::getItemName, Comparator.nullsLast(Comparator.naturalOrder()))
                .thenComparing(Inventory::getBatchNumber, Comparator.nullsLast(Comparator.naturalOrder()));

        searchInventories = searchInventories.stream()
                .sorted(compareInventory)
                .collect(Collectors.toList());
        return searchInventories;
    }

    private Map<String, Integer> getClinicInventoryStockMap(String clinicId, List<Inventory> inventories) throws CMSException {

        Map<String, List<Inventory>> itemInventoryMap;
        if (useNavInventory) {
            itemInventoryMap = inventories.stream().collect(Collectors.groupingBy(Inventory::getItemRefId));
        } else {
            itemInventoryMap = findLocationByClinicId(clinicId)
                    .orElse(new Location(clinicId))
                    .getInventory().stream()
                    .collect(Collectors.groupingBy(Inventory::getItemRefId));
        }

        Map<String, Integer> itemStockLevelMap = new HashMap<>();

        itemInventoryMap.keySet().forEach(
                key -> {
                    itemInventoryMap.compute(key, (itemId, inventoryList) -> {

                        itemStockLevelMap.put(itemId, inventoryList.stream()
                                .filter(inventory -> inventory.getExpiryDate() == null || inventory.getExpiryDate().isAfter(LocalDate.now()))
                                .mapToInt(inventory -> inventory.getAvailableCountInt())
                                .sum());
                        return inventoryList;
                    });
                }
        );
        return itemStockLevelMap;
    }

    public void updateItemUsage(List<InventoryUsage> usages, String clinicId, String visitId) throws CMSException {
        Location location = new Location(clinicId);
        List<Inventory> inventories = usages.stream()
                .map(usage -> {
                    try {
                        return LocationMapper.mapUsageToInventory(usage, getUOMRatio(usage));
                    } catch (CMSException e) {
                        logger.error("mapUsageToInventory[" + usage + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());

        location.setInventory(inventories);
        List<InventoryTransaction> inventoryTransactionList = findAndModify(location, true, false);
        saveInventoryTransactions(inventoryTransactionList, visitId, InventoryTransaction.Type.DISPENSING);
    }

    public void saveInventoryTransactions(List<InventoryTransaction> inventoryTransactionList, String refId, InventoryTransaction.Type type) {
        inventoryTransactionList.stream()
                .forEach(transactions -> {
                    transactions.setType(type);
                    transactions.setRefNumber(refId);
                });
        inventoryTransactionRepository.saveAll(inventoryTransactionList);
    }

    public void validateInventoryUsage(List<InventoryUsage> usages, String clinicId) throws CMSException {
        final List<String> itemIds = usages.stream()
                .map(InventoryUsage::getItemId)
                .collect(Collectors.toList());
        final Map<String, Item> items = itemDatabaseService.findItemsByIds(itemIds)
                .stream()
                .collect(Collectors.toMap(Item::getId, item -> item));

        final Map<String, List<LocationInventory>> inventoryMap = locationInventoryRepository.findAllByClinicIdAndItemRefIdIn(clinicId, itemIds)
                .stream()
                .collect(Collectors.groupingBy(LocationInventory::getItemRefId));

        for (InventoryUsage usage : usages) {
            double uomRatio = getUOMRatio(usage);
            BigDecimal usageQuantity = BigDecimal.valueOf(uomRatio * usage.getQuantity());
            List<LocationInventory> itemInventoryList = inventoryMap.get(usage.getItemId());
            Item item = items.get(usage.getItemId());
            Optional<LocationInventory> inventoryOpt = itemInventoryList.stream()
                    .filter(itemInventory -> !item.isTrackingCode() || (itemInventory.getBatchNumber() != null &&
                            itemInventory.getBatchNumber().equals(usage.getBatchNo())))
                    .filter(itemInventory -> itemInventory.getAvailableCount().compareTo(usageQuantity) >= 0)
                    .findFirst();

            if (inventoryOpt.isEmpty()) {
                throw new CMSException(StatusCode.E1010, "Insufficient inventory to dispense for item " + item.getCode() +
                        (item.isTrackingCode() ? " of batch " + usage.getBatchNo() : ""));
            }
            BigDecimal inventoryCount = inventoryOpt.get().getAvailableCount();
            inventoryOpt.get().setAvailableCount(inventoryCount.subtract(usageQuantity));
        }
    }

    public Inventory mapDeliveryItemToInventory(Optional<DeliveryItem> previousDeliveryItem, DeliveryItem deliveryItem, boolean isCorrection) throws CMSException {

        Item item = itemDatabaseService.findById(deliveryItem.getItemRefId())
                .orElseThrow(() -> {
                    logger.error("Item[" + deliveryItem.getItemRefId() + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });
        if (item == null) {
            logger.error("Item not found, itemId[" + deliveryItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "item not found");
        }
        if (item.getBaseUom() == null) {
            logger.error("Base uom not found for item[" + deliveryItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "Item's base uom not found");
        }
        Double ratio;
        try {
            if (!useNavInventory) {
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), deliveryItem.getUom());
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + deliveryItem.getUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

        double availableCount = ratio * deliveryItem.getQuantity();

        if (isCorrection && previousDeliveryItem.isPresent()) {
            availableCount = deliveryItem.getQuantity() - ratio * previousDeliveryItem.get().getQuantity();
        }

        BigDecimal purchasePrice = deliveryItem.getPurchasePrice() != null && !deliveryItem.getPurchasePrice().equals(BigDecimal.ZERO)
                && availableCount > 0 ? deliveryItem.getPurchasePrice().divide(BigDecimal.valueOf(availableCount), 4, RoundingMode.HALF_UP) : BigDecimal.ZERO;

        return new Inventory(deliveryItem.getItemRefId(), deliveryItem.getBatchNumber(), item.getBaseUom(),
                deliveryItem.getExpiryDate(), deliveryItem.getManufacturerDate(), BigDecimal.valueOf(availableCount),
                item.isTrackingCode(), purchasePrice);
    }

    public Inventory mapDeliveryItemToInventory(DeliveryItem deliveryItem, boolean isCorrection) throws CMSException {

        Item item = itemDatabaseService.findById(deliveryItem.getItemRefId())
                .orElseThrow(() -> {
                    logger.error("Item[" + deliveryItem.getItemRefId() + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });
        if (item == null) {
            logger.error("Item not found, itemId[" + deliveryItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "item not found");
        }
        if (item.getBaseUom() == null) {
            logger.error("Base uom not found for item[" + deliveryItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "Item's base uom not found");
        }
        Double ratio;
        try {
            if (!useNavInventory) {
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), deliveryItem.getUom());
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + deliveryItem.getUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

        double availableCount = ratio * deliveryItem.getQuantity();

        if (isCorrection) {
            availableCount = -1 * availableCount;
        }

        return new Inventory(deliveryItem.getItemRefId(),
                deliveryItem.getBatchNumber(),
                item.getBaseUom(),
                deliveryItem.getExpiryDate(),
                deliveryItem.getManufacturerDate(),
                BigDecimal.valueOf(availableCount), item.isTrackingCode(), deliveryItem.getPurchasePrice());
    }

    public Inventory mapSalesItemToInventory(SalesItem salesItem) throws CMSException {

        Item item = itemDatabaseService.findById(salesItem.getItemRefId())
                .orElseThrow(() -> {
                    logger.error("Item[" + salesItem.getItemRefId() + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });
        if (item == null) {
            logger.error("Item not found, itemId[" + salesItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "item not found");
        }
        if (item.getBaseUom() == null) {
            logger.error("Base uom not found for item[" + salesItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "Item's base uom not found");
        }
        Double ratio;
        try {
            if (!useNavInventory) {
                String salesUOM = salesItem.getPurchaseUom();
                if (Objects.isNull(salesUOM)) {
                    salesUOM = item.getSalesUom();
                }
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), salesUOM);
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + salesItem.getPurchaseUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

//        Inventory inventory = new Inventory(salesItem.getItemRefId(),
//                salesItem.getBatchNo(),
//                item.getBaseUom(),
//                salesItem.getExpireDate(),
//                roundingQuantity(ratio * salesItem.getDispenseQty()));
        Inventory inventory = new Inventory(salesItem.getItemRefId(),
                salesItem.getBatchNo(),
                item.getBaseUom(),
                salesItem.getExpireDate(),
                BigDecimal.valueOf(ratio * salesItem.getDispenseQty()), item.isTrackingCode());
        return inventory;
    }

    public Inventory mapSalesItemAdjToInventory(SalesItemAdj salesItemAdj, SalesItem soldItem) throws CMSException {

        Item item = itemDatabaseService.findById(soldItem.getItemRefId())
                .orElseThrow(() -> {
                    logger.error("Item[" + soldItem.getItemRefId() + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });
        if (item == null) {
            logger.error("Item not found, itemId[" + soldItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "item not found");
        }
        if (item.getBaseUom() == null) {
            logger.error("Base uom not found for item[" + soldItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "Item's base uom not found");
        }

        Double ratio;
        try {
            if (!useNavInventory) {
                String soldUOM = soldItem.getPurchaseUom();
                if (Objects.isNull(soldUOM)) {
                    soldUOM = item.getSalesUom();
                }
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), soldUOM);
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + soldItem.getPurchaseUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

        int adjustedCount = salesItemAdj.getDispenseQty() - soldItem.getDispenseQty();

        return new Inventory(soldItem.getItemRefId(),
                soldItem.getBatchNo(),
                item.getBaseUom(),
                soldItem.getExpireDate(),
                BigDecimal.valueOf(ratio * adjustedCount), item.isTrackingCode());
    }

    public Inventory mapReturnItemsToInventory(GoodReturnItem returnItem) throws CMSException {

        Item item = itemDatabaseService.findById(returnItem.getItemRefId())
                .orElseThrow(() -> {
                    logger.error("Item[" + returnItem.getItemRefId() + "] not found");
                    return new CMSException(StatusCode.E2000, "Item not found");
                });

        if (item.getBaseUom() == null) {
            logger.error("Base uom not found for item[" + returnItem.getItemRefId() + "]");
            throw new CMSException(StatusCode.E2000, "Item's base uom not found");
        }
        Double ratio;
        try {
            if (!useNavInventory) {
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), returnItem.getUom());
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + returnItem.getUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

        double returnCount = -1 * ratio * returnItem.getQuantity();

        return new Inventory(returnItem.getItemRefId(),
                returnItem.getBatchNumber(),
                item.getBaseUom(),
                returnItem.getExpiryDate(),
                returnItem.getManufacturerDate(),
                BigDecimal.valueOf(returnCount), item.isTrackingCode());
    }

    public double getUOMRatio(InventoryUsage usage) throws CMSException {
        String salesUOM = usage.getSalesUom();
        if (Objects.isNull(salesUOM)) {
            salesUOM = usage.getBaseUom();
        }
        return uomMatrixService.findReverseRatio(usage.getBaseUom(), salesUOM);
    }

    public Inventory mapInventoryDetails(Inventory inventory, Item item) {
        try {
            double saleUomQuantity = uomMatrixService.convertItemUom(item, inventory.getBaseUom(), item.getSalesUom(), inventory.getAvailableCountInt());
            double purchaseUomQuantity = uomMatrixService.convertItemUom(item, inventory.getBaseUom(), item.getPurchaseUom(), inventory.getAvailableCountInt());
            inventory.setSalesUom(item.getSalesUom());
            inventory.setSalesUomQuantity(saleUomQuantity);
            inventory.setPurchaseUom(item.getPurchaseUom());
            inventory.setPurchaseUomQuantity(purchaseUomQuantity);
        } catch (Exception e) {
            logger.error("Error getting ratio for inventory details : ", e);
            throw new RuntimeException(e);
        }
        return inventory;
    }

    public Inventory mapDispatchItemToInventory(DispatchItem dispatchItem, Item item, int updatedQuantity) throws CMSException {

        Double ratio;
        try {
            if (!useNavInventory) {
                String soldUOM = item.getSalesUom();
                if (Objects.isNull(soldUOM)) {
                    soldUOM = item.getBaseUom();
                }
                ratio = uomMatrixService.findReverseRatio(item.getBaseUom(), soldUOM);
            } else {
                ratio = 1.0;
            }
        } catch (CMSException e) {
            logger.error("Cannot find ratio from uom[" + item.getSalesUom() + "] to uom[" + item.getBaseUom() + "]", e);
            throw new CMSException(e);
        }

        int adjustedCount = dispatchItem.getDispenseQty() - updatedQuantity;
        return new Inventory(dispatchItem.getItemId(), dispatchItem.getBatchNo(), item.getBaseUom(),
                BigDecimal.valueOf(ratio * adjustedCount), item.isTrackingCode());
    }

    public double convertQuantityWithNavCheck(int sourceQuantity, String sourceUom, String destinationUom) throws CMSException {

        double ratio = 1;
        if (!useNavInventory) {
            ratio = uomMatrixService.findReverseRatio(sourceUom, destinationUom);
        }
        return sourceQuantity * ratio;
    }

    public boolean useNavInventory() {
        return useNavInventory;
    }

    public void deleteZeroQuantityItems(long zeroSince) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime dateBeforeLtd = now.minusMonths(zeroSince);
        Date date3MonthsBefore = Date.from(dateBeforeLtd.atZone(ZoneId.systemDefault()).toInstant());
        List<LocationInventory> locationInventories = locationInventoryRepository
                .deleteAllByAvailableCountLessThanEqualAndLastModifiedDateBefore(BigDecimal.ZERO, date3MonthsBefore);
        logger.info("deleted items with zero quantity {}", locationInventories);
    }

    public List<String> findClinicsByItems(List<String> itemIds) throws CMSException {
        return locationInventoryRepository.findAllByItemRefIdIn(itemIds).stream()
                .map(LocationInventory::getClinicId)
                .distinct()
                .collect(Collectors.toList());
    }

    public List<Inventory> findItemByClinic(String clinicId) throws CMSException {
        return locationInventoryRepository.findAllByClinicId(clinicId).stream()
                .map(locationInventory -> {
                    Inventory inventory = new Inventory();
                    inventory.setItemRefId(locationInventory.getItemRefId());
                    inventory.setBaseUom(locationInventory.getBaseUom());
                    inventory.setAvailableCount(locationInventory.getAvailableCount());
                    inventory.setBatchNumber(locationInventory.getBatchNumber());
                    inventory.setExpiryDate(locationInventory.getExpiryDate());
                    inventory.setBatchPrice(locationInventory.getBatchPrice());
                    return inventory;
                })
                .collect(Collectors.toList());
    }

    public List<Inventory> findAllByClinicIdAndItemRefId(String clinicId, List<String> itemRefId) throws CMSException {
        return locationInventoryRepository.findAllByClinicIdAndItemRefIdIn(clinicId, itemRefId).stream()
                .map(locationInventory -> {
                    Inventory inventory = new Inventory();
                    inventory.setItemRefId(locationInventory.getItemRefId());
                    inventory.setBaseUom(locationInventory.getBaseUom());
                    inventory.setAvailableCount(locationInventory.getAvailableCount());
                    inventory.setBatchNumber(locationInventory.getBatchNumber());
                    inventory.setExpiryDate(locationInventory.getExpiryDate());
                    inventory.setBatchPrice(locationInventory.getBatchPrice());
                    return inventory;
                })
                .collect(Collectors.toList());
    }

    public List<LocationInventory> findExpiredItems() throws CMSException {
        return locationInventoryRepository.findAllByExpiryDateBefore(LocalDate.now());
    }

    public LocationInventory saveInventoryLocation(LocationInventory locationInventory) {
        return locationInventoryRepository.save(locationInventory);
    }

    public LocationInventory findByClinicIdAndItemIdAndBatchNo(String clinicId, String itemRefId, String batchNo) throws CMSException {
        return locationInventoryRepository
                .findLocationInventoryByClinicIdAndItemRefIdAndBatchNumber(clinicId, itemRefId, batchNo);
    }

    public List<LocationInventory> billAdjustmentUpdate(List<BillAdjustmentUpdate> billAdjustmentUpdates, String caseId) throws CMSException {
        Optional<Case> caseOptional = caseRepository.findById(caseId);

        if (caseOptional.isEmpty()) {
            logger.error("bill adjustment update declined  as  Case not found for case id [" + caseId + "]");
            throw new CMSException(StatusCode.E2002, "Case not found");
        }

        Optional<Clinic> clinicOp = clinicRepository.findById(caseOptional.get().getClinicId());
        if (clinicOp.isEmpty()) {
            logger.error("bill adjustment update declined  as  Clinic not found for Clinic id [" + caseOptional.get().getClinicId() + "]");
            throw new CMSException(StatusCode.E2002, "Clinic not found");
        }

        Clinic clinic = clinicOp.get();

        List<String> itemIds = billAdjustmentUpdates.stream()
                .filter(adj -> adj.getQuantity() != 0)
                .map(BillAdjustmentUpdate::getItemId)
                .collect(Collectors.toList());

        logger.info("billAdjustmentUpdate() there are "+itemIds.size()+ " to update");

        if (itemIds.size() > 0) {
            logger.info("validateInventoryForBillAdjustment initiated ");
            List<Inventory> inventories = validateInventoryForBillAdjustment(billAdjustmentUpdates, clinic, itemIds);
            logger.info("validateInventoryForBillAdjustment completed ");
            Location location = new Location(clinic.getId());
            location.setInventory(inventories);

            logger.info("[" + inventories.size() + "] inventory is about to update");
            List<InventoryTransaction> inventoryTransactionList = findAndModify(location, true, false);
            logger.info("[" + inventoryTransactionList.size() + "] InventoryTransactions are about to update");
            saveInventoryTransactions(inventoryTransactionList, caseId, InventoryTransaction.Type.DISPENSING);
            logger.info("bill Adjustment update process completed");
            return locationInventoryRepository.findAllByClinicId(clinic.getId());
        }
        logger.info("billAdjustmentUpdate() returns null as  itemIds count is 0 ");
        return null;
    }

    private List<Inventory> validateInventoryForBillAdjustment(List<BillAdjustmentUpdate> billAdjustmentUpdates, Clinic clinic, List<String> itemIds)
            throws CMSException {
        logger.info("validateInventoryForBillAdjustment() initiated");
        Map<String, Item> itemMap = itemDatabaseService.findItemsByIds(itemIds).stream()
                .filter(i -> i.isInventoried())
                .collect(Collectors.toMap(Item::getId, Function.identity()));

        logger.info("itemMap size "+ itemMap.size());

        Location locationByClinicId = findLocationByClinicIdIncludingZeroQtyInventories(clinic.getId(), itemMap.values().stream()
                .collect(Collectors.toList()))
                .orElseThrow(() -> new CMSException(StatusCode.E1010, "No inventory found to approve bill adjustment"));

        logger.info("locationByClinicId inventories "+ locationByClinicId.getInventory().size());

        List<Inventory> inventories = new ArrayList<>();
        for (BillAdjustmentUpdate billAdjustmentUpdate : billAdjustmentUpdates) {
            logger.info("billAdjustmentUpdate process started for the item "+ billAdjustmentUpdate.getItemId());
            if (billAdjustmentUpdate.getQuantity() == 0) {
                logger.info("billAdjustmentUpdate Quantity is 0 ");
                continue;
            }
            Item item = itemMap.get(billAdjustmentUpdate.getItemId());
            double reverseRatio = uomMatrixService.findReverseRatio(item.getBaseUom(), item.getSalesUom());
            logger.info("reverseRatio is "+reverseRatio);
            BigDecimal invUpdateVal = BigDecimal.valueOf(billAdjustmentUpdate.getQuantity() * reverseRatio);
            logger.info("invUpdateVal is "+invUpdateVal);
            List<Inventory> inventory = locationByClinicId.getInventory();

            if(!item.isTrackingCode()) {
                logger.info("Item of "+ item + " is not inventory tracking");
                BigDecimal totalAvailableInv = inventory.stream()
                        .filter(inventoryData -> inventoryData.getItemRefId().equals(billAdjustmentUpdate.getItemId()))
                        .map(Inventory::getAvailableCount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                logger.info("Total Inventory Available Quantity "+ totalAvailableInv);

                checkAndUpdateInventory(inventories, billAdjustmentUpdate, item, invUpdateVal, totalAvailableInv, null);
            } else {
                logger.info("Item of "+ item + " is inventory tracking");
                if(StringUtil.isBlank(billAdjustmentUpdate.getBatchNo())) {
                    logger.info("billAdjustmentUpdate entry has no batch number");
                    Comparator<Inventory> compareInventory = Comparator
                            .comparing(Inventory::getExpiryDate, Comparator.nullsLast(Comparator.naturalOrder()))
                            .thenComparing(Inventory::getBatchNumber, Comparator.nullsLast(Comparator.naturalOrder()));
                    //only negative adjustments to inventory will happen here, as this is to handle a new item added through bill adjustment
                    List<Inventory> sortedInventory = inventory.stream()
                            .filter(inventoryData -> inventoryData.getExpiryDate() == null || inventoryData.getExpiryDate().isAfter(LocalDate.now()))
                            .filter(inventoryData -> inventoryData.getItemRefId().equals(billAdjustmentUpdate.getItemId()))
                            .sorted(compareInventory)
                            .collect(Collectors.toList());
                    logger.info("Inventory Sorted and Before sort there are ["+ inventory.size()+" ]Records and after sorted there are ["+sortedInventory.size()+ "] Records");

                    BigDecimal totalAvailableInv = sortedInventory.stream()
                            .map(Inventory::getAvailableCount)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);

                    if (!sortedInventory.isEmpty() && (invUpdateVal.compareTo(BigDecimal.ZERO) > 0 ||totalAvailableInv.compareTo(invUpdateVal.abs()) >= 0)) {
                        BigDecimal tempValueHolder = invUpdateVal;
                        for (Inventory inventoryItem : sortedInventory) {
                            if (tempValueHolder.compareTo(BigDecimal.ZERO) == 0) {
                                logger.info("Process Break as inventory value is filed");
                                break;
                            }

                            BigDecimal amountToAdjust = tempValueHolder.abs().compareTo(inventoryItem.getAvailableCount()) >= 0 ? inventoryItem.getAvailableCount().negate() :
                                    tempValueHolder;
                            checkAndUpdateInventory(inventories, billAdjustmentUpdate, item, amountToAdjust, inventoryItem.getAvailableCount(),
                                    inventoryItem.getBatchNumber());
                            tempValueHolder = tempValueHolder.subtract(amountToAdjust);
                        }
                    } else {
                        logger.error("Inventory is not sufficient to complete the bill adjustment "+billAdjustmentUpdate.getBatchNo()+" and item of "+billAdjustmentUpdate.getItemId());
                        throw new CMSException(StatusCode.E1010, "Inventory is not sufficient to complete the bill adjustment");
                    }
                } else {
                    logger.info("billAdjustmentUpdate entry item of "+billAdjustmentUpdate.getItemId()+" has  batch number and Batch is "+ billAdjustmentUpdate.getBatchNo());
                    Inventory inventoryObj = inventory.stream()
                            .filter(inventoryData -> inventoryData.getItemRefId().equals(billAdjustmentUpdate.getItemId()))
                            .filter(inventoryData -> inventoryData.getBatchNumber().equals(billAdjustmentUpdate.getBatchNo()))
                            .findFirst()
                            .orElseThrow(() ->new CMSException(StatusCode.E1010, "Inventory not available for item " + item.getCode() + " to complete bill adjustment"));

                    checkAndUpdateInventory(inventories, billAdjustmentUpdate, item, invUpdateVal, inventoryObj.getAvailableCount(),
                            inventoryObj.getBatchNumber());
                }
            }
        }
        logger.info("There are "+inventories.size()+" inventories to be updated");
        return inventories;
    }

    private void checkAndUpdateInventory(List<Inventory> inventories, BillAdjustmentUpdate billAdjustmentUpdate, Item item,
                                         BigDecimal invUpdateVal, BigDecimal totalAvailableInv, String batchNo) throws CMSException {
        if (invUpdateVal.compareTo(BigDecimal.ZERO) > 0 || totalAvailableInv.compareTo(invUpdateVal.abs()) >= 0 ) {
            logger.info("checkAndUpdateInventory update inventory details for item : "+ billAdjustmentUpdate.getItemId());
            inventories.add(new Inventory(billAdjustmentUpdate.getItemId(), batchNo, item.getBaseUom(), invUpdateVal,
                    item.isTrackingCode()));
        } else {
            logger.error("Inventory is not sufficient to complete the bill adjustment for item " + billAdjustmentUpdate.getItemId());
            throw new CMSException(StatusCode.E1010, "Inventory is not sufficient to complete the bill adjustment for item : " + item.getCode());
        }
    }
}

