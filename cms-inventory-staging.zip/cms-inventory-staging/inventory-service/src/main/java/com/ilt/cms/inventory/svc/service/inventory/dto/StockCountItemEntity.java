package com.ilt.cms.inventory.svc.service.inventory.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.StockCountItemStatus;
import com.lippo.cms.util.CMSConstant;
import lombok.*;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockCountItemEntity {

    public enum StockCountItemRemark {
        DRUG_DISPENSING
    }

    private String stockTakeId;
    private String stockTakeName;
    private String transactionNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime startTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime endTime;

    private String clinicId;
    private String clinicCode;
    private String clinicName;

    private StockCountType countType;
    private String countName;
    private StockTakeStatus stockTakeStatus;
    private StockTakeApproveStatus stockTakeApproveStatus;
    private LocalDate stockTakeApprovedDate;
    private LocalDate stockTakeRejectedDate;
    @LastModifiedDate
    private Date lastModifiedDate;
    private String lastModifiedBy;

    private String lineId;
    private Double firstQuantity;
    private Double adjustedQuantity;
    private String purposeOfAdjustmentCode;
    private String remark;
    private String cpRemarks;
    private StockCountItemStatus status;
    private LocalDate approvedDate;
    private LocalDate rejectedDate;

    private String inventoryId;
    private String itemRefId;
    private String itemCode;
    private String itemName;
    private String curBatchNumber;
    private String curUom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate curExpiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate curManufacturerDate;
    private double availableCount;
    private String batchNumber;
    private String baseUom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;
	private BigDecimal purchasePrice;

}
