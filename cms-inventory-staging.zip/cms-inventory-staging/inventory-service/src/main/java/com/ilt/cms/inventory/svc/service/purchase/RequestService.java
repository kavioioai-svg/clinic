package com.ilt.cms.inventory.svc.service.purchase;

import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.supplier.MinPurchaseAmount;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.SupplierDatabaseService;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequestItemView;
import com.ilt.cms.inventory.svc.model.purchase.RequestItem;
import com.ilt.cms.inventory.svc.model.purchase.api.PurchaseRequestItemViewFilter;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestType;
import com.ilt.cms.inventory.svc.observer.NavPurchaseNotification;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.commons.util.StatusCode;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.lippo.cms.util.Calculations.roundingBackQuantity;
import static com.lippo.commons.util.CommonUtils.isStringValid;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;

@Service
public class RequestService {

    private static final Logger logger = LoggerFactory.getLogger(RequestService.class);
    private final MongoTemplate mongoTemplate;
    private OrderDatabaseService orderDatabaseService;
    private RunningNumberService runningNumberService;
    private DrugItemService itemService;
    private SupplierDatabaseService supplierDatabaseService;
    private SystemNotifier systemNotifier;
    private UOMMatrixService uomMatrixService;

    public RequestService(OrderDatabaseService orderDatabaseService, RunningNumberService runningNumberService,
                          DrugItemService itemService, SupplierDatabaseService supplierDatabaseService,
                          MongoTemplate mongoTemplate, SystemNotifier systemNotifier,
                          UOMMatrixService uomMatrixService) {
        this.orderDatabaseService = orderDatabaseService;
        this.runningNumberService = runningNumberService;
        this.itemService = itemService;
        this.supplierDatabaseService = supplierDatabaseService;
        this.systemNotifier = systemNotifier;
        this.mongoTemplate = mongoTemplate;
        this.uomMatrixService = uomMatrixService;
    }

    public PurchaseRequest findRequestById(String requestId) throws CMSException {

        logger.info("Find request by id [" + requestId + "]");
        return orderDatabaseService.findPurchaseRequestById(requestId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));
    }

    public List<PurchaseRequest> listPurchaseRequest() {

        logger.info("listPurchaseRequest");
        List<PurchaseRequest> requests = orderDatabaseService.findPurchaseRequest();
        return requests;
    }

    public List<PurchaseRequest> listPurchaseRequestByClinicId(String clinicId) {

        logger.info("listPurchaseRequestByClinicId[" + clinicId + "]");
        List<PurchaseRequest> requests = orderDatabaseService.findPurchaseRequestByClinicId(clinicId);
        return requests;
    }

    public PurchaseRequest createPurchaseRequest(PurchaseRequest purchaseRequest) throws CMSException {

        logger.info("createPurchaseRequest[" + purchaseRequest + "]");
        checkSubmitRequestValidate(purchaseRequest);

        if (purchaseRequest.getRequestStatus() == RequestStatus.REQUESTED) {
            purchaseRequest.setRequestDate(LocalDate.now());
            checkRequestValidate(purchaseRequest);
        }

        if (purchaseRequest.getRequestNo() == null) {
            purchaseRequest.setRequestNo(runningNumberService.generateRequestNumber());
        }

        purchaseRequest.setCreateDate(LocalDate.now());
        PurchaseRequest savePurchaseRequest = orderDatabaseService.savePurchaseRequest(purchaseRequest);
        if (savePurchaseRequest.getRequestStatus() == RequestStatus.REQUESTED) {
            systemNotifier.notify(new NavPurchaseNotification(purchaseRequest.getRequestClinicId(), savePurchaseRequest));
        }
        return savePurchaseRequest;
    }

    public PurchaseRequest modifyPurchaseRequest(String purchaseRequestId, PurchaseRequest purchaseRequest) throws CMSException {

        logger.info("modifyPurchaseRequest[" + purchaseRequestId + "], purchaseRequest[" + purchaseRequest + "]");
        checkSubmitRequestValidate(purchaseRequest);

        PurchaseRequest curPurchaseRequest = orderDatabaseService.findPurchaseRequestById(purchaseRequestId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));

        if (curPurchaseRequest.getRequestStatus() != RequestStatus.DRAFT) {
            logger.error("purchaseRequest is requested");
            throw new CMSException(StatusCode.E1010, "purchaseRequest is requested");
        }

        curPurchaseRequest.copy(purchaseRequest);
        if (curPurchaseRequest.getRequestStatus() == RequestStatus.REQUESTED) {
            curPurchaseRequest.setRequestDate(LocalDate.now());
            checkRequestValidate(curPurchaseRequest);
        }

        PurchaseRequest savePurchaseRequest = orderDatabaseService.savePurchaseRequest(curPurchaseRequest);
        if (savePurchaseRequest.getRequestStatus() == RequestStatus.REQUESTED) {
            systemNotifier.notify(new NavPurchaseNotification(purchaseRequest.getRequestClinicId(), savePurchaseRequest));
        }
        return savePurchaseRequest;
    }

    public void deletePurchaseRequest(String purchaseRequestId) throws CMSException {

        logger.info("deletePurchaseRequest[" + purchaseRequestId + "]");
        PurchaseRequest curPurchaseRequest = orderDatabaseService.findPurchaseRequestById(purchaseRequestId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));
        if (curPurchaseRequest.getRequestStatus() != RequestStatus.DRAFT) {
            throw new CMSException(StatusCode.E1010, "Not allow to delete with status [" + curPurchaseRequest.getRequestStatus() + "]");
        }
        orderDatabaseService.deletePurchaseRequest(purchaseRequestId);
    }

    public boolean approvePurchaseRequest(String purchaseRequestId, PurchaseRequest purchaseRequest) throws CMSException {

        logger.info("approvePurchaseRequest[" + purchaseRequestId + "], purchaseRequest[" + purchaseRequest + "]");
        return approvePurchaseRequest(purchaseRequestId, purchaseRequest, RequestStatus.APPROVED);
    }

    public boolean approvePurchaseRequest(String purchaseRequestId, PurchaseRequest purchaseRequest, RequestStatus requestStatus) throws CMSException {

        logger.info("approvePurchaseRequest[" + purchaseRequestId + "], purchaseRequest[" + purchaseRequest + "]");
        PurchaseRequest curPurchaseRequest = orderDatabaseService.findPurchaseRequestById(purchaseRequestId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));
        if (curPurchaseRequest.getRequestStatus() != RequestStatus.REQUESTED) {
            throw new CMSException(StatusCode.E1010, "Approve purchase request not allow:" + curPurchaseRequest.getRequestStatus());
        }
        if (!purchaseRequest.checkValidate()) {
            throw new CMSException(StatusCode.E1002, "Invalid in purchase request");
        }
        if (!purchaseRequest.getRequestItems().stream().allMatch(RequestItem::checkValidate)) {
            throw new CMSException(StatusCode.E1002, "Invalid in request item");
        }
        if (requestStatus != RequestStatus.APPROVED && requestStatus != RequestStatus.PARTIAL_APPROVED) {
            throw new CMSException(StatusCode.E1002, "Invalid request status not allow:" + requestStatus);
        }
        curPurchaseRequest.setRequestItems(purchaseRequest.getRequestItems());
        curPurchaseRequest.setRequestStatus(requestStatus);
        orderDatabaseService.savePurchaseRequest(curPurchaseRequest);
        return true;
    }

    public boolean rejectPurchaseRequest(String purchaseRequestId) throws CMSException {

        logger.info("rejectPurchaseRequest[" + purchaseRequestId + "]");
        PurchaseRequest curPurchaseRequest = orderDatabaseService.findPurchaseRequestById(purchaseRequestId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));

        if (curPurchaseRequest.getRequestStatus() != RequestStatus.REQUESTED) {
            throw new CMSException(StatusCode.E1010, "Modify transfer request not allow:" + curPurchaseRequest.getRequestStatus());
        }
        curPurchaseRequest.setRequestStatus(RequestStatus.REJECTED);
        orderDatabaseService.savePurchaseRequest(curPurchaseRequest);
        return true;
    }

    public boolean rejectPurchaseRequests(List<PurchaseRequestItemView> purchaseRequestItemViewList) throws CMSException {
        List<PurchaseRequest> existingPrs = orderDatabaseService
                .findPurchaseRequestsByIds(purchaseRequestItemViewList.stream()
                        .map(PurchaseRequestItemView::getId).collect(Collectors.toList()));

        for (PurchaseRequest pr : existingPrs) {
            List<RequestItem> requestItems = pr.getRequestItems();
            for (PurchaseRequestItemView prItem : purchaseRequestItemViewList) {
                Optional<RequestItem> requestItemOpt = requestItems.stream()
                        .filter(requestItem -> prItem.getItemRefId().equals(requestItem.getItemRefId())).findFirst();
                if (requestItemOpt.isPresent()) {
                    RequestItem requestItem = requestItemOpt.get();
                    requestItem.setRemark(prItem.getRemark());
                    requestItem.setCpRemarks(prItem.getCpRemarks());
                    if (requestItem.getApprovedQuantity() == 0) {
                        requestItem.setRequestItemStatus(RequestItem.RequestItemStatus.REJECTED);
                    } else if (Objects.equals(requestItem.getRequestItemStatus(), RequestItem.RequestItemStatus.SUBMITTED)) {
                        requestItem.setRequestItemStatus(RequestItem.RequestItemStatus.APPROVED);
                    } else {
                        throw new CMSException(StatusCode.E1002, "Invalid request item status, some items are approved");
                    }
                }
            }

            boolean allRejected = requestItems.stream()
                    .allMatch(requestItem -> RequestItem.RequestItemStatus.REJECTED
                            .equals(requestItem.getRequestItemStatus()));
            boolean allApproved = requestItems.stream()
                    .allMatch(requestItem -> RequestItem.RequestItemStatus.APPROVED
                            .equals(requestItem.getRequestItemStatus()));

            if (allRejected) {
                pr.setRequestStatus(RequestStatus.REJECTED);
            }
            if (allApproved) {
                pr.setRequestStatus(RequestStatus.APPROVED);
            }
        }

        orderDatabaseService.savePurchaseRequests(existingPrs);

        return true;
    }

    private boolean checkDrugItemIdExist(List<Item> items, String itemRefId) {

        boolean itemExist = items.stream()
                .anyMatch(drugItem -> drugItem.getId().equals(itemRefId));
        if (!itemExist) {
            logger.warn("Item[" + itemRefId + "] not exist");
        }
        return itemExist;
    }

    private boolean checkIsPurchaseBlock(List<Item> items, String itemRefId) {

        boolean itemBlock = items.stream()
                .anyMatch(drugItem ->
                        drugItem.getId().equals(itemRefId) && drugItem.isPurchasingBlocked());
        if (itemBlock) {
            logger.warn("Item[" + itemRefId + "] set purchasing blocked");
        }
        return !itemBlock;
    }

    private boolean checkItemPurchaseQuantity(List<Supplier> suppliers, RequestItem requestItem) {

        return suppliers.stream()
                .filter(supplier -> supplier.getId().equals(requestItem.getSupplierId()))
                .flatMap(supplier -> supplier.getItems().stream())
                .filter(purchaseItem -> purchaseItem.getItemId().equals(requestItem.getItemRefId()))
                .anyMatch(purchaseItem -> {
                            if (!(purchaseItem.getMinPurchaseQuantity() <= requestItem.getQuantity())) {
                                logger.warn("RequestItem[" + requestItem.getItemRefId() + "] ordered[" + requestItem.getQuantity() +
                                        "] does not have enough quantity[" + roundingBackQuantity(purchaseItem.getMinPurchaseQuantity()) + "]");
                            }
                            return roundingBackQuantity(purchaseItem.getMinPurchaseQuantity()) <= requestItem.getQuantity();
                        }
                );
    }

    private boolean checkItemPurchaseAmount(String clinicId, List<Supplier> suppliers, List<RequestItem> requestItems) {

        Map<String, List<RequestItem>> supplierRequestItemMap = requestItems.stream()
                .collect(Collectors.groupingBy(RequestItem::getSupplierId));
        List<String> SupplierIds = new ArrayList<>(supplierRequestItemMap.keySet());

        Map<String, Supplier> supplierIdMap = suppliers.stream()
                .filter(supplier -> SupplierIds.contains(supplier.getId()))
                .collect(Collectors.toMap(Supplier::getId, Function.identity()));

        for (String id : SupplierIds) {
            Supplier supplier = supplierIdMap.get(id);
            if (supplier == null) {
                logger.warn("Cannot find supplier[" + id + "]");
                continue;
            }
            List<RequestItem> requestItemList = supplierRequestItemMap.get(id);

            Integer totalPrice = requestItemList.stream()
                    .collect(Collectors.summingInt(requestItem -> requestItem.getUnitPrice().getPrice() * requestItem.getQuantity()));

            Optional<MinPurchaseAmount> existClinicMinPurchaseAmountOpt = supplier.getMinPurchaseAmounts().stream()
                    .filter(clinicMinPurchaseAmount -> clinicMinPurchaseAmount.getClinicId() != null &&
                            clinicMinPurchaseAmount.getClinicId().equals(clinicId))
                    .findFirst();
            MinPurchaseAmount existMinPurchaseAmount;
            if (existClinicMinPurchaseAmountOpt.isPresent()) {
                existMinPurchaseAmount = existClinicMinPurchaseAmountOpt.get();
            } else {
                logger.warn("Clinic[" + clinicId + "] does not have min purchase amount");
                existMinPurchaseAmount = supplier.getMinPurchaseAmounts().stream()
                        .filter(MinPurchaseAmount::isGlobal).findFirst()
                        .orElseGet(() -> new MinPurchaseAmount(clinicId, false, 0));

            }
            if (!(totalPrice >= existMinPurchaseAmount.getMinPurchaseAmount())) {
                logger.warn("Request item total amount[" + totalPrice + "] does not have enough amount for supplier[" + id +
                        "] min amount[" + existMinPurchaseAmount.getMinPurchaseAmount() + "]");
                return false;
            }
        }
        return true;

    }

    private boolean checkRequestItemUOM(List<Item> items, RequestItem requestItem) {
        return items.stream().filter(item -> item.getId().equals(requestItem.getItemRefId()))
                .map(Item::getPurchaseUom).allMatch(s -> s.equals(requestItem.getUom()));
    }

    private void checkRequestValidate(PurchaseRequest purchaseRequest) throws CMSException {

        if (purchaseRequest.getRequestStatus() == RequestStatus.REQUESTED) {
            boolean isPurchaseRequestValidate = purchaseRequest.checkValidate();

            boolean isPurchaseItemValidate = purchaseRequest.getRequestItems().stream()
                    .allMatch(requestItem -> requestItem.checkValidate());

            List<String> supplierIds = purchaseRequest.getRequestItems().stream()
                    .map(RequestItem::getSupplierId)
                    .distinct()
                    .collect(Collectors.toList());

            List<Supplier> suppliers = supplierDatabaseService.findByIdIn(supplierIds);

            List<String> itemIds = purchaseRequest.getRequestItems().stream()
                    .map(RequestItem::getItemRefId)
                    .collect(Collectors.toList());

            List<Item> drugItems = itemService.findItemByIds(itemIds)
                    .stream()
                    .filter(item -> item.isInventoried() || item.getItemType() == Item.ItemType.CONSUMABLE)
                    .collect(Collectors.toList());

            boolean isAllPurchaseUOM = purchaseRequest.getRequestItems().stream()
                    .allMatch(requestItem -> checkRequestItemUOM(drugItems, requestItem));

            boolean isAllAllowPurchase = purchaseRequest.getRequestItems().stream()
                    .allMatch(requestItem -> checkIsPurchaseBlock(drugItems, requestItem.getItemRefId()));

            boolean isAllQuantityFulfill = purchaseRequest.getRequestItems().stream()
                    .allMatch(requestItem -> checkItemPurchaseQuantity(suppliers, requestItem));
            boolean isAllAmountFulfill = checkItemPurchaseAmount(purchaseRequest.getRequestClinicId(), suppliers, purchaseRequest.getRequestItems());

            if (!isPurchaseRequestValidate) {
                logger.error("Purchase request in request No[" + purchaseRequest.getRequestNo() + "] is invalid");
                throw new CMSException(StatusCode.E1002, "Purchase request is invalid");
            }
            if (!isPurchaseItemValidate) {
                logger.error("Request item in request No[" + purchaseRequest.getRequestNo() + "] is invalid");
                throw new CMSException(StatusCode.E1002, "Request item is invalid");
            }
            if (!isAllAllowPurchase) {
                logger.error("Purchase item in request No[" + purchaseRequest.getRequestNo() + "] is blocked");
                throw new CMSException(StatusCode.E1002, "Purchase Item selected is blocked");
            }
            if (purchaseRequest.getRequestType() != RequestType.LOOSE) {
                if (!isAllPurchaseUOM) {
                    logger.error("Item is not purchase uom");
                    throw new CMSException(StatusCode.E2000, "Item uom not match to purchase uom");
                }
                if (!isAllQuantityFulfill) {
                    logger.error("Item quantity not fulfill supplier requirement");
                    throw new CMSException(StatusCode.E1002, "Item quantity not fulfill supplier requirement");
                }
                if (!isAllAmountFulfill) {
                    logger.error("Item amount not fulfill supplier requirement");
                    throw new CMSException(StatusCode.E1002, "Item amount not fulfill supplier requirement");
                }
            }
        }
    }

    private void checkSubmitRequestValidate(PurchaseRequest purchaseRequest) throws CMSException {

        if (!purchaseRequest.checkValidate()) {
            logger.error("Invalid purchase request[" + purchaseRequest + "]");
            throw new CMSException(StatusCode.E1002, "Invalid purchase request");
        }
        if (!purchaseRequest.getRequestItems().stream()
                .allMatch(requestItem -> requestItem.checkValidate())) {
            logger.error("RequestItem not validate");
            throw new CMSException(StatusCode.E1002, "requestItem not validate");
        }
        if (!(purchaseRequest.getRequestStatus() == RequestStatus.DRAFT ||
                purchaseRequest.getRequestStatus() == RequestStatus.REQUESTED)) {
            logger.error("Status not valid:" + purchaseRequest.getRequestStatus());
            throw new CMSException(StatusCode.E1002, "Status not valid");
        }
    }

    public Page<PurchaseRequestItemView> searchRequestItems(PurchaseRequestItemViewFilter filter) throws CMSException {
        Pageable pageable = PageRequest.of(filter.getPageNumber(), filter.getSize());
        Criteria criteria = new Criteria();

        if (isStringValid(filter.getRequestNo())) {
            criteria.and("requestNo").regex(Pattern.compile(filter.getRequestNo(), Pattern.CASE_INSENSITIVE));
        }
		if (filter.getRequestType() != null) {
			criteria.and("requestType").is(filter.getRequestType());
		}
        if (isStringValid(filter.getItemRefId())) {
            criteria.and("requestItems.itemRefId").is(filter.getItemRefId());
        }
        if (isStringValid(filter.getRequestClinicId())) {
            criteria.and("requestClinicId").is(filter.getRequestClinicId());
        }
        if (isStringValid(filter.getSupplierId())) {
            criteria.and("requestItems.supplierId").is(filter.getSupplierId());
        }
        if (filter.getRequestItemStatus() != null) {
            if (RequestItem.RequestItemStatus.PENDING.equals(filter.getRequestItemStatus())) {
                criteria.and("requestItems.requestItemStatus").in(filter.getRequestItemStatus(), null);
            } else {
                criteria.and("requestItems.requestItemStatus").is(filter.getRequestItemStatus());
            }
        }
        if (filter.getRequestDateStart() != null && filter.getRequestDateEnd() != null) {
            criteria.and("requestDate").gte(filter.getRequestDateStart()).lte(filter.getRequestDateEnd());
        }

        //criteria.and("inventoryClinicMatch").is(1);

        MatchOperation matchOperation = Aggregation.match(criteria);
        ProjectionOperation projectionOperation = Aggregation.project(
                "requestNo",
                "requestClinicId",
                "inventories",
                "item",
                "createDate",
                "requestDate",
                "requiredBeforeDate",
                "requestItems.itemRefId",
                "requestItems.supplierId",
                "requestItems.uom",
                "requestItems.quantity",
                "requestItems.approvedUom",
                "requestItems.approvedQuantity",
                "requestItems.unitPrice",
                "requestItems.requestItemStatus",
                "requestItems.remark",
                "requestItems.cpRemarks");


        UnwindOperation requestItemsUnwind = Aggregation.unwind("requestItems");
        LookupOperation inventoryLookup = Aggregation.lookup("locationInventory", "requestItems.itemRefId", "itemRefId", "inventories");
        AddFieldsOperation addFieldsOperation = Aggregation.addFields()
                .addFieldWithValue("itemIdObj", new Document("$toObjectId", "$requestItems.itemRefId"))
                .build();
        LookupOperation itemLookup = Aggregation.lookup("item", "itemIdObj", "_id", "item");
        UnwindOperation itemUnWind = Aggregation.unwind("item");
//        AddFieldsOperation addInventoryClinicMatch = Aggregation.addFields().addFieldWithValue("inventoryClinicMatch",
//                new Document("$cond",
//                        Arrays.asList(new Document("$in",
//                                new String[]{"$requestClinicId", "$inventory.clinicId"}), 1L, 0L)))
//                .build();
        SkipOperation skipOperation = new SkipOperation((long) pageable.getPageNumber() * pageable.getPageSize());
        LimitOperation limitOperation = new LimitOperation(pageable.getPageSize());
        SortOperation sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, "createDate"));

        TypedAggregation<PurchaseRequest> typedAggregation = newAggregation(
                PurchaseRequest.class,
                requestItemsUnwind,
                //addInventoryClinicMatch,
                inventoryLookup,
                addFieldsOperation,
                itemLookup,
                itemUnWind,
                matchOperation,
                sortOperation,
                skipOperation,
                limitOperation,
                projectionOperation);

        AggregationResults<PurchaseRequestItemView> purchaseRequestItemViews = mongoTemplate.aggregate(
                typedAggregation,
                "purchaseRequest",
                PurchaseRequestItemView.class);

        TypedAggregation<PurchaseRequest> totalCountAggregation = newAggregation(
                PurchaseRequest.class,
                requestItemsUnwind,
                //addInventoryClinicMatch,
                inventoryLookup,
                matchOperation,
                group()
                        .addToSet(Aggregation.ROOT).as("documents")
                        .count().as("count"));

        AggregationResults<NumberOfResults> totalCount = mongoTemplate.aggregate(
                totalCountAggregation,
                "purchaseRequest",
                NumberOfResults.class);

        List<NumberOfResults> totalCountMappedResults = totalCount.getMappedResults();
        int count = !totalCountMappedResults.isEmpty() ? totalCountMappedResults.get(0).getCount() : 0;
        return new PageImpl<>(
                purchaseRequestItemViews.getMappedResults()
                        .stream()
                        .peek(prItem -> {
                            prItem.setuId(prItem.getId() + "-" + prItem.getItemRefId());

                            if (prItem.getRequestItemStatus() == null) {
                                prItem.setRequestItemStatus(RequestItem.RequestItemStatus.PENDING);
                            }

                            prItem.setCurrQty(prItem.getInventories().stream()
                                    .filter(locationInventory -> locationInventory.getClinicId().equals(prItem.getRequestClinicId()))
                                    .map(LocationInventory::getAvailableCount)
                                    .reduce(BigDecimal.ZERO, BigDecimal::add));

                            double ratio;
                            try {
                                ratio = uomMatrixService.findReverseRatio(prItem.getItem().getBaseUom(), prItem.getUom());
                            } catch (CMSException e) {
                                throw new RuntimeException(e);
                            }

                            prItem.setBaseUom(prItem.getItem().getBaseUom());
                            prItem.setRefQty(BigDecimal.valueOf(prItem.getQuantity() * ratio));
                        })
                        .collect(Collectors.toList()), pageable, count);

    }

    private static class NumberOfResults {
        private int count;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }
    }

    private static class SearchResults {
        private int count;
        private List<PurchaseRequestItemView> result;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public List<PurchaseRequestItemView> getResult() {
            return result;
        }

        public void setResult(List<PurchaseRequestItemView> result) {
            this.result = result;
        }
    }
}
