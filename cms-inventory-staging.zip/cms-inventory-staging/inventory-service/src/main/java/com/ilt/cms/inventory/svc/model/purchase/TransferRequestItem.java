package com.ilt.cms.inventory.svc.model.purchase;

import com.lippo.cms.util.IdUtils;
import org.springframework.data.annotation.Transient;

import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class TransferRequestItem {

    private String lineNo;

    private String itemRefId;

    private String uom;

    private int quantity;

    private String purchaseRequestId;

    private String remark;

    private String cpRemarks;

    private String batchNumber;

    private Double backOrderedQuantity;

    private Double pendingOrderedQuantity;

    public boolean checkValidate(){
        return isStringValid(itemRefId, uom) && quantity > 0;
    }

    public TransferRequestItem() {
    }

    public TransferRequestItem(String lineNo, String itemRefId, String uom, int quantity) {
        this.lineNo = lineNo;
        this.itemRefId = itemRefId;
        this.uom = uom;
        this.quantity = quantity;
    }

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCpRemarks() {
        return cpRemarks;
    }

    public void setCpRemarks(String cpRemarks) {
        this.cpRemarks = cpRemarks;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public Double getBackOrderedQuantity() {
        return backOrderedQuantity;
    }

    public void setBackOrderedQuantity(Double backOrderedQuantity) {
        this.backOrderedQuantity = backOrderedQuantity;
    }

    public Double getPendingOrderedQuantity() {
        return pendingOrderedQuantity;
    }

    public void setPendingOrderedQuantity(Double pendingOrderedQuantity) {
        this.pendingOrderedQuantity = pendingOrderedQuantity;
    }

    @Override
    public String toString() {
        return "TransferRequestItem{" +
                "lineNo='" + lineNo + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", uom='" + uom + '\'' +
                ", quantity=" + quantity +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransferRequestItem that = (TransferRequestItem) o;
        return quantity == that.quantity &&
                Objects.equals(lineNo, that.lineNo) &&
                Objects.equals(itemRefId, that.itemRefId) &&
                Objects.equals(uom, that.uom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lineNo, itemRefId, uom, quantity);
    }

    public void setPurchaseRequestId(String purchaseRequestId) {
        this.purchaseRequestId = purchaseRequestId;
    }

    public String getPurchaseRequestId() {
        return purchaseRequestId;
    }

    public void copy(TransferRequestItem incoming) {
        if(this.getLineNo() == null){
            this.setLineNo(incoming.getLineNo());
        }
        if(this.getPurchaseRequestId() == null){
            this.setPurchaseRequestId(incoming.getPurchaseRequestId());
        }
        this.setItemRefId(incoming.getItemRefId());
        this.setBatchNumber(incoming.getBatchNumber());
        this.setUom(incoming.getUom());
        this.setRemark(incoming.getRemark());
        this.setCpRemarks(incoming.getCpRemarks());
        this.setQuantity(incoming.getQuantity());
    }
}
