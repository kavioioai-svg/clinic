package com.ilt.cms.inventory.svc.observer;

import com.ilt.cms.inventory.svc.service.nav.NavPurchaseService;
import com.lippo.cms.notify.CmsNotification;
import com.lippo.cms.notify.CmsNotificationsObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class NavPurchaseObserver implements CmsNotificationsObserver {

    private static final Logger logger = LoggerFactory.getLogger(NavPurchaseObserver.class);

    private NavPurchaseService purchaseService;

    public NavPurchaseObserver(NavPurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    @Override
    public void notify(CmsNotification notification) {
        if (notification instanceof NavPurchaseNotification) {
            NavPurchaseNotification navPurchaseNotification = (NavPurchaseNotification) notification;

            NavPurchaseNotification.NavAction action = navPurchaseNotification.getAction();
            switch (action) {
                case CREATE_PR:
                    purchaseService.createNavPurchaseRequest(navPurchaseNotification.getClinicId(), navPurchaseNotification.getPurchaseRequest().getId());
                    break;
                case CREATE_PUR_GRN:
                    purchaseService.createPurchaseGoodReceivedNote(navPurchaseNotification.getClinicId(), navPurchaseNotification.getOrderId(),
                            navPurchaseNotification.getGoodReceivedNote().getId());
                    break;
                case CREATE_GRVN:
                    purchaseService.createNavReturnOrder(navPurchaseNotification.getClinicId(), navPurchaseNotification.getOrderId());
                    break;
                case CREATE_RO_DN:
                    purchaseService.createPurchaseReturnDeliveryNote(navPurchaseNotification.getClinicId(), navPurchaseNotification.getOrderId(),
                            navPurchaseNotification.getDeliveryNote().getId());
                    break;
                case CREATE_TRANSFER_GRN:
                    purchaseService.createTransferGoodReceivedNote(navPurchaseNotification.getClinicId(), navPurchaseNotification.getOrderId(),
                            navPurchaseNotification.getGoodReceivedNote().getId());
                    break;
                case CREATE_DN:
                    purchaseService.createDeliveryNote(navPurchaseNotification.getClinicId(), navPurchaseNotification.getOrderId(),
                            navPurchaseNotification.getDeliveryNote().getId());
                    break;
                default:
                    logger.warn("No action is match:" + action);
            }

        }
    }
}
