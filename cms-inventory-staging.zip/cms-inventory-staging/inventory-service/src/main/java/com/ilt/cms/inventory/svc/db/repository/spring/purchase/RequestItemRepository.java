package com.ilt.cms.inventory.svc.db.repository.spring.purchase;

import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequestItemView;
import com.ilt.cms.inventory.svc.model.purchase.RequestItem;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequestItemRepository extends MongoRepository<PurchaseRequestItemView, String> {
    List<PurchaseRequestItemView> findAllByRequestNoIn(List<String> requestNumber);
    List<PurchaseRequestItemView> findAllByRequestNo(String requestNumber);
    void deleteAllByRequestNo(String requestNumber);
    List<PurchaseRequestItemView> findAllByIdIn(List<String> ids);
}
