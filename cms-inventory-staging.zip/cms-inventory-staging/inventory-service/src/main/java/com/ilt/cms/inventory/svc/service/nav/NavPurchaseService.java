package com.ilt.cms.inventory.svc.service.nav;

import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.inventory.svc.model.purchase.DeliveryNote;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedNote;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedVoidNote;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.cms.exception.RestTemplateResponseErrorHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class NavPurchaseService {

    private static final Logger logger = LoggerFactory.getLogger(NavPurchaseService.class);

    @Value("${nav.api.create.pr:}")
    private String apiCreatePR;

    @Value("${nav.api.create.ro:}")
    private String apiCreateRO;

    @Value("${nav.api.create.pur.grn:}")
    private String apiCreatePurchaseGRN;

    @Value("${nav.api.create.do:}")
    private String apiCreateDO;

    @Value("${nav.api.create.grvn.do:}")
    private String apiCreateGRVNDO;

    @Value("${nav.api.create.trnsf.grn:}")
    private String apiCreateTransferGRN;

    private RestTemplate restTemplate;

    public NavPurchaseService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder
                .errorHandler(new RestTemplateResponseErrorHandler())
                .build();
    }

    public void createNavPurchaseRequest(String clinicId, String purchaseRequestId) {

        try {
            logger.info("CreateNavPurchaseRequest [" + apiCreatePR + "] clinicId[" + clinicId + "] purchaseRequests [" + purchaseRequestId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreatePR, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, purchaseRequestId);


            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateNavPurchaseRequest get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateNavPurchaseRequest cannot get response for clinic[" + clinicId + "], purchaseRequest[" + purchaseRequestId + "]");
            }
        } catch (Exception e) {
            logger.error("Error createNavPurchaseRequest from clinicId[" + clinicId + "], purchaseRequest[" + purchaseRequestId + "], message[" + e.getMessage() + "]");
        }
    }

    public void createNavReturnOrder(String clinicId, String returnOrderId) {

        try {
            logger.info("CreateNavReturnOrder [" + apiCreateRO + "] clinicId[" + clinicId + "], returnOrderId[" + returnOrderId +
                    "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateRO, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, returnOrderId);
            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateNavReturnOrder get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateNavReturnOrder cannot get response for clinic[" + clinicId + "], returnOrderId[" + returnOrderId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreateNavReturnOrder from clinicId[" + clinicId + "], returnOrderId[" + returnOrderId + "], message[" + e.getMessage() + "]");
        }
    }

    public void createPurchaseGoodReceivedNote(String clinicId, String orderId, String goodReceivedNoteId) {

        try {
            logger.info("CreatePurchaseGoodReceivedNote [" + apiCreatePurchaseGRN + "], clinicId[" + clinicId + "], orderId["
                    + orderId + "], goodReceivedVoidNotes [" + goodReceivedNoteId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreatePurchaseGRN, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, orderId, goodReceivedNoteId);
            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreatePurchaseGoodReceivedNote get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreatePurchaseGoodReceivedNote cannot get response for clinic[" + clinicId + "], orderId[" + orderId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreatePurchaseGoodReceivedNote from clinicId[" + clinicId + "], orderId[" + orderId + "], goodReceivedNote["
                    + goodReceivedNoteId + "] , message[" + e.getMessage() + "]");
        }
    }

    public void createDeliveryNote(String clinicId, String orderId, String deliveryNoteId) {

        try {
            logger.info("CreateDeliveryNote [" + apiCreateDO + "], clinicId[" + clinicId + "], orderId[" + orderId +
                    "] goodReceivedVoidNotes [" + deliveryNoteId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateDO, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, orderId, deliveryNoteId);
            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateDeliveryNote get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateDeliveryNote cannot get response for clinic[" + clinicId + "], orderId[" + orderId + "], " +
                        "deliveryNoteId[" + deliveryNoteId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreateDeliveryNote : [" + e.getMessage() + "]");
        }
    }

    public void createPurchaseReturnDeliveryNote(String clinicId, String returnOrderId, String purchaseReturnDeliveryNoteId) {

        try {
            logger.info("CreatePurchaseReturnDeliveryNote [" + apiCreateGRVNDO + "], clinicId[" + clinicId + "], orderId[" + returnOrderId +
                    "] purchaseReturnDeliveryNote [" + purchaseReturnDeliveryNoteId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateGRVNDO, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, returnOrderId, purchaseReturnDeliveryNoteId);
            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreatePurchaseReturnDeliveryNote get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreatePurchaseReturnDeliveryNote cannot get response for clinic[" + clinicId + "], orderId["
                        + returnOrderId + "], dnId[" + purchaseReturnDeliveryNoteId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreatePurchaseReturnDeliveryNote : [" + e.getMessage() + "]");
        }
    }

    public void createTransferGoodReceivedNote(String clinicId, String orderId, String goodReceivedNoteId) {

        try {
            logger.info("CreateTransferGoodReceivedNote [" + apiCreateDO + "], clinicId[" + clinicId + "], orderNo[" + orderId +
                    "] goodReceivedNotes [" + goodReceivedNoteId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateTransferGRN, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, Map.of("orderId", orderId, "doId", goodReceivedNoteId));
            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateTransferGoodReceivedNote get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateTransferGoodReceivedNote cannot get response for clinic[" + clinicId + "], orderId["
                        + orderId + "], grnId[" + goodReceivedNoteId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreateTransferGoodReceivedNote : [" + e.getMessage() + "]");
        }
    }

    private HttpEntity<String> getCustomHeaderHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Tenant", TenantContext.getTenantId());

        HttpEntity<String> entity = new HttpEntity<>("body", headers);
        return entity;
    }

}
