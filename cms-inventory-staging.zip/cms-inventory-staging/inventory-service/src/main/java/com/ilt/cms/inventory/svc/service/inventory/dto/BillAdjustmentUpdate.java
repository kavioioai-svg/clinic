package com.ilt.cms.inventory.svc.service.inventory.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillAdjustmentUpdate {
    private String itemId;
    private String batchNo;
    private int dispensedQuantity;
    private int updatedQuantity;
    private boolean isTrackingCode;

    public long getQuantity() {
        return dispensedQuantity - updatedQuantity;
    }
}
