package com.ilt.cms.inventory.svc.db.repository.spring.inventory;

import com.ilt.cms.core.entity.common.AggregationGroupCount;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.ilt.cms.inventory.svc.model.nav.NavQueueRecordStatus;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public interface LocationInventoryRepository extends MongoRepository<LocationInventory, String> {
    List<LocationInventory> findAllByClinicId(String clinicId);

    List<LocationInventory> findAllByClinicIdAndAvailableCountIsGreaterThan(String clinicId, BigDecimal availableCount);

    List<LocationInventory> findAllByClinicIdAndAvailableCountIsGreaterThanAndItemRefIdIn(String clinicId, BigDecimal availableCount, Collection<String> itemRefId);

    List<LocationInventory> findAllByClinicIdAndItemRefId(String clinicId, String itemRefId);

    List<LocationInventory> findAllByClinicIdAndItemRefIdIn(String clinicId, List<String> itemRefId);

    void deleteAllByClinicId(String clinicId);
    
    List<LocationInventory> findByLastModifiedDateBetween(LocalDateTime start, LocalDateTime end);
    
    List<LocationInventory> deleteAllByAvailableCountLessThanEqualAndLastModifiedDateBefore(BigDecimal qty, Date date3MonthsBefore);

    List<LocationInventory> findAllByItemRefIdIn(List<String> itemRefIds);

    List<LocationInventory> findAllByExpiryDateBefore(LocalDate currentDate);

    LocationInventory findLocationInventoryByClinicIdAndItemRefIdAndBatchNumber(String clinicId, String itemRefId, String batchNo);
}
