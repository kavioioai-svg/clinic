package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum GoodReceivedReturnStatus {
    DRAFT, CONFIRM, APPROVED, REJECTED, RETURNED, FAILED;
}
