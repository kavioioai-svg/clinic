package com.ilt.cms.inventory.svc.model.purchase.common;

import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.inventory.svc.model.common.ClinicFilter;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrderBuilder {
    private String requestId;
    private LocalDate requestDate;
    private String requestNo;
    private String requestClinicId;
    private OrderType orderType;
    private String orderNo;
    private LocalDate createDate;
    private LocalDate orderDate;
    private LocalDate completeDate;
    private List<GoodReceivedNote> goodReceivedNotes = new ArrayList<>();
    private OrderStatus orderStatus;
    private GoodReceivedReturnStatus returnStatus;
    private String supplierId;
    private ClinicFilter clinicFilter;
    private List<GoodOrderedItem> goodPurchasedItems = new ArrayList<>();
    private List<TransferRequestItem> transferRequestItems = new ArrayList<>();
    private List<GoodReturnItem> returnItems = new ArrayList<>();
    private String senderClinicId;
    private List<DeliveryNote> deliveryNotes = new ArrayList<>();
    private String remark;
    private boolean cPTransfer;
    private String blanketPO;
    private boolean interComp;
    private NavIntegrationResult navIntegrationResult;
    private String purchaseOrderId;

    private Order.DiscountType discountType;
    private BigDecimal discountAmount;

    public OrderBuilder setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public OrderBuilder setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
        return this;
    }

    public OrderBuilder setRequestNo(String requestNo) {
        this.requestNo = requestNo;
        return this;
    }

    public OrderBuilder setRequestClinicId(String requestClinicId) {
        this.requestClinicId = requestClinicId;
        return this;
    }

    public OrderBuilder setOrderType(OrderType orderType) {
        this.orderType = orderType;
        return this;
    }

    public OrderBuilder setOrderNo(String orderNo) {
        this.orderNo = orderNo;
        return this;
    }

    public OrderBuilder setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
        return this;
    }

    public OrderBuilder setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
        return this;
    }

    public OrderBuilder setCompleteDate(LocalDate completeDate) {
        this.completeDate = completeDate;
        return this;
    }

    public OrderBuilder setGoodReceivedNotes(List<GoodReceivedNote> goodReceivedNotes) {
        this.goodReceivedNotes = goodReceivedNotes;
        return this;
    }

    public OrderBuilder setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        return this;
    }

    public OrderBuilder setReturnStatus(GoodReceivedReturnStatus returnStatus) {
        this.returnStatus = returnStatus;
        return this;
    }

    public OrderBuilder setSupplierId(String supplierId) {
        this.supplierId = supplierId;
        return this;
    }

    public OrderBuilder setClinicFilter(ClinicFilter clinicFilter) {
        this.clinicFilter = clinicFilter;
        return this;
    }

    public OrderBuilder setGoodPurchasedItems(List<GoodOrderedItem> goodPurchasedItems) {
        this.goodPurchasedItems = goodPurchasedItems;
        return this;
    }

    public OrderBuilder setTransferRequestItems(List<TransferRequestItem> transferRequestItems) {
        this.transferRequestItems = transferRequestItems;
        return this;
    }

    public OrderBuilder setReturnItems(List<GoodReturnItem> returnItems) {
        this.returnItems = returnItems;
        return this;
    }

    public OrderBuilder setSenderClinicId(String senderClinicId) {
        this.senderClinicId = senderClinicId;
        return this;
    }

    public OrderBuilder setDeliveryNotes(List<DeliveryNote> deliveryNotes) {
        this.deliveryNotes = deliveryNotes;
        return this;
    }

    public OrderBuilder setRemark(String remark) {
        this.remark = remark;
        return this;
    }

    public OrderBuilder setcPTransfer(boolean cPTransfer) {
        this.cPTransfer = cPTransfer;
        return this;
    }

    public OrderBuilder setBlanketPO(String blanketPO) {
        this.blanketPO = blanketPO;
        return this;
    }

    public OrderBuilder setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
        return this;
    }

    public OrderBuilder setPurchaseOrderId(String purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
        return this;
    }

    public Order createPurchaseOrder() {
        Order order = new Order(requestId, requestDate, requestNo, requestClinicId, orderType, orderNo, createDate, orderDate,
                completeDate, goodReceivedNotes, orderStatus, returnStatus, supplierId, clinicFilter, goodPurchasedItems,
                transferRequestItems, returnItems, senderClinicId, deliveryNotes, remark, cPTransfer, blanketPO, navIntegrationResult, purchaseOrderId);
        order.setOrderType(OrderType.PURCHASE);
        order.setInterComp(interComp);
        order.setDiscountType(discountType);
        order.setDiscountAmount(discountAmount);
        return order;
    }

    public Order createTransferOrder() {
        Order order = new Order(requestId, requestDate, requestNo, requestClinicId, orderType, orderNo, createDate, orderDate,
                completeDate, goodReceivedNotes, orderStatus, returnStatus, supplierId, clinicFilter, goodPurchasedItems,
                transferRequestItems, returnItems, senderClinicId, deliveryNotes, remark, cPTransfer, blanketPO, navIntegrationResult, purchaseOrderId);
        order.setOrderType(OrderType.TRANSFER);
        return order;
    }

    public OrderBuilder setInterComp(boolean interComp) {
        this.interComp = interComp;
        return this;
    }

    public OrderBuilder setDiscountType(Order.DiscountType discountType) {
        this.discountType = discountType;
        return this;
    }

    public OrderBuilder setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
        return this;
    }

    public Order createReturnOrder() {
        Order order = new Order(requestId, requestDate, requestNo, requestClinicId, orderType, orderNo, createDate, orderDate,
                completeDate, goodReceivedNotes, orderStatus, returnStatus, supplierId, clinicFilter, goodPurchasedItems,
                transferRequestItems, returnItems, senderClinicId, deliveryNotes, remark, cPTransfer, blanketPO, navIntegrationResult, purchaseOrderId);
        order.setOrderType(OrderType.RETURN);
        return order;
    }
}
