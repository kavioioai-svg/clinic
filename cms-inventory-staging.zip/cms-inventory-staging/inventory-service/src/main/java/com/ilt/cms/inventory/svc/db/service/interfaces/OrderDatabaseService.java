package com.ilt.cms.inventory.svc.db.service.interfaces;

import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface OrderDatabaseService {

    List<PurchaseRequest> findPurchaseRequest();
    List<PurchaseRequest> findPurchaseRequestsByIds(List<String> ids);

    List<PurchaseRequest> findPurchaseRequestByClinicId(String clinicId);

    List<Order> findOrderByOrderTypeAndOrderNos(OrderType orderType, List<String> orderNos);

    List<Order> findOrderByClinicIdOrClinicGroupName(String clinicId, String groupName);

    Optional<PurchaseRequest> findPurchaseRequestById(String purchaseRequestId);

    List<PurchaseRequest> findPurchaseRequestNumbers(List<String> purchaseRequestId);

    PurchaseRequest savePurchaseRequest(PurchaseRequest purchaseRequest);

    List<PurchaseRequest> savePurchaseRequests(List<PurchaseRequest> purchaseRequests);

    void deletePurchaseRequest(String purchaseRequestId);

    List<PurchaseRequest> findActivePurchaseRequests(List<RequestStatus> requestStatuses, LocalDate startDate, LocalDate endDate);

    Order saveOrder(Order order);

    List<Order> saveOrders(List<Order> orders);

    List<Order> findAllOrder();

    List<Order> findOrdersByIds(List<String> ids);

    Optional<Order> findOrderById(String orderId);

    List<Order> findOrderByIdsAndOrderType(List<String> orderIds, OrderType type);

    List<PurchaseRequest> saveAllPurchaseRequests(List<PurchaseRequest> mappedList);

    List<Order> findActiveOrders(List<OrderStatus> requestStatuses, OrderType orderType, LocalDate startDate, LocalDate endDate);

    List<Order> findActiveReturnOrders(List<GoodReceivedReturnStatus> returnStatuses, LocalDate startDate, LocalDate endDate);

    List<Order> findOrderBySenderClinicId(String clinicId);

    List<Order> findOrderByRequestId(String requestId);

    List<PurchaseRequest> findActivePurchaseRequest(LocalDate startDate, LocalDate endDate);

    List<Order> findReturnOrderByRequestClinicIdAndCreateDateAndReturnNumberAndRequestStatusIn(String clinicId, String groupName, LocalDate startDate,
                                                                                               LocalDate endDate, String number, List<String> status);

    boolean deleteOrder(String orderId);

    List<Order> findReturnOrderByReturnItemsPurchaseOrderId(String purchaseOrderId, List<GoodReceivedReturnStatus> returnStatus);

    List<Order> listReturnOrders(SearchPurchaseReturnOrderContainer search, int page, int size);

    List<Order> findOpenOrdersWithItemRefIds(Set<String> itemRefIds, String clinicId);

//    Page<PurchaseRequestItemView> findPurchaseRequestItems(PurchaseRequestItemViewFilter filter, Pageable pageable);

//    PurchaseRequestItemView findById(String id);

//    List<PurchaseRequestItemView> findPurchaseRequestItems(List<String> requestItemIds);
}
