package com.ilt.cms.inventory.svc.model.purchase;

import com.ilt.cms.core.entity.item.Item;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;

public class GoodReturnItem extends DeliveryItem {

    private String reasonCode;

    public GoodReturnItem() {
    }

    public GoodReturnItem(String lineNo, String itemRefId, String uom, String batchNumber, int quantity, LocalDate receiptDate,
                          String invoiceNo, LocalDate expiryDate, LocalDate manufacturerDate,
                          String reasonCode) {
        super(lineNo, itemRefId, uom, batchNumber, quantity, receiptDate, invoiceNo, expiryDate, manufacturerDate, null, BigDecimal.ZERO);
        this.reasonCode = reasonCode;
    }

    @Override
    public boolean checkValidate(Item item) {
        boolean isValidate = super.checkValidate(item);

        boolean isReturnValidate = isStringValid(reasonCode);

        return isValidate && isReturnValidate;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    @Override
    public String toString() {
        return "GoodReturnItem{" +
                "reasonCode='" + reasonCode + '\'' +
                ", lineNo='" + lineNo + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", uom='" + uom + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                ", quantity=" + quantity +
                ", receiptDate=" + receiptDate +
                ", invoiceNo='" + invoiceNo + '\'' +
                ", expiryDate=" + expiryDate +
                ", manufacturerDate=" + manufacturerDate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GoodReturnItem that = (GoodReturnItem) o;
        return Objects.equals(reasonCode, that.reasonCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reasonCode);
    }
}
