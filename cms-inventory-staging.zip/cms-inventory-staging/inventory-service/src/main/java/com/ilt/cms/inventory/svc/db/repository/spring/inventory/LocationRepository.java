package com.ilt.cms.inventory.svc.db.repository.spring.inventory;

import com.ilt.cms.core.entity.inventory.InventoryCache;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.nav.NavQueueRecordStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface LocationRepository extends MongoRepository<Location, String> {

    Optional<Location> findByClinicId(String clinicId);
}
