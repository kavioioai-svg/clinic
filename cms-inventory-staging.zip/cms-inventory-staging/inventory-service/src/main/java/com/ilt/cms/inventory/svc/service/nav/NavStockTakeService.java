package com.ilt.cms.inventory.svc.service.nav;

import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.cms.exception.RestTemplateResponseErrorHandler;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class NavStockTakeService {

    private static final Logger logger = LoggerFactory.getLogger(NavStockTakeService.class);

    @Value("${nav.api.create.stocktake:}")
    private String apiCreateStockTake;

    @Value("${nav.api.create.stockadjustment:}")
    private String apiCreateStockAdjustment;

    @Value("${nav.api.get.expired.stock:}")
    private String apiGetExpiredStock;

    @Value("${nav.api.get.disposed.stock:}")
    private String apiGetDisposedStock;

    @Value("${nav.api.update.disposed.stock:}")
    private String apiUpdateDisposedStock;

    private RestTemplate restTemplate;

    public NavStockTakeService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder
                .errorHandler(new RestTemplateResponseErrorHandler())
                .build();
    }

    public void createNavStockTake(String stockTakeId) {

        try {
            logger.info("Use [" + apiCreateStockTake + "] CreateNavStockTake stockTakeId[" + stockTakeId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateStockTake, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, stockTakeId);


            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateNavStockTake get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateNavStockTake cannot get response for stockTake[" + stockTakeId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreateNavStockTake : [" + e.getMessage() + "]");
        }
    }

    public void createNavStockAdjustment(String stockTakeId) {

        try {
            logger.info("Use [" + apiCreateStockAdjustment + "] CreateNavStockAdjustment stockTakeId[" + stockTakeId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiCreateStockAdjustment, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, stockTakeId);


            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("CreateNavStockAdjustment get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("CreateNavStockAdjustment cannot get response for stockTake[" + stockTakeId + "]");
            }
        } catch (Exception e) {
            logger.error("Error CreateNavStockAdjustment : [" + e.getMessage() + "]");
        }
    }

    /**
     * @param clinicId
     */
    public List<InventoryDetail> getExpiredStock(String clinicId) {

        logger.info("Get expired stock from clinic[" + clinicId + "] by api[" + apiGetExpiredStock + "]");
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Tenant", TenantContext.getTenantId());
            MultiValueMap<String, String> body1 = new LinkedMultiValueMap<String, String>();
            ParameterizedTypeReference<CmsServiceResponse<List<InventoryDetail>>> responseType = new ParameterizedTypeReference<>() {
            };
            ResponseEntity<CmsServiceResponse<List<InventoryDetail>>> responseEntity = restTemplate
                    .exchange(apiGetExpiredStock, HttpMethod.POST, new HttpEntity<>(body1, headers),
                            responseType, clinicId);
            CmsServiceResponse<List<InventoryDetail>> body = responseEntity.getBody();
            if (body.getPayload() != null && body.getStatusCode() == StatusCode.S0000) {
                List<InventoryDetail> inventoryDetails = body.getPayload();
                return inventoryDetails;
            } else {
                logger.error("Cannot get expired stock, status[" + body.getStatusCode() + "], message:[" + body.getMessage() + "]");
            }
        } catch (Exception e) {
            logger.error("Error getting expired stock : [" + e.getMessage() + "]");
        }
        return new ArrayList<>();
    }

    /**
     * @param clinicId
     */
    public List<InventoryDetail> getDisposedStock(String clinicId) {

        logger.info("Get disposed stock from clinic[" + clinicId + "] by api[" + apiGetDisposedStock + "]");
        try {

            ParameterizedTypeReference<CmsServiceResponse<List<InventoryDetail>>> responseType = new ParameterizedTypeReference<>() {
            };
            ResponseEntity<CmsServiceResponse<List<InventoryDetail>>> responseEntity = restTemplate
                    .exchange(apiGetDisposedStock, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            responseType, clinicId);
            CmsServiceResponse<List<InventoryDetail>> body = responseEntity.getBody();
            if (body != null && body.getStatusCode() == StatusCode.S0000) {
                List<InventoryDetail> inventoryDetails = body.getPayload();
                return inventoryDetails;
            } else {
                logger.error("Cannot get disposed stock, status[" + responseEntity.getBody().getStatusCode() + "], message[" + responseEntity.getBody().getMessage() + "]");
            }
        } catch (Exception e) {
            logger.error("Error getting disposed stock : [" + e.getMessage() + "]");
        }
        return new ArrayList<>();
    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    public void updateDisposeStock(String disposeStockId) {

        try {
            logger.info("Use [" + apiUpdateDisposedStock + "] UpdateDisposeStock disposeStockId[" + disposeStockId + "]");

            ResponseEntity<CmsServiceResponse> responseEntity = restTemplate
                    .exchange(apiUpdateDisposedStock, HttpMethod.POST, getCustomHeaderHttpEntity(),
                            CmsServiceResponse.class, disposeStockId);


            CmsServiceResponse body = responseEntity.getBody();

            if (body != null) {
                logger.info("UpdateDisposeStock get response code[" + body.getStatusCode() + "], message[" + body.getMessage() + "]");
            } else {
                logger.warn("UpdateDisposeStock cannot get response for disposeStock[" + disposeStockId + "]");
            }
        } catch (Exception e) {
            logger.error("Error UpdateDisposeStock : [" + e.getMessage() + "]");
        }
    }

    private HttpEntity<String> getCustomHeaderHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Tenant", TenantContext.getTenantId());

        HttpEntity<String> entity = new HttpEntity<>("body", headers);
        return entity;
    }
}
