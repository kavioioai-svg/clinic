package com.ilt.cms.inventory.svc.model.purchase.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.inventory.svc.model.purchase.RequestItem;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestType;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class PurchaseRequestItemViewFilter {
    private String requestClinicId;
    private String requestNo;
	private RequestType requestType;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDateStart;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate createDateEnd;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDateStart;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requestDateEnd;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requiredBeforeDateStart;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate requiredBeforeDateEnd;
    private String itemRefId;
    private String supplierId;
    private RequestItem.RequestItemStatus requestItemStatus;
    private String sortBy;
    private String sortOrder;
    private int pageNumber;
    private int size;
    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

	public RequestType getRequestType() {
		return requestType;
	}

	public void setRequestType(RequestType requestType) {
		this.requestType = requestType;
	}

	public LocalDate getCreateDateStart() {
        return createDateStart;
    }

    public void setCreateDateStart(LocalDate createDateStart) {
        this.createDateStart = createDateStart;
    }

    public LocalDate getCreateDateEnd() {
        return createDateEnd;
    }

    public void setCreateDateEnd(LocalDate createDateEnd) {
        this.createDateEnd = createDateEnd;
    }

    public LocalDate getRequestDateStart() {
        return requestDateStart;
    }

    public void setRequestDateStart(LocalDate requestDateStart) {
        this.requestDateStart = requestDateStart;
    }

    public LocalDate getRequestDateEnd() {
        return requestDateEnd;
    }

    public void setRequestDateEnd(LocalDate requestDateEnd) {
        this.requestDateEnd = requestDateEnd;
    }

    public LocalDate getRequiredBeforeDateStart() {
        return requiredBeforeDateStart;
    }

    public void setRequiredBeforeDateStart(LocalDate requiredBeforeDateStart) {
        this.requiredBeforeDateStart = requiredBeforeDateStart;
    }

    public LocalDate getRequiredBeforeDateEnd() {
        return requiredBeforeDateEnd;
    }

    public void setRequiredBeforeDateEnd(LocalDate requiredBeforeDateEnd) {
        this.requiredBeforeDateEnd = requiredBeforeDateEnd;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public RequestItem.RequestItemStatus getRequestItemStatus() {
        return requestItemStatus;
    }

    public void setRequestItemStatus(RequestItem.RequestItemStatus requestItemStatus) {
        this.requestItemStatus = requestItemStatus;
    }

    public String getRequestClinicId() {
        return requestClinicId;
    }

    public void setRequestClinicId(String requestClinicId) {
        this.requestClinicId = requestClinicId;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Pageable getPageable() {
        Sort.Direction direction;
        if ("desc".equals(sortOrder)) {
            direction = Sort.Direction.DESC;
        } else {
            direction = Sort.Direction.ASC;
        }

        return PageRequest.of(pageNumber, size, direction, sortBy != null ? sortBy : "requestDate");
    }
}
