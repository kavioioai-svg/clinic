package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.item.Item;
import com.lippo.cms.util.CMSConstant;
import com.lippo.commons.util.CommonUtils;
import org.springframework.data.annotation.Transient;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;


public class Inventory {
    private String inventoryId;
    private String itemRefId;
    @Transient
    private String itemName;
    @Transient
    private String itemCode;
    private String batchNumber;
    private String baseUom;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate manufacturerDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate expiryDate;
    private BigDecimal availableCount = BigDecimal.ZERO;
    @Transient
    private int baseUomQuantity;
    private String salesUom;
    private double salesUomQuantity;
    private String purchaseUom;
    private double purchaseUomQuantity;
    private BigDecimal batchPrice;
    private boolean isTrackingCode;

    public Inventory() {
        this.inventoryId = CommonUtils.idGenerator();
    }

    public Inventory(String itemRefId, String batchNumber, String baseUom, LocalDate expiryDate, LocalDate manufacturerDate,
                     BigDecimal availableCount, boolean isTrackingCode, BigDecimal batchPrice) {
        this.isTrackingCode = isTrackingCode;
        this.inventoryId = CommonUtils.idGenerator();
        this.itemRefId = itemRefId;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.manufacturerDate = manufacturerDate;
        this.batchPrice = batchPrice;
    }

    public Inventory(String itemRefId, String batchNumber, String baseUom, LocalDate expiryDate, LocalDate manufacturerDate,
                     BigDecimal availableCount, boolean isTrackingCode) {
        this.isTrackingCode = isTrackingCode;
        this.inventoryId = CommonUtils.idGenerator();
        this.itemRefId = itemRefId;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.manufacturerDate = manufacturerDate;
    }

    public Inventory(String itemRefId, String batchNumber, String baseUom, LocalDate expiryDate,
                     BigDecimal availableCount, boolean isTrackingCode) {
        this.isTrackingCode = isTrackingCode;
        this.inventoryId = CommonUtils.idGenerator();
        this.itemRefId = itemRefId;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
    }

    public Inventory(String itemRefId, String batchNumber, String baseUom,
                     BigDecimal availableCount, boolean isTrackingCode) {
        this.isTrackingCode = isTrackingCode;
        this.inventoryId = CommonUtils.idGenerator();
        this.itemRefId = itemRefId;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.availableCount = availableCount;
    }

    public Inventory(String itemRefId, String baseUom, BigDecimal availableCount, boolean isTrackingCode) {
        this.isTrackingCode = isTrackingCode;
        this.inventoryId = CommonUtils.idGenerator();
        this.itemRefId = itemRefId;
        this.baseUom = baseUom;
        this.availableCount = availableCount;
    }


    private Inventory(String inventoryId, String itemRefId, String itemName, String itemCode, String batchNumber, String baseUom,
                      LocalDate manufacturerDate, LocalDate expiryDate, BigDecimal availableCount, int baseUomQuantity, boolean isTrackingCode) {
        this.inventoryId = inventoryId;
        this.itemRefId = itemRefId;
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.batchNumber = batchNumber;
        this.baseUom = baseUom;
        this.manufacturerDate = manufacturerDate;
        this.expiryDate = expiryDate;
        this.availableCount = availableCount;
        this.baseUomQuantity = baseUomQuantity;
        this.isTrackingCode = isTrackingCode;
    }

    public static Inventory createInventory(String inventoryId, String itemRefId, String itemName, String itemCode, String batchNumber,
                                            String baseUom, LocalDate manufacturerDate, LocalDate expiryDate, BigDecimal availableCount,
                                            int baseUomQuantity, boolean isTrackingCode) {
        return new Inventory(inventoryId, itemRefId, itemName, itemCode, batchNumber, baseUom, manufacturerDate, expiryDate,
                availableCount, baseUomQuantity, isTrackingCode);
    }

    public static Inventory fromItem(Item item, String batchNumber, LocalDate expiryDate, LocalDate manufacturerDate, BigDecimal availableCount,
                                     int baseUomQuantity, boolean isTrackingCode) {
        return new Inventory("", item.getId(), item.getName(), item.getCode(), batchNumber, item.getBaseUom(),
                manufacturerDate, expiryDate, availableCount, baseUomQuantity, isTrackingCode);
    }

    public String getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(String inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getBaseUom() {
        return baseUom;
    }

    public void setBaseUom(String baseUom) {
        this.baseUom = baseUom;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public BigDecimal getAvailableCount() {
        return availableCount;
    }

    public int getAvailableCountInt() {
        if (availableCount != null) {
            return availableCount.setScale(0, RoundingMode.HALF_UP).intValue();
        } else {
            return 0;
        }
    }

    public void setAvailableCount(BigDecimal availableCount) {
        this.availableCount = availableCount;
    }

    public LocalDate getManufacturerDate() {
        return manufacturerDate;
    }

    public void setManufacturerDate(LocalDate manufacturerDate) {
        this.manufacturerDate = manufacturerDate;
    }

    public int getBaseUomQuantity() {
        return baseUomQuantity;
    }

    public void setBaseUomQuantity(int baseUomQuantity) {
        this.baseUomQuantity = baseUomQuantity;
    }

    public String getSalesUom() {
        return salesUom;
    }

    public void setSalesUom(String salesUom) {
        this.salesUom = salesUom;
    }

    public double getSalesUomQuantity() {
        return salesUomQuantity;
    }

    public void setSalesUomQuantity(double salesUomQuantity) {
        this.salesUomQuantity = salesUomQuantity;
    }

    public String getPurchaseUom() {
        return purchaseUom;
    }

    public void setPurchaseUom(String purchaseUom) {
        this.purchaseUom = purchaseUom;
    }

    public double getPurchaseUomQuantity() {
        return purchaseUomQuantity;
    }

    public void setPurchaseUomQuantity(double purchaseUomQuantity) {
        this.purchaseUomQuantity = purchaseUomQuantity;
    }

    public boolean isTrackingCode() {
        return isTrackingCode;
    }

    public void setTrackingCode(boolean trackingCode) {
        isTrackingCode = trackingCode;
    }

    public BigDecimal getBatchPrice() {
        return batchPrice;
    }

    public void setBatchPrice(BigDecimal batchPrice) {
        this.batchPrice = batchPrice;
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "inventoryId='" + inventoryId + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemCode='" + itemCode + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                ", baseUom='" + baseUom + '\'' +
                ", manufacturerDate=" + manufacturerDate +
                ", expiryDate=" + expiryDate +
                ", availableCount=" + availableCount +
                ", isTrackingCode=" + isTrackingCode +
                '}';
    }

}
