package com.ilt.cms.inventory.svc.model.purchase.api;

import java.io.ByteArrayOutputStream;

public class FileDowload {
    private String fileName;
    private ByteArrayOutputStream outputStream;


    public FileDowload(String fileName, ByteArrayOutputStream outputStream) {
        this.fileName = fileName;
        this.outputStream = outputStream;
    }

    public String getFileName() {
        return fileName;
    }

    public ByteArrayOutputStream getOutputStream() {
        return outputStream;
    }
}
