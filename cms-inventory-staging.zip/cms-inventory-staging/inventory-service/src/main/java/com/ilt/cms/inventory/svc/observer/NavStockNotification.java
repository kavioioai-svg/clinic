package com.ilt.cms.inventory.svc.observer;

import com.lippo.cms.notify.CmsNotification;

public class NavStockNotification implements CmsNotification {

    private NavAction action;

    private String stockId;

    public enum NavAction {
        CREATE_STOCK_TAKE, CREATE_STOCK_ADJUSTMENT, UPDATE_DISPOSE_STOCK
    }

    public NavStockNotification(String stockTakeId, NavAction action) {
        this.stockId = stockTakeId;
        this.action = action;
    }

    public NavAction getAction() {
        return action;
    }

    public void setAction(NavAction action) {
        this.action = action;
    }

    public String getStockId() {
        return stockId;
    }

    public void setStockId(String stockId) {
        this.stockId = stockId;
    }

    @Override
    public String toString() {
        return "NavStockNotification{" +
                "action=" + action +
                ", stockTakeId='" + stockId + '\'' +
                '}';
    }
}
