package com.ilt.cms.inventory.svc.model.inventory.enums;

public enum StockCountType {
    FULL, PARTIAL, ADJUSTMENT
}
