package com.ilt.cms.inventory.svc.service.inventory.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.inventory.svc.model.inventory.StockCountItem;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.lippo.cms.util.CMSConstant;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.lippo.commons.util.CommonUtils.isStringValid;

@Getter
@Setter
public class StockTakeEntity {

    private String id;

    private Date createdDate;

    private Date lastModifiedDate;

    private String lastModifiedBy;

    private String stockTakeName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime startTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime endTime;

    private String transactionNo;

    private String clinicId;

    private String clinicCode;

    private String clinicName;

    private StockCountType countType;

    private String startRange;

    private String endRange;

    private List<String> itemStockTakeRange;

    private String countName;

    private StockTakeStatus stockTakeStatus;

    private StockTakeApproveStatus approveStatus;

    private List<StockCountItemEntity> stockCountItems;

    private NavIntegrationResult navIntegrationResult;

    private LocalDate approvedDate;

    private LocalDate rejectedDate;

}
