package com.ilt.cms.inventory.svc.service.purchase;

import com.google.common.collect.Streams;
import com.ilt.cms.core.entity.*;
import com.ilt.cms.core.entity.casem.*;
import com.ilt.cms.core.entity.common.ContactPerson;
import com.ilt.cms.core.entity.inventory.InventoryTransaction;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.UomMatrix;
import com.ilt.cms.core.entity.supplier.BonusDetail;
import com.ilt.cms.core.entity.supplier.PurchaseBonus;
import com.ilt.cms.core.entity.supplier.PurchaseItem;
import com.ilt.cms.core.entity.supplier.Supplier;
import com.ilt.cms.database.RunningNumberService;
import com.ilt.cms.database.item.UomMatrixDatabaseService;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestItemRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.ilt.cms.inventory.svc.model.common.UomConversionRequest;
import com.ilt.cms.inventory.svc.model.inventory.Inventory;
import com.ilt.cms.inventory.svc.model.inventory.Location;
import com.ilt.cms.inventory.svc.model.purchase.*;
import com.ilt.cms.inventory.svc.model.purchase.api.GoodOrderedItemPrint;
import com.ilt.cms.inventory.svc.model.purchase.api.PurchaseOrderPrint;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.common.OrderBuilder;
import com.ilt.cms.inventory.svc.model.purchase.enums.*;
import com.ilt.cms.inventory.svc.observer.NavPurchaseNotification;
import com.ilt.cms.inventory.svc.service.common.LogoUtil;
import com.ilt.cms.inventory.svc.service.common.UOMMatrixService;
import com.ilt.cms.inventory.svc.service.inventory.DrugItemService;
import com.ilt.cms.inventory.svc.service.inventory.LocationService;
import com.ilt.cms.repository.spring.CaseRepository;
import com.ilt.cms.repository.spring.ClinicRepository;
import com.ilt.cms.repository.spring.InventoryTransactionRepository;
import com.ilt.cms.repository.spring.SupplierRepository;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.gst.service.GstUtilsService;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.cms.util.IdUtils;
import com.lippo.cms.util.Tuple;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import com.mitchellbosecke.pebble.PebbleEngine;
import com.mitchellbosecke.pebble.error.PebbleException;
import com.mitchellbosecke.pebble.loader.ClasspathLoader;
import com.mitchellbosecke.pebble.template.PebbleTemplate;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.cms.CMSRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);
    private static final DecimalFormat df = new DecimalFormat("0.00");
    private OrderDatabaseService orderDatabaseService;
    private RunningNumberService runningNumberService;
    private LocationService locationService;
    private UOMMatrixService uomMatrixService;
    private UomMatrixDatabaseService uomMatrixDatabaseService;
    private DrugItemService itemService;
    private ClinicRepository clinicRepository;
    //    private RequestRepository requestRepository;
    private SupplierRepository supplierRepository;
    private SystemNotifier systemNotifier;

    private final RequestService requestService;

    private CaseRepository caseRepository;

    private InventoryTransactionRepository inventoryTransactionRepository;

    private PebbleEngine pebbleEngine;

    private RequestItemRepository requestItemRepository;

    private GstUtilsService gstUtilsService;

    private final LogoUtil logoUtil;

    public OrderService(OrderDatabaseService orderDatabaseService, RunningNumberService runningNumberService,
                        LocationService locationService, UOMMatrixService uomMatrixService,
                        UomMatrixDatabaseService uomMatrixDatabaseService,
                        DrugItemService itemService,
                        ClinicRepository clinicRepository, SupplierRepository supplierRepository, SystemNotifier systemNotifier,
                        CaseRepository caseRepository, InventoryTransactionRepository inventoryTransactionRepository,
                        RequestService requestService, RequestItemRepository requestItemRepository,
                        GstUtilsService gstUtilsService, LogoUtil logoUtil) {
        this.orderDatabaseService = orderDatabaseService;
        this.runningNumberService = runningNumberService;
        this.locationService = locationService;
        this.uomMatrixService = uomMatrixService;
        this.uomMatrixDatabaseService = uomMatrixDatabaseService;
        this.itemService = itemService;
        this.clinicRepository = clinicRepository;
//        this.requestRepository = requestRepository;
        this.supplierRepository = supplierRepository;
        this.systemNotifier = systemNotifier;
        this.requestService = requestService;
        this.caseRepository = caseRepository;
        this.inventoryTransactionRepository = inventoryTransactionRepository;
        this.logoUtil = logoUtil;
        this.pebbleEngine = new PebbleEngine.Builder().loader(new ClasspathLoader()).build();
        this.requestItemRepository = requestItemRepository;
        this.gstUtilsService = gstUtilsService;
    }

    public List<Order> listAllTransferOrder() {

        return orderDatabaseService.findAllOrder().stream()
                .filter(order -> order.getOrderType() == OrderType.TRANSFER)
                .map(this::addRequestDetail)
                .collect(Collectors.toList());
    }

    public List<Order> listAllPurchaseOrder() {

        return orderDatabaseService.findAllOrder().stream()
                .filter(order -> order.getOrderType() == OrderType.PURCHASE)
                .map(this::addRequestDetail)
                .collect(Collectors.toList());
    }

    public List<Order> listOrderByClinicIdOrClinicGroupName(String clinicId) throws CMSException {

        logger.info("listOrderByClinicIdOrClinicGroupName[" + clinicId + "]");
        Clinic clinic = clinicRepository.findByIdAndStatus(clinicId, Status.ACTIVE)
                .orElseThrow(() -> {
                    logger.error("Cannot find clinic by id[" + clinicId + "], and status[" + Status.ACTIVE + "]");
                    return new CMSException(StatusCode.E2000, "clinic not found");
                });
        return orderDatabaseService.findOrderByClinicIdOrClinicGroupName(clinicId, clinic.getGroupName()).stream()
                .filter(order -> order.getOrderType() != OrderType.RETURN)
                .map(this::addRequestDetail)
                .collect(Collectors.toList());
    }

    public List<Order> listOrderBySenderClinicId(String clinicId) {

        logger.info("listOrderBySenderClinicId[" + clinicId + "]");
        return orderDatabaseService.findOrderBySenderClinicId(clinicId);
    }

    public List<Order> listOrderByReturnOrderDateAndFilter(String clinicId, LocalDate startDate, LocalDate endDate,
                                                           String requestStatus, String number) throws CMSException {

        logger.info("listOrderByReturnOrder, clinicId[" + clinicId + "], startDate[" + startDate + "], endDate[" + endDate +
                "], requestStatus[" + requestStatus + "], number[" + number + "]");

        Clinic clinic = getClinic(clinicId);

        List<String> status = new ArrayList<>();
        if (Objects.nonNull(requestStatus)) {
            status = getGoodReturnStatusList(requestStatus);
        }
        return orderDatabaseService.findReturnOrderByRequestClinicIdAndCreateDateAndReturnNumberAndRequestStatusIn(clinicId,
                clinic.getGroupName(), startDate, endDate, number, status);
    }

    public Order findOrderById(String orderId) throws CMSException {

        logger.info("findOrderById[" + orderId + "]");
        Order order = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not find"));
        for (GoodOrderedItem goodOrderedItem : order.getGoodPurchasedItems()) {
            if (goodOrderedItem.getBonusItem() == null) {
                goodOrderedItem.setBonusItem(false);
            }
        }
        order = addRequestDetail(order);
        Optional<PurchaseRequest> purchaseRequestOpt = Objects.nonNull(order.getRequestId()) ?
                orderDatabaseService.findPurchaseRequestById(order.getRequestId()) : Optional.empty();
        for (GoodReceivedNote goodReceivedNote : order.getGoodReceivedNotes()) {
            addRequestDetail(purchaseRequestOpt, goodReceivedNote);
        }

        return order;
    }

    public Map<String, Double> findBackOrderCounts(Order refOrder) {

        Set<String> itemRefIds = refOrder.getGoodPurchasedItems().stream()
                .map(GoodOrderedItem::getItemRefId)
                .collect(Collectors.toSet());

        itemRefIds.addAll(refOrder.getTransferRequestItems().stream()
                .map(TransferRequestItem::getItemRefId)
                .collect(Collectors.toSet()));

        return findBackOrderCount(itemRefIds, refOrder.getRequestClinicId(), refOrder.getId(), refOrder.getOrderType());
    }

    public List<Order> findPurchaseOrderByIds(List<String> orderIds) {

        logger.info("find order by ids[" + orderIds + "]");
        return orderDatabaseService.findOrderByIdsAndOrderType(orderIds, OrderType.PURCHASE);
    }

    public Order findReturnOrderByOrderId(String orderId) throws CMSException {

        logger.info("findReturnOrderByOrderId orderId[" + orderId + "]");
        return orderDatabaseService.findOrderById(orderId).stream()
                .filter(order1 -> order1.getOrderType() == OrderType.RETURN)
                .findFirst()
                .orElseThrow(() ->
                {
                    logger.error("Order[" + orderId + "] not found");
                    return new CMSException(StatusCode.E2000, "Order not found");
                });
    }

    public List<Clinic> purchaseOrderClinics(Order order) throws CMSException {
        Set<String> prIdList = order.getGoodPurchasedItems().stream()
                .map(GoodOrderedItem::getPurchaseRequestId).collect(Collectors.toSet());

        List<Clinic> clinics = new ArrayList<>();
        for (String prId : prIdList) {
            PurchaseRequest purchaseRequest = requestService.findRequestById(prId);
            String clinicId = purchaseRequest.getRequestClinicId();
            Optional<Clinic> clinic = clinicRepository.findById(clinicId);
            clinic.ifPresent(clinics::add);
        }

        return clinics;
    }

    public List<Order> modifyPurchaseOrders(List<Order> orders, boolean issue) throws CMSException {
        List<Order> savedOrders = new ArrayList<>();
        for (Order order : orders) {
            Order savedOrder;
            if (OrderType.PURCHASE.equals(order.getOrderType())) {
                savedOrder = modifyPurchaseOrder(order, issue);
            } else {
                savedOrder = modifyTransferOrder(order, issue);
            }

            savedOrders.add(savedOrder);
        }

        return savedOrders;
    }

    private PurchaseRequest createPurchaseRequest(Order order) throws CMSException {

        PurchaseRequest purchaseRequest = new PurchaseRequest();
        purchaseRequest.setRequestClinicId(order.getRequestClinicId());
        purchaseRequest.setRequestStatus(RequestStatus.REQUESTED);
        purchaseRequest.setJustificationForPurchase("REPL_STOCK");
        purchaseRequest.setRequestItems(new ArrayList<>());

        return purchaseRequest;
    }

    private PurchaseRequest createPurchaseRequestByPO(Order order, PurchaseRequest purchaseRequest) {

        purchaseRequest.setRequestType(RequestType.LOOSE);
        for (GoodOrderedItem goodOrderedItem : order.getGoodPurchasedItems()) {
            if (goodOrderedItem.getPurchaseRequestId() == null) {
                RequestItem requestItem = new RequestItem();
                requestItem.setItemRefId(goodOrderedItem.getItemRefId());
                requestItem.setUom(goodOrderedItem.getUom());
                requestItem.setSupplierId(order.getSupplierId());
                requestItem.setQuantity(goodOrderedItem.getQuantity());
                requestItem.setApprovedQuantity(goodOrderedItem.getQuantity());
                requestItem.setUnitPrice(goodOrderedItem.getUnitPrice());
                requestItem.setRemark(goodOrderedItem.getRemark());
                requestItem.setCpRemarks(goodOrderedItem.getCpRemarks());//ToDo:set approved uom
                purchaseRequest.addNewRequestItem(requestItem);
            }
        }
        return purchaseRequest;
    }

    private PurchaseRequest createPurchaseRequestByTO(Order order, PurchaseRequest purchaseRequest) throws CMSException {

        purchaseRequest.setRequestType(RequestType.LOOSE);
        for (TransferRequestItem transferRequestItem : order.getTransferRequestItems()) {
            if (transferRequestItem.getPurchaseRequestId() == null) {
                Item item = itemService.findItemById(transferRequestItem.getItemRefId());
                Supplier supplier = supplierRepository.findById(item.getSupplierId())
                        .orElseThrow(() -> new CMSException(StatusCode.E2000, "Supplier not found"));
                PurchaseItem pItem = supplier.getItems().stream()
                        .filter(sItem -> sItem.getItemId().equals(item.getId()))
                        .findFirst().orElseThrow(() -> new CMSException(StatusCode.E2000, "Item not found"));

                RequestItem requestItem = new RequestItem();
                requestItem.setItemRefId(transferRequestItem.getItemRefId());
                requestItem.setUom(transferRequestItem.getUom());
                requestItem.setSupplierId(item.getSupplierId());
                requestItem.setQuantity(transferRequestItem.getQuantity());
                requestItem.setApprovedQuantity(transferRequestItem.getQuantity());
                //Todo-Get Confirmation from Nilu
                if (pItem.getUnitPrice() != null) {
                    requestItem.setUnitPrice(new UnitPrice(pItem.getUnitPrice().getPrice()
                            , pItem.getUnitPrice().isTaxIncluded()));
                } else {
                    requestItem.setUnitPrice(new UnitPrice(0, false));
                }
                requestItem.setRemark(transferRequestItem.getRemark());
                requestItem.setCpRemarks(transferRequestItem.getCpRemarks());//ToDo:set approved uom
                purchaseRequest.addNewRequestItem(requestItem);
                //Todo-Get Confirmation from Nilu - Set approved UOM
                purchaseRequest.addNewRequestItem(requestItem);
            }
        }

        return purchaseRequest;
    }

    public Order modifyPurchaseOrder(Order po, boolean issue) throws CMSException {
        logger.info("modify purchase order [" + po + "]");

        validateOrder(po);
        addPODefaultValues(po);
        Order order = getOrder(po);

        if (issue) {
            modifyPurchaseRequestByPO(po, order);
        }

        if (po.getOrderStatus() != null) {
            order.setOrderStatus(po.getOrderStatus());
        }

        order.setRemark(po.getRemark());
        List<GoodOrderedItem> orderItems = new ArrayList<>();

        int lastLineNo = po.getGoodPurchasedItems().stream().mapToInt(item -> {
            try {
                return Integer.parseInt(item.getLineNo());
            } catch (NumberFormatException | NullPointerException e) {
                return 0;
            }
        }).max().orElse(0);

        for (GoodOrderedItem incoming : po.getGoodPurchasedItems()) {
            if (incoming.getLineNo() == null) {
                incoming.setLineNo(++lastLineNo + "");
            }

            GoodOrderedItem orderItem = incoming;

            Optional<GoodOrderedItem> existingOpt = order.getGoodPurchasedItems().
                    stream().filter(item -> incoming.getLineNo().equals(item.getLineNo()))
                    .findFirst();

            if (existingOpt.isPresent()) {
                orderItem = existingOpt.get();
                orderItem.copy(incoming);
            }

            boolean isValid = orderItem.checkValidate();
            if (!isValid) {
                throw new CMSException(StatusCode.I5000, "Invalid order item");
            }

            orderItems.add(orderItem);
        }
        order.setGoodPurchasedItems(orderItems);
        order.setDiscountType(po.getDiscountType());
        order.setDiscountAmount(po.getDiscountAmount());

        if (order.getGstEnabled()) {
            Tuple<Double, Double> gstTuple = calculateGst(order);
            order.setGstPercentage(BigDecimal.valueOf(gstTuple.getFirst()));
            order.setGstAmount(BigDecimal.valueOf(gstTuple.getSecond()));
        } else {
            order.setGstPercentage(BigDecimal.ZERO);
            order.setGstAmount(BigDecimal.ZERO);
        }

        return orderDatabaseService.saveOrder(order);
    }

    private void modifyPurchaseRequestByPO(Order po, Order order) throws CMSException {
        Set<String> prIds = order.getGoodPurchasedItems().stream()
                .map(GoodOrderedItem::getPurchaseRequestId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        Map<String, List<GoodOrderedItem>> existingItemsByPurchaseRequest = order.getGoodPurchasedItems().stream()
                .filter(go -> go.getPurchaseRequestId() != null)
                .collect(Collectors.groupingBy(GoodOrderedItem::getPurchaseRequestId));

        Map<String, List<GoodOrderedItem>> newItemsByPurchaseRequest = po.getGoodPurchasedItems()
                .stream()
                .filter(go -> go.getPurchaseRequestId() != null)
                .collect(Collectors.groupingBy(GoodOrderedItem::getPurchaseRequestId));

        List<PurchaseRequest> purchaseRequests = new ArrayList<>();

        for (String prId : prIds) {
            PurchaseRequest purchaseRequest = orderDatabaseService.findPurchaseRequestById(prId)
                    .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));

            List<RequestItem> prRequestItems = purchaseRequest.getRequestItems();

            Map<String, List<GoodOrderedItem>> existingItemsByItemId = existingItemsByPurchaseRequest.get(prId).stream()
                    .collect(Collectors.groupingBy(GoodOrderedItem::getItemRefId));

            Map<String, List<GoodOrderedItem>> newItemsByItemId = newItemsByPurchaseRequest.get(prId).stream()
                    .collect(Collectors.groupingBy(GoodOrderedItem::getItemRefId));

            for (RequestItem requestItem : prRequestItems) {
                List<GoodOrderedItem> existingGoodOrderedItems = existingItemsByItemId.get(requestItem.getItemRefId());
                int existingQuantity = 0;
                if (order.getOrderStatus() != OrderStatus.DRAFT && existingGoodOrderedItems != null) {
                    existingQuantity = existingGoodOrderedItems.stream().filter(goodOrderedItem -> goodOrderedItem.getBonusItem() == null || !goodOrderedItem.getBonusItem()).mapToInt(GoodOrderedItem::getQuantity).sum();
                }

                List<GoodOrderedItem> newGoodOrderedItems = newItemsByItemId.get(requestItem.getItemRefId());
                int newQuantity = 0;
                if (newGoodOrderedItems != null) {
                    newQuantity = newGoodOrderedItems.stream().filter(goodOrderedItem -> goodOrderedItem.getBonusItem() == null || !goodOrderedItem.getBonusItem()).mapToInt(GoodOrderedItem::getQuantity).sum();
                }

                int diff = newQuantity - existingQuantity;
                requestItem.setApprovedQuantity(requestItem.getApprovedQuantity() + diff);
                if (requestItem.getApprovedQuantity() < 0) {
                    throw new CMSException(StatusCode.E1010, "Cannot be modified. Approved quantity is less than 0");
                }
                if (requestItem.getApprovedQuantity() >= requestItem.getQuantity()) {
                    requestItem.setRequestItemStatus(RequestItem.RequestItemStatus.APPROVED);
                } else {
                    requestItem.setRequestItemStatus(RequestItem.RequestItemStatus.SUBMITTED);
                }
            }
            if (prRequestItems.stream().allMatch(requestItem -> requestItem.getRequestItemStatus() == RequestItem.RequestItemStatus.APPROVED)) {
                purchaseRequest.setRequestStatus(RequestStatus.APPROVED);
            } else {
                purchaseRequest.setRequestStatus(RequestStatus.PARTIAL_APPROVED);
            }
            purchaseRequests.add(purchaseRequest);
        }

        orderDatabaseService.savePurchaseRequests(purchaseRequests);
    }

    private Order getOrder(Order order) throws CMSException {
        if (OrderStatus.DRAFT.equals(order.getOrderStatus()) || order.getId() == null) {
            order = orderDatabaseService.saveOrder(order);
        } else {
            order = orderDatabaseService.findOrderById(order.getId()).orElseThrow(
                    () -> new CMSException(StatusCode.E2000, "Order not found"));
        }
        return order;
    }

    private void addPODefaultValues(Order order) throws CMSException {
        if (order.getRequestId() == null) {
            PurchaseRequest purchaseRequest = createPurchaseRequest(order);

            createPurchaseRequestByPO(order, purchaseRequest);
            PurchaseRequest newPr = requestService.createPurchaseRequest(purchaseRequest);

            order.setRequestId(newPr.getId());
            order.setRequestNo(newPr.getRequestNo());
            order.getGoodPurchasedItems().forEach(
                    goodOrderedItem -> goodOrderedItem.setPurchaseRequestId(newPr.getId())
            );
        }

        if (order.getCreateDate() == null) {
            order.setCreateDate(LocalDate.now());
        }

        if (order.getOrderStatus() == null) {
            order.setOrderStatus(OrderStatus.DRAFT);
        }

        if (order.getOrderNo() == null) {
            order.setOrderNo(runningNumberService.generateOrderNumber());
        }

        if (order.getOrderDate() == null) {
            order.setOrderDate(LocalDate.now());
        }

        if (order.getRequestDate() == null) {
            order.setRequestDate(LocalDate.now());
        }
    }

    public Order modifyTransferOrder(Order transferOrder, boolean issue) throws CMSException {
        logger.info("modify transfer order [" + transferOrder + "]");

        //validateTO(transferOrder);
        addTODefaultValues(transferOrder);
        Order order = getOrder(transferOrder);

        if (issue) {
            modifyPurchaseRequestByTO(transferOrder, order);
        }

        if (transferOrder.getOrderStatus() != null) {
            order.setOrderStatus(transferOrder.getOrderStatus());
        }
        order.setRemark(transferOrder.getRemark());
        order.setRequestClinicId(transferOrder.getRequestClinicId());
        order.setSenderClinicId(transferOrder.getSenderClinicId());
        List<TransferRequestItem> transferRequestItems = new ArrayList<>();

        for (TransferRequestItem incoming : transferOrder.getTransferRequestItems()) {
            if (incoming.getLineNo() == null) {
                incoming.setLineNo(IdUtils.lineNoGenerator());
            }

            TransferRequestItem transferRequestItem = incoming;

            Optional<TransferRequestItem> existingOpt = order.getTransferRequestItems().
                    stream().filter(item -> incoming.getLineNo().equals(item.getLineNo()))
                    .findFirst();

            if (existingOpt.isPresent()) {
                transferRequestItem = existingOpt.get();
                transferRequestItem.copy(incoming);
            }

            boolean isValid = transferRequestItem.checkValidate();
            if (!isValid) {
                throw new CMSException(StatusCode.I5000, "Invalid transfer item");
            }

            transferRequestItems.add(transferRequestItem);
        }
        order.setTransferRequestItems(transferRequestItems);

        return orderDatabaseService.saveOrder(order);
    }

    private void modifyPurchaseRequestByTO(Order transferOrder, Order order) throws CMSException {
        Set<String> prIds = order.getTransferRequestItems().stream()
                .map(TransferRequestItem::getPurchaseRequestId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        List<PurchaseRequest> purchaseRequests = new ArrayList<>();

        for (String prId : prIds) {
            PurchaseRequest purchaseRequest = orderDatabaseService.findPurchaseRequestById(prId)
                    .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));
            List<RequestItem> prRequestItems = purchaseRequest.getRequestItems();

            for (RequestItem prRequestItem : prRequestItems) {
                int newQty = transferOrder.getTransferRequestItems()
                        .stream()
                        .filter(ti -> ti.getItemRefId().equals(prRequestItem.getItemRefId()))
                        .collect(Collectors.summingInt(TransferRequestItem::getQuantity));

                int extQty = 0;
                if (!OrderStatus.DRAFT.equals(order.getOrderStatus())) {
                    extQty = order.getTransferRequestItems()
                            .stream()
                            .filter(ti -> ti.getPurchaseRequestId() != null && ti.getItemRefId().equals(prRequestItem.getItemRefId()))
                            .collect(Collectors.summingInt(TransferRequestItem::getQuantity));
                }

                int qtyDiff = newQty - extQty;
                prRequestItem.setApprovedQuantity(prRequestItem.getApprovedQuantity() + qtyDiff);

                if (prRequestItem.getApprovedQuantity() >= prRequestItem.getQuantity()) {
                    prRequestItem.setRequestItemStatus(RequestItem.RequestItemStatus.APPROVED);
                } else {
                    prRequestItem.setRequestItemStatus(RequestItem.RequestItemStatus.SUBMITTED);
                }

                if (prRequestItems.stream().allMatch(requestItem -> requestItem.getRequestItemStatus() == RequestItem.RequestItemStatus.APPROVED)) {
                    purchaseRequest.setRequestStatus(RequestStatus.APPROVED);
                } else {
                    purchaseRequest.setRequestStatus(RequestStatus.PARTIAL_APPROVED);
                }
            }
            purchaseRequests.add(purchaseRequest);
        }

        orderDatabaseService.savePurchaseRequests(purchaseRequests);
    }

    private void validateTO(Order order) throws CMSException {
        if (order.getSenderClinicId() == null || order.getSenderClinicId().equals("")) {
            throw new CMSException(StatusCode.I5000,
                    "Cannot be modified. Missing sender clinic id");
        }

        boolean isBatchNoNotPresent = order.getTransferRequestItems()
                .stream()
                .anyMatch(transferRequestItem -> transferRequestItem.getBatchNumber() == null
                        || transferRequestItem.getBatchNumber().equals(""));

        if (isBatchNoNotPresent) {
            throw new CMSException(StatusCode.I5000,
                    "Batch no cannot be empty");
        }

        validateOrder(order);
    }

    private void validateOrder(Order order) throws CMSException {
        if (OrderStatus.FULL_RECEIVED.equals(order.getOrderStatus())) {
            throw new CMSException(StatusCode.E1010,
                    "Cannot be modified. Order status is " + OrderStatus.FULL_RECEIVED);
        }
    }

    private void addTODefaultValues(Order order) throws CMSException {
        if (order.getRequestNo() == null) {
            PurchaseRequest purchaseRequest = createPurchaseRequest(order);

            createPurchaseRequestByTO(order, purchaseRequest);
            PurchaseRequest newPr = requestService.createPurchaseRequest(purchaseRequest);

            order.setRequestId(newPr.getId());
            order.setRequestNo(newPr.getRequestNo());
            order.getTransferRequestItems().forEach(
                    transferRequestItem -> transferRequestItem.setPurchaseRequestId(newPr.getId())
            );
        }

        if (order.getCreateDate() == null) {
            order.setCreateDate(LocalDate.now());
        }

        if (order.getOrderStatus() == null) {
            order.setOrderStatus(OrderStatus.DRAFT);
        }
        if (order.getOrderNo() == null) {
            order.setOrderNo(runningNumberService.generateOrderNumber());
        }
        if (order.getOrderDate() == null) {
            order.setOrderDate(LocalDate.now());
        }
        if (order.getRequestDate() == null) {
            order.setRequestDate(LocalDate.now());
        }
    }

    public Order deleteOrder(String orderId) throws CMSException {
        Order order = orderDatabaseService.findOrderById(orderId).orElseThrow(() -> new CMSException(StatusCode.I5000,
                "Order not found"));

        int receivedQtySum = getReceivedQtySum(order);

        if (receivedQtySum > 0) {
            logger.info("delete not allowed.total received qty of order[" + orderId + "] is " + receivedQtySum);
            throw new CMSException(StatusCode.I5000,
                    "Delete not allowed.Received quantity is greater than zero");
        }

        order.setOrderStatus(OrderStatus.DELETED);

        logger.info("status changed to deleted of order[" + orderId + "]");
        orderDatabaseService.saveOrder(order);

        return order;
    }

    public int getReceivedQtySum(Order order) {
        List<GoodReceivedNote> goodReceivedNotes = order.getGoodReceivedNotes();
        int receivedQtySum = goodReceivedNotes.stream()
                .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                .collect(Collectors.summingInt(DeliveryItem::getQuantity));
        return receivedQtySum;
    }

    public List<Order> createOrderByRequestId(String requestId, List<Order> orders) throws CMSException {

        logger.info("createOrderByRequestId[" + requestId + "], orders[" + orders + "]");
        PurchaseRequest purchaseRequest = null;
        if (requestId != null) {
            purchaseRequest = orderDatabaseService.findPurchaseRequestById(requestId)
                    .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request[" + requestId + "] not found"));
        }

        if (purchaseRequest != null && purchaseRequest.getRequestStatus() != RequestStatus.APPROVED
                && purchaseRequest.getRequestStatus() != RequestStatus.PARTIAL_APPROVED) {
            logger.error("Invalid request status:" + purchaseRequest.getRequestStatus());
            throw new CMSException(StatusCode.E1010, "Invalid request status");
        }

        for (Order order : orders) {
            if (!order.checkValidate()) {
                logger.error("Invalid order[" + order + "]");
                throw new CMSException(StatusCode.E1002, "Invalid purchaseOrder");
            }
        }

        if (!orders.stream()
                .filter(order -> order.getOrderType() == OrderType.PURCHASE)
                .flatMap(order -> order.getGoodPurchasedItems().stream())
                .allMatch(GoodOrderedItem::checkValidate)) {
            logger.error("Invalid purchase request items[" + orders + "]");
            throw new CMSException(StatusCode.E1002, "Invalid good purchased items");
        }

        if (!orders.stream()
                .filter(order -> order.getOrderType() == OrderType.TRANSFER)
                .flatMap(order -> order.getTransferRequestItems().stream())
                .allMatch(TransferRequestItem::checkValidate)) {
            logger.error("Invalid transfer request items[" + orders + "]");
            throw new CMSException(StatusCode.E1002, "Invalid transfer request items");
        }

        Set<String> itemIds = new HashSet<>();
        itemIds.addAll(orders.stream()
                .filter(order -> order.getOrderType() == OrderType.RETURN)
                .flatMap(order -> order.getReturnItems().stream())
                .map(GoodReturnItem::getItemRefId)
                .collect(Collectors.toSet()));

        itemIds.addAll(orders.stream()
                .filter(order -> order.getOrderType() == OrderType.RETURN)
                .flatMap(order -> order.getDeliveryNotes().stream())
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .map(DeliveryItem::getItemRefId)
                .collect(Collectors.toSet()));

        Map<String, Item> itemMap = getItemMapByIds(new ArrayList<>(itemIds));

        if (!orders.stream()
                .filter(order -> order.getOrderType() == OrderType.RETURN)
                .flatMap(order -> order.getReturnItems().stream())
                .allMatch(goodReturnItem -> goodReturnItem.checkValidate(itemMap.get(goodReturnItem.getItemRefId())))) {
            logger.error("Invalid purchase request items[" + orders + "]");
            throw new CMSException(StatusCode.E1002, "Invalid good purchased items");
        }

        List<Order> returnOrder = new ArrayList<>();
        for (Order order : orders) {
            order.setRequestId(requestId);

            order.getGoodPurchasedItems().stream()
                    .filter(goodOrderedItem -> goodOrderedItem.getLineNo() == null)
                    .forEach(
                            goodOrderedItem -> goodOrderedItem.setLineNo(IdUtils.lineNoGenerator())
                    );

            order.getTransferRequestItems().stream()
                    .filter(goodOrderedItem -> goodOrderedItem.getLineNo() == null)
                    .forEach(
                            transferRequestItem -> transferRequestItem.setLineNo(IdUtils.lineNoGenerator())
                    );

            order.getReturnItems().stream()
                    .filter(goodReturnItem -> goodReturnItem.getLineNo() == null)
                    .forEach(
                            goodReturnItem -> goodReturnItem.setLineNo(IdUtils.lineNoGenerator())
                    );

            Order savedOrder = createOrder(order);

            savedOrder = addRequestDetail(savedOrder);

            returnOrder.add(savedOrder);
        }

        return returnOrder;
    }

    private Order createOrder(Order order) throws CMSException {

        logger.info("createPurchaseOrder [" + order + "]");

        if (order.getOrderStatus() == OrderStatus.REJECTED
                || order.getOrderStatus() == OrderStatus.FULL_RECEIVED) {
            throw new CMSException(StatusCode.E1002, "Invalid order status");
        }

        order.setCreateDate(LocalDate.now());

        if (order.getOrderNo() == null) {
            order.setOrderNo(runningNumberService.generateOrderNumber());
        }

        if (order.getOrderStatus() == null) {
            order.setOrderStatus(OrderStatus.INITIAL);
        }
        List<GoodOrderedItem> purchaseItems = order.getGoodPurchasedItems().stream()
                .map(goodOrderedItem -> setPrice(order.getSupplierId(), goodOrderedItem))
                .collect(Collectors.toList());
        order.setGoodPurchasedItems(purchaseItems);

        Tuple<Double, Double> gstTuple = calculateGst(order);

        order.setGstPercentage(BigDecimal.valueOf(gstTuple.getFirst()));
        order.setGstAmount(BigDecimal.valueOf(gstTuple.getSecond()));
        return orderDatabaseService.saveOrder(order);
    }

    private Order updateOrder(String orderId, Order order) throws CMSException {

        logger.info("updateOrder[" + orderId + "], order[" + order + "]");
        if (!order.checkValidate()) {
            throw new CMSException(StatusCode.E1002, "Invalid order");
        }
        if (order.getOrderType() == OrderType.PURCHASE && !order.getGoodPurchasedItems().stream()
                .allMatch(GoodOrderedItem::checkValidate)) {
            throw new CMSException(StatusCode.E1002, "Invalid good purchased item");
        }

        if (order.getOrderType() == OrderType.TRANSFER && !order.getTransferRequestItems().stream()
                .allMatch(TransferRequestItem::checkValidate)) {
            throw new CMSException(StatusCode.E1002, "Invalid transfer request item");
        }

        Order existOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Blanket purchase order not found"));

        if (existOrder.getOrderStatus() != OrderStatus.INITIAL &&
                existOrder.getOrderStatus() != OrderStatus.PARTIAL_RECEIVED) {
            throw new CMSException(StatusCode.E1010, "Not allow to update blanket purchase order for status:" + existOrder.getOrderStatus());
        }

        existOrder.copy(order);

        Order savedBlanketPurchaseOrder = orderDatabaseService.saveOrder(existOrder);

        return savedBlanketPurchaseOrder;
    }

    public Order createReturnOrder(String requestClinicId, String supplierId, String purchaseOrderId, GoodReceivedReturnStatus status, List<GoodReturnItem> goodReturnItems) throws CMSException {

        logger.info("create return order by good return items[" + goodReturnItems + "]");

        getClinic(requestClinicId);
        getSupplier(supplierId);

        if (goodReturnItems == null || goodReturnItems.size() == 0) {
            logger.error("ReturnItems should not be null");
            throw new CMSException(StatusCode.E1002, "Return items should not be empty");
        }

        goodReturnItems.stream().forEach(
                goodReturnItem -> goodReturnItem.setLineNo(IdUtils.lineNoGenerator())
        );

        Order returnOrder = new OrderBuilder()
                .setRequestClinicId(requestClinicId)
                .setSupplierId(supplierId)
                .setCreateDate(LocalDate.now())
                .setReturnStatus(status)
                .setReturnItems(goodReturnItems)
                .setDeliveryNotes(new ArrayList<>())
                .setPurchaseOrderId(purchaseOrderId)
                .setNavIntegrationResult(new NavIntegrationResult())
                .createReturnOrder();

        Optional<Order> purchaseOrderOpt = Objects.nonNull(returnOrder.getPurchaseOrderId()) ?
                orderDatabaseService.findOrderById(returnOrder.getPurchaseOrderId()) : Optional.empty();

        List<Order> returnOrders = new ArrayList<>();
        if (Objects.nonNull(returnOrder.getPurchaseOrderId())) {
            returnOrders = orderDatabaseService.findReturnOrderByReturnItemsPurchaseOrderId(returnOrder.getPurchaseOrderId(),
                    List.of(GoodReceivedReturnStatus.CONFIRM, GoodReceivedReturnStatus.APPROVED, GoodReceivedReturnStatus.RETURNED));
        }
        if (returnOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM) {
            returnOrder.setOrderDate(LocalDate.now());
        }
        returnOrders.add(returnOrder);

        Set<String> itemIds = new HashSet<>();
        itemIds.addAll(returnOrders.stream()
                .filter(order -> order.getOrderType() == OrderType.RETURN)
                .flatMap(order -> order.getReturnItems().stream())
                .map(GoodReturnItem::getItemRefId)
                .collect(Collectors.toSet()));

        itemIds.addAll(returnOrders.stream()
                .filter(order -> order.getOrderType() == OrderType.RETURN)
                .flatMap(order -> order.getDeliveryNotes().stream())
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .map(DeliveryItem::getItemRefId)
                .collect(Collectors.toSet()));

        if (purchaseOrderOpt.isPresent()) {
            itemIds.addAll(purchaseOrderOpt.get().getGoodReceivedNotes().stream()
                    .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                    .map(DeliveryItem::getItemRefId)
                    .collect(Collectors.toSet()));
        }

        Map<String, Item> itemMap = getItemMapByIds(new ArrayList<>(itemIds));

        checkValidateCreateOrUpdateReturnOrder(status, goodReturnItems, itemMap);

        checkGoodReturnItemIsAvailable(requestClinicId, returnOrders, itemMap);

        if (!checkReturnOrderItemHaveReceived(purchaseOrderOpt, returnOrders, itemMap)) {
            logger.error("Return Item does not match to GRN, goodReceivedNotes[{}], return orders[{}]",
                    purchaseOrderOpt.isPresent() ? purchaseOrderOpt.get() : null, returnOrders);
            throw new CMSException(StatusCode.E1010, "Return Item does not match to GRN");
        }

        returnOrder.setOrderNo(runningNumberService.generateOrderNumber());

        Order savedOrder = orderDatabaseService.saveOrder(returnOrder);
        if (savedOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(savedOrder.getRequestClinicId(), savedOrder.getId(), savedOrder));
        }
        return savedOrder;
    }

    public Order updateReturnOrder(String orderId, String supplierId, GoodReceivedReturnStatus status, List<GoodReturnItem> goodReturnItems) throws CMSException {

        logger.info("Update return order by id[" + orderId + "] and status[" + status + "] goodReturnItem[" + goodReturnItems + "]");

        Order existReturnOrder = getOrder(orderId, OrderType.RETURN);

        if (existReturnOrder.getReturnStatus() != GoodReceivedReturnStatus.DRAFT) {
            logger.error("return order not validate, status[{}]", existReturnOrder.getReturnStatus());
            throw new CMSException(StatusCode.E1010, "Return order status not allow, status[" + existReturnOrder.getReturnStatus() + "]");
        }

        getSupplier(supplierId);

        goodReturnItems.stream().forEach(
                goodReturnItem -> goodReturnItem.setLineNo(IdUtils.lineNoGenerator())
        );

        existReturnOrder.setReturnItems(goodReturnItems);

        Optional<Order> purchaseOrderOpt = Objects.nonNull(existReturnOrder.getPurchaseOrderId()) ?
                orderDatabaseService.findOrderById(existReturnOrder.getPurchaseOrderId()) : Optional.empty();

        List<Order> returnOrders = new ArrayList<>();
        if (Objects.nonNull(existReturnOrder.getPurchaseOrderId())) {
            returnOrders = orderDatabaseService.findReturnOrderByReturnItemsPurchaseOrderId(existReturnOrder.getPurchaseOrderId(),
                    List.of(GoodReceivedReturnStatus.CONFIRM, GoodReceivedReturnStatus.APPROVED, GoodReceivedReturnStatus.RETURNED));
        }
        existReturnOrder.setReturnStatus(status);
        if (existReturnOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM) {
            existReturnOrder.setOrderDate(LocalDate.now());
        }
        returnOrders.add(existReturnOrder);

        Set<String> itemIds = new HashSet<>();
        itemIds.addAll(returnOrders.stream()
                .flatMap(order -> order.getReturnItems().stream())
                .map(GoodReturnItem::getItemRefId)
                .collect(Collectors.toSet()));

        itemIds.addAll(returnOrders.stream()
                .flatMap(order -> order.getDeliveryNotes().stream())
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .map(DeliveryItem::getItemRefId)
                .collect(Collectors.toSet()));

        if (purchaseOrderOpt.isPresent()) {
            itemIds.addAll(purchaseOrderOpt.get().getGoodReceivedNotes().stream()
                    .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                    .map(DeliveryItem::getItemRefId)
                    .collect(Collectors.toSet()));
        }

        Map<String, Item> itemMap = getItemMapByIds(new ArrayList<>(itemIds));

        checkValidateCreateOrUpdateReturnOrder(status, goodReturnItems, itemMap);
        checkGoodReturnItemIsAvailable(existReturnOrder.getRequestClinicId(), returnOrders, itemMap);

        if (!checkReturnOrderItemHaveReceived(purchaseOrderOpt, returnOrders, itemMap)) {
            logger.error("Return Item does not match to GRN, goodReceivedNotes[{}], return orders[{}]",
                    purchaseOrderOpt.isPresent() ? purchaseOrderOpt.get() : null, returnOrders);
            throw new CMSException(StatusCode.E1010, "Return Item does not match to GRN");
        }

        Order savedOrder = orderDatabaseService.saveOrder(existReturnOrder);
        if (savedOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(savedOrder.getRequestClinicId(), savedOrder.getId(), savedOrder));
        }
        return savedOrder;
    }

    public GoodReceivedNote addGoodReceivedNote(String orderId, GoodReceivedNote goodReceivedNote) throws CMSException {

        logger.info("addGoodReceivedNote for orderId[" + orderId + "], goodReceivedNote[" + goodReceivedNote + "]");

        Order curOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));

        if (curOrder.getOrderStatus() == OrderStatus.FULL_RECEIVED || curOrder.getOrderStatus() == OrderStatus.DELETED) {
            logger.error("Invalid order status:" + curOrder.getOrderStatus());
            throw new CMSException(StatusCode.E1010, "Invalid order status:" + curOrder.getOrderStatus());
        }

        goodReceivedNote.setId(CommonUtils.idGenerator());
        goodReceivedNote.setCreateDate(LocalDate.now());
        curOrder.getGoodReceivedNotes().add(goodReceivedNote);
        Map<String, Item> itemMap = getItemMapByOrder(curOrder);
        checkGoodReceivedNoteValidate(goodReceivedNote, curOrder.getOrderType() == OrderType.PURCHASE, itemMap);
        if (curOrder.getOrderType() == OrderType.PURCHASE &&
                !checkGoodReceivedItemHaveOrdered(curOrder.getGoodPurchasedItems(), curOrder.getGoodReceivedNotes(), itemMap)) {
            logger.error("Received items does not match to order, goodPurchasedItem[" +
                    curOrder.getGoodPurchasedItems() +
                    "], goodReceivedNote[" + curOrder.getGoodReceivedNotes() + "]");
            throw new CMSException(StatusCode.E1002, "Received items does not match to order");
        } else if (curOrder.getOrderType() == OrderType.TRANSFER
                && !curOrder.iscPTransfer()
                && !checkTransferItemHaveOrdered(curOrder.getDeliveryNotes(), curOrder.getGoodReceivedNotes(), itemMap)) {
            logger.error("Received items does not match to delivery note, transferRequestItem[" + curOrder.getTransferRequestItems() +
                    "], goodReceivedNote[" + curOrder.getGoodReceivedNotes() + "]");
            throw new CMSException(StatusCode.E1002, "Received items does not match to delivery note");
        }

        if (goodReceivedNote.getGrnNo() == null) {
            goodReceivedNote.setGrnNo(runningNumberService.generateGRNNumber());
        }
        String grnNo = goodReceivedNote.getGrnNo();

        changeOrderStatus(curOrder, itemMap);

        String requestClinicId = curOrder.getRequestClinicId();
        if (goodReceivedNote.getReceiverId() != null) {
            requestClinicId = goodReceivedNote.getReceiverId();
        }
        updateInventoryRecordByGRN(orderId, requestClinicId, goodReceivedNote, false);

        curOrder = orderDatabaseService.saveOrder(curOrder);
        if (curOrder.getOrderStatus() == OrderStatus.FULL_RECEIVED) {
            updateRequestToTransferStatus(curOrder.getRequestId());
        }
        if (goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            if (curOrder.getOrderType() == OrderType.PURCHASE) {
                systemNotifier.notify(new NavPurchaseNotification(NavPurchaseNotification.NavAction.CREATE_PUR_GRN,
                        goodReceivedNote.getReceiverId(), curOrder.getId(), goodReceivedNote));
            } else {
                systemNotifier.notify(new NavPurchaseNotification(NavPurchaseNotification.NavAction.CREATE_TRANSFER_GRN,
                        goodReceivedNote.getReceiverId(), curOrder.getId(), goodReceivedNote));
            }
        }

        String requestId = curOrder.getRequestId();
        Optional<PurchaseRequest> purchaseRequestOpt = Objects.nonNull(requestId) ?
                orderDatabaseService.findPurchaseRequestById(requestId) :
                Optional.empty();

        return curOrder.getGoodReceivedNotes().stream()
                .filter(goodReceiveNote1 -> goodReceiveNote1.getGrnNo().equals(grnNo))
                .map(goodReceivedNote1 -> addRequestDetail(purchaseRequestOpt, goodReceivedNote1))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "GoodReceivedNote cannot save"));
    }

    public void revertGoodReceivedNote(String orderId, String grnId, boolean revert) throws CMSException {

        Order curOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));

        final Optional<GoodReceivedNote> grnOpt = curOrder.getGoodReceivedNoteByGrnId(grnId);

        if (grnOpt.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "GRN not found");
        }

        GoodReceivedNote grn = grnOpt.get();
        List<Item> clinicItems = itemService.listItemByClinicId(grn.getReceiverId());
        List<Inventory> inventories = grn.getReceivedItems().stream()
                .filter(receivedItem -> checkItemNeedUpdateInventory(clinicItems, receivedItem))
                .map(receivedItem -> {
                    try {
                        return locationService.mapDeliveryItemToInventory(receivedItem, revert);
                    } catch (CMSException e) {
                        logger.error("mapDeliveryItemToInventory[" + receivedItem + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());
        Location location = new Location(grn.getReceiverId());
        location.setInventory(inventories);

        locationService.findAndModify(location, true, false);
    }

    public GoodReceivedNote updateGoodReceivedNote(String orderId, String grnId, GoodReceivedNote goodReceivedNote) throws CMSException {

        logger.info("updateGoodReceivedNote for orderId[" + orderId + "], grnId[" + grnId + "], goodReceivedNote[" + goodReceivedNote + "]");
        Order curOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));

        GoodReceivedNote curGoodReceivedNote = curOrder.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote1 -> goodReceivedNote1.getId().equals(grnId))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "GoodReceivedNote not found"));

        if (curGoodReceivedNote.getStatus() != DeliveryNoteStatus.DRAFT) {
            logger.error("Not allow to update for status:" + curGoodReceivedNote.getStatus());
            throw new CMSException(StatusCode.E1010, "Not allow to update for status:" + curGoodReceivedNote.getStatus());
        }
        goodReceivedNote.setPreviousReceivedItems(curGoodReceivedNote.getReceivedItems());
        curGoodReceivedNote.copy(goodReceivedNote);

        Map<String, Item> itemMap = getItemMapByOrder(curOrder);
        checkGoodReceivedNoteValidate(goodReceivedNote, curOrder.getOrderType() == OrderType.PURCHASE, itemMap);
        if (curOrder.getOrderType() == OrderType.PURCHASE &&
                !checkGoodReceivedItemHaveOrdered(curOrder.getGoodPurchasedItems(), curOrder.getGoodReceivedNotes(), itemMap)) {
            logger.error("checkGoodReceivedItemHaveOrdered, goodPurchasedItem[" + curOrder.getGoodPurchasedItems() +
                    "], goodReceivedNote[" + curOrder.getGoodReceivedNotes() + "]");
            throw new CMSException(StatusCode.E1002, "Received items does not match to order");
        } else if (curOrder.getOrderType() == OrderType.TRANSFER
                && !curOrder.iscPTransfer()
                && !checkTransferItemHaveOrdered(curOrder.getDeliveryNotes(), curOrder.getGoodReceivedNotes(), itemMap)) {
            logger.error("checkTransferItemHaveOrdered, transferRequestItem[" + curOrder.getTransferRequestItems() +
                    "], goodReceivedNote[" + curOrder.getGoodReceivedNotes() + "]");
            throw new CMSException(StatusCode.E1002, "Received items does not match to delivery note");
        }

        changeOrderStatus(curOrder, itemMap);

        updateInventoryRecordByGRN(orderId, curOrder.getRequestClinicId(), goodReceivedNote, true);
        Order order = orderDatabaseService.saveOrder(curOrder);
        if (curOrder.getOrderStatus() == OrderStatus.FULL_RECEIVED) {
            updateRequestToTransferStatus(curOrder.getRequestId());
        }
        if (goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(NavPurchaseNotification.NavAction.CREATE_PUR_GRN,
                    goodReceivedNote.getReceiverId(), order.getId(), curGoodReceivedNote));
        }
        String requestId = order.getRequestId();
        Optional<PurchaseRequest> purchaseRequestOpt = Objects.nonNull(requestId) ?
                orderDatabaseService.findPurchaseRequestById(requestId) :
                Optional.empty();

        return order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote1 -> goodReceivedNote1.getId().equals(grnId))
                .map(goodReceivedNote1 -> addRequestDetail(purchaseRequestOpt, goodReceivedNote1))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "GoodReceivedNote cannot save"));
    }

    public boolean updateInventoryByCaseId(String caseId, boolean isSoCorrection, boolean isRefund) throws CMSException {
        logger.info("createSalesOrderByCaseId[" + caseId + "]");

        Case cmsCase = caseRepository.findById(caseId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Case is not found in CMS" + caseId));

        SalesOrder salesOrder = cmsCase.getSalesOrder();

        if (salesOrder == null) {
            throw new CMSException(StatusCode.E2000, "SalesOrder is not found in CMS for caseId:[" + caseId + "]");
        }

        boolean isSoContainsPackages = !cmsCase.getPackages().isEmpty();

        if (salesOrder.getPurchaseItems().isEmpty() && !isSoContainsPackages) {
            logger.debug("No Purchase Items/Packages found in sales order for Case::" + cmsCase.getCaseNumber() + "]");
            return true;
        }

        validateCase(cmsCase, isSoCorrection, isSoContainsPackages, isRefund);
        updateInventoryRecordBySalesOrder(cmsCase, salesOrder, isSoCorrection, isRefund);

        return true;
    }

    private Optional<Location> updateInventoryRecordBySalesOrder(Case cmsCase, SalesOrder salesOrder, boolean isSoCorrection, boolean isRefund) throws CMSException {
        Clinic clinic = clinicRepository.findById(cmsCase.getClinicId())
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Clinic is not found in CMS" + cmsCase.getClinicId()));

        String clinicId = clinic.getId();
        Location location = new Location(clinicId);
        List<Inventory> inventories;

        if (isSoCorrection) {
            inventories = createInventoryItemsForSOCorrection(salesOrder, cmsCase);
        } else {
            inventories = createInventoryItemsForSO(salesOrder, cmsCase);
        }

        location.setInventory(inventories);
        locationService.findAndModify(location, true, false);

        return Optional.empty();
    }

    private void validateCase(Case cmsCase, boolean isSoCorrection,
                              boolean isSoContainsPackages, boolean isRefund) throws CMSException {
        if (isSoCorrection || isRefund) {
            if (!cmsCase.getStatus().equals(Case.CaseStatus.CLOSED)) {
                throw new CMSException(StatusCode.E2000, "Case is not closed in while doing SO Correction/ Refund" + cmsCase.getId());
            }
        }

        if (isSoContainsPackages) {
            if (!cmsCase.getSalesOrder().getStatus().equals(SalesOrder.SalesStatus.CLOSED)) {
                throw new CMSException(StatusCode.E2000, "Case is not open or salesOrder is not open" + cmsCase.getId());
            }
        }
    }

    private List<Inventory> createInventoryItemsForSO(SalesOrder salesOrder, Case cmsCase) {
        List<Inventory> inventories = salesOrder.getPurchaseItems()
                .stream()
                .map(salesItem -> {
                    try {
                        Inventory inventory = locationService.mapSalesItemToInventory(salesItem);
//                        inventory.setAvailableCount(inventory.getAvailableCount()*-1);
                        inventory.setAvailableCount(inventory.getAvailableCount().multiply(BigDecimal.valueOf(-1)));

                        return inventory;
                    } catch (CMSException e) {
                        logger.error("mapSalesItemToInventory[" + salesItem + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());

        List<Inventory> packageItemInventories = cmsCase.getPackages()
                .stream()
                .flatMap(pack -> pack.getPackageItems().stream())
                .map(pi -> {
                    SalesItem salesItem = new SalesItem();
                    salesItem.setItemRefId(pi.getItemId());
                    salesItem.setPurchaseUom(pi.getSalesUom());
                    salesItem.setDispenseQty(pi.getDispenseQty());
                    salesItem.setBatchNo(pi.getBatchNo());
                    salesItem.setExpireDate(pi.getExpiryDate());

                    try {
                        Inventory inventory = locationService.mapSalesItemToInventory(salesItem);
                        //inventory.setAvailableCount(inventory.getAvailableCount()*-1);
                        inventory.setAvailableCount(inventory.getAvailableCount().multiply(BigDecimal.valueOf(-1)));

                        return inventory;
                    } catch (CMSException e) {
                        logger.error("mapSalesItemToInventory[" + salesItem + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                }).collect(Collectors.toList());

        inventories.addAll(packageItemInventories);

        return inventories;
    }

    private List<Inventory> createInventoryItemsForSOCorrection(SalesOrder salesOrder, Case cmsCase) {
        List<BillAdjustment> billAdjustments = salesOrder.getBillAdjustments();
        List<Inventory> inventories = new ArrayList<>();

        for (BillAdjustment billAdjustment : billAdjustments) {
            List<Inventory> billAdjumentInventories = createInventoryItemsForBillAdjustment(salesOrder, cmsCase, billAdjustment);
            inventories.addAll(billAdjumentInventories);
        }

        return inventories;
    }

    public List<Inventory> createInventoryItemsForBillAdjustment(SalesOrder salesOrder, Case cmsCase, BillAdjustment billAdjustment) {
        List<Inventory> inventories = billAdjustment.getPurchaseItemsAdj()
                .stream()
                .map(salesItemAdj -> {
                    try {
                        SalesItem soldItem = salesOrder.getPurchaseItems().stream()
                                .filter(salesItem -> salesItem.getItemRefId().equals(salesItemAdj.getItemRefId()))
                                .findFirst()
                                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Item not found in a sold item list [" + salesItemAdj.getItemRefId() + "]"));
                        return locationService.mapSalesItemAdjToInventory(salesItemAdj, soldItem);
                    } catch (CMSException e) {
                        logger.error("mapSalesItemToInventory[" + salesItemAdj + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());

        List<Inventory> packageItemInventories = billAdjustment.getPackagesAdj()
                .stream()
                .flatMap(packAdj -> packAdj.getPackageItems().stream())
                .map(pai -> {
                    try {
                        PackageItem soldPackageItem = cmsCase.getPackages()
                                .stream()
                                .flatMap(pack -> pack.getPackageItems().stream())
                                .filter(spi -> spi.getSalesItemId().equals(pai.getSalesItemId()))
                                //.filter(spi -> spi.getItemId().equals(pai.getItemRefId()))
                                .findFirst()
                                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Item not found in a sold package item list for sales item id[" + pai.getSalesItemId() + "]"));

                        SalesItem soldItem = new SalesItem();
                        soldItem.setItemRefId(soldPackageItem.getItemId());
                        soldItem.setPurchaseUom(soldPackageItem.getSalesUom());
                        soldItem.setDispenseQty(soldPackageItem.getDispenseQty());
                        soldItem.setBatchNo(soldPackageItem.getBatchNo());
                        soldItem.setExpireDate(soldPackageItem.getExpiryDate());

                        return locationService.mapSalesItemAdjToInventory(pai, soldItem);
                    } catch (CMSException e) {
                        logger.error("mapSalesItemToInventory[" + pai + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                }).collect(Collectors.toList());
        inventories.addAll(packageItemInventories);

        return inventories;
    }

    public void approveReturnOrder(String orderId, List<GoodReturnItem> goodReturnItems) throws CMSException {

        logger.info("approveGoodReceivedVoidNote, orderId[" + orderId + "] goodReturnItems[" + goodReturnItems + "]");

        Order curReturnOrder = getOrder(orderId, OrderType.RETURN);

        if (curReturnOrder.getReturnStatus() != GoodReceivedReturnStatus.CONFIRM) {
            logger.error("Invalid good received void note status:" + curReturnOrder.getReturnStatus() + " orderId[" + orderId + "]");
            throw new CMSException(StatusCode.E1010, "Invalid good received void note status:" + curReturnOrder.getReturnStatus());
        }

        goodReturnItems.stream().forEach(
                goodReturnItem -> goodReturnItem.setLineNo(IdUtils.lineNoGenerator())
        );

        curReturnOrder.setReturnItems(goodReturnItems);
        Map<String, Item> itemMap = getItemMapByOrder(curReturnOrder);
        if (!goodReturnItems.stream()
                .allMatch(returnItem -> returnItem.checkValidate(itemMap.get(returnItem.getItemRefId())))) {
            logger.error("Invalid in good return Item in orderId[" + orderId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid in good return Item");
        }

        if (curReturnOrder.getReturnStatus() != GoodReceivedReturnStatus.RETURNED) {
            curReturnOrder.setReturnStatus(GoodReceivedReturnStatus.APPROVED);
        }

        String purchaseOrderId = curReturnOrder.getPurchaseOrderId();

        if (purchaseOrderId != null) {
            Order purchaseOrder = getOrder(purchaseOrderId, OrderType.PURCHASE);
            purchaseOrder.setOrderStatus(OrderStatus.REJECTED);

            orderDatabaseService.saveOrder(purchaseOrder);
        }

        orderDatabaseService.saveOrder(curReturnOrder);
    }

    public void rejectReturnOrder(String orderId) throws CMSException {

        logger.info("rejectGoodReceivedVoidNote, orderId[" + orderId + "]");
        Order curReturnOrder = getOrder(orderId, OrderType.RETURN);

        if (curReturnOrder.getReturnStatus() != GoodReceivedReturnStatus.CONFIRM) {
            throw new CMSException(StatusCode.E1010, "Invalid good received void note status:" + curReturnOrder.getReturnStatus());
        }
        curReturnOrder.setReturnStatus(GoodReceivedReturnStatus.REJECTED);
        orderDatabaseService.saveOrder(curReturnOrder);
    }

    public DeliveryNote addReturnOrderDeliveryNote(String orderId,
                                                   DeliveryNote deliveryNote) throws CMSException {

        logger.info("Add good received delivery note orderId[" + orderId + "] " +
                "goodReceivedVoidDeliveryNote[" + deliveryNote + "]");
        Order returnOrder = getOrder(orderId, OrderType.RETURN);

        if (returnOrder.getReturnStatus() != GoodReceivedReturnStatus.APPROVED) {
            logger.error("Not allow to add returnOrderDeliveryNote for status:" + returnOrder.getReturnStatus() +
                    " ,orderId[" + orderId + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to add goodReceivedVoidDeliveryNote for status:" + returnOrder.getReturnStatus());
        }

        deliveryNote.getTransferSendItems().forEach(
                deliveryItem -> deliveryItem.setLineNo(IdUtils.lineNoGenerator())
        );

        deliveryNote.setId(CommonUtils.idGenerator());
        deliveryNote.setCreateDate(LocalDate.now());
        returnOrder.getDeliveryNotes().add(deliveryNote);

        Map<String, Item> itemMap = getItemMapByOrder(returnOrder);
        checkDeliveryNoteValidate(orderId, deliveryNote, itemMap);
        if (!checkDeliveryItemHaveOrdered(returnOrder.getReturnItems(), returnOrder.getDeliveryNotes(), itemMap)) {
            logger.error("checkDeliveryItemHaveOrdered, returnItem[" + returnOrder.getReturnItems() + "], deliveryItem[" + deliveryNote.getTransferSendItems() + "]");
            throw new CMSException(StatusCode.E1010, "Delivery item does not match to return order");
        }

        deliveryNote.setDnNo(runningNumberService.generateDeliveryNote());
        String dnId = deliveryNote.getId();

        updateInventoryRecordByDeliveryNote(orderId, returnOrder.getRequestClinicId(), deliveryNote, false);

        changeReturnOrderStatus(returnOrder, itemMap);

        Order savedOrder = orderDatabaseService.saveOrder(returnOrder);

        DeliveryNote savedDeliveryNote = savedOrder
                .getDeliveryNotes().stream()
                .filter(goodReceivedVoidDeliveryNote1 -> goodReceivedVoidDeliveryNote1.getId().equals(dnId))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "GoodReceivedVoidDeliveryNote cannot save"));

        if (deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(savedOrder.getRequestClinicId(), savedOrder.getId(), null, savedDeliveryNote));
        }

        return savedDeliveryNote;
    }

    public DeliveryNote updateReturnOrderDeliveryNote(String orderId, String grvndnId,
                                                      DeliveryNote deliveryNote) throws CMSException {

        logger.info("Update good received delivery note orderId[" + orderId + "] " +
                "grvndnId[" + grvndnId + "], goodReceivedVoidDeliveryNote[" + deliveryNote + "]");

        Order returnOrder = getOrder(orderId, OrderType.RETURN);

        DeliveryNote curGoodReceivedVoidDeliveryNote = returnOrder.getDeliveryNotes().stream()
                .filter(goodReceivedVoidDeliveryNote1 -> goodReceivedVoidDeliveryNote1.getId().equals(grvndnId))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("Delivery note not found by orderId[{}] and grvndn[{}]", orderId, grvndnId);
                    return new CMSException(StatusCode.E2000, "Delivery Note not found");
                });

        curGoodReceivedVoidDeliveryNote.setPreviousTransferSendItems(curGoodReceivedVoidDeliveryNote.getTransferSendItems());

        if (returnOrder.getReturnStatus() != GoodReceivedReturnStatus.APPROVED) {
            logger.info("Not allow to update return order for status:" + returnOrder.getReturnStatus() +
                    " ,orderId[" + orderId + "], grvndnId[" + grvndnId + "]");
            throw new CMSException(StatusCode.E1010, "Not allow to update goodReceivedVoidNote for status:" + returnOrder.getReturnStatus());
        }

        deliveryNote.getTransferSendItems().forEach(
                deliveryItem -> deliveryItem.setLineNo(IdUtils.lineNoGenerator())
        );

        if (curGoodReceivedVoidDeliveryNote.getStatus() != DeliveryNoteStatus.DRAFT) {
            logger.error("Not allow to update Delivery note in return order[" + returnOrder.getId() + "] for status:" + curGoodReceivedVoidDeliveryNote.getStatus());
            throw new CMSException(StatusCode.E1010, "Not allow to update delivery note in return order for status:" + curGoodReceivedVoidDeliveryNote.getStatus());
        }

        curGoodReceivedVoidDeliveryNote.copy(deliveryNote);

        Map<String, Item> itemMap = getItemMapByOrder(returnOrder);
        checkDeliveryNoteValidate(orderId, deliveryNote, itemMap);
        if (!checkDeliveryItemHaveOrdered(returnOrder.getReturnItems(), returnOrder.getDeliveryNotes(), itemMap)) {
            logger.error("Delivery item does not match to return order, returnItem[" + returnOrder.getReturnItems() + "], deliveryItem[" + deliveryNote.getTransferSendItems() + "]");
            throw new CMSException(StatusCode.E1010, "Delivery item does not match to return order");
        }

        updateInventoryRecordByDeliveryNote(orderId, returnOrder.getRequestClinicId(), curGoodReceivedVoidDeliveryNote, true);

        changeReturnOrderStatus(returnOrder, itemMap);

        Order savedOrder = orderDatabaseService.saveOrder(returnOrder);

        DeliveryNote savedDeliveryNote = savedOrder.getDeliveryNotes().stream()
                .filter(goodReceivedVoidDeliveryNote1 -> goodReceivedVoidDeliveryNote1.getId().equals(grvndnId))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "GoodReceivedVoidDeliveryNote cannot save"));

        if (deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(savedOrder.getRequestClinicId(), savedOrder.getId(), null, savedDeliveryNote));
        }
        return savedDeliveryNote;
    }

    public DeliveryNote addDeliveryNote(String transferOrderId, DeliveryNote deliveryNote) throws CMSException {

        logger.info("addDeliveryNote, transferOrderId[" + transferOrderId + "], deliveryNote[" + deliveryNote + "]");

        Order curTransferOrder = orderDatabaseService.findOrderById(transferOrderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));

        if (curTransferOrder.getOrderType() != OrderType.TRANSFER) {
            logger.error("Order is not transfer type");
            throw new CMSException(StatusCode.E2000, "Order not found");
        }

        if (curTransferOrder.getOrderStatus() != OrderStatus.INITIAL &&
                curTransferOrder.getOrderStatus() != OrderStatus.PARTIAL_RECEIVED) {
            logger.error("Invalid order status:" + curTransferOrder.getOrderStatus());
            throw new CMSException(StatusCode.E1010, "Invalid order status:" + curTransferOrder.getOrderStatus());
        }

        deliveryNote.setId(CommonUtils.idGenerator());
        deliveryNote.setCreateDate(LocalDate.now());
        curTransferOrder.getDeliveryNotes().add(deliveryNote);
        Map<String, Item> itemMap = getItemMapByOrder(curTransferOrder);
        checkDeliveryNoteValidate(transferOrderId, deliveryNote, itemMap);
        if (!checkTransferDeliveryItemHaveOrdered(curTransferOrder.getTransferRequestItems(), curTransferOrder.getDeliveryNotes(), itemMap)) {
            logger.error("Delivery item not match to transfer order, transferRequestItem[" + curTransferOrder.getTransferRequestItems() +
                    "], DeliveryNote[" + curTransferOrder.getDeliveryNotes() + "]");
            throw new CMSException(StatusCode.E1010, "Delivery item not match to transfer order");
        }

        if (deliveryNote.getDnNo() == null) {
            deliveryNote.setDnNo(runningNumberService.generateDeliveryNote());
        }
        String dnNo = deliveryNote.getDnNo();

        updateInventoryRecordByDeliveryNote(transferOrderId, curTransferOrder.getSenderClinicId(), deliveryNote, false);
        curTransferOrder = orderDatabaseService.saveOrder(curTransferOrder);
        if (deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(curTransferOrder.getSenderClinicId(), curTransferOrder.getId(), deliveryNote));
        }
        return curTransferOrder.getDeliveryNotes().stream()
                .filter(deliveryNote1 -> deliveryNote1.getDnNo().equals(dnNo))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "Delivery note cannot save"));
    }

    public DeliveryNote updateDeliveryNote(String transferOrderId, String dnId, DeliveryNote deliveryNote) throws CMSException {

        logger.info("updateDeliveryNote, transferOrderId[" + transferOrderId + "], dnId[" + dnId + "], deliveryNote[" + deliveryNote + "]");

        Order curTransferOrder = orderDatabaseService.findOrderById(transferOrderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));

        if (curTransferOrder.getOrderType() != OrderType.TRANSFER) {
            logger.error("Order is not transfer type");
            throw new CMSException(StatusCode.E2000, "Order not found");
        }

        if (curTransferOrder.getOrderStatus() != OrderStatus.INITIAL &&
                curTransferOrder.getOrderStatus() != OrderStatus.PARTIAL_RECEIVED) {
            throw new CMSException(StatusCode.E1010, "Invalid order status:" + curTransferOrder.getOrderStatus());
        }

        DeliveryNote curDeliveryNote = curTransferOrder.getDeliveryNotes().stream()
                .filter(deliveryNote1 -> deliveryNote1.getId().equals(dnId))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Delivery note not found"));

        deliveryNote.setPreviousTransferSendItems(curDeliveryNote.getTransferSendItems());

        if (curDeliveryNote.getStatus() != DeliveryNoteStatus.DRAFT) {
            logger.error("Delivery note[{}] in order[{}] is not allow to update, status[{}]", curDeliveryNote.getId(), curTransferOrder.getId(), curDeliveryNote.getStatus());
            throw new CMSException(StatusCode.E1010, "Delivery note has been confirmed");
        }
        curDeliveryNote.copy(deliveryNote);
        Map<String, Item> itemMap = getItemMapByOrder(curTransferOrder);
        checkDeliveryNoteValidate(transferOrderId, deliveryNote, itemMap);
        if (!checkTransferDeliveryItemHaveOrdered(curTransferOrder.getTransferRequestItems(), curTransferOrder.getDeliveryNotes(), itemMap)) {
            logger.error("Delivery item not match to transfer order, transferRequestItem[" + curTransferOrder.getTransferRequestItems() +
                    "], DeliveryNote[" + curTransferOrder.getDeliveryNotes() + "]");
            throw new CMSException(StatusCode.E1010, "Delivery item not match to transfer order");
        }

        updateInventoryRecordByDeliveryNote(transferOrderId, curTransferOrder.getSenderClinicId(), deliveryNote, true);
        curTransferOrder = orderDatabaseService.saveOrder(curTransferOrder);
        if (deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM) {
            systemNotifier.notify(new NavPurchaseNotification(curTransferOrder.getSenderClinicId(), curTransferOrder.getId(), deliveryNote));
        }
        return curTransferOrder.getDeliveryNotes().stream()
                .filter(deliveryNote1 -> deliveryNote1.getId().equals(dnId))
                .findFirst()
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "Delivery note cannot save"));
    }

    private boolean isGoodOrderItemReceived(List<GoodOrderedItem> goodOrderedItems, Map<String, Double> itemIdQtyMap, Map<String, Item> itemMap) {
        Map<String, Double> orderItemIdQtyMap = convertGoodOrderedItemItemToItemIdQtyMap(goodOrderedItems, itemMap);

        List<String> itemIds = new ArrayList<>(orderItemIdQtyMap.keySet());

        return isOverExistingQty(itemIds, itemIdQtyMap, orderItemIdQtyMap);
    }

    private boolean isTransferRequestItemReceived(List<TransferRequestItem> transferRequestItems, Map<String, Double> itemIdQtyMap, Map<String, Item> itemMap) {
        Map<String, Double> transferItemIdQtyMap = convertTransferRequestItemToItemIdQtyMap(transferRequestItems, itemMap);

        List<String> itemIds = new ArrayList<>(transferItemIdQtyMap.keySet());

        return isOverExistingQty(itemIds, itemIdQtyMap, transferItemIdQtyMap);
    }

    private boolean checkIsAllItemReturned(Order returnOrder, Map<String, Item> itemMap) {

        List<GoodReturnItem> returnItems = returnOrder.getReturnItems();

        List<DeliveryItem> deliveryItems = returnOrder.getDeliveryNotes().stream()
                .filter(deliveryNote -> deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> itemIdReturnQtyMap = convertDeliveryItemToItemIdQtyMap(returnItems, itemMap);

        Map<String, Double> itemIdDeliveryQtyMap = convertDeliveryItemToItemIdQtyMap(deliveryItems, itemMap);

        List<String> itemIds = new ArrayList<>(itemIdReturnQtyMap.keySet());

        return isOverExistingQty(itemIds, itemIdDeliveryQtyMap, itemIdReturnQtyMap);
    }

    private boolean checkIsAllItemReceived(Order order, Map<String, Item> itemMap) {

        List<DeliveryItem> goodReceivedItems = order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(goodReceiveNote -> goodReceiveNote.getReceivedItems().stream())
                .collect(Collectors.toList());

        List<Order> returnOrders = orderDatabaseService.findReturnOrderByReturnItemsPurchaseOrderId(order.getId(),
                List.of(GoodReceivedReturnStatus.APPROVED));

        List<DeliveryItem> goodReturnItems = returnOrders.stream()
                .flatMap(goodReceiveVoidNote -> goodReceiveVoidNote.getReturnItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> itemIdReceiveQtyMap = convertDeliveryItemToItemIdQtyMap(goodReceivedItems, itemMap);

        Map<String, Double> itemIdReturnQtyMap = convertDeliveryItemToItemIdQtyMap(goodReturnItems, itemMap);

        Map<String, Double> itemIdQtyMap = itemIdReceiveQtyMap.entrySet().stream()
                .collect(Collectors.toMap(map -> map.getKey(), map -> (
                        map.getValue() - (itemIdReturnQtyMap.get(map.getKey()) == null ? 0 : itemIdReturnQtyMap.get(map.getKey()))
                )));

        if (order.getOrderType() == OrderType.PURCHASE) {
            return isGoodOrderItemReceived(order.getGoodPurchasedItems(), itemIdQtyMap, itemMap);
        } else {
            return isTransferRequestItemReceived(order.getTransferRequestItems(), itemIdQtyMap, itemMap);
        }
    }

    private Optional<Location> updateInventoryRecordByGRN(String orderId, String clinicId, GoodReceivedNote goodReceivedNote, boolean isCorrection) throws CMSException {

        if (goodReceivedNote.getStatus() != DeliveryNoteStatus.CONFIRM) {
            logger.warn("Not update inventory GRN[" + goodReceivedNote.getGrnNo() + "] status:" + goodReceivedNote.getStatus());
            return Optional.empty();
        }

        if (locationService.useNavInventory()) {
            return Optional.empty();
        }

        List<Item> allItems = itemService.listAllItems();
        List<Inventory> inventories = goodReceivedNote.getReceivedItems().stream()
                .filter(receivedItem -> checkItemNeedUpdateInventory(allItems, receivedItem))
                .map(receivedItem -> {
                    try {
                        Optional<DeliveryItem> previousReceivedItem = Optional.ofNullable(goodReceivedNote.getPreviousReceivedItems()).orElse(Collections.emptyList())
                                .stream().filter(pReceivedItem -> receivedItem.getItemRefId().equals(pReceivedItem.getItemRefId()))
                                .findFirst();
                        return locationService.mapDeliveryItemToInventory(previousReceivedItem, receivedItem, isCorrection);
                    } catch (CMSException e) {
                        logger.error("mapDeliveryItemToInventory[" + receivedItem + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());
        Location location = new Location(clinicId);
        location.setInventory(inventories);

        List<InventoryTransaction> transactionList = locationService.findAndModify(location, true, true);

        locationService.saveInventoryTransactions(transactionList, orderId, InventoryTransaction.Type.GRN);

        return Optional.empty();
    }

    public Optional<Location> updateInventoryRecordByDeliveryNote(String orderId, String clinicId, DeliveryNote deliveryNote, boolean isCorrection) throws CMSException {

        if (deliveryNote.getStatus() != DeliveryNoteStatus.CONFIRM) {
            logger.warn("Not update inventory DeliveryNote[" + deliveryNote + "] status:" + deliveryNote.getStatus());
            return Optional.empty();
        }

        if (locationService.useNavInventory()) {
            return Optional.empty();
        }

        List<Item> clinicItems = itemService.listItemByClinicId(clinicId);
        List<Inventory> inventories = deliveryNote.getTransferSendItems().stream()
                .filter(deliveryItem -> checkItemNeedUpdateInventory(clinicItems, deliveryItem))
                .map(deliveryItem -> {
                    try {
                        Optional<DeliveryItem> previousDeliveryItem = Optional.ofNullable(deliveryNote.getPreviousTransferSendItems()).orElse(Collections.emptyList())
                                .stream().filter(pDeliveryItem -> deliveryItem.getItemRefId().equals(pDeliveryItem.getItemRefId()))
                                .findFirst();

                        Inventory inventory = locationService.mapDeliveryItemToInventory(previousDeliveryItem, deliveryItem, isCorrection);
                        //inventory.setAvailableCount(inventory.getAvailableCount() * -1);
                        inventory.setAvailableCount(inventory.getAvailableCount().multiply(BigDecimal.valueOf(-1)));
                        return inventory;
                    } catch (CMSException e) {
                        logger.error("mapDeliveryItemToInventory[" + deliveryItem + "] throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());

        Location location = new Location(clinicId);
        location.setInventory(inventories);

        List<InventoryTransaction> inventoryTransactionList = locationService.findAndModify(location, true, false);
        locationService.saveInventoryTransactions(inventoryTransactionList, orderId, InventoryTransaction.Type.DO);

        return Optional.empty();
    }

    private boolean checkItemNeedUpdateInventory(List<Item> drugItems, DeliveryItem deliveryItem) throws CMSRuntimeException {

        try {
            Item item = drugItems.stream()
                    .filter(drugItem -> drugItem.getId().equals(deliveryItem.getItemRefId()))
                    .findFirst()
                    .orElseThrow(() -> new CMSException(StatusCode.E2000, "Item not found"));

            logger.debug("drugItem[" + item.getId() + "] need inventory[" + item.isInventoried() + "]");
            return item.isInventoried();
        } catch (CMSException e) {
            logger.warn("find item throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            throw new CMSRuntimeException("Item not found");
        }
    }

    private Inventory updateInventoryLowStockLevel(List<Item> drugItems, Inventory inventory) {

        drugItems.stream()
                .filter(drugItem -> drugItem.getId().equals(inventory.getItemRefId()))
                .findFirst()
                .ifPresent(
                        e -> {
                            /*
                             * if (e.getSafetyStockQty() > inventory.getAvailableCount()) {
                             * inventory.setLowStockLevel(true); } else { inventory.setLowStockLevel(false);
                             * }
                             */
                        }
                );
        return inventory;
    }

    private boolean checkReturnOrderItemHaveReceived(Optional<Order> purchaseOrderOpt, List<Order> returnOrders, Map<String, Item> itemMap) {

        if (!purchaseOrderOpt.isPresent()) {
            return true;
        }

        List<DeliveryItem> goodReceivedItems = purchaseOrderOpt.get().getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                .collect(Collectors.toList());

        List<DeliveryItem> goodReturnItems = returnOrders.stream()
                .filter(returnOrder -> returnOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM ||
                        returnOrder.getReturnStatus() == GoodReceivedReturnStatus.APPROVED ||
                        returnOrder.getReturnStatus() == GoodReceivedReturnStatus.RETURNED)
                .flatMap(goodReceivedVoidNote -> goodReceivedVoidNote.getReturnItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> goodReceivedItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(goodReceivedItems, itemMap);

        Map<String, Double> goodReturnItemIdQtyMap = this.convertDeliveryItemToItemIdQtyMap(goodReturnItems, itemMap);

        List<String> itemIdKeys = returnOrders.stream()
                .flatMap(goodReceivedVoidNote -> goodReceivedVoidNote.getReturnItems().stream())
                .map(DeliveryItem::getItemRefId)
                .collect(Collectors.toList());

        return isOverExistingQty(itemIdKeys, goodReceivedItemIdQtyMap, goodReturnItemIdQtyMap);
    }

    private boolean checkGoodReceivedItemHaveOrdered(List<GoodOrderedItem> goodOrderedItems, List<GoodReceivedNote> goodReceivedNotes, Map<String, Item> itemMap) {

        List<DeliveryItem> deliveryItems = goodReceivedNotes.stream()
                .filter(deliveryNote -> deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> goodOrderedItemIdQtyMap = convertGoodOrderedItemItemToItemIdQtyMap(goodOrderedItems, itemMap);

        Map<String, Double> deliveryItemIdQtyMap = this.convertDeliveryItemToItemIdQtyMap(deliveryItems, itemMap);

        List<String> itemIdKeys = new ArrayList<>(deliveryItemIdQtyMap.keySet());

        return isOverExistingQty(itemIdKeys, goodOrderedItemIdQtyMap, deliveryItemIdQtyMap);
    }

    private boolean checkDeliveryItemHaveOrdered(List<GoodReturnItem> returnItems, List<DeliveryNote> deliveryNotes, Map<String, Item> itemMap) {

        List<DeliveryItem> deliveryItems = deliveryNotes.stream()
                .filter(deliveryNote -> deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .collect(Collectors.toList());
        Map<String, Double> goodReturnItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(returnItems, itemMap);

        Map<String, Double> deliveryItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(deliveryItems, itemMap);

        List<String> itemIdKeys = new ArrayList<>(deliveryItemIdQtyMap.keySet());

        return isOverExistingQty(itemIdKeys, goodReturnItemIdQtyMap, deliveryItemIdQtyMap);
    }

    private boolean checkTransferItemHaveOrdered(List<DeliveryNote> deliveryNotes, List<GoodReceivedNote> goodReceivedNotes, Map<String, Item> itemMap) {
        List<DeliveryItem> deliveryItems = deliveryNotes.stream()
                .filter(deliveryNote -> deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(goodReceivedNote -> goodReceivedNote.getTransferSendItems().stream())
                .collect(Collectors.toList());

        List<DeliveryItem> receivedItems = goodReceivedNotes.stream()
                .filter(goodReceivedNote -> goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> deliveryItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(deliveryItems, itemMap);

        Map<String, Double> receivedItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(receivedItems, itemMap);

        List<String> itemIdKeys = new ArrayList<>(deliveryItemIdQtyMap.keySet());

        return isOverExistingQty(itemIdKeys, deliveryItemIdQtyMap, receivedItemIdQtyMap);
    }

    private boolean checkTransferDeliveryItemHaveOrdered(List<TransferRequestItem> transferRequestItems, List<DeliveryNote> deliveryNotes, Map<String, Item> itemMap) {

        List<DeliveryItem> deliveryItems = deliveryNotes.stream()
                .filter(deliveryNote -> deliveryNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .collect(Collectors.toList());

        Map<String, Double> transferRequestItemIdQtyMap = convertTransferRequestItemToItemIdQtyMap(transferRequestItems, itemMap);

        Map<String, Double> deliveryItemIdQtyMap = convertDeliveryItemToItemIdQtyMap(deliveryItems, itemMap);

        List<String> itemIdKeys = new ArrayList<>(deliveryItemIdQtyMap.keySet());

        return isOverExistingQty(itemIdKeys, transferRequestItemIdQtyMap, deliveryItemIdQtyMap);
    }

    private Map<String, Double> convertDeliveryItemToItemIdQtyMap(List<? extends DeliveryItem> items, Map<String, Item> itemMap) {

        return items.stream()
                .collect(Collectors.toMap(DeliveryItem::getItemRefId,
                        o -> {
                            try {
                                String baseUom = findBaseUom(itemMap.get(o.getItemRefId()))
                                        .orElseThrow(() -> {
                                            logger.error("Base uom doesn't exist for item[" + o.getItemRefId() + "]");
                                            return new CMSException(StatusCode.E2000, "Base uom not exit");
                                        });
                                double quantity = locationService.convertQuantityWithNavCheck(o.getQuantity(), o.getUom(), baseUom);
                                logger.debug("Item[" + o.getItemRefId() + "] convert from[" + o.getUom() + "] Quantity["
                                        + o.getQuantity() + "] to uom[" + baseUom + "] quantity[" + quantity + "]");
                                return quantity;
                            } catch (CMSException e) {
                                logger.error("checkTransferItemHaveOrdered throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                                throw new RuntimeException(e);
                            }
                        },
                        (a, b) -> a + b));
    }

    private Map<String, Double> convertTransferRequestItemToItemIdQtyMap(List<TransferRequestItem> items, Map<String, Item> itemMap) {

        return items.stream()
                .collect(Collectors.toMap(TransferRequestItem::getItemRefId,
                        o -> {
                            try {
                                String baseUom = findBaseUom(itemMap.get(o.getItemRefId()))
                                        .orElseThrow(() -> {
                                            logger.error("Base uom doesn't exist for item[" + o.getItemRefId() + "]");
                                            return new CMSException(StatusCode.E2000, "Base uom not exit");
                                        });
                                double quantity = locationService.convertQuantityWithNavCheck(o.getQuantity(), o.getUom(), baseUom);
                                logger.debug("Item[" + o.getItemRefId() + "] convert from[" + o.getUom() + "]to uom[" + baseUom + "] quantity[" + quantity + "]");
                                return quantity;
                            } catch (CMSException e) {
                                logger.error("checkTransferItemHaveOrdered throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                                throw new RuntimeException(e);
                            }
                        },
                        (a, b) -> a + b));
    }

    private Map<String, Double> convertGoodOrderedItemItemToItemIdQtyMap(List<GoodOrderedItem> items, Map<String, Item> itemMap) {

        return items.stream()
                .collect(Collectors.toMap(GoodOrderedItem::getItemRefId,
                        o -> {
                            try {
                                String baseUom = findBaseUom(itemMap.get(o.getItemRefId()))
                                        .orElseThrow(() -> {
                                            logger.error("Base uom doesn't exist for item[" + o.getItemRefId() + "]");
                                            return new CMSException(StatusCode.E2000, "Base uom not exit");
                                        });
                                double quantity = locationService.convertQuantityWithNavCheck(o.getQuantity(), o.getUom(), baseUom);
                                logger.debug("Item[" + o.getItemRefId() + "] convert from[" + o.getUom() + "]to uom[" + baseUom + "] quantity[" + quantity + "]");
                                return quantity;
                            } catch (CMSException e) {
                                logger.error("checkTransferItemHaveOrdered throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
                                throw new RuntimeException(e);
                            }
                        },
                        (a, b) -> a + b));
    }

    private boolean isOverExistingQty(List<String> itemIds, Map<String, Double> itemIdMaxQtyMap, Map<String, Double> itemIdCountQtyMap) {
        for (String id : itemIds) {
            itemIdMaxQtyMap.putIfAbsent(id, 0.0);
            itemIdCountQtyMap.putIfAbsent(id, 0.0);
            logger.debug("item[{}] max quantity limit[{}], now there are count quantity[{}]", id, itemIdMaxQtyMap.get(id), itemIdCountQtyMap.get(id));
        }
        boolean isAllMatch = itemIds.stream()
                .allMatch(itemIdKey -> {
                    boolean match = BigDecimal.valueOf(itemIdMaxQtyMap.get(itemIdKey)).setScale(8, RoundingMode.HALF_UP)
                            .compareTo(BigDecimal.valueOf(itemIdCountQtyMap.get(itemIdKey)).setScale(8, RoundingMode.HALF_UP)) >= 0;

                    if (!match) {
                        logger.warn("item[" + itemIdKey + "] not match item Qty, existing Qty[" +
                                itemIdMaxQtyMap.get(itemIdKey) + "], return Qty[" + itemIdCountQtyMap.get(itemIdKey) + "]");
                    }
                    return match;
                });
        return isAllMatch;
    }

    private void changeOrderStatus(Order order, Map<String, Item> itemMap) {

        if (order.getOrderStatus() == OrderStatus.REJECTED || order.getOrderStatus() == OrderStatus.DELETED) {
            logger.warn("order cannot change status[{}]", order.getOrderStatus());
            return;
        }

        Optional<GoodReceivedNote> goodReceivedNoteOpt = order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getStatus() == DeliveryNoteStatus.CONFIRM)
                .findFirst();
        if (goodReceivedNoteOpt.isPresent()) {
            if (checkIsAllItemReceived(order, itemMap)) {
                order.setOrderStatus(OrderStatus.FULL_RECEIVED);
            } else {
                order.setOrderStatus(OrderStatus.PARTIAL_RECEIVED);
            }
        } else {
            order.setOrderStatus(OrderStatus.INITIAL);
        }
        setOrderCompleteDate(order);
    }

    private void changeReturnOrderStatus(Order returnOrder, Map<String, Item> itemMap) {

        if (returnOrder.getOrderType() != OrderType.RETURN) {
            logger.warn("Order[{}] is not a return order", returnOrder.getId());
            return;
        }
        if (returnOrder.getReturnStatus() == GoodReceivedReturnStatus.REJECTED
                || returnOrder.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM) {
            logger.warn("Return order[{}] cannot change status[{}]", returnOrder.getId(), returnOrder.getReturnStatus());
            return;
        }

        if (checkIsAllItemReturned(returnOrder, itemMap)) {
            returnOrder.setReturnStatus(GoodReceivedReturnStatus.RETURNED);
            returnOrder.setCompleteDate(LocalDate.now());
        } else {
            returnOrder.setReturnStatus(GoodReceivedReturnStatus.APPROVED);
            returnOrder.setCompleteDate(null);
        }
    }

    private void setOrderCompleteDate(Order order) {

        switch (order.getOrderStatus()) {
            case INITIAL:
            case PARTIAL_RECEIVED:
                order.setCompleteDate(null);
                break;
            case FULL_RECEIVED:
                if (order.getCompleteDate() == null) {
                    order.setCompleteDate(LocalDate.now());
                }
                break;
        }
    }

    private void updateRequestToTransferStatus(String requestId) throws CMSException {

        List<Order> orders = orderDatabaseService.findOrderByRequestId(requestId);
        if (!orders.stream()
                .anyMatch(order -> order.getOrderStatus() == OrderStatus.INITIAL || order.getOrderStatus() == OrderStatus.PARTIAL_RECEIVED)) {
            PurchaseRequest purchaseRequest = orderDatabaseService.findPurchaseRequestById(requestId)
                    .orElseThrow(() -> new CMSException(StatusCode.E2000, "Purchase request not found"));
            purchaseRequest.setRequestStatus(RequestStatus.TRANSFER);
            orderDatabaseService.savePurchaseRequest(purchaseRequest);
        }
    }

    private Optional<String> findBaseUom(Item item) {
        if (item == null) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(item.getBaseUom());
        }
    }

    private Order addRequestDetail(Order order) {
        Optional<PurchaseRequest> purchaseRequestOpt = Optional.empty();
        if (order.getRequestId() != null) {
            purchaseRequestOpt = orderDatabaseService.findPurchaseRequestById(order.getRequestId());
        }

        if (purchaseRequestOpt.isPresent()) {
            order.setRequestDate(purchaseRequestOpt.get().getRequestDate());
            order.setRequestNo(purchaseRequestOpt.get().getRequestNo());
        } else {
            order.setRequestDate(order.getOrderDate());
            order.setRequestNo("");
        }
        return order;
    }

    private GoodReceivedNote addRequestDetail(Optional<PurchaseRequest> purchaseRequestOpt, GoodReceivedNote goodReceivedNote) {
        if (!purchaseRequestOpt.isPresent()) {
            return goodReceivedNote;
        }

        goodReceivedNote.setPrDate(purchaseRequestOpt.get().getRequestDate());
        goodReceivedNote.setPrNo(purchaseRequestOpt.get().getRequestNo());

        return goodReceivedNote;
    }

    private List<String> getGoodReturnStatusList(String requestStatus) {
        List<String> status = new ArrayList<>();
        switch (requestStatus) {
            case "APPROVED":
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.APPROVED.toString()));
                break;
            case "DRAFT":
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.DRAFT.toString()));
                break;
            case "CONFIRM":
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.CONFIRM.toString()));
                break;
            case "REJECTED":
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.REJECTED.toString()));
                break;
            case "RETURNED":
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.RETURNED.toString()));
                break;
            default:
                status.addAll(Arrays.asList(GoodReceivedReturnStatus.APPROVED.toString(),
                        GoodReceivedReturnStatus.DRAFT.toString(),
                        GoodReceivedReturnStatus.CONFIRM.toString(),
                        GoodReceivedReturnStatus.REJECTED.toString(),
                        GoodReceivedReturnStatus.RETURNED.toString()));
                break;
        }
        return status;
    }

    private GoodOrderedItem setPrice(String supplierId, GoodOrderedItem goodOrderedItem) {

        Supplier supplier = supplierRepository.findById(supplierId)
                .orElseThrow(() -> {
                    logger.error("Supplier[" + goodOrderedItem.getSupplierId() + "] not found");
                    return new RuntimeException("supplier not found");
                });
        PurchaseItem selectedPurchaseItem = supplier.getItems().stream()
                .filter(purchaseItem -> purchaseItem.getItemId().equals(goodOrderedItem.getItemRefId()))
                .findFirst()
                .orElse(null);
        if (selectedPurchaseItem != null) {
            if (goodOrderedItem.getUnitPrice() != null && selectedPurchaseItem.getUnitPrice().getPrice() != 0) {
                goodOrderedItem.setUnitPrice(new UnitPrice(selectedPurchaseItem.getUnitPrice().getPrice(),
                        selectedPurchaseItem.getUnitPrice().isTaxIncluded()));
            }
        } else {
            logger.warn("Item[" + goodOrderedItem.getItemRefId() + "] is null, cannot retrieve cost");
        }
        return goodOrderedItem;
    }

    private void checkGoodReceivedNoteValidate(GoodReceivedNote goodReceivedNote, boolean isPurchaseOrder, Map<String, Item> itemMap) throws CMSException {
        if (!goodReceivedNote.checkValidate()) {
            logger.error("Invalid in good receive note[" + goodReceivedNote + "]");
            throw new CMSException(StatusCode.E1002, "Invalid in good receive note");
        }

        if (!goodReceivedNote.getReceivedItems().stream()
                .allMatch(goodReceivedItem -> goodReceivedItem.checkValidate(itemMap.get(goodReceivedItem.getItemRefId())))) {
            logger.error("Invalid in good receive Item[" + goodReceivedNote.getReceivedItems() + "]");
            throw new CMSException(StatusCode.E1002, "Invalid in good receive item");
        }
    }

    private void checkDeliveryNoteValidate(String orderId, DeliveryNote deliveryNote, Map<String, Item> itemMap) throws CMSException {
        if (!deliveryNote.checkValidate()) {
            logger.error("Invalid in delivery note[" + deliveryNote + "]");
            throw new CMSException(StatusCode.E1002, "Invalid in delivery note");
        }

        if (!deliveryNote.getTransferSendItems().stream()
                .allMatch(deliveryItem -> deliveryItem.checkValidate(itemMap.get(deliveryItem.getItemRefId())))) {
            logger.error("Invalid in transfer item[" + deliveryNote.getTransferSendItems() + "] for Id[" + orderId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid in delivery Item");
        }
    }

//    private Map<String, Item> getItemMap(List<? extends DeliveryItem> deliveryItems) {
//        List<String> itemIds = deliveryItems.stream()
//                .map(DeliveryItem::getItemRefId)
//                .collect(Collectors.toList());
//
//        return itemService.findItemByIds(itemIds).stream()
//                .collect(Collectors.toMap(Item::getId, o -> o));
//    }

    private void checkGoodReturnItemIsAvailable(String clinicId, List<Order> returnOrders, Map<String, Item> itemMap) throws CMSException {

        returnOrders = returnOrders.stream()
                .filter(order -> order.getReturnStatus() == GoodReceivedReturnStatus.CONFIRM
                        || order.getReturnStatus() == GoodReceivedReturnStatus.APPROVED)
                .collect(Collectors.toList());

        List<GoodReturnItem> goodReturnItems = returnOrders.stream()
                .flatMap(returnOrder -> returnOrder.getReturnItems().stream())
                .collect(Collectors.toList());

        List<DeliveryItem> deliveryItems = returnOrders.stream()
                .filter(returnOrder -> returnOrder.getReturnStatus() == GoodReceivedReturnStatus.APPROVED)
                .flatMap(returnOrder -> returnOrder.getDeliveryNotes().stream())
                .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                .collect(Collectors.toList());

        Map<String, List<GoodReturnItem>> itemIdGoodReturnItemMap = goodReturnItems.stream()
                .collect(Collectors.groupingBy(GoodReturnItem::getItemRefId));

        Map<String, List<DeliveryItem>> itemIdDeliveryItemMap = deliveryItems.stream()
                .collect(Collectors.groupingBy(DeliveryItem::getItemRefId));

        itemIdGoodReturnItemMap.keySet().forEach(
                itemId -> {
                    itemIdDeliveryItemMap.compute(itemId, (key, existDeliveryItems) -> {
                        existDeliveryItems = deliveryItems.stream()
                                .filter(deliveryItem -> deliveryItem.getItemRefId().equals(key))
                                .collect(Collectors.toList());
                        return existDeliveryItems;
                    });
                }
        );
        Location location = locationService.findLocationByClinicId(clinicId, new ArrayList<>(itemMap.values()))
                .orElseGet(() -> new Location(clinicId));
        List<Inventory> inventories = location.getInventory();

        logger.debug("loop return item");
        itemIdGoodReturnItemMap.keySet().forEach(
                itemId -> {
                    List<GoodReturnItem> goodReturnItems1 = itemIdGoodReturnItemMap.get(itemId);
                    List<DeliveryItem> deliveryItems1 = itemIdDeliveryItemMap.get(itemId);

                    Set<String> batchNos = goodReturnItems1.stream()
                            .map(GoodReturnItem::getBatchNumber)
                            .collect(Collectors.toSet());
                    logger.debug("check item[{}], with batchNo[{}]", itemId, batchNos);

                    batchNos.forEach(
                            batchNo -> {
                                logger.debug("loop batch No[{}]", batchNo);
                                double totalReturnQty = goodReturnItems1.stream()
                                        .filter(goodReturnItem -> (!CommonUtils.isStringValid(batchNo) && !CommonUtils.isStringValid(goodReturnItem.getBatchNumber()))
                                                || goodReturnItem.getBatchNumber().equals(batchNo))
                                        .mapToDouble(goodReturnItem -> convertToBaseUomQuantity(itemMap.get(goodReturnItem.getItemRefId()),
                                                goodReturnItem.getUom(), goodReturnItem.getQuantity()))
                                        .sum();

                                double totalDeliveredQty = deliveryItems1.stream()
                                        .filter(deliveryItem -> (!CommonUtils.isStringValid(batchNo) && !CommonUtils.isStringValid(deliveryItem.getBatchNumber()))
                                                || deliveryItem.getBatchNumber().equals(batchNo))
                                        .mapToDouble(deliveryItem -> convertToBaseUomQuantity(itemMap.get(deliveryItem.getItemRefId()), deliveryItem.getUom(), deliveryItem.getQuantity()))
                                        .sum();

                                double totalRequestQty = totalReturnQty - totalDeliveredQty;

                                Optional<Inventory> existInventoryOpt = inventories.stream()
                                        .filter(inventory -> inventory.getItemRefId().equals(itemId))
                                        .filter(inventory -> (!CommonUtils.isStringValid(batchNo) && !CommonUtils.isStringValid(inventory.getBatchNumber()))
                                                || batchNo.equals(inventory.getBatchNumber()))
                                        .findFirst();

                                if (existInventoryOpt.isPresent()) {
                                    if (existInventoryOpt.get().getAvailableCount().compareTo(BigDecimal.valueOf(totalRequestQty)) == -1) {
                                        logger.error("Return item[{}] will be return quantity[{}] does not have enough available count[{}] in inventory"
                                                , itemId, totalReturnQty, existInventoryOpt.get().getAvailableCount());
                                        throw new RuntimeException("Not enough available inventory to return");
                                    }
                                } else {
                                    logger.error("Item[{}] with batchNo[{}], Cannot get the inventory from NAV", itemId, batchNo);
                                    throw new RuntimeException("Inventory does not exist in item[" + itemId + "]");
                                }
                            }
                    );
                }
        );
    }

    private double convertToBaseUomQuantity(Item item, String uom, int sourceQuantity) {
        try {
            String baseUom = findBaseUom(item)
                    .orElseThrow(() -> {
                        logger.error("Base uom doesn't exist for due to item not exist");
                        return new CMSException(StatusCode.E2000, "Base uom not exit");
                    });
            double quantity = locationService.convertQuantityWithNavCheck(sourceQuantity, uom, baseUom);
            String itemId = Objects.nonNull(item) ? item.getId() : null;
            logger.debug("Item[" + itemId + "] convert from[" + uom + "] Quantity["
                    + sourceQuantity + "] to uom[" + baseUom + "] quantity[" + quantity + "]");
            return quantity;
        } catch (CMSException e) {
            logger.error("convert to baseUom quantity throw error[" + e.getCode() + "], message[" + e.getMessage() + "]");
            throw new RuntimeException(e);
        }
    }

    public GoodReceivedNote deleteGoodReceivedNote(String orderId, String grnId) throws CMSException {

        logger.info("deleteGoodReceivedNote for orderId[" + orderId + "], goodReceivedNote[" + grnId + "]");
        Order curOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));
        Optional<GoodReceivedNote> grnOptional = curOrder.getGoodReceivedNoteByGrnId(grnId);
        if (!grnOptional.isPresent()) {
            logger.error("Invalid Grn No::[" + grnId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid Grn No::[" + grnId + "]");
        }
        GoodReceivedNote goodReceivedNote = grnOptional.get();
        NavIntegrationResult navIntegrationResult = goodReceivedNote.getNavIntegrationResult();
        if (navIntegrationResult == null || !navIntegrationResult.getStatus().equals(NavIntegrationResult.ResultStatus.FAILED)) {
            logger.error("Invalid Grn Status, Status must be failed::[" + grnId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid Grn Status, Status must be failed::[" + grnId + "]");
        }
        curOrder.deleteGoodReceivedNote(goodReceivedNote);
        Map<String, Item> itemMap = getItemMapByOrder(curOrder);
        changeOrderStatus(curOrder, itemMap);
        orderDatabaseService.saveOrder(curOrder);
        return goodReceivedNote;
    }

    public Order deleteReturnOrder(String orderId) throws CMSException {

        logger.info("deleteReturnOrder for orderId[" + orderId + "]");
        Order curOrder = getOrder(orderId, OrderType.RETURN);

        if (!NavIntegrationResult.ResultStatus.FAILED.equals(curOrder.getNavIntegrationResult().getStatus())) {
            logger.error("Invalid Grvn Status, Status must be failed::[" + orderId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid Grvn Status, Status must be failed::[" + orderId + "]");
        }
        orderDatabaseService.deleteOrder(orderId);
        return curOrder;
    }

    public DeliveryNote deleteTransferShipment(String orderId, String dnId) throws CMSException {
        logger.info("deleteTransferShipment for orderId[" + orderId + "], goodReceivedNote[" + dnId + "]");
        Order curOrder = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> new CMSException(StatusCode.E2000, "Order not found"));
        if (!curOrder.getOrderType().equals(OrderType.TRANSFER)) {
            logger.error("Invalid TO Order Id::[" + orderId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid TO Order Id::[" + orderId + "]");
        }
        Optional<DeliveryNote> deliveryNoteOptional = curOrder.getDeliveryNoteByDnId(dnId);
        if (!deliveryNoteOptional.isPresent()) {
            logger.error("Invalid TO DN No::[" + dnId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid TO DN No::[" + dnId + "]");
        }
        DeliveryNote deliveryNote = deliveryNoteOptional.get();
        if (!deliveryNote.getNavIntegrationResult().getStatus().equals(NavIntegrationResult.ResultStatus.FAILED)) {
            logger.error("Invalid TO DN Status, Status must be failed::[" + dnId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid TO DN Status, Status must be failed::[" + dnId + "]");
        }
        curOrder.deleteDeliveryNote(deliveryNote);
        orderDatabaseService.saveOrder(curOrder);
        return deliveryNote;
    }

    public DeliveryNote deleteReturnOrderDn(String orderId, String grvndoId) throws CMSException {

        logger.info("delete return order Delivery note for return orderId[" + orderId + "], grvndoId[" + grvndoId + "]");
        Order curReturnOrder = getOrder(orderId, OrderType.RETURN);

        DeliveryNote deliveryNote = curReturnOrder.getDeliveryNoteByDnId(grvndoId)
                .orElseThrow(() -> {
                    logger.error("Invalid Grvn DN No::[" + grvndoId + "]");
                    return new CMSException(StatusCode.E1002, "Invalid Grvn DN No::[" + grvndoId + "]");
                });

        if (!deliveryNote.getNavIntegrationResult().getStatus().equals(NavIntegrationResult.ResultStatus.FAILED)) {
            logger.error("Invalid Grvn DN Status, Status must be failed::[" + grvndoId + "]");
            throw new CMSException(StatusCode.E1002, "Invalid Grvn DN Status, Status must be failed::[" + grvndoId + "]");
        }

        curReturnOrder.deleteDeliveryNote(deliveryNote);
        Map<String, Item> itemMap = getItemMapByOrder(curReturnOrder);
        changeReturnOrderStatus(curReturnOrder, itemMap);
        orderDatabaseService.saveOrder(curReturnOrder);
        return deliveryNote;
    }

    private Clinic getClinic(String clinicId) throws CMSException {

        return clinicRepository.findByIdAndStatus(clinicId, Status.ACTIVE).orElseThrow(() -> {
            logger.error("Active clinic not found by Id[{}]", clinicId);
            return new CMSException(StatusCode.E1002, "Clinic not found");
        });
    }

    private Supplier getSupplier(String supplierId) throws CMSException {

        return supplierRepository.findById(supplierId).orElseThrow(() -> {
            logger.error("Supplier[] not exist, status[{}]", supplierId);
            return new CMSException(StatusCode.E1002, "Supplier not found");
        });
    }

    private List<Order> getOrderByIdsAndOrderType(List<String> orderIds, OrderType type) {

        return orderDatabaseService.findOrderByIdsAndOrderType(orderIds, type);
    }

    private Order getOrder(String orderId, OrderType type) throws CMSException {

        return orderDatabaseService.findOrderById(orderId)
                .filter(order -> order.getOrderType() == type)
                .orElseThrow(() -> {
                    logger.error("Order not found by Id[{}] and type[{}]", orderId, type);
                    return new CMSException(StatusCode.E1002, "Order not found");
                });
    }

    private void checkValidateCreateOrUpdateReturnOrder(GoodReceivedReturnStatus status, List<GoodReturnItem> goodReturnItems, Map<String, Item> itemMap) throws CMSException {

        if (!(status == GoodReceivedReturnStatus.CONFIRM || status == GoodReceivedReturnStatus.DRAFT)) {
            logger.error("Status[{}] not valid", status);
            throw new CMSException(StatusCode.E1002, "Status not validate [" + status + "]");
        }

        if (!goodReturnItems.stream()
                .allMatch(goodReturnItem -> {
                    boolean isValidate = goodReturnItem.checkValidate(itemMap.get(goodReturnItem.getItemRefId()));
                    if (!isValidate) {
                        logger.warn("Not validate in GoodReturnItem[{}]", goodReturnItem);
                    }
                    return isValidate;
                })) {
            logger.error("Invalid in goodReturnItem");
            throw new CMSException(StatusCode.E1002, "Not validate in return items");
        }
    }

    private Map<String, Item> getItemMapByOrder(Order order) {
        Set<String> itemIds = new HashSet<>();

        if (Objects.nonNull(order.getGoodPurchasedItems())) {
            Set<String> goodPurchaseItems = order.getGoodPurchasedItems().stream()
                    .map(GoodOrderedItem::getItemRefId)
                    .collect(Collectors.toSet());
            itemIds.addAll(goodPurchaseItems);
        }

        if (Objects.nonNull(order.getTransferRequestItems())) {
            Set<String> transferRequestItems = order.getTransferRequestItems().stream()
                    .map(TransferRequestItem::getItemRefId)
                    .collect(Collectors.toSet());
            itemIds.addAll(transferRequestItems);
        }

        if (Objects.nonNull(order.getGoodReceivedNotes())) {
            Set<String> receivedItems = order.getGoodReceivedNotes().stream()
                    .flatMap(goodReceivedNote -> goodReceivedNote.getReceivedItems().stream())
                    .map(DeliveryItem::getItemRefId)
                    .collect(Collectors.toSet());
            itemIds.addAll(receivedItems);
        }

        if (Objects.nonNull(order.getDeliveryNotes())) {
            Set<String> transferSendItems = order.getDeliveryNotes().stream()
                    .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                    .map(DeliveryItem::getItemRefId)
                    .collect(Collectors.toSet());
            itemIds.addAll(transferSendItems);
        }

        if (Objects.nonNull(order.getReturnItems())) {

            Set<String> returnItems = order.getReturnItems().stream()
                    .map(GoodReturnItem::getItemRefId)
                    .collect(Collectors.toSet());
            itemIds.addAll(returnItems);

            List<DeliveryNote> deliveryNotes = order.getDeliveryNotes();
            if (Objects.nonNull(deliveryNotes)) {
                Set<String> returnDeliveryItems = deliveryNotes.stream()
                        .flatMap(deliveryNote -> deliveryNote.getTransferSendItems().stream())
                        .map(DeliveryItem::getItemRefId)
                        .collect(Collectors.toSet());
                itemIds.addAll(returnDeliveryItems);
            }
        }

        return getItemMapByIds(new ArrayList<>(itemIds));
    }

    private Map<String, Item> getItemMapByIds(List<String> itemIds) {
        return itemService.findItemByIds(new ArrayList<>(itemIds)).stream()
                .collect(Collectors.toMap(Item::getId, o -> o));
    }

    public List<String> saveOrdersFromRequests(String type, String variant, List<PurchaseRequestItemView> requestIds) throws CMSException {
        List<Order> orders = createOrdersFromRequests(type, variant, requestIds);
//        List<Order> saveOrders = orderDatabaseService.saveOrders(orders);
        return orders.stream()
                .map(Order::getId)
                .collect(Collectors.toList());
    }

    private List<Order> createOrdersFromRequests(String type, String variant, List<PurchaseRequestItemView> purchaseRequestItems) throws CMSException {
        log.info("Create orders from requests, type[{}], variant[{}], purchaseRequestItems[{}]", type, variant, purchaseRequestItems);
//        List<PurchaseRequestItemView> purchaseRequestItems = orderDatabaseService.findPurchaseRequestItems(requests);

        if (type.equals("TO")) {
            log.info("Create transfer orders from purchase requests");
            return createTransferOrdersFromPurchaseRequests(purchaseRequestItems);
        }

        Map<String, List<PurchaseRequestItemView>> supplierIdBasedLineItems = purchaseRequestItems.stream()
                .filter(purchaseRequestItem -> Objects.nonNull(purchaseRequestItem.getSupplierId()))
                .collect(Collectors.groupingBy(PurchaseRequestItemView::getSupplierId));

        Map<String, Supplier> supplierMap = Streams.stream(supplierRepository.findAllById(supplierIdBasedLineItems.keySet()))
                .collect(Collectors.toMap(Supplier::getId, o -> o));

        try {
            switch (variant) {
                case "single":
                    log.info("Create single orders from purchase requests");
                    return createSingleOrdersFromPurchaseRequests(supplierIdBasedLineItems, supplierMap);
                case "combined":
                    log.info("Create combined orders from purchase requests");
                    return createCombinedOrdersFromTransferRequests(supplierIdBasedLineItems, supplierMap);
                default:
                    throw new CMSException(StatusCode.E1002, "Invalid type");
            }
        } catch (ExecutionException e) {
            throw new CMSException(StatusCode.E1002, "Error while creating order");
        }
    }

    private List<Order> createTransferOrdersFromPurchaseRequests(List<PurchaseRequestItemView> purchaseRequests) throws CMSException {
        Map<String, List<PurchaseRequestItemView>> clinicBasedPurchaseRequests = purchaseRequests.stream()
                .collect(Collectors.groupingBy(PurchaseRequestItemView::getRequestClinicId));
        try {
            List<Order> orders = new ArrayList<>();
            for (String clinicId : clinicBasedPurchaseRequests.keySet()) {
                List<PurchaseRequestItemView> purchaseRequestItemViews = clinicBasedPurchaseRequests.get(clinicId);
                PurchaseRequestItemView value = purchaseRequestItemViews.get(0);
                Order order = new Order();
                order.setOrderType(OrderType.TRANSFER);
                order.setOrderStatus(OrderStatus.DRAFT);
                order.setRequestClinicId(clinicId);
                order.setOrderDate(LocalDate.now());
                order.setRequestNo(value.getRequestNo());
                order.setRequestId(value.getId());
                order.setCreateDate(LocalDate.now());
                order.setOrderNo(runningNumberService.generateOrderNumber());
                order.setRequestDate(value.getRequestDate());
                order.setRequestId(value.getId());
                ArrayList<TransferRequestItem> transferRequestItems = new ArrayList<>();
                for (PurchaseRequestItemView requestItem : purchaseRequestItemViews) {
                    double convertedQuantity = uomMatrixService
                            .convertItemUom(requestItem.getItem(), requestItem.getUom(), requestItem.getBaseUom(), requestItem.getQuantity());
                    TransferRequestItem transferRequestItem = new TransferRequestItem();
                    transferRequestItem.setItemRefId(requestItem.getItemRefId());
                    transferRequestItem.setQuantity((int) convertedQuantity);
                    transferRequestItem.setLineNo(IdUtils.lineNoGenerator());
                    transferRequestItem.setUom(requestItem.getBaseUom());
                    transferRequestItem.setPurchaseRequestId(requestItem.getId());
                    transferRequestItem.setRemark(requestItem.getRemark());
                    transferRequestItem.setCpRemarks(requestItem.getCpRemarks());
                    transferRequestItems.add(transferRequestItem);
                }
                order.setTransferRequestItems(transferRequestItems);
                orders.add(orderDatabaseService.saveOrder(order));
            }

            return orders;
        } catch (ExecutionException e) {
            log.error("Error while creating transfer order", e);
            throw new CMSException(StatusCode.E1002, "Error while creating order");
        }
    }

    private List<Order> createCombinedOrdersFromTransferRequests(Map<String, List<PurchaseRequestItemView>> purchaseRequests, Map<String, Supplier> supplierMap) throws ExecutionException, CMSException {
        Map<String, Item> items = findItems(purchaseRequests);

        ArrayList<Order> result = new ArrayList<>();
        for (Map.Entry<String, List<PurchaseRequestItemView>> supplierEntry : purchaseRequests.entrySet()) {
            log.info("Create combined order for supplier[{}]", supplierEntry.getKey());
            Map<String, List<PurchaseRequestItemView>> clinicViseRequests = supplierEntry.getValue().stream()
                    .collect(Collectors.groupingBy(PurchaseRequestItemView::getRequestClinicId));

            Supplier supplier = supplierMap.get(supplierEntry.getKey());

            if (supplier == null) {
                log.info("Supplier not found for id[{}]", supplierEntry.getKey());
                continue;
            }

            for (Map.Entry<String, List<PurchaseRequestItemView>> clinicEntry : clinicViseRequests.entrySet()) {
                log.info("Create combined order for clinic[{}]", clinicEntry.getKey());
                Order order = new Order();
                order.setOrderType(OrderType.PURCHASE);
                order.setSupplierId(supplierEntry.getKey());
                order.setOrderDate(LocalDate.now());
                order.setCreateDate(LocalDate.now());
                order.setOrderNo(runningNumberService.generateOrderNumber());
                order.setOrderStatus(OrderStatus.DRAFT);
                PurchaseRequestItemView firstItem = clinicEntry.getValue().get(0);
                order.setRequestDate(firstItem.getRequestDate());
                order.setRequestId(firstItem.getId());
                order.setRequestClinicId(clinicEntry.getKey());
                order.setGstEnabled(supplier.isGstEnabled());
                List<GoodOrderedItem> list = new ArrayList<>();
                for (PurchaseRequestItemView purchaseRequestItemView : clinicEntry.getValue()) {
                    log.info("Create good ordered item for item[{}]", purchaseRequestItemView.getItemRefId());
                    Item item = items.get(purchaseRequestItemView.getItemRefId());
                    GoodOrderedItem goodOrderedItem = createGoodOrderedItem(purchaseRequestItemView, item);
                    list.add(goodOrderedItem);
                    addBonusItems(supplier, item, purchaseRequestItemView, list);
                }
                order.setGoodPurchasedItems(list);
                if (supplier.isGstEnabled()) {
                    int gst = gstUtilsService.getGst(LocalDateTime.now());
                    order.setGstPercentage(BigDecimal.valueOf(gst));
                    Tuple<Double, Double> gstTuple = calculateGst(order);
                    order.setGstAmount(BigDecimal.valueOf(gstTuple.getSecond()));
                }
                result.add(orderDatabaseService.saveOrder(order));
            }
        }

        return result;
    }

    private void addBonusItems(Supplier supplier, Item item, PurchaseRequestItemView purchaseRequestItemView, List<GoodOrderedItem> list) throws ExecutionException {
        log.info("Add bonus items");
        List<PurchaseBonus> purchaseBonuses = supplier.getPurchaseBonuses();
        if (purchaseBonuses == null) {
            log.info("No bonus items found");
            return;
        }

        for (PurchaseBonus purchaseBonus : purchaseBonuses) {
            if (!purchaseBonus.getItemId().equals(item.getId())) {
                log.info("Bonus item not found for item {}", item.getId());
                continue;
            }
            log.debug("Bonus item found for item {}, purchase bonuses [{}]", item.getId(), purchaseBonus);
            purchaseBonus.getBonusDetails().sort(Comparator.comparing(BonusDetail::getPurchaseQuantity).reversed());

            int quantity = purchaseRequestItemView.getQuantity();

            for (BonusDetail bonusDetail : purchaseBonus.getBonusDetails()) {
                if (bonusDetail.getPurchaseQuantity() > quantity) {
                    continue;
                }

                double bonusQuantity = Math.floor((double) quantity / bonusDetail.getPurchaseQuantity()) * bonusDetail.getBonusQuantity();
                quantity = quantity % bonusDetail.getPurchaseQuantity();

                log.info("Bonus item found for item {}", item.getId());
                GoodOrderedItem bonusItem = createGoodOrderedItem(purchaseRequestItemView, item);
                bonusItem.setQuantity((int) bonusQuantity);
                bonusItem.setUom(bonusDetail.getUom());
                bonusItem.setBonusItem(true);
                bonusItem.setUnitPrice(new UnitPrice(0, false));
                log.debug("Bonus item {}", bonusItem);
                list.add(bonusItem);
            }

        }
    }

    private Map<String, Item> findItems(Map<String, List<PurchaseRequestItemView>> purchaseRequests) {
        List<String> itemIds = purchaseRequests.values().stream().flatMap(List::stream)
                .map(PurchaseRequestItemView::getItemRefId)
                .collect(Collectors.toList());
        return itemService.findItemByIds(itemIds).stream().collect(Collectors.toMap(Item::getId, o -> o));
    }

    private List<Order> createSingleOrdersFromPurchaseRequests(Map<String, List<PurchaseRequestItemView>> purchaseRequests, Map<String, Supplier> supplierMap) throws ExecutionException {
        Map<String, Item> items = findItems(purchaseRequests);
        ArrayList<Order> result = new ArrayList<>();

        for (Map.Entry<String, List<PurchaseRequestItemView>> entry : purchaseRequests.entrySet()) {
            log.info("Creating order for supplier {}", entry.getKey());

            Supplier supplier = supplierMap.get(entry.getKey());

            Map<String, List<PurchaseRequestItemView>> groupedItems =
                    entry.getValue().stream().collect(Collectors.groupingBy(PurchaseRequestItemView::getRequestNo));
            for (Map.Entry<String, List<PurchaseRequestItemView>> groupedItem : groupedItems.entrySet()) {
                log.info("Creating order for request {}", groupedItem.getKey());
                Order order = new Order();
                order.setOrderType(OrderType.PURCHASE);
                order.setSupplierId(entry.getKey());
                order.setRequestId(groupedItem.getKey());
                order.setOrderDate(LocalDate.now());
                order.setOrderStatus(OrderStatus.DRAFT);
                PurchaseRequestItemView firstItem = groupedItem.getValue().get(0);
                order.setRequestClinicId(firstItem.getRequestClinicId());
                order.setCreateDate(LocalDate.now());
                order.setOrderNo(runningNumberService.generateOrderNumber());
                order.setRequestDate(firstItem.getRequestDate());
                order.setRequestId(firstItem.getId());
                order.setRequestClinicId(firstItem.getRequestClinicId());
                List<GoodOrderedItem> list = new ArrayList<>();
                for (PurchaseRequestItemView purchaseRequestItemView : groupedItem.getValue()) {
                    log.info("Creating order for item {}", purchaseRequestItemView.getItemRefId());
                    Item item = items.get(purchaseRequestItemView.getItemRefId());
                    GoodOrderedItem goodOrderedItem = createGoodOrderedItem(purchaseRequestItemView,
                            item);
                    list.add(goodOrderedItem);
                    addBonusItems(supplier, item, purchaseRequestItemView, list);
                }
                order.setGoodPurchasedItems(list);
                result.add(orderDatabaseService.saveOrder(order));
            }
        }

        return result;
    }

    private GoodOrderedItem createGoodOrderedItem(PurchaseRequestItemView purchaseRequestItemView, Item item) throws ExecutionException {
        double newQuantity = uomMatrixService.convertItemUom(item, purchaseRequestItemView.getUom(), item.getPurchaseUom(), purchaseRequestItemView.getQuantity());

        GoodOrderedItem goodOrderedItem = new GoodOrderedItem();
        goodOrderedItem.setItemRefId(purchaseRequestItemView.getItemRefId());
        goodOrderedItem.setUnitPrice(purchaseRequestItemView.getUnitPrice());
        goodOrderedItem.setLineNo(IdUtils.lineNoGenerator());
        goodOrderedItem.setUom(item.getPurchaseUom());
        goodOrderedItem.setQuantity((int) Math.ceil(newQuantity));
        goodOrderedItem.setSupplierId(purchaseRequestItemView.getSupplierId());
        goodOrderedItem.setReceiverClinicId(purchaseRequestItemView.getRequestClinicId());
        goodOrderedItem.setPurchaseRequestId(purchaseRequestItemView.getId());
        goodOrderedItem.setPurchaseRequestNo(purchaseRequestItemView.getRequestNo());
        goodOrderedItem.setRemark(purchaseRequestItemView.getRemark());
        goodOrderedItem.setCpRemarks(purchaseRequestItemView.getCpRemarks());
        return goodOrderedItem;
    }

    public Tuple<List<String>, String> createOrderMail(String orderId, List<String> email) throws CMSException, IOException {
        Optional<Order> optOrder = orderDatabaseService.findOrderById(orderId);
        if (optOrder.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Order with id [" + orderId + "] not found");
        }

        Order order = optOrder.get();

        Optional<Supplier> supplierOpt = supplierRepository.findById(order.getSupplierId());
        if (supplierOpt.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Supplier with id [" + order.getSupplierId() + "] not found");
        }
        Supplier supplier = supplierOpt.get();

        List<GoodOrderedItem> goodOrderedItems = order.getGoodPurchasedItems();
        List<GoodOrderedItemPrint> goodOrderedItemPrints = convertGoodOrderedItemsToPrint(goodOrderedItems);
        List<ContactPerson> contactPeoples = supplier.getContacts()
			.stream()
			.filter(contactPerson -> contactPerson.getType() != null && contactPerson.getType() == ContactPerson.Type.Purchase)
			.filter(contactPerson -> CommonUtils.isStringValid(contactPerson.getEmail()) && email.contains(contactPerson.getEmail()))
			.collect(Collectors.toList());
		List<String> emailIds = contactPeoples.stream()
			.map(ContactPerson::getEmail)
			.collect(Collectors.toList());

        Optional<Clinic> optClinic = clinicRepository.findById(order.getRequestClinicId());
        if (optClinic.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Requested clinic with id [" + order.getRequestClinicId() + "] not found");
        }
        Clinic requestedClinic = optClinic.get();

		if (!contactPeoples.isEmpty()) {
			String messageContent = createMessageContent(order, supplier, requestedClinic, contactPeoples, goodOrderedItemPrints);
			return new Tuple<>(emailIds, messageContent);
		}

        throw new CMSException(StatusCode.I5000, "Email for purchase type contact not found in the contact list");
    }

    private List<GoodOrderedItemPrint> convertGoodOrderedItemsToPrint(List<GoodOrderedItem> goodOrderedItems) {
        return goodOrderedItems.stream()
                .map(goodOrderedItem -> {
                    try {
                        Item item = itemService.findItemById(goodOrderedItem.getItemRefId());
                        Optional<UomMatrix> uomMatrixOpt = uomMatrixDatabaseService.findUOMatrixByUomCode(item.getBaseUom());
                        String packSize = "";
                        if (uomMatrixOpt.isPresent()) {
                            Map<String, BigDecimal> exchangeRatio = uomMatrixOpt.get().getExchangeRatio();
                            if (exchangeRatio != null) {
                                BigDecimal size = exchangeRatio.get(goodOrderedItem.getUom());
                                if (size != null) {
                                    packSize = size + " " + item.getBaseUom();
                                }
                            }
                        }

                        double unitPrice = goodOrderedItem.getUnitPrice().getPrice() / 100.0;
                        unitPrice = Double.parseDouble(df.format(unitPrice));
                        double total = unitPrice * goodOrderedItem.getQuantity();
                        return GoodOrderedItemPrint.builder()
                                .itemRefId(goodOrderedItem.getItemRefId())
                                .uom(goodOrderedItem.getUom())
                                .quantity(goodOrderedItem.getQuantity())
                                .packSize(packSize)
                                .unitPrice(BigDecimal.valueOf(unitPrice))
                                .taxIncluded(goodOrderedItem.getUnitPrice().isTaxIncluded())
                                .itemName(item.getName())
                                .totalPrice(BigDecimal.valueOf(total))
                                .build();
                    } catch (CMSException e) {
                        throw new RuntimeException(e);
                    }
                }).collect(Collectors.toList());
    }

    public PurchaseOrderPrint getPrintContent(String orderId) throws CMSException {
        Optional<Order> optOrder = orderDatabaseService.findOrderById(orderId);
        if (optOrder.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Order with id [" + orderId + "] not found");
        }

        Order order = optOrder.get();

        Optional<Supplier> supplierOpt = supplierRepository.findById(order.getSupplierId());
        if (supplierOpt.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Supplier with id [" + order.getSupplierId() + "] not found");
        }
        Supplier supplier = supplierOpt.get();

        List<GoodOrderedItem> goodOrderedItems = order.getGoodPurchasedItems();
        List<GoodOrderedItemPrint> goodOrderedItemPrints = convertGoodOrderedItemsToPrint(goodOrderedItems);
        List<ContactPerson> contactPeople = supplier.getContacts();

        Optional<Clinic> optClinic = clinicRepository.findById(order.getRequestClinicId());
        if (optClinic.isEmpty()) {
            throw new CMSException(StatusCode.E1002, "Requested clinic with id [" + order.getRequestClinicId() + "] not found");
        }
        Clinic requestedClinic = optClinic.get();

        BigDecimal subTotal = goodOrderedItemPrints.stream().map(GoodOrderedItemPrint::getTotalPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Tuple<Double, Double> gstTuple = calculateGst(order);
        BigDecimal total = subTotal.add(BigDecimal.valueOf(gstTuple.getSecond()));

        return PurchaseOrderPrint.builder()
                .order(order)
                .supplier(supplier)
                .contactPerson(contactPeople)
                .goodOrderedItems(goodOrderedItemPrints)
                .requestedClinic(requestedClinic)
                .subTotal(subTotal)
                .gst(BigDecimal.valueOf(gstTuple.getFirst()))
                .total(total.setScale(2, RoundingMode.HALF_DOWN))
                .logo(logoUtil.getClinicLogoInBase64(requestedClinic, LogoUtil.ClinicLogoType.BLACK_AND_WHITE))
                .build();
    }

    private String createMessageContent(Order order, Supplier supplier, Clinic requestedClinic, List<ContactPerson> contactPersons, List<GoodOrderedItemPrint> goodOrderedItems) throws IOException, PebbleException, CMSException {

        PebbleEngine engine = new PebbleEngine.Builder()
                .loader(new ClasspathLoader())
                .build();
        PebbleTemplate compiledTemplate = engine.getTemplate("purchase_order_email_template.html");

        HashMap<String, Object> map = new HashMap<>();

        map.put("po_number", order.getOrderNo());
        map.put("po_date", order.getCreateDate());
        map.put("po_remarks", order.getRemark() != null ? order.getRemark() : "");

        String clinicAddress = "";
        if (requestedClinic.getAddress() != null) {
            if (requestedClinic.getAddress().getAttentionTo() != null) {
                clinicAddress += supplier.getAddress().getAttentionTo() + "\n";
            }
            clinicAddress += requestedClinic.getAddress().getAddress() + "\n";
            if (requestedClinic.getAddress().getPostalCode() != null) {
                clinicAddress += requestedClinic.getAddress().getPostalCode();
            }
        }

        map.put("clinic_name", requestedClinic.getName());
        map.put("clinic_address", clinicAddress);
        map.put("clinic_phone", requestedClinic.getContactNumber());
        map.put("clinic_email", requestedClinic.getEmailAddress());

        String supplierNo = supplier.getSupplierNo();
        String supplierName = supplier.getName();
        String supplerAddress = "";
        if (supplier.getAddress() != null) {
            if (supplier.getAddress().getAttentionTo() != null) {
                supplerAddress += supplier.getAddress().getAttentionTo() + "\n";
            }
            supplerAddress += supplier.getAddress().getAddress() + "\n";
            if (supplier.getAddress().getPostalCode() != null) {
                supplerAddress += supplier.getAddress().getPostalCode();
            }
        }
        String supplierMobileNumber = contactPersons.stream()
			.map(ContactPerson::getMobileNumber)
			.filter(CommonUtils::isStringValid)
			.collect(Collectors.joining(", "));

        String supplierEmail = contactPersons.stream()
			.map(ContactPerson::getEmail)
			.filter(CommonUtils::isStringValid)
			.collect(Collectors.joining(", "));

        map.put("supplier_no", supplierNo);
        map.put("supplier_name", supplierName);
        map.put("supplier_address", supplerAddress);
        map.put("supplier_phone", supplierMobileNumber);
        map.put("supplier_email", supplierEmail);

        BigDecimal subTotal = BigDecimal.ZERO;
        List<Map<String, Object>> items = new ArrayList<>();
        for (GoodOrderedItemPrint goodOrderedItem : goodOrderedItems) {
            Item item = itemService.findItemById(goodOrderedItem.getItemRefId());
            subTotal = subTotal.add(goodOrderedItem.getTotalPrice());
            Map<String, Object> itemMap = new HashMap<>();

            itemMap.put("code", item.getCode());
            itemMap.put("name", item.getName());
            itemMap.put("pack_size", goodOrderedItem.getPackSize());
            itemMap.put("quantity", goodOrderedItem.getQuantity());
            itemMap.put("uom", goodOrderedItem.getUom());
            itemMap.put("unit_price", goodOrderedItem.getUnitPrice());
            itemMap.put("total", goodOrderedItem.getTotalPrice());

            items.add(itemMap);
        }

        Tuple<Double, Double> gstTuple = calculateGst(order);
        BigDecimal total = subTotal.add(BigDecimal.valueOf(gstTuple.getSecond()));
        map.put("items", items);
        map.put("sub_total", subTotal.setScale(2, RoundingMode.HALF_DOWN));
        map.put("gst", gstTuple.getFirst() + "%");
        map.put("total", total.setScale(2, RoundingMode.HALF_DOWN));
        map.put("today_date", new SimpleDateFormat(CmsConstant.JSON_DATE_FORMAT).format(System.currentTimeMillis()));

        StringWriter writer = new StringWriter();
        compiledTemplate.evaluate(writer, map);

        return writer.toString();
    }

    public Tuple<Double, Double> calculateGst(Order order) throws CMSException {
        Double sum = order.getGoodPurchasedItems().stream()
                .mapToDouble(item -> (item.getUnitPrice().getPrice() * item.getQuantity()))
                .reduce(0.00, Double::sum);
        double gstPercent = order.getGstPercentage().doubleValue();
        double gst = (sum / 100) * gstPercent / 100;

        return new Tuple<>(gstPercent, gst);
    }

    public List<Order> listReturnOrders(SearchPurchaseReturnOrderContainer search,
                                        int page, int size) {

        return orderDatabaseService.listReturnOrders(search, page, size);
    }

    public List<Order> approveOrRejectReturnOrders(List<String> orderIds, GoodReceivedReturnStatus returnStatus) throws CMSException {

        List<Order> returnOrders = orderDatabaseService.findOrdersByIds(orderIds);
        List<Order> approvedOrRejectedReturnOrders = new ArrayList<>();
        List<Tuple<Order, CMSException>> failedReturnOrders = new ArrayList<>();

        for (Order returnOrder : returnOrders) {
            try {
                validateReturnOrder(returnStatus, returnOrder);

                returnOrder.setReturnStatus(returnStatus);
                approvedOrRejectedReturnOrders.add(returnOrder);

                if (returnOrder.getReturnStatus().equals(GoodReceivedReturnStatus.APPROVED)) {
                    updateInventoryByReturnOrder(returnOrder);
                }
            } catch (CMSException e) {
                failedReturnOrders.add(new Tuple<>(returnOrder, e));
            }
        }

        List<Order> savedOrders = orderDatabaseService.saveOrders(approvedOrRejectedReturnOrders);
        if (!failedReturnOrders.isEmpty()) {
            throw new CMSException(StatusCode.I5000, "Failed to approve or reject return orders: " + failedReturnOrders.stream()
                    .map(tuple -> tuple.getFirst().getOrderNo())
                    .collect(Collectors.joining(",")));
        }
        return savedOrders;
    }

    public Order editAndApproveReturnOrder(Order returnOrder) throws CMSException {

        Order order = orderDatabaseService.findOrderById(returnOrder.getId())
                .orElseThrow(() -> new CMSException(StatusCode.I5000, "Return order not found"));

        validateReturnOrder(returnOrder.getReturnStatus(), returnOrder);
        List<GoodReturnItem> updatedReturnItems = order.getReturnItems().stream().map(returnItem -> {
            GoodReturnItem incomingGoodReturnItem = null;
            try {
                incomingGoodReturnItem = returnOrder.getReturnItems()
                        .stream().filter(returnItem1 -> returnItem.getItemRefId().equals(returnItem1.getItemRefId()))
                        .findFirst()
                        .orElseThrow(() -> new CMSException(StatusCode.I5000, "Return item not found"));
            } catch (CMSException e) {
                throw new RuntimeException(e);
            }

            returnItem.setQuantity(incomingGoodReturnItem.getQuantity());

            return returnItem;
        }).collect(Collectors.toList());

        order.setReturnItems(updatedReturnItems);
        order.setReturnStatus(GoodReceivedReturnStatus.APPROVED);

        updateInventoryByReturnOrder(order);

        return orderDatabaseService.saveOrder(order);
    }

    private List<InventoryTransaction> updateInventoryByReturnOrder(Order returnOrder) throws CMSException {

        List<Inventory> inventories = returnOrder.getReturnItems().stream().map(returnItem -> {
            try {
                Inventory inventory = locationService.mapReturnItemsToInventory(returnItem);

                return inventory;
            } catch (CMSException e) {
                throw new RuntimeException(e);
            }
        }).collect(Collectors.toList());

        Location location = new Location(returnOrder.getRequestClinicId());
        location.setInventory(inventories);

        List<InventoryTransaction> inventoryTransactionList = locationService.findAndModify(location, true, false);
        locationService.saveInventoryTransactions(inventoryTransactionList, returnOrder.getId(), InventoryTransaction.Type.GRVN);

        return inventoryTransactionList;
    }

    private void validateReturnOrder(GoodReceivedReturnStatus returnStatus, Order order) throws CMSException {
        if (!OrderType.RETURN.equals(order.getOrderType())) {
            throw new CMSException(StatusCode.I5000, "Invalid order type");
        }

        if (!GoodReceivedReturnStatus.CONFIRM.equals(order.getReturnStatus())) {
            throw new CMSException(StatusCode.I5000, "Invalid return order status");
        }
    }

    public Order cancelOrder(String id) throws CMSException {
        Order order = findOrderById(id);
        if (order == null) {
            throw new CMSException(StatusCode.I5000, "Order not found");
        }

        if (!order.getOrderStatus().equals(OrderStatus.DRAFT) && !order.getOrderStatus().equals(OrderStatus.INITIAL)) {
            throw new CMSException(StatusCode.I5000, "Order cannot be cancelled");
        }

        order.setOrderStatus(OrderStatus.DELETED);
        return orderDatabaseService.saveOrder(order);
    }

    public List<Order> rejectOrder(List<String> orderIds) throws CMSException {
        List<Order> orders = orderDatabaseService.findOrdersByIds(orderIds);
        orders.forEach(a -> a.setOrderStatus(OrderStatus.REJECTED));
        orderDatabaseService.saveOrders(orders);
        return orders;
    }

    public Map<String, Double> findBackOrderCount(Set<String> itemRefIds, String clinicId, String orderId, OrderType orderType) {
        log.info("Started findBackOrderCount with itemRefIds = {}, clinicId = {}, orderId = {}, orderType = {}", itemRefIds, clinicId, orderId, orderType);

        try {
            List<Order> orders = orderDatabaseService.findOpenOrdersWithItemRefIds(itemRefIds, clinicId);
            log.debug("Retrieved orders: {}", orders);

            Map<String, Item> itemsMap = itemService.findItemByIds(new ArrayList<>(itemRefIds))
                    .stream()
                    .collect(Collectors.toMap(PersistedObject::getId, Function.identity()));
            log.debug("Retrieved items map: {}", itemsMap);

            Map<String, Double> result = new HashMap<>();

            for (Order order : orders) {
                if (Objects.equals(order.getId(), orderId)) {
                    log.debug("Skipping requested order");
                    continue;
                }

                for (GoodOrderedItem goodPurchasedItem : order.getGoodPurchasedItems()) {
                    if (!itemRefIds.contains(goodPurchasedItem.getItemRefId())) continue;
                    Double baseQuantity = convertToBaseUom(itemsMap, goodPurchasedItem.getItemRefId(), goodPurchasedItem.getUom(), goodPurchasedItem.getQuantity());
                    log.debug("Calculated baseQuantity for goodPurchasedItem: {}", baseQuantity);
                    result.put(goodPurchasedItem.getItemRefId(), result.getOrDefault(goodPurchasedItem.getItemRefId(), 0D) + baseQuantity);
                    log.debug("Following itemRefId, updated result map: {}", result);
                }

                for (TransferRequestItem transferRequestItem : order.getTransferRequestItems()) {
                    if (!itemRefIds.contains(transferRequestItem.getItemRefId())) continue;
                    Double baseQuantity = convertToBaseUom(itemsMap, transferRequestItem.getItemRefId(), transferRequestItem.getUom(), transferRequestItem.getQuantity());
                    log.debug("Calculated baseQuantity for transferRequestItem: {}", baseQuantity);
                    result.put(transferRequestItem.getItemRefId(), result.getOrDefault(transferRequestItem.getItemRefId(), 0D) + baseQuantity);
                    log.debug("Following transferRequestItem update, updated result map: {}", result);
                }

                for (GoodReceivedNote goodReceivedNote : order.getGoodReceivedNotes()) {
                    for (DeliveryItem deliveryItem : goodReceivedNote.getReceivedItems()) {
                        if (!itemRefIds.contains(deliveryItem.getItemRefId())) continue;
                        Double baseQuantity = convertToBaseUom(itemsMap, deliveryItem.getItemRefId(), deliveryItem.getUom(), deliveryItem.getQuantity());
                        log.debug("Calculated baseQuantity for deliveryItem: {}", baseQuantity);
                        result.put(deliveryItem.getItemRefId(), result.getOrDefault(deliveryItem.getItemRefId(), 0D) - baseQuantity);
                        log.debug("Following deliveryItem update, updated result map: {}", result);
                    }
                }
            }

            if (orderType == OrderType.PURCHASE) {
                Set<String> keys = result.keySet();
                for (String key : keys) {
                    Item item = itemsMap.get(key);
                    result.put(key, uomMatrixService.convertItemUom(item, item.getBaseUom(), item.getPurchaseUom(), result.get(key)));
                    log.debug("Following conversion of item uom, updated result map: {}", result);
                }
            }

            log.info("Completed findBackOrderCount with result = {}", result);
            return result;
        } catch (ExecutionException e) {
            log.error("Error in findBackOrderCount", e);
            throw new RuntimeException(e);
        }
    }

    private double convertToBaseUom(Map<String, Item> itemsMap, String itemRefId, String uom, int quantity) throws ExecutionException {
        Item item = itemsMap.get(itemRefId);
        return uomMatrixService.convertItemUom(item, uom, item.getBaseUom(), quantity);
    }

    public Map<String, BigDecimal> convertUom(List<UomConversionRequest> requests) throws CMSException, ExecutionException {
        List<String> itemRefIds = requests.stream()
                .map(UomConversionRequest::getItemRefId)
                .collect(Collectors.toList());

        Map<String, Item> itemMap = itemService.findItemByIds(itemRefIds).stream()
                .collect(Collectors.toMap(PersistedObject::getId, a -> a));

        HashMap<String, BigDecimal> result = new HashMap<>();

        for (UomConversionRequest request : requests) {
            Item item = itemMap.get(request.getItemRefId());
            if (item == null) {
                throw new CMSException(StatusCode.E1002, "Item not found for id [" + request.getItemRefId() + "]");
            }

            double convertedQuantity = uomMatrixService.convertItemUom(item, request.getSourceUom(), request.getDestinationUom(),request.getQuantity());
            result.put(request.getId(), BigDecimal.valueOf(convertedQuantity));
        }

        return result;
    }
}
