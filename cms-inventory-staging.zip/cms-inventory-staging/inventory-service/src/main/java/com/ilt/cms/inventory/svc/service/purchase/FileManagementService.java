package com.ilt.cms.inventory.svc.service.purchase;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.ilt.cms.core.entity.file.FileMetaData;

import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.purchase.GoodReceivedNote;
import com.ilt.cms.inventory.svc.model.purchase.api.FileDowload;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.DeliveryNoteStatus;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.util.AWSConfig;
import com.lippo.cms.util.ConcurrencyLock;
import com.lippo.commons.util.CommonUtils;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class FileManagementService {

    private static final Logger logger = LoggerFactory.getLogger(FileManagementService.class);

    @Value("${aws.access.key:}")
    private String awsAccessKey;
    @Value("${aws.secret.key:}")
    private String awsSecretKey;
    @Value("${s3.backet.name:}")
    private String s3BucketName;
    @Value("${max.file.size:0}")
    private long maxFileSize;

    private final ConcurrencyLock concurrencyLock;

    private AWSConfig<AmazonS3> awsConfig;

    private OrderDatabaseService orderDatabaseService;

    public FileManagementService(OrderDatabaseService orderDatabaseService) {
        this.concurrencyLock = new ConcurrencyLock();
        this.orderDatabaseService = orderDatabaseService;
    }

    @PostConstruct
    private void initAWSConfig() {
        logger.debug("s3BucketName:" + s3BucketName);
        awsConfig = AWSConfig.getInstance(Regions.AP_SOUTHEAST_1.getName(), awsAccessKey, awsSecretKey, s3BucketName, maxFileSize,
                AmazonS3ClientBuilder
                        .standard()
                        .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsAccessKey, awsSecretKey)))
                        .withRegion(Regions.AP_SOUTHEAST_1)
                        .build());
    }

    public FileMetaData uploadDeliveryNoteFileToGoodReceivedNote(Principal principal, String name, String clinicId, String orderId, String grnId, String fileName,
                                                                 String description, MultipartFile uploadFile) throws CMSException, IOException {

        logger.info("uploadDeliveryNoteFileToGoodReceivedNote by user[" + principal.getName() + "], name[" + name + "], orderId[" +
                orderId + "], grnId[" + grnId + "], fileName[" + fileName + "], description[" + description + "], uploadFile[" + uploadFile + "]");

        if (!CommonUtils.isStringValid(name, clinicId, orderId, grnId, fileName, description) || uploadFile == null) {
            logger.error("Invalid parameters");
            throw new CMSException(StatusCode.E1002);
        }

        if (uploadFile.getSize() > awsConfig.getMaxFileSize()) {
            logger.error("File size[" + uploadFile.getSize() + "] is too big");
            throw new CMSException(StatusCode.E1010, "File size[" + uploadFile.getSize() + "] is too big");
        }

        Order order = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> {
                    logger.error("Order[" + orderId + "] not found");
                    return new CMSException(StatusCode.E2000, "Order not found");
                });
        GoodReceivedNote existGoodReceivedNote = order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getId().equals(grnId))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("Cannot found goodReceivedNote by orderId[" + orderId + "], grnId[" + grnId + "]");
                    return new CMSException(StatusCode.E2000, "GoodReceivedNote not found");
                });

        Optional<FileMetaData> fileMetaDataOpt = existGoodReceivedNote.getFileMetaData().stream()
                .filter(fileMetaData -> !fileMetaData.isDeleted()).findFirst();

        logger.info("saving file into s3");
        int lockNumber = 0;
        try {
            lockNumber = concurrencyLock.lock(orderId + grnId);
            logger.debug("Locking on number [" + lockNumber + "]");
            if (fileMetaDataOpt.isPresent()) {
                String oldFileId = fileMetaDataOpt.get().decodedFileIdValue();
                String newFileId = formulateDeletedDeliveryNoteFileId(order, existGoodReceivedNote);
                FileMetaData metaData = copyInS3(fileMetaDataOpt.get(), newFileId);
                deleteFromS3(oldFileId, null);
                metaData.setDeleted(true);
                existGoodReceivedNote.getFileMetaData().remove(fileMetaDataOpt.get());
                existGoodReceivedNote.getFileMetaData().add(metaData);
            }
            return uploadFileToS3(principal, name, grnId, fileName, description, uploadFile, order, existGoodReceivedNote);

        } finally {
            concurrencyLock.unlock(lockNumber);
        }

    }

    public FileDowload downloadFileFromGRN(String orderId, String grnId, String fileId) throws IOException, CMSException {

        logger.info("downloadFileFromGRN [" + orderId + "], grnId[" + grnId + "]");

        Order order = orderDatabaseService.findOrderById(orderId)
                .orElseThrow(() -> {
                    logger.error("Order[" + orderId + "] not found");
                    return new CMSException(StatusCode.E2000, "Order not found");
                });

        GoodReceivedNote existGoodReceivedNote = order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getId().equals(grnId))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("GoodReceivedNotes not found, orderId[" + orderId + "], goodReceivedNote[" + grnId + "]");
                    return new CMSException(StatusCode.E2000, "Order not found");
                });

        FileMetaData existFileMetaData = existGoodReceivedNote.getFileMetaData()
                .stream()
                .filter(fileMetaData -> fileMetaData.getFileId().equals(fileId) && !fileMetaData.isDeleted())
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("File metadata[" + fileId + "] not found");
                    return new CMSException(StatusCode.E2000, "File metadata not found");
                });

        logger.debug("Downloading file [" + fileId + "] from s3");
        ByteArrayOutputStream outputStream = downloadFromS3(existFileMetaData);
        return new FileDowload(existFileMetaData.getFileName(), outputStream);


    }

    public FileMetaData findMetaDataFromGRN(String orderId, String grnId) throws CMSException {

        logger.info("findMetaDataFromGRN, orderId[" + orderId + "], grnId[" + grnId + "]");
        Order order = orderDatabaseService.findOrderById(orderId).orElseThrow(() -> {
            logger.error("Order[" + orderId + "] not found");
            return new CMSException(StatusCode.E2000, "order not found");
        });

        GoodReceivedNote existGoodReceivedNote = order.getGoodReceivedNotes().stream()
                .filter(goodReceivedNote -> goodReceivedNote.getId().equals(grnId))
                .findFirst()
                .orElseThrow(() -> {
                    logger.error("GoodReceivedNote not found, orderId[" + orderId + "], grnNo[" + grnId + "]");
                    return new CMSException(StatusCode.E2000, "GoodReceivedNote not found");
                });
        FileMetaData validFileMetaData = existGoodReceivedNote.getFileMetaData().stream()
                .filter(fileMetaData -> !fileMetaData.isDeleted())
                .findFirst()
                .orElse(null);
        return validFileMetaData;
    }

    private FileMetaData uploadFileToS3(Principal principal, String name, String clinicId, String fileName,
                                        String description, MultipartFile uploadFile, Order order, GoodReceivedNote goodReceivedNote) throws CMSException, IOException {

        String fileId = formulateDeliveryNoteId(order, goodReceivedNote);
        ObjectMetadata metadata = new ObjectMetadata();

        metadata.addUserMetadata("clinic-id", order.getId());
        metadata.addUserMetadata("order-id", order.getId());
        metadata.addUserMetadata("grn-no", goodReceivedNote.getGrnNo());
        metadata.addUserMetadata("username", principal.getName());
        try {
            FileMetaData fileMetaData = uploadToS3(principal, name, clinicId, fileName, description, uploadFile, goodReceivedNote.getFileMetaData(), fileId, metadata);
            logger.info("updating local database");
            orderDatabaseService.saveOrder(order);
            logger.info("Recoded added");
            return fileMetaData;
        } catch (AmazonServiceException e) {
            logger.error("Error adding to S3 bucket : ", e);
            throw new CMSException(StatusCode.I5000, "Error adding file");
        }
    }

    private FileMetaData uploadToS3(Principal principal, String name, String clinicId, String fileName, String description,
                                    MultipartFile uploadFile, List<FileMetaData> fileMetaData, String fileId,
                                    ObjectMetadata metadata) throws IOException {

        logger.info("upload file to S3 s3BucketName[" + awsConfig.getS3BucketName() + "], fileId[" + fileId + "], metadata[" + metadata + "]");
        PutObjectResult result = awsConfig.getAmazonS3().putObject(awsConfig.getS3BucketName(), fileId, uploadFile.getInputStream(), metadata);
        logger.info("Added to S3 bucket [" + result + "]");
        String fileExtension = findFileExtension(uploadFile);

        FileMetaData metaData = new FileMetaData(fileId, name, fileName, principal.getName(), clinicId, fileExtension,
                uploadFile.getSize(), description, LocalDateTime.now());
        fileMetaData.add(metaData);
        return metaData;
    }

    private void deleteFromS3(String fileId, String versionId) {

        String bucketVersionStatus = awsConfig.getAmazonS3()
                .getBucketVersioningConfiguration(awsConfig.getS3BucketName()).getStatus();
        logger.info("Is enable bucketVersion[" + bucketVersionStatus + "]");
        if (bucketVersionStatus.equals(BucketVersioningConfiguration.ENABLED) && versionId != null) {
            logger.info("delete version from [" + awsConfig.getS3BucketName() + "], file[" + fileId + "], versionId[" + versionId + "]");
            awsConfig.getAmazonS3().deleteVersion(awsConfig.getS3BucketName(), fileId, versionId);
        } else {
            logger.info("delete object from [" + awsConfig.getS3BucketName() + "], file[" + fileId + "]");
            awsConfig.getAmazonS3().deleteObject(awsConfig.getS3BucketName(), fileId);
        }
    }

    private FileMetaData copyInS3(FileMetaData fileMetaData, String newFileId) {

        logger.info("copy file to S3 s3BucketName[" + awsConfig.getS3BucketName() + "], old fileId[" +
                fileMetaData.decodedFileIdValue() + "], new fileId[" + newFileId + "]");
        CopyObjectResult copyObjectResult = awsConfig.getAmazonS3()
                .copyObject(awsConfig.getS3BucketName(), fileMetaData.decodedFileIdValue(), awsConfig.getS3BucketName(), newFileId);
        logger.info("Copied to S3 bucket [" + copyObjectResult + "]");
        FileMetaData newFileMetaData = new FileMetaData();
        newFileMetaData.copy(fileMetaData);
        newFileMetaData.setFileId(Base64.getEncoder().encodeToString(newFileId.getBytes()));
        return newFileMetaData;
    }

    private ByteArrayOutputStream downloadFromS3(FileMetaData fileMetaData) throws IOException {
        S3Object s3Object = awsConfig.getAmazonS3().getObject(awsConfig.getS3BucketName(), fileMetaData.decodedFileIdValue());
        S3ObjectInputStream objectContent = s3Object.getObjectContent();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte[] readBuf = new byte[1024];
        int readLen;
        try {
            while ((readLen = objectContent.read(readBuf)) > 0) {
                outputStream.write(readBuf, 0, readLen);
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw e;
        } finally {
            objectContent.close();
            outputStream.close();
        }
        return outputStream;
    }


    private String formulateDeliveryNoteId(Order order, GoodReceivedNote goodReceivedNote) {
        return "order/" + LocalDate.now().getYear() + "/" + order.getId() + "/" + goodReceivedNote.getGrnNo() + "/" + CommonUtils.idGenerator();
    }

    private String formulateDeletedDeliveryNoteFileId(Order order, GoodReceivedNote goodReceivedNote) {
        return "deleted-files/order/" + LocalDate.now().getYear() + "/" + order.getId() + "/" + goodReceivedNote.getGrnNo() + "/" + CommonUtils.idGenerator();
    }

    private String findFileExtension(MultipartFile uploadFile) {
        String originalFilename = uploadFile.getOriginalFilename();
        if (originalFilename.contains(".")) {
            String[] split = originalFilename.split("\\.");
            originalFilename = split[split.length - 1];
        }
        return originalFilename;
    }

}
