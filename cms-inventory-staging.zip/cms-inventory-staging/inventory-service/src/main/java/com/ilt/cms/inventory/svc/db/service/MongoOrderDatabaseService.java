package com.ilt.cms.inventory.svc.db.service;

import com.ilt.cms.inventory.svc.db.repository.spring.purchase.OrderRepository;
import com.ilt.cms.inventory.svc.db.repository.spring.purchase.RequestRepository;
import com.ilt.cms.inventory.svc.db.service.interfaces.OrderDatabaseService;
import com.ilt.cms.inventory.svc.model.purchase.PurchaseRequest;
import com.ilt.cms.inventory.svc.model.purchase.api.SearchPurchaseReturnOrderContainer;
import com.ilt.cms.inventory.svc.model.purchase.common.Order;
import com.ilt.cms.inventory.svc.model.purchase.enums.GoodReceivedReturnStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderStatus;
import com.ilt.cms.inventory.svc.model.purchase.enums.OrderType;
import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.lippo.commons.util.CommonUtils.isStringValid;

@Service
public class MongoOrderDatabaseService implements OrderDatabaseService {

    private static final Logger logger = LoggerFactory.getLogger(MongoOrderDatabaseService.class);

    private final int MAX_LIST_SIZE = 1000;

    private final OrderRepository orderRepository;

    private final RequestRepository requestRepository;

    private MongoTemplate mongoTemplate;

    public MongoOrderDatabaseService(OrderRepository orderRepository, RequestRepository requestRepository,
                                     MongoTemplate mongoTemplate) {
        this.orderRepository = orderRepository;
        this.requestRepository = requestRepository;
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public List<PurchaseRequest> findPurchaseRequest() {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return requestRepository.findAll(pageable).getContent();
    }

    @Override
    public List<PurchaseRequest> findPurchaseRequestsByIds(List<String> ids) {
        return requestRepository.findAllByIdIn(ids);
    }

    @Override
    public List<PurchaseRequest> findPurchaseRequestByClinicId(String clinicId) {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return requestRepository.findAllByRequestClinicId(clinicId, pageable);
    }

    @Override
    public List<Order> findAllOrder() {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return orderRepository.findAll(pageable).getContent();
    }

    @Override
    public List<Order> findOrdersByIds(List<String> ids) {
        return (List<Order>) orderRepository.findAllById(ids);
    }

    @Override
    public Optional<Order> findOrderById(String orderId) {
        return orderRepository.findById(orderId);
    }

    @Override
    public List<Order> findOrderByIdsAndOrderType(List<String> orderIds, OrderType type) {
        return orderRepository.findAllByIdInAndOrderType(orderIds, type);
    }

    @Override
    public List<Order> findOrderByRequestId(String requestId) {

        return orderRepository.findByRequestId(requestId);
    }

    @Override
    public List<Order> findOrderByOrderTypeAndOrderNos(OrderType orderType, List<String> orderNos) {
        return orderRepository.findByOrderTypeAndOrderNoIn(orderType, orderNos);
    }

    @Override
    public List<Order> findOrderByClinicIdOrClinicGroupName(String clinicId, String clinicGroupName) {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return orderRepository.findAllByRequestClinicIdOrClinicFilterClinicsInOrClinicFilterClinicGroupName(clinicId,
                Arrays.asList(clinicId), clinicGroupName, pageable);
    }

    @Override
    public List<Order> findOrderBySenderClinicId(String clinicId) {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return orderRepository.findAllBySenderClinicId(clinicId);
    }

    @Override
    public Optional<PurchaseRequest> findPurchaseRequestById(String purchaseRequestId) {
        return requestRepository.findById(purchaseRequestId);
    }

    @Override
    public List<PurchaseRequest> findPurchaseRequestNumbers(List<String> purchaseRequestId) {
        return requestRepository.findAllByRequestNoIn(purchaseRequestId);
    }

    @Override
    public PurchaseRequest savePurchaseRequest(PurchaseRequest purchaseRequest) {
        return requestRepository.save(purchaseRequest);
    }

    @Override
    public List<PurchaseRequest> savePurchaseRequests(List<PurchaseRequest> purchaseRequests) {
        return requestRepository.saveAll(purchaseRequests);
    }

    @Override
    public void deletePurchaseRequest(String purchaseRequestId) {
        requestRepository.deleteById(purchaseRequestId);
    }

    @Override
    public List<PurchaseRequest> findActivePurchaseRequests(List<RequestStatus> requestStatuses, LocalDate startDate, LocalDate endDate) {
        return requestRepository.findAllByRequestStatusInAndCreatedDateBetweenAndIsReadByNavIsNull(requestStatuses, startDate, endDate,
                Sort.by(Sort.Direction.DESC, "createdDate"));
    }

    @Override
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    @Override
    public List<Order> saveOrders(List<Order> orders) {
        return orderRepository.saveAll(orders);
    }

    public boolean deleteOrder(String orderId) {
        orderRepository.deleteById(orderId);
        return true;
    }

    @Override
    public List<Order> findReturnOrderByReturnItemsPurchaseOrderId(String purchaseOrderId, List<GoodReceivedReturnStatus> returnStatus) {

        return orderRepository.findAllByOrderTypeAndReturnStatusInAndPurchaseOrderId(OrderType.RETURN, returnStatus, purchaseOrderId);
    }

    @Override
    public List<Order> listReturnOrders(SearchPurchaseReturnOrderContainer search, int page, int size) {

        String clinicId = search.getClinicId();
        LocalDate startDate = search.getStartDate();
        LocalDate endDate = search.getEndDate();
        String orderNo = search.getOrderNo();
        String returnStatus = search.getRequestStatus();
        String itemRefId = search.getItemRefId();
        String supplierId = search.getSupplierId();

        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));

        Query query = new Query();

        query.addCriteria(Criteria.where("orderType").is(OrderType.RETURN));

        if(clinicId != null){
            query.addCriteria(Criteria.where("requestClinicId").is(search.getClinicId()));
        }

        if (startDate != null && endDate != null) {
            query.addCriteria(Criteria.where("createDate").gte(startDate).lte(endDate));
        }

        if (orderNo != null) {
            query.addCriteria(Criteria.where("orderNo").is(orderNo));
        }

        if (returnStatus != null) {
            query.addCriteria(Criteria.where("returnStatus").is(returnStatus));
        }

        if (itemRefId != null) {
            query.addCriteria(Criteria.where("returnItems.itemRefId").is(itemRefId));
        }

        if (supplierId != null) {
            query.addCriteria(Criteria.where("supplierId").is(supplierId));
        }

        query.with(pageable);

        return mongoTemplate.find(query, Order.class);
    }

    @Override
    public List<Order> findOpenOrdersWithItemRefIds(Set<String> itemRefIds, String clinicId) {
        Query query = new Query();
        query.addCriteria(
                new Criteria()
                        .orOperator(
                                Criteria.where("transferRequestItems.itemRefId").in(itemRefIds),
                                Criteria.where("goodPurchasedItems.itemRefId").in(itemRefIds)
                        )
                        .and("requestDate").gte(LocalDate.now().minusMonths(3))

                        .and("orderStatus").in(OrderStatus.INITIAL.name(), OrderStatus.PARTIAL_RECEIVED.name())
                        .and("requestClinicId").is(clinicId)
        );

        return mongoTemplate.find(query, Order.class);
    }

    @Override
    public List<PurchaseRequest> saveAllPurchaseRequests(List<PurchaseRequest> mappedList) {
        return requestRepository.saveAll(mappedList);

    }

    @Override
    public List<Order> findActiveOrders(List<OrderStatus> requestStatuses, OrderType orderType, LocalDate startDate,
                                        LocalDate endDate) {
        return orderRepository.findByOrderTypeAndOrderStatusInAndCreateDateBetween(orderType, requestStatuses, startDate, endDate,
                Sort.by(Sort.Direction.DESC, "createDate"));
    }

    @Override
    public List<Order> findActiveReturnOrders(List<GoodReceivedReturnStatus> returnStatuses, LocalDate startDate, LocalDate endDate) {
        return orderRepository.findByOrderTypeAndReturnStatusInAndCreateDateBetween(OrderType.RETURN, returnStatuses, startDate, endDate,
                Sort.by(Sort.Direction.DESC, "createDate"));
    }

    @Override
    public List<PurchaseRequest> findActivePurchaseRequest(LocalDate startDate, LocalDate endDate) {
        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));
        return requestRepository.findAllByRequestDateBetween(startDate, endDate, pageable);
    }

    @Override
    public List<Order> findReturnOrderByRequestClinicIdAndCreateDateAndReturnNumberAndRequestStatusIn(String clinicId, String groupName, LocalDate startDate,
                                                                                                      LocalDate endDate, String number,
                                                                                                      List<String> status) {

        Pageable pageable = PageRequest.of(0, MAX_LIST_SIZE, Sort.by(Sort.Direction.DESC, "createdDate"));

        Query query = new Query();

        query.addCriteria(new Criteria()
                .orOperator(
                        Criteria.where("requestClinicId").is(clinicId),
                        Criteria.where("clinicFilter.clinics").is(clinicId),
                        Criteria.where("clinicFilter.clinicGroupName").is(groupName)));

        query.addCriteria(Criteria.where("orderType").is(OrderType.RETURN));
        if (startDate != null && endDate != null) {
            query.addCriteria(Criteria.where("createDate").gte(startDate).lte(endDate));
        }
        if (isStringValid(number)) {
            query.addCriteria(Criteria.where("orderNo").is(number));
        }
        if (status != null && status.size() > 0) {
            query.addCriteria(Criteria.where("returnStatus").in(status));
        }
        query.with(pageable);

        return mongoTemplate.find(query, Order.class);
    }


}
