package com.ilt.cms.inventory.svc.service.nav;

import com.hmc.multi.tenant.filter.TenantContext;
import com.ilt.cms.core.entity.billing.ItemChargeDetail;
import com.ilt.cms.core.entity.inventory.InventoryDetail;
import com.ilt.cms.core.entity.inventory.InventoryUsage;
import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.inventory.svc.mapper.InventoryMapper;
import com.lippo.cms.container.CmsServiceResponse;
import com.lippo.cms.exception.RestTemplateResponseErrorHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NavInventoryService implements InventoryService {

    private static final Logger logger = LoggerFactory.getLogger(NavInventoryService.class);

    @Value("${legacy.api.all.usage:}")
    private String legacyApiAllUsage;


    @Value("${nav.api.url:}")
    private String navApi;


    private RestTemplate restTemplate;

    public NavInventoryService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder
                .errorHandler(new RestTemplateResponseErrorHandler())
                .build();
    }

    @Override
    public List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> fireInventoryApi(String clinicId, List<Item> items) {

        logger.info("Get usage from [" + legacyApiAllUsage + "] + items [" + items.size() + "], clinic[" + clinicId + "]");
        List<InventoryUsage> inventoryUsages = items.stream()
                .filter(item -> item.isInventoried())
                .map(item -> InventoryMapper.mapToInventoryUsage(item))
                .collect(Collectors.toList());
        if (inventoryUsages.size() > 0) {
            logger.debug("Convert to inventoryUsages[" + inventoryUsages + "]");
            return fireInventoryApiByInventoryUsages(clinicId, inventoryUsages);
        }
        return new ArrayList<>();
    }

    public List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> fireInventoryApiByInventoryUsages(String clinicId, List<InventoryUsage> inventoryUsages) {
        try {
            logger.info("Get usage from [" + legacyApiAllUsage + "] + inventoryUsages [" + inventoryUsages.size() + "], clinic[" + clinicId + "]");
            ParameterizedTypeReference<CmsServiceResponse<List<InventoryDetail>>> responseType = new ParameterizedTypeReference<>() {
            };

            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Tenant", TenantContext.getTenantId());

            ResponseEntity<CmsServiceResponse<List<InventoryDetail>>> responseEntity = restTemplate
                    .exchange(legacyApiAllUsage, HttpMethod.POST, new HttpEntity<>(inventoryUsages, headers),
                            responseType, clinicId);
            CmsServiceResponse<List<InventoryDetail>> body = responseEntity.getBody();
            if (body.getPayload() != null) {
                List<InventoryDetail> InventoryDetails = body.getPayload();
                return InventoryDetails.stream()
                        .map(this::mapToInventoryData).collect(Collectors.toList());
            } else {
                logger.error("Cannot get inventory, status[" + body.getStatusCode() + "], message:[" + body.getMessage() + "]");
            }
        } catch (Exception e) {
            logger.error("Error getting inventory details : [" + e.getMessage() + "]");
        }
        return new ArrayList<>();
    }

    private ItemChargeDetail.ItemChargeDetailResponse.InventoryData mapToInventoryData(InventoryDetail inventoryDetail) {
        ItemChargeDetail.ItemChargeDetailResponse.InventoryData inventoryData = new ItemChargeDetail.ItemChargeDetailResponse.InventoryData();
        inventoryData.setInventoryDetailId(inventoryDetail.getInventoryDetailId());
        inventoryData.setInventoryId(inventoryDetail.getInventoryId());
        inventoryData.setClinicId(inventoryDetail.getClinicId());
        inventoryData.setChargeId(inventoryDetail.getChargeId());
        if (inventoryDetail.getExpiryDate() != null) {
            inventoryData.setExpireDate(inventoryDetail.getExpiryDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        }
        inventoryData.setBatchNo(inventoryDetail.getBatchNo());
        //inventoryData.setQuantity(inventoryDetail.getBaseUomQuantity());
        inventoryData.setRemainingQuantity(inventoryDetail.getBaseUomQuantity());
        inventoryData.setQuantityTotal(inventoryDetail.getQuantityTotal());
        inventoryData.setAmount(inventoryDetail.getAmount());
        inventoryData.setItemAmount(inventoryDetail.getItemAmount());
        inventoryData.setItemCost(inventoryDetail.getItemCost());
//        inventoryData.setRemainingQuantity(inventoryDetail.getRemainingQuantity());
        inventoryData.setRemainingAmount(inventoryDetail.getRemainingAmount());
        if (inventoryDetail.getCreatedAt() != null) {
            inventoryData.setCreatedAt(inventoryDetail.getCreatedAt().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
        }
        inventoryData.setCreatedUserId(inventoryDetail.getCreatedUserId());
        if (inventoryDetail.getUpdatedAt() != null) {
            inventoryData.setUpdatedAt(inventoryDetail.getUpdatedAt().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
        }
        inventoryData.setDrugCode(inventoryDetail.getDrugCode());
        inventoryData.setTotalAmount(inventoryDetail.getTotalAmount());
        inventoryData.setTotalQuantity(inventoryDetail.getTotalQuantity());
        inventoryData.setTotalAmount(inventoryDetail.getTotalAmount());
        inventoryData.setCost(inventoryDetail.getCost());
        inventoryData.setMixingFlag(inventoryDetail.isMixingFlag());
        inventoryData.setItemId(inventoryDetail.getItemId());
        inventoryData.setInventoryUsageIndex(inventoryDetail.getInventoryUsageIndex());
        inventoryData.setPatientRegisterDetailId(inventoryDetail.getPatientRegisterDetailId());
        inventoryData.setBaseUom(inventoryDetail.getBaseUom());
        inventoryData.setSaleUom(inventoryDetail.getSaleUom());
        inventoryData.setPurchaseUom(inventoryDetail.getPurchaseUom());
        inventoryData.setBaseUomQuantity(inventoryDetail.getBaseUomQuantity());
        inventoryData.setSaleUomQuantity(inventoryDetail.getSaleUomQuantity());
        inventoryData.setPurchaseUomQuantity(inventoryDetail.getPurchaseUomQuantity());
        return inventoryData;

    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * @param clinicId
     * @return
     */
    public List<ItemChargeDetail.ItemChargeDetailResponse.InventoryData> fireNavInventoryApi(String clinicId, List<Item> items) {
        try {
            logger.info("fire nav inventory api by clinic[" + clinicId + "], items size[" + items.size() + "]");
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Tenant", TenantContext.getTenantId());

            List<InventoryUsage> inventoryUsages = items.stream()
                    .filter(item -> item.isInventoried())
                    .map(item -> InventoryMapper.mapToInventoryUsage(item))
                    .collect(Collectors.toList());
            logger.info("Get usage from [" + navApi + "] + inventoryUsages.size [" + inventoryUsages.size() + "], clinic[" + clinicId + "]");
            logger.debug("Pass inventoryUsage size [{}] to get usage", inventoryUsages.size());
            ParameterizedTypeReference<CmsServiceResponse<List<InventoryDetail>>> responseType = new ParameterizedTypeReference<>() {
            };
            ResponseEntity<CmsServiceResponse<List<InventoryDetail>>> responseEntity = restTemplate
                    .exchange(navApi, HttpMethod.POST, new HttpEntity<>(inventoryUsages, headers),
                            responseType, clinicId);
            CmsServiceResponse<List<InventoryDetail>> body = responseEntity.getBody();
            if (body.getPayload() != null) {
                List<InventoryDetail> InventoryDetails = body.getPayload();
                return InventoryDetails.stream()
                        .map(this::mapToInventoryData).collect(Collectors.toList());
            } else {
                logger.error("Cannot get inventory, status[" + body.getStatusCode() + "], message:[" + body.getMessage() + "]");
            }
        } catch (Exception e) {
            logger.error("Error getting inventory details : [" + e.getMessage() + "]");
        }
        return new ArrayList<>();
    }
}
