package com.ilt.cms.inventory.svc.model.purchase;

import com.ilt.cms.inventory.svc.model.common.UnitPrice;
import com.lippo.cms.util.IdUtils;
import org.springframework.data.annotation.Transient;

import java.math.BigDecimal;
import java.util.Objects;

import static com.lippo.commons.util.CommonUtils.isStringValid;


public class GoodOrderedItem {
    private String lineNo;
    private String receiverClinicId; //for BPO indicate receive item clinic
    private String itemRefId;
    private String supplierId;
    private String uom;
    private int quantity;
    private UnitPrice unitPrice;
    private String additionalDescription;
    private String fromClinicCode;
    private Boolean isBonusItem;

    private String purchaseRequestId;
    private String purchaseRequestNo;

    private String remark;

    private String cpRemarks;
    private String purchaseCode;
    private Double backOrderedQuantity;
    private Double pendingOrderedQuantity;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCpRemarks() {
        return cpRemarks;
    }

    public void setCpRemarks(String cpRemarks) {
        this.cpRemarks = cpRemarks;
    }

    public String getPurchaseCode() {return purchaseCode;}

    public void setPurchaseCode(String purchaseCode) {this.purchaseCode = purchaseCode;}

    public boolean checkValidate() {
        return isStringValid(itemRefId, uom) && quantity > 0 && unitPrice != null;
    }

    public GoodOrderedItem() {
    }

    public GoodOrderedItem(String lineNo, String itemRefId, String supplierId, String uom, int quantity, UnitPrice unitPrice, String additionalDescription) {
        this.lineNo = lineNo;
        this.itemRefId = itemRefId;
        this.supplierId = supplierId;
        this.uom = uom;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.additionalDescription = additionalDescription;
    }

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getItemRefId() {
        return itemRefId;
    }

    public void setItemRefId(String itemRefId) {
        this.itemRefId = itemRefId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public UnitPrice getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(UnitPrice unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getReceiverClinicId() {
        return receiverClinicId;
    }

    public void setReceiverClinicId(String receiverClinicId) {
        this.receiverClinicId = receiverClinicId;
    }

    public String getAdditionalDescription() {
        return additionalDescription;
    }

    public String getPurchaseRequestId() {
        return purchaseRequestId;
    }

    public void setPurchaseRequestId(String purchaseRequestId) {
        this.purchaseRequestId = purchaseRequestId;
    }

    public String getPurchaseRequestNo() {
        return purchaseRequestNo;
    }

    public void setPurchaseRequestNo(String purchaseRequestNo) {
        this.purchaseRequestNo = purchaseRequestNo;
    }

    public GoodOrderedItem setAdditionalDescription(String additionalDescription) {
        this.additionalDescription = additionalDescription;
        return this;
    }

    public String getFromClinicCode() {
        return fromClinicCode;
    }

    public void setFromClinicCode(String fromClinicCode) {
        this.fromClinicCode = fromClinicCode;
    }

    public Boolean getBonusItem() {
        return isBonusItem;
    }

    public void setBonusItem(Boolean bonusItem) {
        isBonusItem = bonusItem;
    }

    public Double getBackOrderedQuantity() {
        return backOrderedQuantity;
    }

    public void setBackOrderedQuantity(Double backOrderedQuantity) {
        this.backOrderedQuantity = backOrderedQuantity;
    }

    public Double getPendingOrderedQuantity() {
        return pendingOrderedQuantity;
    }

    public void setPendingOrderedQuantity(Double pendingOrderedQuantity) {
        this.pendingOrderedQuantity = pendingOrderedQuantity;
    }


    @Override
    public String toString() {
        return "GoodOrderedItem{" +
                "lineNo='" + lineNo + '\'' +
                ", receiverClinicId='" + receiverClinicId + '\'' +
                ", itemRefId='" + itemRefId + '\'' +
                ", supplierId='" + supplierId + '\'' +
                ", uom='" + uom + '\'' +
                ", quantity=" + quantity +
                ", unitPrice=" + unitPrice +
                ", fromClinicCode=" + fromClinicCode +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GoodOrderedItem that = (GoodOrderedItem) o;
        return quantity == that.quantity &&
                Objects.equals(lineNo, that.lineNo) &&
                Objects.equals(receiverClinicId, that.receiverClinicId) &&
                Objects.equals(itemRefId, that.itemRefId) &&
                Objects.equals(supplierId, that.supplierId) &&
                Objects.equals(uom, that.uom) &&
                Objects.equals(unitPrice, that.unitPrice) &&
                Objects.equals(fromClinicCode, that.fromClinicCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lineNo, receiverClinicId, itemRefId, supplierId, uom, quantity, unitPrice, fromClinicCode);
    }

    public void copy(GoodOrderedItem incoming) {
        if(this.getLineNo() == null){
            this.setLineNo(incoming.getLineNo());
        }
        if(this.getPurchaseRequestId() == null){
            this.setPurchaseRequestId(incoming.getPurchaseRequestId());
        }
        this.setItemRefId(incoming.getItemRefId());
        this.setUom(incoming.getUom());
        this.setRemark(incoming.getRemark());
        this.setCpRemarks(incoming.getCpRemarks());
        this.setQuantity(incoming.getQuantity());
        this.setUnitPrice(incoming.getUnitPrice());
        this.setBonusItem(incoming.getBonusItem());
    }

}
