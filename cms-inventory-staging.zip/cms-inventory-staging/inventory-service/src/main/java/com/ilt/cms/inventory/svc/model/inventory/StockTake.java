package com.ilt.cms.inventory.svc.model.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ilt.cms.core.entity.NavIntegrationResult;
import com.ilt.cms.core.entity.PersistedObject;
import com.ilt.cms.core.entity.audit.AuditableEntity;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockCountType;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeApproveStatus;
import com.ilt.cms.inventory.svc.model.inventory.enums.StockTakeStatus;
import com.lippo.cms.util.CMSConstant;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static com.lippo.commons.util.CommonUtils.isStringValid;

@AuditableEntity
public class StockTake extends PersistedObject {

    @Indexed(unique = true)
    private String stockTakeName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime startTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_DATE_FORMAT)
    @DateTimeFormat(pattern = CMSConstant.JSON_DATE_FORMAT)
    private LocalDate endDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    @DateTimeFormat(pattern = CMSConstant.JSON_TIME_FORMAT_WITH_SECONDS)
    private LocalTime endTime;

    private String transactionNo;

    private String clinicId;

    private StockCountType countType;

    private String startRange;

    private String endRange;

    private List<String> itemStockTakeRange;

    private String countName;

    private StockTakeStatus stockTakeStatus;

    private StockTakeApproveStatus approveStatus;

    private List<StockCountItem> stockCountItems;

    private NavIntegrationResult navIntegrationResult;

    private LocalDate approvedDate;

    private LocalDate rejectedDate;

    public boolean checkValidate() {
        return isStringValid(stockTakeName, clinicId, countName) && countType != null && stockTakeStatus != null
                && approveStatus != null;
    }

    public void addStockCountItem(StockCountItem stockCountItem) {
        stockCountItems.add(stockCountItem);
    }

    public StockTake() {
        stockCountItems = new ArrayList<>();
    }

    public StockTake(LocalDate startDate, LocalTime startTime, StockCountType countType, String startRange, String endRange,
                     String countName, String transactionNo, StockTakeStatus stockTakeStatus) {
        this.startDate = startDate;
        this.startTime = startTime;
        this.countType = countType;
        this.startRange = startRange;
        this.endRange = endRange;
        this.countName = countName;
        this.transactionNo = transactionNo;
        this.stockTakeStatus = stockTakeStatus;
        this.stockCountItems = new ArrayList<>();
    }

    public StockTake(String stockTakeName, LocalDate startDate, LocalTime startTime, String clinicId,
                     StockCountType countType, String startRange, String endRange, String countName, String transactionNo, StockTakeStatus stockTakeStatus,
                     StockTakeApproveStatus approveStatus) {
        this.stockTakeName = stockTakeName;
        this.startDate = startDate;
        this.startTime = startTime;
        this.clinicId = clinicId;
        this.countType = countType;
        this.startRange = startRange;
        this.endRange = endRange;
        this.countName = countName;
        this.transactionNo = transactionNo;
        this.stockTakeStatus = stockTakeStatus;
        this.approveStatus = approveStatus;
        this.stockCountItems = new ArrayList<>();
    }

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo;
    }

    public String getStockTakeName() {
        return stockTakeName;
    }

    public void setStockTakeName(String stockTakeName) {
        this.stockTakeName = stockTakeName;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public LocalTime getEndTime() { return endTime;}

    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }

    public String getClinicId() {
        return clinicId;
    }

    public void setClinicId(String clinicId) {
        this.clinicId = clinicId;
    }

    public StockCountType getCountType() {
        return countType;
    }

    public void setCountType(StockCountType countType) {
        this.countType = countType;
    }

    public String getStartRange() {
        return startRange;
    }

    public void setStartRange(String startRange) {
        this.startRange = startRange;
    }

    public String getEndRange() {
        return endRange;
    }

    public void setEndRange(String endRange) {
        this.endRange = endRange;
    }

    public String getCountName() {
        return countName;
    }

    public void setCountName(String countName) {
        this.countName = countName;
    }

    public StockTakeStatus getStockTakeStatus() {
        return stockTakeStatus;
    }

    public void setStockTakeStatus(StockTakeStatus stockTakeStatus) {
        this.stockTakeStatus = stockTakeStatus;
    }

    public List<StockCountItem> getStockCountItems() {
        return stockCountItems;
    }

    public void setStockCountItems(List<StockCountItem> stockCountItems) {
        this.stockCountItems = stockCountItems;
    }

    public StockTakeApproveStatus getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(StockTakeApproveStatus approveStatus) {
        this.approveStatus = approveStatus;
    }

    public NavIntegrationResult getNavIntegrationResult() {
        return navIntegrationResult;
    }

    public void setNavIntegrationResult(NavIntegrationResult navIntegrationResult) {
        this.navIntegrationResult = navIntegrationResult;
    }

    public List<String> getItemStockTakeRange() {
        return itemStockTakeRange;
    }

    public void setItemStockTakeRange(List<String> itemStockTakeRange) {
        this.itemStockTakeRange = itemStockTakeRange;
    }

    public LocalDate getApprovedDate() {
        return approvedDate;
    }
    public void setApprovedDate(LocalDate approvedDate) {
        this.approvedDate = approvedDate;
    }
    public LocalDate getRejectedDate() {
        return rejectedDate;
    }
    public void setRejectedDate(LocalDate rejectedDate) {
        this.rejectedDate = rejectedDate;
    }
    @Override
    public String toString() {
        return "StockTake{" +
                "stockTakeName='" + stockTakeName + '\'' +
                ", startDate=" + startDate +
                ", startTime=" + startTime +
                ", transactionNo='" + transactionNo + '\'' +
                ", clinicId='" + clinicId + '\'' +
                ", countType=" + countType +
                ", startRange='" + startRange + '\'' +
                ", endRange='" + endRange + '\'' +
                ", countName='" + countName + '\'' +
                ", stockTakeStatus=" + stockTakeStatus +
                ", approveStatus=" + approveStatus +
                ", stockCountItems=" + stockCountItems +
                ", itemStockTakeRange=" + itemStockTakeRange +
                ", endDate=" + endDate +
                ", endTime=" + endTime +
                ", id='" + id + '\'' +
                '}';
    }

    public boolean addNewStockCountItem(StockCountItem stockItem) {
        for(StockCountItem stockCountItem:stockCountItems){
            if(stockCountItem.equals(stockCountItem)){
                return true;
            }

        }
        return stockCountItems.add(stockItem);
    }


}
