package com.ilt.cms.inventory.svc.service.common;

import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.core.entity.item.ItemClinicDetail;
import com.ilt.cms.database.item.ItemClinicDetailDatabaseService;
import com.ilt.cms.database.item.ItemDatabaseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ItemClinicDetailService {

    private static final Logger logger = LoggerFactory.getLogger(ItemClinicDetailService.class);

    private ItemClinicDetailDatabaseService itemClinicDetailDatabaseService;

    private ItemDatabaseService itemDatabaseService;

    public ItemClinicDetailService(ItemClinicDetailDatabaseService itemClinicDetailDatabaseService, ItemDatabaseService itemDatabaseService) {
        this.itemClinicDetailDatabaseService = itemClinicDetailDatabaseService;
        this.itemDatabaseService = itemDatabaseService;
    }

    public List<ItemClinicDetail> listItemClinicDetailByClinicIdAndItemIds(String clinicId, List<String> itemIds){
        List<ItemClinicDetail> itemClinicDetails = itemClinicDetailDatabaseService.findByClinicIdAndItemIdIn(clinicId, itemIds);
        itemClinicDetails.forEach(
                itemClinicDetail -> {
                    itemClinicDetail.setClinicDetails(itemClinicDetail.getClinicDetails().stream()
                            .filter(itemExtraDetails -> itemExtraDetails.getClinicId().equals(clinicId))
                            .collect(Collectors.toList()));
                }
        );

        return itemClinicDetails;
    }

    public List<ItemClinicDetail> listItemClinicDetailByClinicId(String clinicId) {

        logger.info("listItemClinicDetailByClinicId[" + clinicId + "]");
        List<String> itemIds = itemDatabaseService.findItemByClinicId(clinicId).stream()
                .map(Item::getId)
                .collect(Collectors.toList());

        List<ItemClinicDetail> itemClinicDetails = itemClinicDetailDatabaseService.findByClinicIdAndItemIdIn(clinicId, itemIds);
        itemClinicDetails.forEach(
                itemClinicDetail -> {
                    itemClinicDetail.setClinicDetails(itemClinicDetail.getClinicDetails().stream()
                            .filter(itemExtraDetails -> itemExtraDetails.getClinicId().equals(clinicId))
                            .collect(Collectors.toList()));
                }
        );

        return itemClinicDetails;
    }
}
