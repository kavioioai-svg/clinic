package com.ilt.cms.inventory.svc.model.inventory.api;

import com.ilt.cms.inventory.svc.model.purchase.enums.RequestStatus;

import java.util.List;

public class SearchPurchaseContainer {

    private List<String> supplierIds;

    private List<String> itemIds;

    private List<RequestStatus> requestStatuses;

    public List<String> getSupplierIds() {
        return supplierIds;
    }

    public void setSupplierIds(List<String> supplierIds) {
        this.supplierIds = supplierIds;
    }

    public List<String> getItemIds() {
        return itemIds;
    }

    public void setItemIds(List<String> itemIds) {
        this.itemIds = itemIds;
    }

    public List<RequestStatus> getRequestStatuses() {
        return requestStatuses;
    }

    public void setRequestStatuses(List<RequestStatus> requestStatuses) {
        this.requestStatuses = requestStatuses;
    }
}
