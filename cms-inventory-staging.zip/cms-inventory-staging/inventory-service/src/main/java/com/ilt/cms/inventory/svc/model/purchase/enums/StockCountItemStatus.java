package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum StockCountItemStatus {
    APPROVED, REJECTED, REQUESTED
}
