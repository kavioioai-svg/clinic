package com.ilt.cms.inventory.svc.service.inventory;

import com.ilt.cms.core.entity.item.Item;
import com.ilt.cms.database.item.ItemDatabaseService;
import com.ilt.cms.inventory.svc.db.service.interfaces.DisposeOffStockDatabaseService;
import com.ilt.cms.inventory.svc.mapper.DisposeItemMapper;
import com.ilt.cms.inventory.svc.model.inventory.DisposeItem;
import com.ilt.cms.inventory.svc.model.inventory.LocationInventory;
import com.ilt.cms.inventory.svc.model.inventory.api.DisposeItemEntity;
import com.ilt.cms.inventory.svc.model.inventory.enums.DisposeStatus;
import com.ilt.cms.inventory.svc.observer.NavStockNotification;
import com.lippo.cms.exception.CMSException;
import com.lippo.cms.notify.SystemNotifier;
import com.lippo.commons.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DisposalService {

    private static final Logger logger = LoggerFactory.getLogger(DisposalService.class);

    private DisposeOffStockDatabaseService disposeOffStockDatabaseService;
    private ItemDatabaseService itemDatabaseService;
    private LocationService locationService;
    private SystemNotifier systemNotifier;

    public DisposalService(DisposeOffStockDatabaseService disposeOffStockDatabaseService,
                           ItemDatabaseService itemDatabaseService,
                           LocationService locationService,
                           SystemNotifier systemNotifier) {
        this.disposeOffStockDatabaseService = disposeOffStockDatabaseService;
        this.itemDatabaseService = itemDatabaseService;
        this.locationService = locationService;
        this.systemNotifier = systemNotifier;
    }

    public Page<DisposeItemEntity> listDisposalStock(String clinicId, List<DisposeStatus> disposeStatuses,
                                                     LocalDate startDate, LocalDate endDate, int page, int size) throws CMSException {

        logger.info("listDisposalStock, clinicId[" + clinicId +
                "], disposeStatuses[" + disposeStatuses + "], startDate[" + startDate +
                "], endDate[" + endDate + "] page[" + page + "], size[" + size + "]");

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "disposalRequestDate"));

        if (disposeStatuses.size() == 0) {
            disposeStatuses.add(DisposeStatus.REQUESTED);
            disposeStatuses.add(DisposeStatus.COMPLETED);
        }

        Page<DisposeItem> disposeItemPage = disposeOffStockDatabaseService.findDisposeItems(clinicId, disposeStatuses,
                LocalDateTime.of(startDate, LocalTime.MIN), LocalDateTime.of(endDate, LocalTime.MAX), pageable);
        List<DisposeItem> disposeItems = disposeItemPage.getContent();
        Map<String, Item> itemMap = itemDatabaseService.findItemsByIds(disposeItems.stream()
                        .map(DisposeItem::getItemId).collect(Collectors.toList()))
                .stream()
                .collect(Collectors.toMap(Item::getId, item -> item));

        List<DisposeItemEntity> disposeItemEntities = disposeItems.stream()
                .map(e -> DisposeItemMapper.mapToDisposeItemEntity(e, itemMap.get(e.getItemId())))
                .collect(Collectors.toList());

        return new PageImpl<>(disposeItemEntities, pageable, disposeItemPage.getTotalElements());
    }

    public Page<DisposeItemEntity> listExpiredStockAndDisposedStock(String clinicId, List<DisposeStatus> disposeStatuses,
                                                                    LocalDate startDate, LocalDate endDate, int page, int size) throws CMSException {

        logger.info("listDisposalStock, clinicId[" + clinicId +
                "], disposeStatuses[" + disposeStatuses + "], startDate[" + startDate +
                "], endDate[" + endDate + "] page[" + page + "], size[" + size + "]");

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "disposalRequestDate"));

        validateSearchParams(clinicId, disposeStatuses, startDate, endDate);

        List<DisposeItem> allDisposeItems = disposeOffStockDatabaseService.findAll();
        List<LocationInventory> expiredItems = locationService.findExpiredItems();
        Set<DisposeItem> disposeItems = new HashSet<>();

        for (LocationInventory expiredItem : expiredItems) {

            Optional<DisposeItem> disposeItemOptional = allDisposeItems.stream().filter(disposeItem -> (expiredItem.getItemRefId().equals(disposeItem.getItemId()) &&
                    expiredItem.getClinicId().equals(disposeItem.getClinicId()) &&
                    ((expiredItem.getBatchNumber() != null
                            && expiredItem.getBatchNumber().equals(disposeItem.getBatchNo())) ||
                            expiredItem.getBatchNumber() == null)
            )).findFirst();

            if (disposeItemOptional.isEmpty()) {
                DisposeItem newDisposeItem = new DisposeItem();
                newDisposeItem.setClinicId(expiredItem.getClinicId());
                newDisposeItem.setItemId(expiredItem.getItemRefId());
                newDisposeItem.setBatchNo(expiredItem.getBatchNumber());
                newDisposeItem.setDisposeStatus(DisposeStatus.REQUESTED);
                newDisposeItem.setExpiryDate(expiredItem.getExpiryDate());
                newDisposeItem.setManufacturerDate(expiredItem.getManufacturerDate());
                newDisposeItem.setDisposalRequestDate(LocalDate.now());
                //TODO - Set entry no

                disposeItems.add(newDisposeItem);
            } else {
                disposeItems.add(disposeItemOptional.get());
            }
        }

        disposeItems.addAll(allDisposeItems);

        disposeItems = disposeItems.stream()
                .filter(disposeItem -> filterDisposeItem(disposeItem, clinicId, disposeStatuses, startDate, endDate))
                .collect(Collectors.toSet());

        List<DisposeItemEntity> disposeItemEntities = getDisposeItemEntities(page, size, disposeItems);

        return new PageImpl<>(disposeItemEntities, pageable, disposeItems.size());
    }

    private List<DisposeItemEntity> getDisposeItemEntities(int page, int size, Set<DisposeItem> disposeItems) {
        Map<String, Item> itemMap = itemDatabaseService.findItemsByIds(disposeItems.stream()
                        .map(DisposeItem::getItemId).collect(Collectors.toList()))
                .stream()
                .collect(Collectors.toMap(Item::getId, item -> item));

        List<DisposeItemEntity> disposeItemEntities = disposeItems.stream()
                .map(e -> DisposeItemMapper.mapToDisposeItemEntity(e, itemMap.get(e.getItemId())))
                .sorted(Comparator.comparing(DisposeItemEntity::getDisposalRequestDate))
                .skip(page * size)
                .collect(Collectors.toList());
        return disposeItemEntities;
    }

    private void validateSearchParams(String clinicId, List<DisposeStatus> disposeStatuses, LocalDate startDate, LocalDate endDate) throws CMSException {
        if (startDate == null || startDate.equals("") || endDate == null || endDate.equals("")) {
            throw new CMSException(StatusCode.I5000, "Start date & end date are required");
        }

        if (clinicId == null || clinicId.equals("")) {
            throw new CMSException(StatusCode.I5000, "Clinic id is required");
        }

        if (disposeStatuses.size() == 0) {
            disposeStatuses.add(DisposeStatus.INITIAL);
            disposeStatuses.add(DisposeStatus.REQUESTED);
            disposeStatuses.add(DisposeStatus.COMPLETED);
        }
    }

    private boolean filterDisposeItem(DisposeItem disposeItem, String clinicId, List<DisposeStatus> disposeStatuses,
                                      LocalDate startDate, LocalDate endDate) {

        if (disposeItem.getClinicId().equals(clinicId)
                && disposeStatuses.contains(disposeItem.getDisposeStatus())
                && disposeItem.getExpiryDate().compareTo(startDate) >= 0
                && disposeItem.getExpiryDate().compareTo(endDate) <= 0) {
            return true;
        }
        return false;
    }

    public DisposeItem markDisposeItemAsComplete(String clinicId, DisposeItemEntity disposeItemEntity) throws CMSException {

        logger.info("markDisposeItemAsComplete, clinicId[" + clinicId + "], disposeItemID[" + disposeItemEntity.getDisposeItemRefId() + "]");

        if (disposeItemEntity.getRemark() == null || disposeItemEntity.getRemark().isEmpty() || disposeItemEntity.getDisposedDate() == null) {
            logger.error("Dispose item remark[" + disposeItemEntity.getRemark() + "] Dispose Date["
                    + disposeItemEntity.getDisposedDate() + "] are mandatory to mark dispose item as complete");
            throw new CMSException(StatusCode.E2000, "Remark and Dispose Date are required to mark dispose item as complete");
        }

        DisposeItem current = disposeOffStockDatabaseService
                .findDisposeItemByIdAndCliniId(disposeItemEntity.getDisposeItemRefId(), disposeItemEntity.getClinicId())
                .orElseThrow(() -> {
                    logger.error("Dispose item not found for clinic[" + clinicId + "] dispose item id[" + disposeItemEntity.getDisposeItemRefId() + "]");
                    return new CMSException(StatusCode.E2000, "Dispose Item not found");
                });
        current.setCpRemark(disposeItemEntity.getCpRemark());
        current.setDisposedDate(disposeItemEntity.getDisposedDate());
        current.setDisposeStatus(DisposeStatus.COMPLETED);

        logger.debug("Persisting the dispose item [" + current + "]");

        DisposeItem updatedDisposeItem = disposeOffStockDatabaseService.saveDisposeItem(current);
        systemNotifier.notify(new NavStockNotification(updatedDisposeItem.getId(), NavStockNotification.NavAction.UPDATE_DISPOSE_STOCK));

        return updatedDisposeItem;
    }

    public DisposeItem markDisposeItemAsComplete(DisposeItemEntity disposeItemEntity) throws CMSException {

        logger.info("markDisposeItemAsComplete, clinicId[" + disposeItemEntity.getClinicId() + "], disposeItemID[" + disposeItemEntity.getDisposeItemRefId() + "], clinicId[" + disposeItemEntity.getBatchNo() + "]");

        if (disposeItemEntity.getCpRemark() == null || disposeItemEntity.getCpRemark().isEmpty()) {
            logger.error("Dispose item cp remark[" + disposeItemEntity.getRemark() + "] is mandatory to mark dispose item as complete");
            throw new CMSException(StatusCode.E2000, "CP remark is required to mark dispose item as complete");
        }

        Optional<DisposeItem> currentOpt = disposeOffStockDatabaseService
                .findOneByIdAndClinicIdAndBatchNo(disposeItemEntity.getDisposeItemRefId(), disposeItemEntity.getClinicId(),
                        disposeItemEntity.getBatchNo());
        DisposeItem disposeItem = new DisposeItem();
        if (currentOpt.isPresent()) {
            logger.debug("Persisting the dispose item [" + currentOpt.get() + "]");

            if (currentOpt.isPresent()) {
                logger.debug("Dispose item found");

                disposeItem = currentOpt.get();

                if (DisposeStatus.COMPLETED.equals(currentOpt.get().getDisposeStatus())) {
                    logger.debug("Item is already disposed");
                    throw new CMSException(StatusCode.I5000, "Item is already disposed");
                }
            }

            disposeItem = currentOpt.get();
        } else {
            logger.debug("Creating new dispose item with item id[" + disposeItemEntity.getDisposeItemRefId() + "]" +
                    "batch no [" + disposeItemEntity.getBatchNo() + "]" +
                    "clinic id [" + disposeItemEntity.getClinicId() + "]");

            LocationInventory inventory = locationService
                    .findByClinicIdAndItemIdAndBatchNo(disposeItemEntity.getClinicId()
                            , disposeItemEntity.getDisposeItemRefId()
                            , disposeItemEntity.getBatchNo());

            if(inventory == null){
                logger.debug("Item is not present in inventory or disposed item list");

                throw new CMSException(StatusCode.I5000, "Item is not present in inventory or disposed item list");

            }else if (inventory.getExpiryDate().isBefore(LocalDate.now())) {
                disposeItem.setClinicId(inventory.getClinicId());
                disposeItem.setItemId(inventory.getItemRefId());
                disposeItem.setBatchNo(inventory.getBatchNumber());
                disposeItem.setExpiryDate(inventory.getExpiryDate());
                disposeItem.setManufacturerDate(inventory.getManufacturerDate());
                disposeItem.setDisposalRequestDate(LocalDate.now());
            } else {
                logger.debug("Item is not expired");
                throw new CMSException(StatusCode.I5000, "Item is not expired");
            }
        }

        disposeItem.setCpRemark(disposeItemEntity.getCpRemark());
        disposeItem.setDisposedDate(disposeItemEntity.getDisposedDate());
        disposeItem.setDisposeStatus(DisposeStatus.COMPLETED);

        DisposeItem updatedDisposeItem = disposeOffStockDatabaseService.saveDisposeItem(disposeItem);
        systemNotifier.notify(new NavStockNotification(updatedDisposeItem.getId(), NavStockNotification.NavAction.UPDATE_DISPOSE_STOCK));

        return updatedDisposeItem;
    }
}
