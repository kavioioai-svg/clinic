package com.ilt.cms.inventory.svc.model.purchase.enums;

public enum RequestType {
    STANDARD, LOOSE/*special request*/
}
