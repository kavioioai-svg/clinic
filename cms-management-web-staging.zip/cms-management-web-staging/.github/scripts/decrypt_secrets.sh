#!/usr/bin/env bash

for file in $(ls secrets | grep '.gpg')
do
    out_file=$(echo ${file} | sed 's/.gpg//')
    gpg --quiet --batch --yes --decrypt --passphrase="$GITHUB_SECRET_PASSPHRASE" \
    --output secrets/${out_file} secrets/${file}
done