# CmsSidebarSecond



This project was generated with [Angular CLI](https://github.com/angular/angular-cli)



## Development server

### Non NAV
Run `npm run start:mgmt`

### NAV
Run `npm run start:mgmtdua`

### Default
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.


## Build

### Non NAV (DEV)
Run `npm run build:mgmt`


### NAV (DEV)
Run `npm run build:mgmtdua`


### Non NAV (PROD)
Run `npm run build:spec`


### NAV (PROD)
Run `npm run build:prod`


### Default
Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.


### Build for specific domain name
`ng build --bh <domain>` in example, `ng build --bh https://cms.lippoinnolab.com`

All the artifact will be available in the `dist` folder. You can copy all the files in `dist` folder to your web server.




## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


test
