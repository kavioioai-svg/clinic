import { AbstractControl, ValidationErrors } from '@angular/forms';

export function wholeNumberValidator(control: AbstractControl): ValidationErrors | null {
  if (control.value == null || control.value === '') return null;
  const isNotWhole = control.value % 1 !== 0;
  return isNotWhole ? { 'fractionNumber': { value: control.value } } : null;
}
