import { FormGroup } from '@angular/forms';

export function validateLocum(control: FormGroup) {
  const mcrNumber = control.parent.get('mcr').value;
  const nricNumber = control.parent.get('nric').value;

  if (mcrNumber !== nricNumber) {
    return null;
  } else {
    return { validMcr: { value: mcrNumber, message: 'MCR Number cannot be the same as NRIC' } };
  }
}
