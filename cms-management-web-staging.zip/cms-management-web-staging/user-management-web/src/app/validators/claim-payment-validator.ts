import { ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';
import { DISPLAY_DATE_FORMAT } from '../constants/app.constants';

export function totalReceivedAmountValidator(totalPaymentAmount: number, errorName: string): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = +control.value;

    if (!!value && value > totalPaymentAmount) {
      return {
        [errorName]: true,
      };
    }

    return null;
  };
}

export function validateOrder(
  startDate: AbstractControl,
  endDate: AbstractControl,
  controlIsStart: boolean
): ValidatorFn {
  return (control: AbstractControl) => {
    if (invalidOrderOfDates(startDate.value, endDate.value)) {
      if (controlIsStart) {
        return {
          invalidStartDate: {
            value: control.value,
          },
        };
      } else {
        return {
          invalidEndDate: {
            value: control.value,
          },
        };
      }
    } else {
      return null;
    }
  };
}

function invalidOrderOfDates(startDate, endDate) {
  const isStartValid = moment(startDate, DISPLAY_DATE_FORMAT).isValid();
  const isEndValid = moment(endDate, DISPLAY_DATE_FORMAT).isValid();
  const sDate = isStartValid ? startDate : moment(startDate).format(DISPLAY_DATE_FORMAT);
  const eDate = isEndValid ? endDate : moment(endDate).format(DISPLAY_DATE_FORMAT);
  const isInvalid = moment(eDate, DISPLAY_DATE_FORMAT).isBefore(moment(sDate, DISPLAY_DATE_FORMAT));
  return isInvalid;
}
