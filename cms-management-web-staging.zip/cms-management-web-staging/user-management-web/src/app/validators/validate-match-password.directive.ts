import { Directive } from '@angular/core';
import { FormControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';

@Directive({
  selector: '[appValidateMatchPassword]',
  providers: [{
    provide: NG_VALIDATORS, useExisting: ValidateMatchPasswordDirective, multi: true
  }]
})
export class ValidateMatchPasswordDirective implements Validator {

  static validatePasswordMatch(control: FormControl): ValidationErrors {
    const parentForm = control.parent;

    const newPasswordValue = parentForm.get('newPassword').value;
    const confirmNewPasswordValue = parentForm.get('confirmNewPassword').value;

    if (newPasswordValue !== confirmNewPasswordValue) {
      return { passwordMatch: 'Password does not match' };
    }

    return null;
  }

  validate(c: FormControl) {
    return ValidateMatchPasswordDirective.validatePasswordMatch(c);
  }

}
