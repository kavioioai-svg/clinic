import { AbstractControl, ValidationErrors } from '@angular/forms';

export class StringValidators {
  static noSpace(control: AbstractControl): ValidationErrors | null {
    if ((control.value as string).includes(' ')) {
      return { noSpace: true };
    }

    return null;
  }

  static containsSimple(control: AbstractControl): ValidationErrors | null {
    if (!/[a-z]/.test(control.value as string)) {
      return { noSimple: true };
    }

    return null;
  }

  static containsCapital(control: AbstractControl): ValidationErrors | null {
    if (!/[A-Z]/.test(control.value as string)) {
      return { noCapital: true };
    }

    return null;
  }

  static containsNumber(control: AbstractControl): ValidationErrors | null {
    if (!/[0-9]/.test(control.value as string)) {
      return { noNumber: true };
    }

    return null;
  }

  static containsSpecialCharacters(control: AbstractControl): ValidationErrors | null {
    if (!/[~`!@#$%^&*()__+=]/.test(control.value as string)) {
      return { noSpecialCharacters: true };
    }

    return null;
  }
}
