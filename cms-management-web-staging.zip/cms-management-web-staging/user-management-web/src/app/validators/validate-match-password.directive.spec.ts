import { ValidateMatchPasswordDirective } from './validate-match-password.directive';

describe('ValidateMatchPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidateMatchPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
