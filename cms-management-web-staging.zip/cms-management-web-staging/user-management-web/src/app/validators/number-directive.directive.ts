import {Directive, HostListener, Input} from '@angular/core';

@Directive({
  selector: '[appNumberDirective]'
})
export class NumberDirectiveDirective {
  @Input() name?: string;

  constructor() { }
  @HostListener('keypress', ['$event'])
  onkeypress(e) {
    if(this.name == 'float') {
      const charCode = (e.which) ? e.which : e.keyCode;
      return !(charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57));
    } else {
      return (e.charCode == 8 || e.charCode == 0) ? null : e.charCode >= 48 && e.charCode <= 57
    }

  }
}
