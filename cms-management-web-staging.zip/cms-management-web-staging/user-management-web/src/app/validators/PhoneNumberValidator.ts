import { FormGroup } from '@angular/forms';
import { WHATSAPP_NUMBER_PATTERN } from './../constants/app.constants';

export function validatePhoneNumber(control: FormGroup) {
  // const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{1,}$/;
  const PHONE_NUMBER_PATTERN = /^(6|8|9)\d{7}$/;
  const number = control.value;

  if (!number || (number && (PHONE_NUMBER_PATTERN.test(number) || number.length === 0)) || number === undefined || number === '') {
    return null;
  } else {
    return { vaildContactNumber: { value: number, message: 'Number is invalid' } };
  }
}

export function validatecontactNumber(control: FormGroup) {
  // const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{1,}$/;
  // const PHONE_NUMBER_PATTERN =/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{2,6}$/im;
//   Valid formats:(123) 456-7890 | (123)456-7890 | 123-456-7890 | 123.456.7890 | 1234567890 | +31636363634 | 075-63546725
  
const PHONE_NUMBER_PATTERN = /^[\d]{8,10}$/; // New Regex for validate spaces
const number = control.value;

  if (!number || (number && (PHONE_NUMBER_PATTERN.test(number) || number.length === 0)) || number === undefined || number === '') {
    return null;
  } else {
    return { vaildContactNumber: { value: number, message: 'Contact Number is invalid' } };
  }
}

export function validatewhatsAppNumber(control: FormGroup){
  const number = control.value;

  if (!number) {
    return null;
  }
  
  if (WHATSAPP_NUMBER_PATTERN.test(number)) {
    return null;
  } else {
    return { vaildContactNumber: { value: number, message: 'WhatsApp Number is invalid' } };
  }
}