import { FormGroup } from '@angular/forms';

export function validateEmail(control: FormGroup) {
  // const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{1,}$/;

  const PHONE_NUMBER_PATTERN = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
  const number = control.value;

  if (!number || (number && (PHONE_NUMBER_PATTERN.test(number) || number.length === 0)) || number === undefined || number === '') {
    return null;
  } else {
    return { vaildContactNumber: { value: number, message: 'Email is invalid' } };
  }
}
