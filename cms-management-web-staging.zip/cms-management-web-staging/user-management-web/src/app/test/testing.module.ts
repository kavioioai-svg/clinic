import { NgModule } from "@angular/core";
import { AppConfigService } from "../services/app-config.service";
import { StoreService } from "../services/store.service";
import { AlertService } from "../services/alert.service";
import { ItemService } from "../services/item.service";
import { AuthGuardService } from "../services/auth-guard.service";
import { UtilsService } from "../services/utils.service";
import { RouterModule } from "@angular/router";
import { SharedModule } from "../shared.module";
import { RouterTestingModule } from "@angular/router/testing";
import {
  NgxPermissionsService,
  NgxPermissionsAllowStubDirective,
  NgxPermissionsModule
} from "ngx-permissions";
import { AuthService } from "../services/auth.service";
import { ApiCmsManagementService } from "../services/api-cms-management.service";
import { ApiPatientInfoService } from "../services/api-patient-info.service";
import { HttpClientModule } from "@angular/common/http";
import {
  HttpClientTestingModule,
  HttpTestingController
} from "@angular/common/http/testing";
import { JwtHelperService, JwtModule } from "@auth0/angular-jwt";
import { AppConfigServiceSpy } from "./AppConfigServiceSpy";
import { API_DOMAIN } from "../constants/app.constants";
import { getAccessToken } from "../app.module";
import { LoggerService } from "../services/logger.service";
import { ConsoleLoggerService } from "../services/console-logger.service";
import {
  BsModalService,
  BsModalRef
} from "../../../node_modules/ngx-bootstrap";
import { DatePipe } from "../../../node_modules/@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { ApiAAService } from "../services/api-aa";
import { PermissionsGuardService } from "../services/permissions-guard.service";
import { DoctorFormService } from "../views/components/doctor/doctor-form.service";

@NgModule({
  imports: [
    BrowserModule,
    SharedModule,
    RouterTestingModule,
    NgxPermissionsModule.forRoot(),
    HttpClientModule,
    HttpClientTestingModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getAccessToken,
        whitelistedDomains: API_DOMAIN
      }
    })
  ],
  providers: [
    AppConfigService,
    ApiCmsManagementService,
    ApiAAService,
    ApiPatientInfoService,
    AuthGuardService,
    StoreService,
    PermissionsGuardService,
    { provide: LoggerService, useClass: ConsoleLoggerService },
    AlertService,
    AuthService,
    JwtHelperService,
    ItemService,
    UtilsService,
    NgxPermissionsService,
    BsModalRef,
    DatePipe,
    AppConfigServiceSpy,
    DoctorFormService
  ],
  exports: [
    SharedModule,
    RouterTestingModule,
    HttpClientModule,
    HttpClientTestingModule
  ]
})
export class TestingModule {
  constructor(private spy: AppConfigServiceSpy) {}
}
