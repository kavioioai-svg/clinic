import { Pipe, PipeTransform } from '@angular/core';
import {ChargeItemQuery} from '../state/charge-item/charge-item.query';
import {Status, TemplateFucType} from '../model/enum/enums';
import {StockItemInvalidPipe} from './stock-item-invalid.pipe';
import * as moment from 'moment/moment';
import {DB_FULL_DATE_FORMAT, DISPLAY_DATE_FORMAT, DISPLAY_DATE_TIME_NO_SECONDS_FORMAT} from '../constants/app.constants';
import { Clinic } from 'app/objects/response/Clinic';
import {ClinicQuery} from '../state/clinic/clinic.query';

@Pipe({
  name: 'templateFunctions'
})
export class TemplateFunctionsPipe implements PipeTransform {
  private clinics: Clinic[];

  constructor(private chargeItemQuery:ChargeItemQuery,
              private clinicQuery: ClinicQuery,
              private stockItemInvalidPipe : StockItemInvalidPipe,) {

  }


  transform(value: any, type: TemplateFucType , param1?:any , param2?:any): any {
     switch (type) {
       case  TemplateFucType.IsDrugVaccine :
         return this.isDrugOrVaccine(value , param1);
       case  TemplateFucType.DisplayDate :
         return this.getDisplayDate(value);
       case  TemplateFucType.DisplayClinic :
         return this.getDisplayClinic(value);
       case  TemplateFucType.ConvertTimeZone :
         return this.convertTimeZone(value ,param1);
       case  TemplateFucType.calculateVariance :
         return this.calculateVariance(value);
       case  TemplateFucType.StatusLabelColor :
         return this.getStatusLabelColor(value);
     }
  }
  isDrugOrVaccine(itemCode , date) {
    let isDrugOrVaccine = false;
    const correspondingItem = this.chargeItemQuery.getChargeItemByCode(itemCode);
    if (correspondingItem) {
      isDrugOrVaccine = correspondingItem.itemType === 'DRUG' || correspondingItem.itemType === 'VACCINATION' ||
        (correspondingItem.itemType === 'CONSUMABLE' && correspondingItem.trackingCode);
    }
    if(isDrugOrVaccine){
      return this.stockItemInvalidPipe.transform(date);
    } else {
      return '-';
    }
  }

  getDisplayDate(date) {
    if(!date)
      return '';
    return moment(date).format(DISPLAY_DATE_FORMAT);
  }

  getDisplayClinic(value: any) {
    this.clinics = this.clinicQuery.getAll();
    if(this.clinics  && this.clinics .length  > 0)
      return this.clinics .find(res => res.id === value).clinicCode;
  }
  convertTimeZone(d?: any , timeZone?: string) {
     let date: any = moment(d, DB_FULL_DATE_FORMAT);
     if(!date || date === '')
        return ''

    return  new Date((typeof date._d === "string" ? new Date(date._d) : date._d).toLocaleString("en-US",
           {timeZone: timeZone}));
  }

   calculateVariance(item: any) {
     let variance = parseInt(!!item.adjustedQuantity ? item.adjustedQuantity : 0) -
                    parseInt(!!item.availableCount ? item.availableCount : 0);
     if (variance < 0) {
       return ` <span class="text-danger">(${Math.abs(variance)})</span>`;
     } else {
       return variance;
     }
  }

  getStatusLabelColor(value: any ) {
    if(value)
      switch (value) {
        case Status.ACTIVE:
        case Status.APPROVED:
        case Status.INITIAL:
        case Status.FULL_RECEIVED:
          return 'bg-bluish-green';
        case Status.INACTIVE:
        case Status.REQUESTED:
        case Status.DRAFT:
        case Status.PENDING:
          return 'bg-orangey-yellow';
        case Status.BLOCKED:
        case Status.REJECTED:
        case Status.DELETED:
          return 'bg-lipstick';
        case Status.FAILED:
        case Status.TRANSFER:
          return 'bg-black';
        case Status.PARTIAL_APPROVED:
        case Status.PARTIAL_RECEIVED:
        case Status.SUBMITTED:
        case Status.CONFIRM:
          return 'bg-bluish-light-green';
        case Status.RETURNED:
          return 'bg-bluish-blue';
      }
  }
}
