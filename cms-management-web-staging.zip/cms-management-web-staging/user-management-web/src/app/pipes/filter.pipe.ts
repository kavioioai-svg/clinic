import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any[], args: any[]): any {
    if(args.length > 0) {
      return items.filter(item => item.id.indexOf(args[0]) !== -1);

    }else {
      return items;
    }
  }

}
