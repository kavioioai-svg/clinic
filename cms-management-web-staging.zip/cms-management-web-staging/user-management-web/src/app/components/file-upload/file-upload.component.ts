import {ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Observable} from 'rxjs';
import * as _ from 'lodash';
import {UploadFile} from '../../objects/File';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})


export class FileUploadComponent implements OnInit {

  selectedFiles: FileList;
  progressInfos = [];
  message = '';
  @Input() medicalCoverageFormGroup: FormGroup;
  @Input() index: number;
  @Input() isEdit: boolean;

  imageError: string;
  isImageSaved: boolean;
  base64Str: string;
  fileType: string;
  fileName: string;
  size: number;
  imageId: string;
  logoData: any[]= [];
  @Output() uploadFile = new EventEmitter();

  constructor(   public fb: FormBuilder,
                 private cd: ChangeDetectorRef,) { }

  ngOnInit() {
    if (!this.medicalCoverageFormGroup) {
      this.medicalCoverageFormGroup = this.fb.group({

      });
    }
    if(this.isEdit) {
      this.logoData = this.medicalCoverageFormGroup.getRawValue().medicalCoverageExtraDetail.logoFileDbData;
      if(this.logoData.length > 0) {
        let editedLogo = this.logoData[this.index];
        this.size = editedLogo.size;
        this.fileType =editedLogo.type;
        this.fileName = editedLogo.fileName;
        this.base64Str = editedLogo.base64Str;
      }
    }
  }

  selectFiles(fileInput: any) {
    this.imageError = null;
    if (fileInput.target.files && fileInput.target.files[0]) {
      // Size Filter Bytes
      const max_size = 20971520;
      const allowed_types = ['image/png', 'image/jpeg'];
      const max_height = 15200;
      const max_width = 25600;

      if (fileInput.target.files[0].size > max_size) {
        this.imageError =
          'Maximum size allowed is ' + max_size / 1000 + 'Mb';

        return false;
      }

      if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
        this.imageError = 'Only Images are allowed ( JPG | PNG )';
        return false;
      }
      const reader = new FileReader();
      let file = new UploadFile();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          const img_height = rs.currentTarget['height'];
          const img_width = rs.currentTarget['width'];

          console.log(img_height, img_width);
          this.size = fileInput.target.files[0].size;
          this.fileType = fileInput.target.files[0].type;
          this.fileName = fileInput.target.files[0].name;
          this.base64Str = e.target.result;
          this.isImageSaved = true;

          file.id = (Math.random() + 1).toString(36).substring(7)
          file.fileName = this.fileName;
          file.type = this.fileType;
          file.size = this.size;
          file.base64Str  = e.target.result;
          file.newIndex  = this.index;
          this.imageId = file.id;
          this.uploadFile.emit(file);
        };
      };

      reader.readAsDataURL(fileInput.target.files[0]);


    }
  }

  uploadFiles() {
    this.message = '';

    for (let i = 0; i < this.selectedFiles.length; i++) {
      this.upload(i, this.selectedFiles[i]);
    }
  }

  upload(idx, file) {
    this.progressInfos[idx] = { value: 0, fileName: file.name };
    console.log(this.progressInfos)
  }


  removeFile() {


      this.base64Str = null;
      this.fileName = null;
      this.isImageSaved = false;
      this.uploadFile.emit({deletedId: this.imageId , index: this.index});

  }
}
