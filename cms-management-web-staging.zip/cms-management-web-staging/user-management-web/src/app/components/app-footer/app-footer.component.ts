import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html'
})
export class AppFooterComponent implements OnInit {
  version: number;

  constructor() {}

  ngOnInit() {
    const temp = require('../../../../package.json').version;
    this.version = parseFloat(temp);
    this.version = temp;
  }
}
