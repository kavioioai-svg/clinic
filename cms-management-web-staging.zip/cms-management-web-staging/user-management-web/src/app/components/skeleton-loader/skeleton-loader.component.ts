import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-skeleton-loader',
  templateUrl: './skeleton-loader.component.html',
  styleUrls: ['./skeleton-loader.component.scss']
})
export class SkeletonLoaderComponent implements OnInit {
  @Input()  rowCount: number;
  @Input()  columnCount: number;
  counter = Array;
  constructor() { }

  ngOnInit() {
  }

  numberReturn(length){
    return new Array(length);
  }

}
