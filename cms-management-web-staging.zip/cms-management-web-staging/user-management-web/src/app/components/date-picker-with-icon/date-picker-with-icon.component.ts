import {Component, Input, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import DatePickerConfig from '../../objects/DatePickerConfig';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-date-picker-with-icon',
  templateUrl: './date-picker-with-icon.component.html',
  styleUrls: ['./date-picker-with-icon.component.scss']
})
export class DatePickerWithIconComponent implements OnInit {
  @Input() dateControl: FormControl;
  @Input() config: DatePickerConfig;
  @Input() disabled: boolean;
  @Input() hideIcon = false;
  @Input() customStyles: boolean = false;
  @Input() readOnly: boolean;

  bsConfig: Partial<BsDatepickerConfig>;
  constructor() { }

  ngOnInit() {
    if (this.disabled) {
      this.dateControl.disable();
    }

    this.bsConfig = {
      dateInputFormat: 'DD-MM-YYYY',
      containerClass: 'theme-blue',
    };

    if (this.config.minDate) {
      this.bsConfig.minDate = this.config.minDate;
    }

    if (this.config.maxDate) {
      this.bsConfig.maxDate = this.config.maxDate;
    }

    if (this.config.dateInputFormat) {
      this.bsConfig.dateInputFormat = this.config.dateInputFormat;
    }
  }

  bsDatePickerConfig(): Partial<BsDatepickerConfig> {

    if (this.config.minDate) this.bsConfig.minDate = this.config.minDate;
    if (this.config.maxDate) this.bsConfig.maxDate = this.config.maxDate;
    if (this.config.dateInputFormat) this.bsConfig.dateInputFormat = this.config.dateInputFormat;
    this.bsConfig.isAnimated = true;
    return this.bsConfig;
  }

}
