import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatePickerWithIconComponent } from './date-picker-with-icon.component';

describe('DatePickerWithIconComponent', () => {
  let component: DatePickerWithIconComponent;
  let fixture: ComponentFixture<DatePickerWithIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatePickerWithIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatePickerWithIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
