import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { get } from 'lodash';

import { BsModalRef } from 'ngx-bootstrap/modal';

import { ApiAAService } from '../../services/api-aa';
import { AlertService } from '../../services/alert.service';

const getStr = (obj, ltr) => get(obj, ltr) || ''

@Component({
  selector: 'app-app-reset-password',
  templateUrl: './app-reset-password.component.html',
  styleUrls: ['./app-reset-password.component.scss']
})
export class AppResetPasswordComponent implements OnInit {

  @Input() doctorUsername: string;
  @Input() userUsername: string;
  resetPasswordFormGroup: FormGroup;

  title: string;

  constructor(
    private alert: AlertService,
    private apiAAService: ApiAAService,
    private bsModalRef: BsModalRef,
    private fb: FormBuilder
  ) {
  }

  ngOnInit() {
    this.title = 'Create New Password - '.concat((this.doctorUsername) ? this.doctorUsername : this.userUsername);

    this.resetPasswordFormGroup = this.fb.group({
      newPassword: ['', Validators.required],
      confirmNewPassword: ['', Validators.required]
    });
  }

  initFormGroup() {
    this.resetPasswordFormGroup.patchValue({
      newPassword: '',
      confirmNewPassword: ''
    });
  }

  validatePasswordMatch(formControl: FormControl) {
    const parentForm = formControl.parent;

    if (!parentForm) {
      return null;
    }

    const newPassword = parentForm.get('newPassword').value;
    const confirmNewPassword = parentForm.get('confirmNewPassword').value;
    parentForm.get('confirmNewPassword').getError('passwordMatch');

    if (newPassword !== confirmNewPassword) {
      parentForm.controls['confirmNewPassword'].setErrors({ MatchPassword: true });
      if (parentForm.get('confirmNewPassword') === formControl) {
        return { newPasswordRepeat: { MatchPassword: true } };
      }
    } else {
      parentForm.controls['confirmNewPassword'].setErrors(null);
    }
    return null;
  }

  getFormControl() {
    return this.resetPasswordFormGroup.controls;
  }

  closeDialog() {
    this.initFormGroup();
    this.bsModalRef.hide();
  }

  submitPasswordReset() {
    const newPassword = this.resetPasswordFormGroup.value.newPassword;
    this.apiAAService.resetPassword((this.doctorUsername) ? this.doctorUsername : this.userUsername, newPassword).subscribe(result => {
      this.alert.success('Password reset successfully');
      this.bsModalRef.hide();
    }, error => {

      this.alert.error(getStr(error, 'error.message') || JSON.stringify(error));
    });
  }



}
