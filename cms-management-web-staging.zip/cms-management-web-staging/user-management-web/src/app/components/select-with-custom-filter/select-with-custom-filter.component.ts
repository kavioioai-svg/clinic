import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {FormControl} from '@angular/forms';
import {GroupValueFn} from "@ng-select/ng-select/lib/ng-select.component";

@Component({
  selector: 'app-select-with-custom-filter',
  templateUrl: './select-with-custom-filter.component.html',
  styleUrls: ['./select-with-custom-filter.component.scss']
})
export class SelectWithCustomFilterComponent implements OnInit {
  @Input() listItems: any[];
  @Input() className: string;
  @Input() bindValue: string
  @Input() bindLabel: string;
  @Input() placeholder: string;
  @Input() rowHeader: string[];
  @Input() operation?: string;
  @Input() multiple?: boolean;
  @Input() control: FormControl | undefined | any;
  @Input() readonly?: boolean;
  @Output() onItemChange? = new EventEmitter<any>();
  @Input() groupBy: string | Function | undefined;
  @Input() groupValue: GroupValueFn | undefined;


  constructor() { }

  ngOnInit() {
    if(this.readonly == undefined){
      this.readonly = false;
    }
  }



  customFilterSearchFn(term: string, item: any) {
    term = term.toLowerCase();
    return !!this.rowHeader.some(prop => item[prop] && (item[prop] + "").toLowerCase().indexOf(term) != -1)
  }

  onChangeItem($event: any) {
    this.onItemChange.emit($event);
  }

  getHeaderText(header: string) {
    if(header)
     return  header.replace(/([A-Z])/g, ' $1').trim()
  }
}
