import { UtilsService } from './../../services/utils.service';
import { AuthService } from './../../services/auth.service';
import { Router, NavigationEnd } from '@angular/router';
import { Component } from '@angular/core';
import * as moment from 'moment';

import { StoreService } from '../../services/store.service';
import { DB_FULL_DATE_FORMAT } from '../../constants/app.constants';
import { HEADER_TITLES } from './../../constants/app.constants';
import { NgxPermissionsService } from 'ngx-permissions';
import { AuthUserQuery } from '../../state/auth-user/auth-user.query';
import {SupplierService} from "../../services/master-data-service/supplier.service";
import { ItemService } from '../../services/item.service';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
})
export class AppHeaderComponent {
  showRegistryMenu = false;
  headerTitle = '';
  notifications = [];
  doctor;
  clinic;
  username;
  subtitle;
  supplier: any;
  item:any;

  constructor(
    private router: Router,
    public store: StoreService,
    public authUserQuery: AuthUserQuery,
    private auth: AuthService,
    private utilsService: UtilsService,
    private permissionsService: NgxPermissionsService,
    private supplierService:SupplierService,
    private itemService: ItemService
  ) {
    router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        
        HEADER_TITLES.map((title) => {
          if (title.url.includes(event.url)) {
            this.headerTitle = title.value;
            if(this.headerTitle !== 'Supplier'){
              this.supplier = null;
            }
          }
        });

        // your code will goes here
        if (event.url.toLowerCase().includes('consultation/add')) {
          this.showRegistryMenu = true;
        } else {
          this.showRegistryMenu = false;
        }
      }
    });
    this.supplierService.getSelectedSupplier$.subscribe(res => {
      if (!this.router.url.includes('item')) {
        this.supplier = res;
      }
    });

    this.itemService.getSelectedItem$.subscribe(res => {
      if (this.router.url.includes('item') && res) {
        this.item = res.item;
      } else if (!this.router.url.includes('/item/master/')) this.item = "";
    });
  }

  onBtnNotification() {
  }

  onBtnProfile() {
    const user = this.authUserQuery.getValue();
    this.username = user.firstName + ' ' + user.lastName;
    this.subtitle = '-';
  }

  onBtnLogout() {
    this.auth.logout();
  }

  onBtnChangePassword() {
    this.router.navigate(['/pages/profile']);
  }

  markAllAsRead() {}

  formatToTitleCase(string) {
    return this.utilsService.convertToTitleCaseUsingSpace(string);
  }

}
