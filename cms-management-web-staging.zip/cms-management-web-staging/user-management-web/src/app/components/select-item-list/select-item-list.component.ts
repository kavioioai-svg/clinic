import { Component, EventEmitter, OnInit, Input, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

import { map, tap } from 'rxjs/operators';

import { ChargeItemQuery } from '../../state/charge-item/charge-item.query';
import { UtilsService } from '../../services/utils.service';

@Component({
  selector: 'app-select-item-list',
  templateUrl: './select-item-list.component.html',
  styleUrls: ['./select-item-list.component.scss']
})
export class SelectItemListComponent implements OnInit {

  @Output() updatedValue = new EventEmitter<any>();

  @Input('currentItemFormArray') currentItemFormArray;
  @Input('filterForm') filterForm;
  @Input('itemKey') itemKey;
  @Input('itemType') itemType$;
  @Input('selectedList') selectedList$;
  @Input('unselectedList') unselectedList$;

  toBeSelected = new FormControl(new Array<any>());
  toBeUnselected = new FormControl(new Array<any>());

  constructor() { }

  ngOnInit() { }

  addItem() {
    const currentSelectedFormValue = [...this.currentItemFormArray.value];
    this.toBeSelected.value.forEach(item => {
      let currentItem = {};
      currentItem[this.itemKey] = item;
      currentItem['price'] = { price: 0.00, taxIncluded: false };
      currentSelectedFormValue.push(currentItem);
    });
    this.updatedValue.emit(currentSelectedFormValue);
  }

  removeItem() {
    const currentSelectedFormValue = [...this.currentItemFormArray.value].filter(item => !this.toBeUnselected.value.includes(item[this.itemKey]));
    this.updatedValue.emit(currentSelectedFormValue);
  }

  ngForTrackBy(index, item) {
    return item[this.itemKey];
  };

}
