import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import moment = require('moment');
import { Observable, Subject, concat, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { DISPLAY_DATE_FORMAT, DB_FULL_DATE_FORMAT } from '../../../constants/app.constants';
import { Page } from '../../../model/page';
import { MedicalCoverage } from '../../../objects/MedicalCoverage';
import { IClaimPaymentDetail } from '../../../objects/response/claim.model';
import { Clinic } from '../../../objects/response/Clinic';
import { AlertService } from '../../../services/alert.service';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { StoreService } from '../../../services/store.service';
import { MedicalCoverageQuery } from '../../../state/medical-coverage/medical-coverage.query';
import { validateOrder } from '../../../validators/claim-payment-validator';

@Component({
  selector: 'app-claim-manual',
  templateUrl: './claim-manual.component.html',
  styleUrls: ['./claim-manual.component.scss']
})
export class ClaimManualComponent implements OnInit {

  caseStatuses = [
    'OPEN',
    'CLOSED'
  ];

  clinics: Array<Clinic>;
  searchFormGroup: FormGroup;
  page = new Page();
  rows: any[] = [];
  medicalCoverageTypes = ['CORPORATE', 'INSURANCE', 'MEDISAVE']; 
  medicalCoverages$: Observable<MedicalCoverage[]>;
  medicalCoverageInput$ = new Subject<string>();
  maxDate = null;
  medicalCoverageList: Array<MedicalCoverage> = [];

  private componentDestroyed: Subject<void> = new Subject();

  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private store: StoreService,
    private apiPatientVisitService: ApiPatientVisitService,
    // private akitaClaimInvoiceStore: AkitaClaimInvoiceStore
    private medicalCoverageQuery: MedicalCoverageQuery
  ) { }

  ngOnInit() {

    this.newSearchFormGroup();
    this.populateData();

    // this.store
    //   .getIsStoreReady()
    //   .pipe(takeUntil(this.componentDestroyed))
    //   .subscribe(val => {
    //     if (val.isLoaded && !val.isReseting) {
    //       this.populateData();
    //       this.onSearchClaimClicked({ offset: 0 });
    //     }
    //   });

    this.loadMedicalCoverages();
    this.onSearchClaimClicked({ offset: 0 });
    this.maxDate = new Date();
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
    // this.akitaClaimInvoiceStore.reset()
  }

  private populateData() {
    this.clinics = this.store.getClinicList();
    const clinicId = this.searchFormGroup.get('clinicId').value;
    this.searchFormGroup.get('clinicId').patchValue(clinicId && [clinicId]);
    const startDateControl = this.searchFormGroup.get('startDate');
    const endDateControl = this.searchFormGroup.get('endDate');

    this.searchFormGroup.get('startDate').setValidators(
      validateOrder(startDateControl, endDateControl, true)
    )

    this.searchFormGroup.get('endDate').setValidators(
      validateOrder(startDateControl, endDateControl, false)
    )
    this.medicalCoverages$ = this.medicalCoverageQuery.selectAll();
    this.medicalCoverageQuery.selectAll().subscribe(res=> {this.medicalCoverageList = res});
  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      medicalCoverageType: [],
      medicalCoverageId: [],
      startDate: [
        moment()
          .subtract(2, 'month')
          .format(DISPLAY_DATE_FORMAT),
        Validators.required,
      ],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicId: ['', Validators.required],
      // claimStatus: this.searchStatusList[0],
    });
  }

  getMaxStartDate() {
    return moment(this.searchFormGroup.get('endDate').value).toDate();
  }

  onSearchClaimClicked(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    const startDateStr = moment(
      this.searchFormGroup.get('startDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');
    const endDateStr = moment(
      this.searchFormGroup.get('endDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');

    const medicalCoverageId = this.searchFormGroup.get('medicalCoverageId').value || '';
    const medicalCoverageType = this.searchFormGroup.get('medicalCoverageType').value || '';

    let clinicIds = [];
    if (
      !this.searchFormGroup.get('clinicId').value ||
      this.searchFormGroup.get('clinicId').value.length == 0
    ) {
      clinicIds.push(this.searchFormGroup.get('clinicId').value);
    }
    else {
      clinicIds = [this.searchFormGroup.get('clinicId').value];
    }
    this.rows = [];
    this.apiPatientVisitService
      .listClaimPaymentDetails(
        clinicIds,
        medicalCoverageId,
        medicalCoverageType,
        startDateStr,
        endDateStr,
        pageInfo.offset,
        10
      ).subscribe(
        pagedData => {
          const { payload } = pagedData;
          this.rows = payload.map((data: IClaimPaymentDetail) => {
            return {
              paymentDate: moment(data.paymentDate, DB_FULL_DATE_FORMAT).format(
                DISPLAY_DATE_FORMAT
              ),
              medicalCoverageName: data.medicalCoverageName,
              totalReceivedAmount: data.totalAmountReceived,
              bankName: data.bankName || '',
              referenceNumber: data.referenceNumber || '',
              adminFee:data.adminFee || ''
            }
          });
          this.page.pageNumber = pagedData['pageNumber'];
          this.page.totalPages = pagedData['totalPages'];
          this.page.totalElements = pagedData['totalElements'];
        },
        err => {
          this.alertService.error(JSON.stringify(err));
        }
      );
  }

  loadMedicalCoverages() {
    this.medicalCoverages$ = concat(
      of(this.getCoveragesByCoverageType()), // all medical coverages
      this.searchFormGroup.get('medicalCoverageType')
        .valueChanges.pipe(
          map(type => this.getCoveragesByCoverageType(type)),
          tap(_ => {
            this.searchFormGroup.get('medicalCoverageId').patchValue(null);
          })
        )
    );
  }

  getCoveragesByCoverageType(coverageType?: string) {
    return !!coverageType
      ? this.medicalCoverageList.filter(
          coverage => coverage.type === coverageType
        )
      : this.medicalCoverageList.filter(
          coverage =>
          coverage.type && coverage.type.toUpperCase() === 'CORPORATE' ||
          coverage.type && coverage.type.toUpperCase() === 'INSURANCE'
        );
  }

  getRowClass(row) {
    return {
      'is-align-top': true,
    };
  }
}
