import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimSFLComponent } from './claim-sfl.component';

describe('ClaimSFLComponent', () => {
  let component: ClaimSFLComponent;
  let fixture: ComponentFixture<ClaimSFLComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClaimSFLComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimSFLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
