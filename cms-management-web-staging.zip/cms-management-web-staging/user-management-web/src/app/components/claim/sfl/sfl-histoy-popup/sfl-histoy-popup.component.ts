import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap';
import { of, Subject } from 'rxjs';
import { distinctUntilChanged, debounceTime, tap, switchMap, catchError } from 'rxjs/operators';
import { HttpResponseBody } from '../../../../objects/response/HttpResponseBody';
import { AlertService } from '../../../../services/alert.service';
import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';

@Component({
  selector: 'app-sfl-histoy-popup',
  templateUrl: './sfl-histoy-popup.component.html',
  styleUrls: ['./sfl-histoy-popup.component.scss']
})
export class SflHistoyPopupComponent implements OnInit {
  formGroup: FormGroup;
  sflHistoryData: any[] = [];
  selectedHistory:any[] = [];
  testOrders:any[] = [];
  screeningTypes:any[] = [];
  codes:any[] = [];
  title:string = ""
  subCodesTypeahead = new Subject<string>();
  diagnosisLoading = false;
  constructor(    
    public bsModalRef: BsModalRef,
    private apiCmsManagementService: ApiCmsManagementService,
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    this.selectedHistory = this.formGroup.get('sflHistory').value;
    this.onFilterInputChanged();
  }

  onClose() {
    this.bsModalRef.hide();
  }

  onCheck(event, item) {

    if(event.target.checked) {
      this.selectedHistory.push(item);
    } else {
      var index = this.selectedHistory.indexOf(item);
      this.selectedHistory.splice(index, 1);
    }
  }

  selectHistoryFollowup() {
    this.formGroup.get('sflHistory').patchValue(this.selectedHistory);
    this.onClose();
  }

  getTestOrderDescription(testOrder) {
    return this.testOrders.find(order => order.value === testOrder).label;
  }

  getScreenTypeDescription(screenTypeCode) {
    return this.screeningTypes.find(type => type.externalCode === screenTypeCode).externalName;
  }

  checkAlreadyExists(item) {
    return this.selectedHistory.find(history => history === item);
  }

  onFilterInputChanged() {
    this.subCodesTypeahead
      .pipe(
        debounceTime(400)
      )
      .subscribe(result => {
        this.diagnosisLoading = true;
        if (result === '' || result === null || result === undefined) {
          this.diagnosisLoading = false;
        } else {
          this.apiCmsManagementService.searchDiagnosis(encodeURI(result), [], true).subscribe(result => {
            if(result.statusCode === 'S0000') {
              this.codes = result.payload;
              this.diagnosisLoading = false;
            }
          }, error => {
            this.diagnosisLoading = false;
            this.alertService.error(error.error.message);
        });
        }
        
    })
  }

}
