import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SflHistoyPopupComponent } from './sfl-histoy-popup.component';

describe('SflHistoyPopupComponent', () => {
  let component: SflHistoyPopupComponent;
  let fixture: ComponentFixture<SflHistoyPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SflHistoyPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SflHistoyPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
