import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import DatePickerConfig from '../../../objects/DatePickerConfig';
import { Clinic } from '../../../objects/response/Clinic';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Subject, of } from 'rxjs';
import { AlertService } from '../../../services/alert.service';
import { StoreService } from '../../../services/store.service';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { ApiCmsManagementService } from '../../../services/api-cms-management.service';
import {
  takeUntil,
  distinctUntilChanged,
  debounceTime,
  tap,
  switchMap,
  catchError,
} from 'rxjs/operators';
import * as moment from 'moment';
import {
  DISPLAY_DATE_FORMAT,
  DB_FULL_DATE_FORMAT,
  SFL_TEST_ORDER,
} from '../../../constants/app.constants';
import { HttpResponseBody } from '../../../objects/response/HttpResponseBody';
import { BsModalService } from 'ngx-bootstrap';
import { SflHistoyPopupComponent } from './sfl-histoy-popup/sfl-histoy-popup.component';
import { UtilsService } from '../../../services/utils.service';
import { Diagnosis } from '../../../objects/response/Diagnosis';
import { StoreStatusQuery } from '../../../state/store-status/store-status.query';
import { ClinicQuery } from '../../../state/clinic/clinic.query';
import { DoctorQuery } from '../../../state/doctor/doctor.query';

@Component({
  selector: 'app-claim-sfl',
  templateUrl: './claim-sfl.component.html',
  styleUrls: ['./claim-sfl.component.scss']
})
export class ClaimSFLComponent implements OnInit, OnDestroy {
  @ViewChild('myTable', { static: true })
  table: any;
  columns: any[] = [];
  rows: any[] = [];
  historyData: any[] = [];
  datePickerConfigArray: Array<DatePickerConfig>;

  // statusList = [ 'SUBMITTED', 'PENDING', 'REJECTED', 'APPEALED', 'APPROVED' ];
  statusList = ['SUBMITTED', 'FAILED', 'APPROVED'];
  searchStatusList = [
    'ALL',
    'SUBMITTED',
    'PENDING',
    'REJECTED_PERMANENT',
    'REJECTED',
    'APPEALED',
    'APPROVED',
    'PAID',
    'FAILED',
  ];
  doctorList: any[] = [];
  clinics: Array<Clinic>;
  showEdit = false;

  submitting = {};
  editable: boolean = false;
  formGroup: FormGroup;
  searchFormGroup: FormGroup;
  screeningsFormGroup!: FormGroup;
  screeningList: FormArray;

  codes: Array<Diagnosis> = [];
  codesTypeahead = new Subject<string>();
  exsistingCodes: Array<Diagnosis> = [];
  diagnosisLoading = false;

  private componentDestroyed: Subject<void> = new Subject();
  claimItemRows = [];
  relationshipDetails = [];
  datePickerConfig: DatePickerConfig;
  selectedPayersName: any = null;
  patientName: string = null;
  screeningTypes: any[] = [];
  allScreeningTypes: any[] = [];
  screeningSubTypes: any[] = [];
  testOrders = SFL_TEST_ORDER;
  followUpOutcomes : any[] = [];
  followUpTypes: any[] = [];
  followUpType: any
  gst: any = 0;
  selectedRow: any;
  selectedRowIndex: any;
  selectedPatientId:string;
  selectedClinicId:string;  
  claimTotal: Number =0;
  
  private currentRow;

  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private store: StoreService,
    private apiPatientVisitService: ApiPatientVisitService,
    private apiCmsManagementService: ApiCmsManagementService,
    private modalService: BsModalService,
    private storeStatusQuery: StoreStatusQuery,
    private clinicQuery: ClinicQuery,
    private doctorQuery: DoctorQuery,
  ) {
    this.screeningsFormGroup = new FormGroup({  
      screeningList: new FormArray([])  
    });  
  }

  ngOnInit() {
    this.gst = UtilsService.getGSTOnly();;
    this.screeningList = this.screeningsFormGroup.get('screeningList') as FormArray;  
    this.newFormGroup();
    this.newSearchFormGroup();
    this.populateData();

    this.onFilterInputChanged();
    this.initDatePickerConfigsForComponent();

    this.storeStatusQuery
    .select()
    .pipe(takeUntil(this.componentDestroyed))
    .subscribe((val) => {
      if (val.isLoaded && !val.isReseting) {
        this.populateData();
      }
    });
  }

  initDatePickerConfigsForComponent() {
    this.datePickerConfigArray = new Array<DatePickerConfig>();

    const datepickerFrom: DatePickerConfig = this.initDatePickerConfigObject(
      'From',
      new Date(),
      null,
      'bottom',
      'left'
    );
    const datepickerTo: DatePickerConfig = this.initDatePickerConfigObject(
      'To',
      new Date(),
      null,
      'bottom',
      'left'
    );
    this.datePickerConfigArray['from'] = datepickerFrom;
    this.datePickerConfigArray['to'] = datepickerTo;

    // payer dob datepicker
    let maxDate = new Date();
    this.datePickerConfig = new DatePickerConfig(
      '',
      maxDate,
      null,
      'bottom',
      'none'
    );
  }

  followUpTypeChange() {
    const followUpType = this.formGroup.get('followUpType').value;
    this.followUpType = this.followUpTypes.filter(item=> item.cmsCode===followUpType);
    const screeningList = this.screeningsFormGroup.get('screeningList')['controls']
    screeningList.forEach(element => {
      const defaultValue = this.followUpType[0].defaultAmount;
      element.get('remunerationAmount').patchValue(defaultValue);
      element.get('gstAmount').patchValue((defaultValue * this.gst).toFixed(2));
      element.get('remunerationAmount').markAllAsTouched();
      element.get('gstAmount').markAllAsTouched();
      const remunerationAmountAftGst = (defaultValue + (defaultValue * this.gst));
      element.get('remunerationAmountAftGst').patchValue(remunerationAmountAftGst.toFixed(2));
      this.calTotalClaimamount();
    });
  }

  sflScreeningTypeChange(screening) { 
    const testOrders = this.formGroup.get('mhcpPlanCategory').value === 'HSF' ? this.testOrders.filter(item => item.value === 4) : this.testOrders.filter(item => item.value != 4);
    const mhcpPlanCategory = this.formGroup.get('mhcpPlanCategory').value;    
    screening.get('sflScreeningSubType').patchValue(undefined);
    screening.get('testOrder').patchValue(undefined);
    if (screening.value.sflScreeningType) {
      let selectedType = this.screeningTypes.find(item => item.cmsCode === screening.value.sflScreeningType);
      if (selectedType) {
        const defaultValue = ((mhcpPlanCategory && mhcpPlanCategory === 'HSF') ? this.followUpType[0].defaultAmount : selectedType.defaultAmount) || 0;
        screening.get('remunerationAmount').patchValue(defaultValue);
        screening.get('gstAmount').patchValue((defaultValue  * this.gst).toFixed(2));
        screening.get('remunerationAmount').markAllAsTouched();
        screening.get('gstAmount').markAllAsTouched();
        const remunerationAmountAftGst = (defaultValue + (defaultValue  * this.gst));
        screening.get('remunerationAmountAftGst').patchValue(remunerationAmountAftGst.toFixed(2));
        this.calTotalClaimamount();

      }

      if (selectedType && screening.value.sflScreeningType === 'COLORECTAL_CANCER_SCREENING') {
        const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'FITT');
        //const filteredTestOrder = this.testOrders.filter(order => order.value === 1);
        screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
        ///screening.get('testOrderList').patchValue(filteredTestOrder);
        screening.get('testOrderList').patchValue(testOrders);
        screening.get('sflScreeningSubType').patchValue('FITT');
      }
      if (selectedType && screening.value.sflScreeningType === 'CHRONIC_SCREENING') {
        const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'OGTT' || item.cmsCode === 'REPEAT_FASTING'   || item.cmsCode === 'CHRONIC_HBA1C');
        screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
        screening.get('testOrderList').patchValue(testOrders);
      }
      if (selectedType && screening.value.sflScreeningType === 'CERVICAL_CANCER_SCREENING') {
        const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'REPEAT_PAP_SMEAR' || item.cmsCode === 'REPEAT_HPV_DNA');
        screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
        screening.get('testOrderList').patchValue(testOrders);
      }

      this.formGroup.get('mhcpPlanCategory').value === 'HSF' ? screening.get('testOrder').patchValue(4) : screening.get('testOrder').patchValue(1);
      screening.markAllAsTouched();
    }   
  }

  sflTestOrderChange(screening) { 
    if (screening.value.testOrder) {
      if (screening.value.sflScreeningType) {
        let selectedType = this.screeningTypes.find(item => item.cmsCode === screening.value.sflScreeningType);
        if (selectedType) {
          const defaultValue = screening.value.testOrder === 3 ? 0 : (selectedType.defaultAmount || 0);
          screening.get('remunerationAmount').patchValue(defaultValue);
          screening.get('gstAmount').patchValue((defaultValue * this.gst).toFixed(2));
          screening.get('remunerationAmount').markAllAsTouched();
          screening.get('gstAmount').markAllAsTouched();
          const remunerationAmountAftGst = (defaultValue + (defaultValue * this.gst));
          screening.get('remunerationAmountAftGst').patchValue(remunerationAmountAftGst.toFixed(2));
          this.calTotalClaimamount();  
        }
      }
  }   
  }

  initDatePickerConfigObject(
    label,
    maxDate,
    minDate,
    datePickerPlacement,
    labelPlacement
  ) {
    return new DatePickerConfig(
      label,
      maxDate,
      minDate,
      datePickerPlacement,
      labelPlacement
    );
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  private populateData() {
    this.getSFLSetupMapping();
    this.doctorList = this.doctorQuery.getAll();
    this.clinics = this.clinicQuery.getAll();

  }

  private getSFLSetupMapping() {
    this.apiCmsManagementService.listSFLSetupMapping().subscribe(
      	data => {
      		if (data.payload && data.payload.values) {
            this.allScreeningTypes = data.payload.values.find(types => types.name === 'SCREENING_TYPE').values;
            this.screeningSubTypes = data.payload.values.find(types => types.name === 'SCREENING_SUB_TYPE').values;
            this.followUpOutcomes = data.payload.values.find(types => types.name === 'FOLLOW_UP_OUTCOME').values;
            this.followUpTypes = data.payload.values.find(types => types.name === 'FOLLOW_UP_TYPE').values;
            //Filter
            this.screeningTypes = this.allScreeningTypes.filter(item => !(item.externalCode === 'H' || item.externalCode === 'D' || item.externalCode === 'B'))
      		}
      	},
      	err => {
      		this.alertService.error(JSON.stringify(err.error.message));
      	}
      );
  }

  newFormGroup() {
    this.formGroup = this.fb.group({
      claimId: [{ value: '', disabled: true }, Validators.required],
      date: { value: '', disabled: true },
      HEcode: { value: '', disabled: true },
      hospitalName: { value: '', disabled: true },
      clinic: { value: '', disabled: true },
      patientName: { value: '', disabled: true },
      payersName: { value: '', disabled: false },
      patientNric: { value: '', disabled: true },
      payerNric: { value: '', disabled: true },
      mhcpPlanCategory: { value: '', disabled: true },
      patientId: { value: '', disabled: true },
      payerIdType: { value: '', disabled: true },
      payerRelationship: { value: '', disabled: true },
      payerDob: [{ value: '', disabled: false }, Validators.required],
      payerAddress1: [{ value: '', disabled: false }, Validators.required],
      payerAddress2: [{ value: '', disabled: false }, Validators.required],
      doctor: { value: '', disabled: false },
      referNo: { value: '', disabled: true },
      diagnosisCode: { value: '', disabled: false },
      receiptNo: { value: '', disabled: true },
      conAmt: { value: '', disabled: true },
      drugAmt: { value: '', disabled: true },
      labAmt: { value: '', disabled: true },
      otherAmt: { value: '', disabled: true },
      totAmt: { value: '', disabled: true },
      claimAmt: { value: '', disabled: false },
      status: { value: '', disabled: false },
      remarks: { value: '', disabled: false },
      claimedAmt: { value: '', disabled: false },
      claimRefNo: { value: '', disabled: false },
      claimRemarks: { value: '', disabled: false },
      claimStatus: { value: '', disabled: false },      
      followUpType: { value: '', disabled: false },
    });

    // Validation Checking
    this.formGroup
      .get('claimStatus')
      .valueChanges.pipe(takeUntil(this.componentDestroyed))
      .subscribe(val => {
        const claimRefNoControl = this.formGroup.get('claimRefNo');
        const claimAmount = this.formGroup.get('claimedAmt');
        if (val === 'APPROVED') {
          claimAmount.setValidators(Validators.required);
          claimAmount.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimAmount.markAsTouched({ onlySelf: true });
        } else {
          claimAmount.setValidators(null);
          claimAmount.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimAmount.markAsTouched({ onlySelf: true });
        }

        if (val) {
          claimRefNoControl.setValidators(Validators.required);
          claimRefNoControl.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        } else {
          claimRefNoControl.setValidators(null);
          claimRefNoControl.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        }
      });
  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      startDate: [
        moment()
          .subtract(1, 'days')
          .format(DISPLAY_DATE_FORMAT),
        Validators.required,
      ],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicId: [undefined, Validators.required],
      status: this.searchStatusList[0],
    });
  }

  updateForm(row: any) {
    this.patientName = row.patientName;
    this.currentRow = row;

    this.relationshipDetails = [];
    if (row.relationshipDetails && row.relationshipDetails.length > 0) {
      this.relationshipDetails = [...row.relationshipDetails];
      this.movePrimaryRelationToTop();
    }

    this.formGroup.patchValue({
      claimId: row.claimId,
      date: row.billDate,
      HEcode: row.HEcode,
      clinic: row.clinic,
      patientName: row.patientName,
      patientNric: row.patientNric,
      mhcpPlanCategory: row.mhcpPlanCategory,
      patientId: row.patientId,
      payersName: row.payersName,
      payerNric: '',
      payerIdType: '',
      payerRelationship: '',
      payerDob: '',
      payerAddress1: '',
      payerAddress2: '',
      doctor: row.doctor,
      referNo: row.referNo,
      diagnosisCode: row.diagnosisCode,
      conAmt: row.conAmt,
      drugAmt: row.drugAmt,
      labAmt: row.labAmt,
      otherAmt: row.otherAmt,
      totAmt: row.totAmt,
      claimAmt: row.claimAmt,
      status: row.status,
      receiptNo: row.receiptNo,
      remarks: row.remarks,
      claimedAmt: row.claimedAmt,
      claimRefNo: row.claimRefNo,
      claimRemarks: row.claimRemarks,
      claimStatus: row.claimStatus,      
      followUpType: row.followUpType,
    });

    let selfPayer = {
      name: row.patientName,
      userId: {
        idType: '',
        number: row.patientNric,
      },
    };
    this.relationshipDetails = [...this.relationshipDetails, selfPayer];

    if (row.patientNric === row.payerNric) {
      this.formGroup.get('payerDob').disable();
      this.formGroup.get('payerAddress1').disable();
      this.formGroup.get('payerAddress2').disable();
    } else {
      if (row.payerNric) {
        let relation = this.relationshipDetails.find(
          rel => rel.userId.number === row.payerNric
        );
        if (relation) {
          this.setPayersInfo(relation, row);
        }
      }
    }
  }

  movePrimaryRelationToTop() {
    let primaryRel = this.relationshipDetails.find(rel => rel.primary === true);
    if (primaryRel) {
      this.relationshipDetails.splice(
        this.relationshipDetails.findIndex(rel => rel.primary === true),
        1
      );
      this.relationshipDetails.unshift(primaryRel);
    }
  }

  setPayersInfo(relation, row) {
    this.formGroup.get('payerNric').patchValue(row.payerNric);
    this.formGroup.get('payerIdType').patchValue(row.payerIdType);
    this.formGroup.get('payerRelationship').patchValue(row.payerRelationship);

    const addressSplitValue = row.payerAddress.address.split('\n');

    this.formGroup.get('payerDob').patchValue(new Date(row.payerDob));
    this.formGroup
      .get('payerAddress1')
      .patchValue(addressSplitValue[0]);
    this.formGroup
      .get('payerAddress2')
      .patchValue(addressSplitValue[1]);

    this.formGroup.get('payerDob').enable();
    this.formGroup.get('payerAddress1').enable();
    this.formGroup.get('payerAddress2').enable();
  }

  OnPayersNameChanged(event) {
    if (event) {
      this.formGroup.get('payerNric').patchValue(event.userId.number);
      this.formGroup.get('payerIdType').patchValue(event.userId.idType);
      this.formGroup.get('payerRelationship').patchValue(event.relationship);

      this.formGroup.get('payerDob').patchValue('');
      this.formGroup.get('payerAddress1').patchValue('');
      this.formGroup.get('payerAddress2').patchValue('');

      if (event.name === this.patientName) {
        this.formGroup.get('payerNric').patchValue('');
        this.formGroup.get('payerDob').disable();
        this.formGroup.get('payerAddress1').disable();
        this.formGroup.get('payerAddress2').disable();
      } else {
        const payerDobFG = this.formGroup.get('payerDob');
        const payerAddress1FG = this.formGroup.get('payerAddress1');
        const payerAddress2FG = this.formGroup.get('payerAddress2');

        payerDobFG.enable();
        payerDobFG.patchValue(new Date(event.dob));
        payerDobFG.setValidators([Validators.required]);
        payerDobFG.markAsTouched();
        payerDobFG.updateValueAndValidity();

        const addressSplitValue = event.address.address.split('\n');

        payerAddress1FG.enable();
        payerAddress1FG.patchValue(addressSplitValue[0]);
        payerAddress1FG.setValidators([Validators.required]);
        payerAddress1FG.markAsTouched();
        payerAddress1FG.updateValueAndValidity();

        payerAddress2FG.enable();
        payerAddress2FG.patchValue(addressSplitValue[1]);
        payerAddress2FG.setValidators([Validators.required]);
        payerAddress2FG.markAsTouched();
        payerAddress2FG.updateValueAndValidity();

        this.formGroup.updateValueAndValidity();
      }
    }
  }

  resetFormGroup() {
    this.showEdit = false;
    this.formGroup.reset();
    this.newFormGroup();
  }

  onEditUserClicked(row, selectedRowIndex) {
    this.selectedRowIndex = selectedRowIndex;
    this.selectedPatientId = row.patientId;
    this.selectedClinicId = row.clinicId;
    this.selectedRow = row;
    this.historyData = [];
    this.screeningList.clear();
    this.showEdit = true;
    this.updateForm(row);
    this.updateClaimItems(row);
    this.updateCreeningData(row);
    this.calTotalClaimamount();
    window.scrollTo({ left: 0, top: 0, behavior: 'smooth' });
    const followUpType = this.formGroup.get('followUpType').value;
    this.followUpType = this.followUpTypes.filter(item=> item.cmsCode===followUpType);
  }

  updateCreeningData(row: any) {

    if (row.sflClaimDetails && row.sflClaimDetails.screeningDataList && row.sflClaimDetails.screeningDataList.length > 0) {
      row.sflClaimDetails.screeningDataList.forEach (item => {
        this.addScreening(item.screeningInfo, item.prevScreeningInfoList);
      });
        
    } else { 
      this.addScreening();
    }
  }

  updateClaimItems(row: any) {
    this.claimItemRows = [];
    this.claimItemRows = row.claimItems;
  }

  onChargePatientClicked(row: any, rowIndex) {
    this.submitting[rowIndex] = true;
    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before proceeding!');
      return;
    }
    this.apiPatientVisitService.rejectClaim(claimId).subscribe(
      res => {
        alert('Claim is rejected');
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      err => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  viewSFLClaimHistory(showPopup: any = false, screeningFG: any = null) {
    
    let clinicId = this.selectedClinicId;
    const patientId = this.selectedPatientId;
    const mhcpPlanCategory = this.formGroup.controls['mhcpPlanCategory'].value;

    this.apiPatientVisitService
      .listSFLClaimHistory(
        clinicId,
        patientId,
        'HSC',
      )
      .subscribe(
        res => {
          if(res.payload.sflClaimHistoryItems) {
            this.historyData = res.payload.sflClaimHistoryItems;
            this.historyData.forEach(history => {
              if ( history.dateOfVisit) {
                history['screeningDate'] =  moment(history.dateOfVisit, "YYYY-MM-DD").format(DISPLAY_DATE_FORMAT);
              }
              history['sflScreeningType'] = history.screenCodeCms;

              if (!history.diagnosisCodes) {
                history['diagnosisCodes'] = [];
              }
            });
          }

          if (showPopup) {
            this.openHistoryPopup(screeningFG);
          }
        },
        err => {
          this.alertService.error(JSON.stringify(err));
        }
      );  
  }

  addScreening(screen? :any, prevScreening?: any){
      this.screeningList.push(this.createScringFormGroup(screen, prevScreening));
  }

  createScringFormGroup(screen? :any, prevScreening?: any) {
    const testOrders = this.formGroup.get('mhcpPlanCategory').value === 'HSF' ? this.testOrders.filter(item => item.value === 4) : this.testOrders.filter(item => item.value != 4) ;
    
    const screening = this.fb.group({
      testOrder: [screen && screen.testOrder ? screen.testOrder :undefined, Validators.required],
      sflScreeningType: [screen && screen.sflScreeningType ? screen.sflScreeningType :undefined, Validators.required],
      sflFollowUpOutcome: [screen && screen.sflFollowUpOutcome ? screen.sflFollowUpOutcome :this.formGroup.get('mhcpPlanCategory').value === 'HSF' ? Validators.required : null],
      screeningDate: [screen && screen.screeningDate ? moment(screen.screeningDate, "YYYY-MM-DD").format(DISPLAY_DATE_FORMAT) : moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      diagnosisList: [''],
      remunerationAmount: [screen && screen.remunerationAmount ? screen.remunerationAmount :undefined, Validators.required],
      patientPayAmount: [screen && screen.patientPayAmount ? screen.patientPayAmount :undefined],
      gstAmount: [screen && screen.gstAmount ?  screen.gstAmount:  0, Validators.required],
      remunerationAmountAftGst: [screen && screen.gstAmount ?  (screen.gstAmount + screen.remunerationAmount):  0],
      sflScreeningSubType: [screen && screen.sflScreeningSubType ? screen.sflScreeningSubType :undefined, Validators.required],
      isNewObject: screen  ? false :true,
      sflHistory: [prevScreening? prevScreening : []],      
      testOrderList: [testOrders],
      screeningSubTypesList: [this.screeningSubTypes]
    });

    if (this.formGroup.get('mhcpPlanCategory').value === 'HSF' && !screen ) {
      screening.get('testOrder').patchValue(4);
    }

    if (screen && screening.value.sflScreeningType === 'COLORECTAL_CANCER_SCREENING') {
      const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'FITT');
      // const filteredTestOrder = this.testOrders.filter(order => order.value === 1);
      screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
      screening.get('testOrderList').patchValue(testOrders);
    }
    if (screen && screening.value.sflScreeningType === 'CHRONIC_SCREENING') {
      const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'OGTT' || item.cmsCode === 'REPEAT_FASTING'   || item.cmsCode === 'CHRONIC_HBA1C');
      screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
      screening.get('testOrderList').patchValue(testOrders);
    }
    if (screen && screening.value.sflScreeningType === 'CERVICAL_CANCER_SCREENING') {
      const screeningSubTypesFiltered = this.screeningSubTypes.filter(item => item.cmsCode === 'REPEAT_PAP_SMEAR' || item.cmsCode === 'REPEAT_HPV_DNA');
      screening.get('screeningSubTypesList').patchValue(screeningSubTypesFiltered);
      screening.get('testOrderList').patchValue(testOrders);
    }

    return screening;
  }

  getSelectedHistory(formdata) {
    if (!formdata) return;
    const histroyList =  formdata.get('sflHistory').value;
    var nameList = [];
    histroyList.forEach(history => {
      const testOrder = this.testOrders.find(order => order.value === history.testOrder);
      nameList.push(testOrder.label + (history.dateOfVisit ? '|'+history.dateOfVisit : ''));
    });

    return nameList.join();

  }

  calGST(event: any, form) {
    var amount = event.target.value;
    var gst = (amount * this.gst).toFixed(2);
    form.get('gstAmount').patchValue(gst);
    var claimAfterGst = Number(amount) + Number(gst);    
    form.get('remunerationAmountAftGst').patchValue(claimAfterGst);
    this.calTotalClaimamount();
  }

  calTotalClaimamount() {
    this.claimTotal = Number(0);
    this.screeningsFormGroup.get('screeningList');
    this.screeningsFormGroup.get('screeningList').value.forEach( (element) => { 
      this.claimTotal = Number(this.claimTotal) + Number(element.remunerationAmountAftGst);
    });
    this.claimTotal = Number(this.claimTotal) * 100;
  }


  onSearchClaimClicked() {
    const startDateStr = moment(
      this.searchFormGroup.get('startDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');
    const endDateStr = moment(
      this.searchFormGroup.get('endDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');
    const status = this.searchFormGroup.get('status').value;
    let clinicId = ''
    //update clinicId in the form group
    const selectedClinic = this.searchFormGroup.get('clinicId').value;
    if (selectedClinic) {
      clinicId = selectedClinic;
    }

    this.apiPatientVisitService
      .listClaimsByClinlicByDate(
        clinicId,
        'CHAS-SFL',
        status,
        startDateStr,
        endDateStr
      )
      .subscribe(
        res => {
          this.rows = this.mapPayloadToRows(res.payload);
          this.rows = this.rows.sort((a, b) => {
            const date1 = moment(a.billDate, DISPLAY_DATE_FORMAT);
            const date2 = moment(b.billDate, DISPLAY_DATE_FORMAT);

            if (date1.isBefore(date2)) {
              return -1;
            }
            if (date1.isAfter(date2)) {
              return 1;
            }

            // equal
            return 0;
          });
        },
        err => {
          this.alertService.error(JSON.stringify(err));
        }
      );
  }

  loadExistingDiagnosis(diagnosisCodes) {

    const removedDuplicates = diagnosisCodes.filter((value, index) => diagnosisCodes.indexOf(value) === index);

    this.apiCmsManagementService.searchDiagnosisByIcdCodes(removedDuplicates).subscribe(result => {
      if(result.statusCode === 'S0000') {
        this.exsistingCodes = result.payload;

        let missingCodes = [];

        removedDuplicates.forEach(code => {
          let codeEx = this.exsistingCodes.find(exCode => exCode.icd10Code === code);
          if (!codeEx) {
            missingCodes.push ( {
                id : code,
                icd10Id : code,
                snomedId : code,
                icd10Code : code,
                icd10Term : code,
                status : "ACTIVE",
                filterablePlanIds : [ ],
                invalidUsage : false
              } );            
          }
        });

        this.exsistingCodes = [...this.exsistingCodes, ...missingCodes];
        this.codes =  this.exsistingCodes;
        
      }
    }, error => {});
    
  }

  onSaveClicked(isSaveAndSubmit: boolean, rowIndex) {
    
    const claim = this.mapFormGroupToSFLClaimSave(this.formGroup, this.screeningsFormGroup);
    const claimId = this.formGroup.get('claimId').value;

    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }

    if(!this.screeningsFormGroup.valid) {
      this.screeningsFormGroup.get('screeningList').markAllAsTouched();
      return;
    }

    let successMsg = 'Claim is updated';
    if (!!isSaveAndSubmit) {
      claim['submitClaim'] = true;
      successMsg = 'Claim is submitted';
    }
    this.apiPatientVisitService.saveClaim(claimId, claim).subscribe(
      res => {
        alert(successMsg);
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      err => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  onResubmitClicked(row: any, rowIndex) {
    this.onSubmitClicked(row, rowIndex);
  }

  onSubmitClicked(row: any, rowIndex) {
    if(!this.screeningsFormGroup.valid) {
      this.screeningsFormGroup.get('screeningList').markAllAsTouched();
      return;
    }
    this.submitting[rowIndex] = true;
    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }
    
    this.onSaveClicked(true, rowIndex);
  }

  /* Data Mapper */
  mapPayloadToRows(payload: any[]) {
    let diagnosisCodes = [];
    const arr = payload.map(res => {
      const doctor = this.store.findDoctorById(res.claim.claimDoctorId);
      const claimResult =
        res.payload && res.payload.claimResult
          ? <ClaimResult>res.payload.claimResult
          : new ClaimResult();
      const claimSubmissionResult =
        res.payload && res.payload.submissionResult
          ? <ClaimSubmissionResult>res.payload.claimResult
          : new ClaimSubmissionResult();
      this.selectedPayersName = res.claim.payersName;

      if (res.claim.diagnosisCodes) {
        diagnosisCodes = [...diagnosisCodes, ...res.claim.diagnosisCodes]
      }
      return {
        claimId: res.claim.claimId,
        billDate: res.billDate
          ? moment(res.billDate, DB_FULL_DATE_FORMAT).format(
              DISPLAY_DATE_FORMAT
            )
          : 'N/A',
        submitDate: res.claim.submissionDateTime
          ? moment({
              y: res.claim.submissionDateTime[0],
              M: res.claim.submissionDateTime[1] - 1,
              d: res.claim.submissionDateTime[2],
            }).format(DISPLAY_DATE_FORMAT)
          : 'N/A',
        HEcode: 'clinlic.heCode' || 'N/A',
        clinic: res.clinicCode,
        clinicId: res.clinicId,
        patientName: res.patientsName,
        payersName: res.claim.payersName,
        payerDob: res.claim.payerDob,
        payerAddress: res.claim.payerAddress,
        payerIdType: res.claim.payerIdType,
        payerRelationship: res.claim.payerRelationship,
        doctor: res.claim.claimDoctorId,
        doctorName: doctor
          ? doctor.displayName +
            ' \n(' +
            (doctor.mcr ? doctor.mcr : '---') +
            ')'
          : 'N/A',
        referNo: res.claim.claimId,
        diagnosisCode: res.claim.diagnosisCodes,
        conAmt: res.claim.consultationAmt,
        drugAmt: res.claim.medicationAmt / 100,
        labAmt: res.claim.medicalTestAmt / 100,
        otherAmt: res.claim.otherAmt / 100,
        totAmt: res.totalAmount / 100,
        claimAmt: res.claim.claimExpectedAmt / 100,
        status: res.claim.claimStatus,
        remark: this.getRemark(res.claim),
        patientNric: res.patientsNric,
        payerNric: res.claim.payersNric,
        mhcpPlanCategory: res.mhcpPlanCategory,
        patientId: res.patientId,
        receiptNo: res.billReceiptId,
        plan:
          (res.medicalCoverageName ? res.medicalCoverageName : '') +
          ' - \n' +
          (res.planName ? res.planName : ''),
        claimedAmt: '',
        claimRefNo: res.claim.claimRefNo,
        claimRemarks: res.claimRemarks,
        claimResult,
        claimSubmissionResult,
        claimItems: res.claimItems,
        relationshipDetails: res.relationshipDetails,
        sflClaimDetails:  res.claim.sflClaimDetails,
        followUpType:  res.followUpType ?  res.followUpType : undefined,
      };
    });
    this.loadExistingDiagnosis(diagnosisCodes);
    return arr;
  }

  getRemark(claim) {
    const { submissionResult, claimResult } = claim;
    let remark = '';
    if (
      submissionResult &&
      submissionResult.statusCode &&
      claimResult &&
      claimResult.remark
    ) {
      // show claim result
      if (
        submissionResult.statusCode === 'OK' ||
        submissionResult.statusCode === 'Success'
      ) {
        remark = claim.remark;
      } else {
        remark =
          submissionResult.statusDescription &&
          submissionResult.statusDescription;
      }
    } else if (submissionResult && !claimResult) {
      remark =
        submissionResult.statusDescription &&
        submissionResult.statusDescription;
    } else if (!submissionResult && claimResult) {
      remark = claimResult.remark && claimResult.remark;
    }
    return remark;
  }

  selectHistoryFollowup(formGroup) {
    if (!this.historyData || this.historyData.length < 1) {
      this.viewSFLClaimHistory(true, formGroup);
    } else {
      this.openHistoryPopup(formGroup);
    }    

  }

  openHistoryPopup(formGroup) {
    const initialState = {
      title: 'SFL History',
      formGroup: formGroup,
      sflHistoryData: this.historyData,
      testOrders: this.testOrders,
      screeningTypes: this.allScreeningTypes,
    };

    this.modalService.show(SflHistoyPopupComponent, {
      initialState,
      class: 'modal-xl',
      backdrop: 'static',
      keyboard: false,
    });
  }

  mapFormGroupToSFLClaimSave(formGroup: FormGroup, screeningFormGroup: FormGroup): ClaimSave {

    const mhcpPlanCategory = this.formGroup.controls['mhcpPlanCategory'].value;

    const screeningList =  screeningFormGroup.get('screeningList').value;
      const screeningData = [];
      screeningList.forEach(screen => {
        const scInfo = new ScreeningInfo(
          screen.testOrder,
          screen.sflScreeningType,
          screen.sflScreeningSubType,
          screen.screeningDate,
          formGroup.get('diagnosisCode').value,
          screen.remunerationAmount,
          screen.patientPayAmount,
          screen.gstAmount,          
          screen.sflFollowUpOutcome
        );
          screeningData.push(new ScreeningData(scInfo, screen.sflHistory));

      });
  
      const sFLClaimData = new SFLClaimData(screeningData);

    let payerAddress: PayerAddress = {
      address: `${formGroup.get('payerAddress1').value}\n${formGroup.get('payerAddress2').value}`,
    };
    
    const patientNric = formGroup.get('patientNric').value;
    const payerNric = formGroup.get('payerNric').value;

    let dob = formGroup.get('payerDob').value
      ? moment(formGroup.get('payerDob').value).format(DISPLAY_DATE_FORMAT)
      : null || null;
    return new ClaimSave(
      formGroup.get('doctor').value,
      !payerNric ? patientNric : formGroup.get('payerNric').value,
      formGroup.get('payersName').value,
      formGroup.get('diagnosisCode').value,
      formGroup.get('HEcode').value,
      formGroup.get('claimAmt').value * 100,
      formGroup.get('claimRemarks').value,
      formGroup.get('claimedAmt').value * 100,
      formGroup.get('claimRefNo').value,
      formGroup.get('claimStatus').value,
      formGroup.get('payerIdType').value || null,
      formGroup.get('payerRelationship').value || null,
      dob,
      payerAddress,
      sFLClaimData,
      formGroup.get('followUpType').value || null
    );

      
  
      // return new SFLClaim(
      //   formGroup.get('claimRemarks').value,
      //   sFLClaimData
      // );
        
  }

  // mapFormGroupToClaimSave(formGroup: FormGroup): ClaimSave {
  //   let payerAddress: PayerAddress = {
  //     address: `${formGroup.get('payerAddress1').value}\n${formGroup.get('payerAddress2').value}`,
  //   };
    
  //   const patientNric = formGroup.get('patientNric').value;
  //   const payerNric = formGroup.get('payerNric').value;

  //   let dob = formGroup.get('payerDob').value
  //     ? moment(formGroup.get('payerDob').value).format(DISPLAY_DATE_FORMAT)
  //     : null || null;
  //   return new ClaimSave(
  //     formGroup.get('doctor').value,
  //     !payerNric ? patientNric : formGroup.get('payerNric').value,
  //     formGroup.get('payersName').value,
  //     formGroup.get('diagnosisCode').value,
  //     formGroup.get('HEcode').value,
  //     formGroup.get('claimAmt').value * 100,
  //     formGroup.get('claimRemarks').value,
  //     formGroup.get('claimedAmt').value * 100,
  //     formGroup.get('claimRefNo').value,
  //     formGroup.get('claimStatus').value,
  //     formGroup.get('payerIdType').value || null,
  //     formGroup.get('payerRelationship').value || null,
  //     dob,
  //     payerAddress
  //   );
  // }

  mapRowToClaimSubmit(row: any): ClaimSubmit {
    return new ClaimSubmit(
      row.doctor,
      row.payerNric,
      row.payersName,
      row.diagnosisCode,
      row.claimAmt * 100,
      row.claimId
    );
  }

  onDelete(index) {
    this.screeningList.removeAt(index);
  }

  getTestOrderDescription(testOrder) {
    return this.testOrders.find(order => order.value === testOrder).label;
  }

  getScreenTypeDescription(screenTypeCode) {
    return this.allScreeningTypes.find(type => type.externalCode === screenTypeCode).externalName;
  }

  onFilterInputChanged() {
    try {
      this.codesTypeahead
      .pipe(
        debounceTime(400)
      )
      .subscribe(result => {
        this.diagnosisLoading = true;
        if (result === '' || result === null || result === undefined) {
          this.diagnosisLoading = false;
        } else {
          this.apiCmsManagementService.searchDiagnosis(encodeURI(result), [], true).subscribe(result => {
            if(result.statusCode === 'S0000') {
              this.codes = [...this.exsistingCodes, ...result.payload];

              this.diagnosisLoading = false;
            }
          }, error => {
            this.diagnosisLoading = false;
            this.alertService.error(error.error.message);
        });
        }        
    })      
    } catch (err) {
      console.error('Search Diagnosis Error', err);
    }
  }

  getRowClass(row) {
    return {
      'is-align-top': true,
    };
  }

  getEditAccessControl(row) {
    return (
      row.status === 'REJECTED_PERMANENT' ||
      row.status === 'APPROVED' ||
      row.status === 'PAID' ||
      row.status === 'SUBMITTED'
    );
  }

  getSubmitAccessControl(row) {
    return (
      row.status === 'PENDING' ||
      row.status === 'FAILED' ||
      row.status === 'REJECTED'
    );
  }

  getChargePatientAccessControl(row) {
    return (
      row.status === 'SUBMITTED' ||
      row.status === 'PENDING' ||
      row.status === 'REJECTED' ||
      row.status === 'FAILED'
    );
  }
}

class SFLClaim {
  claimRemarks: string;
  sflClaimDetails: SFLClaimData;

  constructor(
    claimRemarks: string,
    sflClaimDetails: SFLClaimData,
  ) {
    this.claimRemarks = claimRemarks;
    this.sflClaimDetails = sflClaimDetails;
  }
}

class SFLClaimData {
  screeningDataList: ScreeningData [];
  constructor(
    screeningDataList: ScreeningData [],
  ) {
    this.screeningDataList = screeningDataList;
  }
  
}

class ScreeningData {
  screeningInfo: ScreeningInfo;
  prevScreeningInfoList: any[];
  constructor(
    screeningInfo: ScreeningInfo,
    prevScreeningInfoList: any[]
    ) {
    this.screeningInfo = screeningInfo;
    this.prevScreeningInfoList = prevScreeningInfoList;
  }
}

class ScreeningInfo {
  testOrder: number;
  sflScreeningType: string;
  sflScreeningSubType: string;
  screeningDate: string;
  diagnosisCodes: string[];
  remunerationAmount: number;
  patientPayAmount:number;
  gstAmount:any;
  sflFollowUpOutcome: string;
  constructor(
    testOrder: number,
    sflScreeningType: string,
    sflScreeningSubType: string,
    screeningDate: string,
    diagnosisCodes: string[],
    remunerationAmount: number,
    patientPayAmount:number,
    gstAmount:any,
    sflFollowUpOutcome: string
  ) {
    this.testOrder = testOrder;
    this.sflScreeningType = sflScreeningType;
    this.sflScreeningSubType = sflScreeningSubType;
    this.screeningDate = screeningDate;
    this.diagnosisCodes = diagnosisCodes;
    this.remunerationAmount = remunerationAmount;
    this.patientPayAmount = patientPayAmount;
    this.gstAmount = gstAmount;
    this.sflFollowUpOutcome = sflFollowUpOutcome;
  }

}

class ClaimSave {
  claimDoctorId: string;
  payersNric: string;
  payersName: string;
  diagnosisCodes: string[];
  clinicHeCode: string;
  expectedClaimAmount: number;
  claimRemarks: string;
  claimedAmount: number;
  claimRefNo: string;
  claimStatus: string;
  payerIdType: string;
  payerRelationship: string;
  payerDob: string;
  payerAddress: PayerAddress;  
  sflClaimDetails:any;
  followUpType:string;
  constructor(
    claimDoctorId: string,
    payersNric: string,
    payersName: string,
    diagnosisCodes: string[],
    clinicHeCode: string,
    expectedClaimAmount: number,
    claimRemarks: string,
    claimedAmount: number,
    claimRefNo: string,
    claimStatus: string,
    payerIdType: string,
    payerRelationship: string,
    payerDob: string,
    payerAddress: PayerAddress,
    sflClaimDetails: any,
    followUpType:string

  ) {
    this.claimDoctorId = claimDoctorId;
    this.payersNric = payersNric;
    this.payersName = payersName;
    this.diagnosisCodes = diagnosisCodes;
    this.clinicHeCode = clinicHeCode;
    this.expectedClaimAmount = expectedClaimAmount;
    this.claimRemarks = claimRemarks;
    this.claimedAmount = claimedAmount;
    this.claimRefNo = claimRefNo;
    this.claimStatus = claimStatus;
    this.payerIdType = payerIdType;
    this.payerRelationship = payerRelationship;
    this.payerDob = payerDob;
    this.payerAddress = payerAddress;
    this.sflClaimDetails = sflClaimDetails;
    this.followUpType = followUpType;
  }
}

class ClaimSubmit {
  doctorId: string;
  payerNric: string;
  payersName: string;
  diagnosisCodes: string[];
  claimAmount: number;
  claimId: string;
  constructor(
    doctorId?: string,
    payerNric?: string,
    payersName?: string,
    diagnosisCodes?: string[],
    claimAmount?: number,
    claimId?: string
  ) {
    this.doctorId = doctorId;
    this.payerNric = payerNric;
    this.payersName = payersName;
    this.diagnosisCodes = diagnosisCodes;
    this.claimAmount = claimAmount;
    this.claimId = claimId;
  }
}

class ClaimResult {
  referenceNumber: string;
  resultDateTime: string;
  amount: number;
  statusCode: string;
  constructor(
    referenceNumber?: string,
    resultDateTime?: string,
    amount?: number,
    statusCode?: string
  ) {
    this.referenceNumber = referenceNumber || '';
    this.resultDateTime = resultDateTime || '';
    this.amount = amount === undefined ? 0 : amount;
    this.statusCode = statusCode || '';
  }
}

class ClaimSubmissionResult {
  statusCode: string;
  statusDescription: string;

  constructor(statusCode?: string, statusDescription?: string) {
    this.statusCode = statusCode || '';
    this.statusDescription = statusDescription || '';
  }
}

class PayerAddress {
  address: string;

  constructor(address?: string) {
    this.address = address || '';
  }
}


