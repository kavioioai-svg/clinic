import { OnDestroy, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import moment = require('moment');
import { Subject, of } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, tap, switchMap, catchError } from 'rxjs/operators';
import { DISPLAY_DATE_FORMAT, DB_FULL_DATE_FORMAT } from '../../../constants/app.constants';
import { Clinic } from '../../../objects/response/Clinic';
import { HttpResponseBody } from '../../../objects/response/HttpResponseBody';
import { AlertService } from '../../../services/alert.service';
import { ApiCmsManagementService } from '../../../services/api-cms-management.service';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { StoreService } from '../../../services/store.service';
import { ClinicQuery } from '../../../state/clinic/clinic.query';
import { DoctorQuery } from '../../../state/doctor/doctor.query';
import { StoreStatusQuery } from '../../../state/store-status/store-status.query';

@Component({
  selector: 'app-claim-medisave',
  templateUrl: './claim-medisave.component.html',
  styleUrls: ['./claim-medisave.component.scss']
})
export class ClaimMedisaveComponent implements OnInit, OnDestroy  {

  @ViewChild('myTable', { static: true })
  table: any;
  columns: any[] = [];
  rows: any[] = [];
  // datePickerConfigArray: Array<DatePickerConfig>;

  // statusList = [ 'SUBMITTED', 'PENDING', 'REJECTED', 'APPEALED', 'APPROVED' ];
  statusList = ['SUBMITTED', 'FAILED', 'APPROVED'];
  searchStatusList = [
    'ALL',
    'SUBMITTED',
    'PENDING',
    'REJECTED_PERMANENT',
    'REJECTED',
    'APPEALED',
    'APPROVED',
    'PAID',
    'FAILED',
  ];
  doctorList: any[] = [];
  clinics: Array<Clinic>;
  showEdit = false;

  submitting = {};

  formGroup: FormGroup;
  searchFormGroup: FormGroup;

  codes = [];
  exsistingCodes = [];
  codesTypeahead = new Subject<string>();
  diagnosisLoading = false;

  private componentDestroyed: Subject<void> = new Subject();
  claimItemRows = [];
  relationshipDetails = [];
  // datePickerConfig: DatePickerConfig;
  selectedPayersName: any = null;
  patientName: string = null;

  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private store: StoreService,
    private apiPatientVisitService: ApiPatientVisitService,
    private apiCmsManagementService: ApiCmsManagementService,
    private clinicQuery: ClinicQuery,
    private doctorQuery: DoctorQuery,
    private storeStatusQuery: StoreStatusQuery
  ) {}

  ngOnInit() {
    this.newFormGroup();
    this.newSearchFormGroup();
    this.populateData();

    this.onFilterInputChanged();
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  private populateData() {
    this.doctorList = this.doctorQuery.getAll();
    this.clinics = this.clinicQuery.getAll();
  }

  newFormGroup() {
    this.formGroup = this.fb.group({
      claimId: [{ value: '', disabled: true }, Validators.required],
      date: { value: '', disabled: true },
      HEcode: { value: '', disabled: true },
      clinic: { value: '', disabled: true },
      patientName: { value: '', disabled: true },
      payersName: { value: '', disabled: false },
      patientNric: { value: '', disabled: true },
      hospitalCode: { value: '', disabled: true },
      payerNric: { value: '', disabled: true },
      payerIdType: { value: '', disabled: true },
      payerRelationship: { value: '', disabled: true },
      payerDob: [{ value: '', disabled: false }, Validators.required],
      payerAddress1: [{ value: '', disabled: false }, Validators.required],
      payerAddress2: [{ value: '', disabled: false }, Validators.required],
      doctor: { value: '', disabled: false },
      referNo: { value: '', disabled: true },
      diagnosisCode: { value: '', disabled: false },
      receiptNo: { value: '', disabled: true },
      conAmt: { value: '', disabled: true },
      drugAmt: { value: '', disabled: true },
      labAmt: { value: '', disabled: true },
      otherAmt: { value: '', disabled: true },
      totAmt: { value: '', disabled: true },
      claimAmt: { value: '', disabled: false },
      status: { value: '', disabled: false },
      remarks: { value: '', disabled: false },
      claimedAmt: { value: '', disabled: false },
      claimRefNo: { value: '', disabled: false },
      claimRemarks: { value: '', disabled: false },
      claimStatus: { value: '', disabled: false },
    });

    // Validation Checking
    this.formGroup
      .get('claimStatus')
      .valueChanges.pipe(takeUntil(this.componentDestroyed))
      .subscribe(val => {
        const claimRefNoControl = this.formGroup.get('claimRefNo');
        const claimAmount = this.formGroup.get('claimedAmt');
        if (val === 'APPROVED') {
          claimAmount.setValidators(Validators.required);
          claimAmount.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimAmount.markAsTouched({ onlySelf: true });
        } else {
          claimAmount.setValidators(null);
          claimAmount.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimAmount.markAsTouched({ onlySelf: true });
        }

        if (val) {
          claimRefNoControl.setValidators(Validators.required);
          claimRefNoControl.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        } else {
          claimRefNoControl.setValidators(null);
          claimRefNoControl.updateValueAndValidity({
            onlySelf: true,
            emitEvent: false,
          });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        }
      });
  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      startDate: [
        moment()
          .subtract(1, 'days')
          .format(DISPLAY_DATE_FORMAT),
        Validators.required,
      ],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicId: ['', Validators.required],
      status: this.searchStatusList[0],
    });
  }

  updateForm(row: any) {
    this.patientName = row.patientName;
    this.relationshipDetails = [];
    if(row.relationshipDetails && row.relationshipDetails.length > 0){
      this.relationshipDetails = [...row.relationshipDetails];
      this.movePrimaryRelationToTop();
    }

    this.formGroup.patchValue({
      claimId: row.claimId,
      date: row.billDate,
      HEcode: row.HEcode,
      clinic: row.clinic,
      patientName: row.patientName,
      patientNric: row.patientNric,
      payersName: row.payersName,
      hospitalCode: row.hospitalCode,
      payerNric: '',
      payerIdType: '',
      payerRelationship: '',
      payerDob: '',
      payerAddress1: '',
      payerAddress2: '',
      doctor: row.doctor,
      referNo: row.referNo,
      diagnosisCode: row.diagnosisCode,
      conAmt: row.conAmt,
      drugAmt: row.drugAmt,
      labAmt: row.labAmt,
      otherAmt: row.otherAmt,
      totAmt: row.totAmt,
      claimAmt: row.claimAmt,
      status: row.status,
      receiptNo: row.receiptNo,
      remarks: row.remarks,
      claimedAmt: row.claimedAmt,
      claimRefNo: row.claimRefNo,
      claimRemarks: row.claimRemarks,
      claimStatus: row.claimStatus,
    });

    let selfPayer = {
      name: row.patientName,
      userId: {
        idType: "",
        number: row.patientNric,
      }
    }
    this.relationshipDetails = [...this.relationshipDetails, selfPayer];

    if(row.patientNric === row.payerNric){
      this.formGroup.get('payerDob').disable();
      this.formGroup.get('payerAddress1').disable();
      this.formGroup.get('payerAddress2').disable();
    } else{
      if(row.payersName){
        let relation = this.relationshipDetails.find(rel => rel.userId.number === row.payerNric);
        if(relation){
          this.setPayersInfo(relation, row);
        }
      }
    }
  }

  movePrimaryRelationToTop() {
   let primaryRel = this.relationshipDetails.find(rel=> rel.primary === true);
    if(primaryRel){
      this.relationshipDetails.splice(this.relationshipDetails.findIndex(rel=> rel.primary === true), 1);
      this.relationshipDetails.unshift(primaryRel);
    }
  }

  setPayersInfo(relation, row){
    this.formGroup.get('payerNric').patchValue(row.payerNric);
    this.formGroup.get('payerIdType').patchValue(row.payerIdType);
    this.formGroup.get('payerRelationship').patchValue(row.payerRelationship);

    const addressSplitValue = row.payerAddress.address.split('\n');

    this.formGroup.get('payerDob').patchValue(new Date(row.payerDob));
    this.formGroup
      .get('payerAddress1')
      .patchValue(addressSplitValue[0]);
    this.formGroup
      .get('payerAddress2')
      .patchValue(addressSplitValue[1]);

    this.formGroup.get('payerDob').enable();
    this.formGroup.get('payerAddress1').enable();
    this.formGroup.get('payerAddress2').enable();
  }

  OnPayersNameChanged(event){
    if(event){
      this.formGroup.get('payerNric').patchValue(event.userId.number);
      this.formGroup.get('payerIdType').patchValue(event.userId.idType);
      this.formGroup.get('payerRelationship').patchValue(event.relationship);

      this.formGroup.get('payerDob').patchValue('');
      this.formGroup.get('payerAddress1').patchValue('');
      this.formGroup.get('payerAddress2').patchValue('');

      if(event.name === this.patientName){
        this.formGroup.get('payerNric').patchValue('');
        this.formGroup.get('payerDob').disable();
        this.formGroup.get('payerAddress1').disable();
        this.formGroup.get('payerAddress2').disable();
      } else{
        const payerDobFG = this.formGroup.get('payerDob');
        const payerAddress1FG = this.formGroup.get('payerAddress1');
        const payerAddress2FG = this.formGroup.get('payerAddress2');

        payerDobFG.enable();
        payerDobFG.patchValue(new Date(event.dob));
        payerDobFG.setValidators([Validators.required]);
        payerDobFG.markAsTouched();
        payerDobFG.updateValueAndValidity();

        const addressSplitValue = event.address.address.split('\n');

        payerAddress1FG.enable();
        payerAddress1FG.patchValue(addressSplitValue[0]);
        payerAddress1FG.setValidators([Validators.required]);
        payerAddress1FG.markAsTouched();
        payerAddress1FG.updateValueAndValidity();

        payerAddress2FG.enable();
        payerAddress2FG.patchValue(addressSplitValue[1]);
        payerAddress2FG.setValidators([Validators.required]);
        payerAddress2FG.markAsTouched();
        payerAddress2FG.updateValueAndValidity();

        this.formGroup.updateValueAndValidity();
      }
    }
  }

  resetFormGroup() {
    this.showEdit = false;
    this.formGroup.reset();
    this.newFormGroup();
  }

  onEditUserClicked(row) {
    this.showEdit = true;
    this.updateForm(row);
    this.updateClaimItems(row);
    window.scrollTo({ left: 0, top: 0, behavior: 'smooth' });
  }

  updateClaimItems(row: any) {
    this.claimItemRows = [];
    this.claimItemRows = row.claimItems;
  }

  onChargePatientClicked(row: any, rowIndex) {
    this.submitting[rowIndex] = true;
    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before proceeding!');
      return;
    }
    this.apiPatientVisitService.rejectClaim(claimId).subscribe(
      res => {
        alert('Claim is rejected');
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      err => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  onSearchClaimClicked() {
    const startDateStr = moment(
      this.searchFormGroup.get('startDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');
    const endDateStr = moment(
      this.searchFormGroup.get('endDate').value,
      'DD-MM-YYYY'
    ).format('DD-MM-YYYY');
    const status = this.searchFormGroup.get('status').value;
    let clinicId = '';

    //update clinicId in the form group
    const selectedClinic = this.searchFormGroup.get('clinicId').value;
    if (selectedClinic) {
      clinicId = selectedClinic;
    }
    this.rows = [];
    this.apiPatientVisitService
      .listClaimsByClinlicByDate(
        clinicId,
        'MEDISAVE',
        status,
        startDateStr,
        endDateStr
      )
      .subscribe(
        res => {
          this.rows = this.mapPayloadToRows(res.payload);
          this.rows = this.rows.sort((a, b) => {
            const date1 = moment(a.billDate, DISPLAY_DATE_FORMAT);
            const date2 = moment(b.billDate, DISPLAY_DATE_FORMAT);

            if (date1.isBefore(date2)) {
              return -1;
            }
            if (date1.isAfter(date2)) {
              return 1;
            }

            // equal
            return 0;
          });
        },
        err => {
          this.alertService.error(JSON.stringify(err));
        }
      );
  }

  onSaveClicked() {
    const claim = this.mapFormGroupToClaimSave(this.formGroup);
    const claimId = this.formGroup.get('claimId').value;
    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }
    this.apiPatientVisitService.saveClaim(claimId, claim).subscribe(
      res => {
        alert('Claim is updated');
        this.resetFormGroup();
        this.onSearchClaimClicked();
      },
      err => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }

  onResubmitClicked(row: any, rowIndex) {
    this.onSubmitClicked(row, rowIndex);
  }

  onSubmitClicked(row: any, rowIndex) {
    this.submitting[rowIndex] = true;
    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }
    this.apiPatientVisitService.submitClaim(claimId, claim).subscribe(
      res => {
        alert('Claim is submitted');
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      err => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  /* Data Mapper */
  mapPayloadToRows(payload: any[]) {
    const clinlic = this.searchFormGroup.get('clinicId').value;
    const hospitalCode =  this.getHospitalCode(clinlic);
    let diagnosisCodes = [];
    const arr = payload.map(res => {
      const doctor = this.store.findDoctorById(res.claim.claimDoctorId);
      const claimResult =
        res.payload && res.payload.claimResult
          ? <ClaimResult>res.payload.claimResult
          : new ClaimResult();
      const claimSubmissionResult =
        res.payload && res.payload.submissionResult
          ? <ClaimSubmissionResult>res.payload.claimResult
          : new ClaimSubmissionResult();
      this.selectedPayersName = res.claim.payersName;

      if (res.claim.diagnosisCodes) {
        diagnosisCodes = [...diagnosisCodes, ...res.claim.diagnosisCodes]
      }
      return {
        claimId: res.claim.claimId,
        billDate: res.billDate
          ? moment(res.billDate, DB_FULL_DATE_FORMAT).format(
              DISPLAY_DATE_FORMAT
            )
          : 'N/A',
        submitDate: res.claim.submissionDateTime
          ? moment({
              y: res.claim.submissionDateTime[0],
              M: res.claim.submissionDateTime[1] - 1,
              d: res.claim.submissionDateTime[2],
            }).format(DISPLAY_DATE_FORMAT)
          : 'N/A',
        HEcode: clinlic.heCode || 'N/A',
        clinic: res.clinicCode,
        patientName: res.patientsName,
        payersName: res.claim.payersName,
        payerDob: res.claim.payerDob,
        payerAddress: res.claim.payerAddress,
        payerIdType: res.claim.payerIdType,
        payerRelationship: res.claim.payerRelationship,
        doctor: res.claim.claimDoctorId,
        doctorName: doctor
          ? doctor.displayName +
            ' \n(' +
            (doctor.mcr ? doctor.mcr : '---') +
            ')'
          : 'N/A',
        referNo: res.claim.claimId,
        diagnosisCode: res.claim.diagnosisCodes,
        conAmt: res.claim.consultationAmt / 100,
        drugAmt: res.claim.medicationAmt / 100,
        labAmt: res.claim.medicalTestAmt / 100,
        otherAmt: res.claim.otherAmt / 100,
        totAmt: res.totalAmount / 100,
        claimAmt: res.claim.claimExpectedAmt / 100,
        status: res.claim.claimStatus,
        remark: this.getRemark(res.claim),
        patientNric: res.patientsNric,
        payerNric: res.claim.payersNric,
        receiptNo: res.billReceiptId,
        hospitalCode:hospitalCode,
        plan:
          (res.medicalCoverageName ? res.medicalCoverageName : '') +
          ' - \n' +
          (res.planName ? res.planName : ''),
        claimedAmt: '',
        claimRefNo: res.claim.claimRefNo,
        claimRemarks: res.claimRemarks,
        claimResult,
        claimSubmissionResult,
        claimItems: res.claimItems,
        relationshipDetails: res.relationshipDetails
      };
    });
    this.loadExistingDiagnosis(diagnosisCodes);
    return arr;
  }

  loadExistingDiagnosis(diagnosisCodes) {
    const removedDuplicates = diagnosisCodes.filter((value, index) => diagnosisCodes.indexOf(value) === index);

    this.apiCmsManagementService.searchDiagnosisByIcdCodes(removedDuplicates).subscribe(result => {
      if(result.statusCode === 'S0000') {
        this.exsistingCodes = result.payload;

        let missingCodes = [];

        removedDuplicates.forEach(code => {
          let codeEx = this.exsistingCodes.find(exCode => exCode.icd10Code === code);
          if (!codeEx) {
            missingCodes.push ( {
                id : code,
                icd10Id : code,
                snomedId : code,
                icd10Code : code,
                icd10Term : code,
                status : "ACTIVE",
                filterablePlanIds : [ ],
                invalidUsage : false
              } );            
          }
        });

        this.exsistingCodes = [...this.exsistingCodes, ...missingCodes];
        this.codes =  this.exsistingCodes;
        
      }
    }, error => {});
    
  }

  getHospitalCode(clinic) {
    const clinicData = this.store.getClinic(clinic);
    
    return clinicData['medisaveHospitalCode'] || '' ;
  }

  getRemark(claim) {
    const { submissionResult, claimResult } = claim;
    let remark = '';
    if (
      submissionResult &&
      submissionResult.statusCode &&
      claimResult &&
      claimResult.remark
    ) {
      // show claim result
      if (
        submissionResult.statusCode === 'OK' ||
        submissionResult.statusCode === 'Success'
      ) {
        remark = claim.remark;
      } else {
        remark =
          submissionResult.statusDescription &&
          submissionResult.statusDescription;
      }
    } else if (submissionResult && !claimResult) {
      remark =
        submissionResult.statusDescription &&
        submissionResult.statusDescription;
    } else if (!submissionResult && claimResult) {
      remark = claimResult.remark && claimResult.remark;
    }
    return remark;
  }

  mapFormGroupToClaimSave(formGroup: FormGroup): ClaimSave {
    let payerAddress: PayerAddress = {
      address: `${formGroup.get('payerAddress1').value}\n${formGroup.get('payerAddress2').value}`,
    };

    const patientNric = formGroup.get('patientNric').value;
    const payerNric = formGroup.get('payerNric').value;

    let dob = formGroup.get('payerDob').value ? moment(formGroup.get('payerDob').value).format(DISPLAY_DATE_FORMAT) : null || null;
    return new ClaimSave(
      formGroup.get('doctor').value,
      !payerNric ? patientNric : formGroup.get('payerNric').value,
      formGroup.get('payersName').value,
      formGroup.get('diagnosisCode').value,
      formGroup.get('HEcode').value,
      formGroup.get('claimAmt').value * 100,
      formGroup.get('claimRemarks').value,
      formGroup.get('claimedAmt').value * 100,
      formGroup.get('claimRefNo').value,
      formGroup.get('claimStatus').value,
      formGroup.get('payerIdType').value || null,
      formGroup.get('payerRelationship').value || null,
      dob,
      payerAddress
    );
  }

  mapRowToClaimSubmit(row: any): ClaimSubmit {
    return new ClaimSubmit(
      row.doctor,
      row.payerNric,
      row.payersName,
      row.diagnosisCode,
      row.claimAmt * 100,
      row.claimId
    );
  }

  onFilterInputChanged() {
    try {
      this.codesTypeahead
        .pipe(
          distinctUntilChanged((a, b) => b.trim().length === 0),
          debounceTime(400),
          tap(() => (this.diagnosisLoading = true)),
          switchMap((term: string) => {
            return this.apiCmsManagementService
              .searchDiagnosis(encodeURI(term), [], true)
              .pipe(
                catchError(error =>
                  of(<HttpResponseBody>{ page: {}, payload: '' })
                )
              );
          }),
          catchError(errors => of(<HttpResponseBody>{ page: {}, payload: '' }))
        )
        .subscribe(
          data => {
            this.diagnosisLoading = false;
            if (data) {
              this.codes = [...this.exsistingCodes, ...data.payload];
            }
          },
          err => {
            this.diagnosisLoading = false;
            if (err && err.error && err.error.message) {
              this.alertService.error(JSON.stringify(err.error.message));
            }
          }
        );
    } catch (err) {
      console.error('Search Diagnosis Error', err);
    }
  }

  getRowClass(row) {
    return {
      'is-align-top': true,
    };
  }

  getEditAccessControl(row) {
    return (
      row.status === 'REJECTED_PERMANENT' ||
      row.status === 'APPROVED' ||
      row.status === 'PAID' ||
      row.status === 'SUBMITTED'
    );
  }

  getSubmitAccessControl(row) {
    return (
      row.status === 'PENDING' ||
      row.status === 'FAILED' ||
      row.status === 'REJECTED'
    );
  }

  getChargePatientAccessControl(row) {
    return (
      row.status === 'SUBMITTED' ||
      row.status === 'PENDING' ||
      row.status === 'REJECTED' ||
      row.status === 'FAILED'
    );
  }
}

class ClaimSave {
  claimDoctorId: string;
  payersNric: string;
  payersName: string;
  diagnosisCodes: string[];
  clinicHeCode: string;
  expectedClaimAmount: number;
  claimRemarks: string;
  claimedAmount: number;
  claimRefNo: string;
  claimStatus: string;
  payerIdType: string;
  payerRelationship: string;
  payerDob: string;
  payerAddress: PayerAddress;
  constructor(
    claimDoctorId: string,
    payersNric: string,
    payersName: string,
    diagnosisCodes: string[],
    clinicHeCode: string,
    expectedClaimAmount: number,
    claimRemarks: string,
    claimedAmount: number,
    claimRefNo: string,
    claimStatus: string,
    payerIdType: string,
    payerRelationship: string,
    payerDob: string,
    payerAddress: PayerAddress,
  ) {
    this.claimDoctorId = claimDoctorId;
    this.payersNric = payersNric;
    this.payersName = payersName;
    this.diagnosisCodes = diagnosisCodes;
    this.clinicHeCode = clinicHeCode;
    this.expectedClaimAmount = expectedClaimAmount;
    this.claimRemarks = claimRemarks;
    this.claimedAmount = claimedAmount;
    this.claimRefNo = claimRefNo;
    this.claimStatus = claimStatus;
    this.payerIdType = payerIdType;
    this.payerRelationship = payerRelationship;
    this.payerDob = payerDob;
    this.payerAddress = payerAddress;
  }
}

class ClaimSubmit {
  doctorId: string;
  payerNric: string;
  payersName: string;
  diagnosisCodes: string[];
  claimAmount: number;
  claimId: string;
  constructor(
    doctorId?: string,
    payerNric?: string,
    payersName?: string,
    diagnosisCodes?: string[],
    claimAmount?: number,
    claimId?: string
  ) {
    this.doctorId = doctorId;
    this.payerNric = payerNric;
    this.payersName = payersName;
    this.diagnosisCodes = diagnosisCodes;
    this.claimAmount = claimAmount;
    this.claimId = claimId;
  }
}

class ClaimResult {
  referenceNumber: string;
  resultDateTime: string;
  amount: number;
  statusCode: string;
  constructor(
    referenceNumber?: string,
    resultDateTime?: string,
    amount?: number,
    statusCode?: string
  ) {
    this.referenceNumber = referenceNumber || '';
    this.resultDateTime = resultDateTime || '';
    this.amount = amount === undefined ? 0 : amount;
    this.statusCode = statusCode || '';
  }
}

class ClaimSubmissionResult {
  statusCode: string;
  statusDescription: string;

  constructor(statusCode?: string, statusDescription?: string) {
    this.statusCode = statusCode || '';
    this.statusDescription = statusDescription || '';
  }
}

class PayerAddress {
  address: string;

  constructor(address?: string) {
    this.address = address || '';
  }
}