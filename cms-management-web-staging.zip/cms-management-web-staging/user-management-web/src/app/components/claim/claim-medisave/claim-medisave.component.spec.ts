import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimMedisaveComponent } from './claim-medisave.component';

describe('ClaimMedisaveComponent', () => {
  let component: ClaimMedisaveComponent;
  let fixture: ComponentFixture<ClaimMedisaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimMedisaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimMedisaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
