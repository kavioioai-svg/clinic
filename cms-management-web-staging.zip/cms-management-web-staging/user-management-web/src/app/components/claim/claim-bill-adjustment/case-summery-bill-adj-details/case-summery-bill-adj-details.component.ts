import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService} from 'ngx-bootstrap';
import { GST } from '../../../../constants/app.constants';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl } from '@angular/forms';
import { Subject,} from 'rxjs';
import { StoreService } from '../../../../services/store.service';
import { MedicalCoverageQuery } from '../../../../state/medical-coverage/medical-coverage.query';
import { ApiDocumentService } from '../../../../services/api-document-service';
import { ApiPatientVisitService } from '../../../../services/api-patient-visit.service';
import { AdjustmentReasonQuery } from '../../../../state/adjustment-reason/adjustment-reason.query';
import moment = require('moment');
import { AlertService } from '../../../../services/alert.service';
import {BillAdjustmentStatus} from '../../../../objects/BillAdjustmentStatus';
import {BillAdjustmentLatest, InvoiceAdjEntities, PurchaseItemsAdj} from '../../../../objects/BillAdjustmentLatest';
import { UtilsService } from '../../../../services/utils.service';

@Component({
  selector: 'app-case-summery-bill-adj-details',
  templateUrl: './case-summery-bill-adj-details.component.html',
  styleUrls: ['./case-summery-bill-adj-details.component.scss']
})
export class CaseSummeryBillAdjDetailsComponent implements OnInit {

  primaryDoc;
  secondaryDoc;

  paymentMethodSelections = [
    { value: 'CASH', label: 'CASH' },
    { value: 'NETS', label: 'NETS' },
    { value: 'VISA', label: 'VISA' },
    { value: 'MASTER_CARD', label: 'MASTER CARD' },
    { value: 'AMERICAN_EXPRESS', label: 'AMERICAN EXPRESS' },
    { value: 'JCB', label: 'JCB' },
    { value: 'OTHER_CREDIT_CARD', label: 'OTHER CREDIT CARD' },
    { value: 'CHEQUE', label: 'CHEQUE' },
    { value: 'GIRO', label: 'GIRO' },
    { value: 'FAVEPAY', label: 'FAVEPAY' },
    { value: 'GRABPAY', label: 'GRABPAY' },
    { value: 'STRIPE', label: 'STRIPE' },
    { value: 'SHOPBACK', label: 'SHOPBACK' },
    { value: 'PAYNOW', label: 'PAYNOW' },
  ];
  paymentMethodSelectionsAddNew;

  private componentDestroyed: Subject<void> = new Subject();
  public event: EventEmitter<any> = new EventEmitter();
  billAdjustmentFormGroup: FormGroup;
  @Input() isEdit: boolean;
  @Input() billAdjItem: any;
  charges = 0;
  discount = 0;
  payableWithGST = 0;
  bsModalRefs: BsModalRef;
  currentChargeItems$;
  currentChargeItems = [];
  codesTypeahead = new Subject<string>();
  loading = false;
  drugId: FormControl;
  INPUT_DELAY_ITEM = 500;
  itemDetailedInfo;
  exsistingfiles= [];
  discountedInvoice:any[];
  reasonsList= [];
  billAdjReasonCodeStr: string;
  BillAdjustmentStatus = BillAdjustmentStatus;
  isBtnLoading: boolean;
  actionType: string;

  public failedMessage: string;

  constructor(
    public bsModalRef: BsModalRef,
    private akitaMedicalCoverageQuery: MedicalCoverageQuery,
    private fb: FormBuilder,
    private store: StoreService,
    private documentManagementService: ApiDocumentService,
    private apiPatientVisitService: ApiPatientVisitService,
    private adjustmentReasonQuery: AdjustmentReasonQuery,
    private alertService: AlertService,
    private modalService: BsModalService,
  ) { }

  ngOnInit() {
    this.reasonsList = this.adjustmentReasonQuery.getAll();
    this.initBillAdjustmentForm();
    this.getDiscount();
    this.setDocs();
    this.setReason();
    this.paymentMethodSelectionsAddNew = this.paymentMethodSelections.filter(method=> method.value !== 'CASH');
    this.loadSavedFiles(this.billAdjItem);
    
    this.apiPatientVisitService.getAllBillAdjustmentByCaseId(this.billAdjItem.caseId).subscribe({
      next: result => {
        this.billAdjItem.actionRemark = result.payload[0].actionRemark;
        this.setSelectedValuesToForm();
        this.failedMessage = result.payload[0].failedMsg;
      },
      error: error => {
        this.alertService.error(error.error.message);
      }
    });
  }

  getDiscount() {
    if(this.billAdjItem && this.billAdjItem.totalDiscount){
      this.discount = this.billAdjItem.totalDiscount;
      this.setChargesAndPayableAmt();
    }
  }

  setDocs() {
    if(this.billAdjItem && this.billAdjItem.primaryDoctorId){
      let pDoc = this.store.findDoctorById(this.billAdjItem.primaryDoctorId);
      if(pDoc){
        this.primaryDoc = pDoc.displayName;
      }
    }

    if(this.billAdjItem && this.billAdjItem.secondaryDoctorIds && this.billAdjItem.secondaryDoctorIds.length > 0){
      this.billAdjItem.secondaryDoctorIds.forEach(element => {
        let secDoc = this.store.findDoctorById(element);
        if(secDoc){
          if(this.secondaryDoc == undefined){
            this.secondaryDoc = secDoc.displayName;
          }else{
            this.secondaryDoc = this.secondaryDoc + ", " + secDoc.displayName;
          }
        }
      });
    }
  }

  setReason() {
    if(this.billAdjItem && this.billAdjItem.billAdjReasonCode){
      let reasonObj = this.reasonsList.find(reason => reason.value === this.billAdjItem.billAdjReasonCode);
      if(reasonObj){
        this.billAdjReasonCodeStr = reasonObj.label;
      }
    }
  }

  initBillAdjustmentForm() {
    this.billAdjustmentFormGroup = this.fb.group({
      purchaseItemsAdj: this.fb.array([]),
      packageAdjEntities: this.fb.array([]),
      invoiceAdjEntities: this.fb.array([]),
      primaryDoctorId: this.fb.control('', Validators.required),
      secondaryDoctorIds: this.fb.control(''),
      remark: this.fb.control('', Validators.required),
      actionRemark: this.fb.control('', Validators.required)
    })
  }

  setChargesAndPayableAmt() {
    this.charges = 0;
    this.payableWithGST = 0;
    let tempCharges = 0;
    this.billAdjustmentFormGroup.get('purchaseItemsAdj').value.forEach(i=> {
      tempCharges += +Number(i.soldPrice);
    });
    this.charges = +(tempCharges).toFixed(2);
    this.payableWithGST =  +((this.charges - this.discount) * UtilsService.getGST(this.billAdjItem.caseDate)).toFixed(2);
  }

  onChangeFinalAmt(){
    this.setChargesAndPayableAmt();
  }

  isShowingAdditionalPaymentMethod(){
    let isShowing = false;
    const formArray = this.billAdjustmentFormGroup.get('invoiceAdjEntities').value;
    if(formArray.length === 0){
      return false;
    }
    if(formArray.some(item=> item.invoiceType === 'DIRECT')){
      isShowing = false;
    } else{
      isShowing = true;
    }
    return false;
  }

  setSelectedValuesToForm(){
    if(this.billAdjItem){
      this.billAdjustmentFormGroup.get('primaryDoctorId').patchValue(this.billAdjItem.primaryDoctorId || '');
      this.billAdjustmentFormGroup.get('secondaryDoctorIds').patchValue(this.billAdjItem.secondaryDoctorIds);
      this.billAdjustmentFormGroup.get('remark').patchValue(this.billAdjItem.remark);
      this.billAdjustmentFormGroup.get('actionRemark').patchValue(this.billAdjItem.actionRemark);

      this.billAdjItem.purchaseItemsAdj.forEach(i=> {
        const purchaseItemsAdj = this.fb.group({
          itemRefId: i.itemRefId,
          soldPrice: Number(i.soldPrice / 100).toFixed(2),
          purchaseQty: i.purchaseQty,
          dispenseQty: i.dispenseQty,
          salesItemId: i.salesItemId,
          itemCode: i.itemCode,
          itemName: i.itemName,
          purchaseUom: i.salesUom,
        });
        const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
        formArray.push(purchaseItemsAdj);
      });

      this.billAdjItem.invoiceAdjEntities.forEach(i => {
        const paymentInfoArr = this.fb.array([]);
        i.paymentInfos.forEach(payInfo => {
          const paymentInfo = this.fb.group({
            billTransactionId: payInfo.billTransactionId,
            billMode: payInfo.billMode,
            amount: Number(payInfo.amount / 100).toFixed(2),
            invoiceNumber: payInfo.invoiceNumber,
          });
          paymentInfoArr.push(paymentInfo);
        });

        const invoiceAdjEntities = this.fb.group({
          visitId: i.visitId,
          invoiceId: i.invoiceId,
          invoiceType: paymentInfoArr.length > 0 ? "DIRECT" : "CREDIT",
          paymentInfos: paymentInfoArr,
          payableAmount: i.payableAmount,
          paidAmount: Number(i.paidAmount / 100).toFixed(2),
          planId: i.planId,
          coverageName: i.coverageName
        });
        const formArray = <FormArray>this.billAdjustmentFormGroup.get('invoiceAdjEntities');
        formArray.push(invoiceAdjEntities);
      });
    }

    this.setChargesAndPayableAmt()
  }

  trackById(index: number, item: any) {
    return item.itemRefId;
  }

  trackByInvoiceId(index: number, item: any) {
    return item.invoiceId;
  }

  trackByPaymentInfo(index: number, item: any) {
    return item.invoiceNumber;
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  getMedicalCoverage(planId) {
    const medicalCoverage = this.store.getMedicalCoverageByPlanId(planId);
    return medicalCoverage;
  }

  getMedicalCoveragePlan(planId) {
    return this.akitaMedicalCoverageQuery.getMedicalCoveragePlan(planId);
  }

  closeModal() {
    this.bsModalRef.hide();
  }

  getReqPayload(): any {
    const purchaseItemsAdj = [];
    this.billAdjustmentFormGroup.get('purchaseItemsAdj').value.forEach(i=> {
      const pItem = {
        itemRefId: i.itemRefId,
        soldPrice: +Number(i.soldPrice *100),
        purchaseQty: i.purchaseQty,
        dispenseQty: i.dispenseQty,
        salesItemId: i.salesItemId,
      };
      purchaseItemsAdj.push(pItem);
    });

    const invoiceAdjEntities = [];
    this.billAdjustmentFormGroup.get('invoiceAdjEntities').value.forEach(i => {
      const paymentInfoArr = [];
      let newPaidAmt = 0;
      let newPayableAmt = 0;
      if(i.planId !== null){
        newPaidAmt = +Number(i.paidAmount * 100).toFixed(0);
        newPayableAmt = +Number(i.paidAmount * 100).toFixed(0);
      }
      i.paymentInfos.forEach(payInfo => {
        const paymentInfo = {
          billTransactionId: payInfo.billTransactionId,
          billMode: payInfo.billMode,
          amount: +Number(payInfo.amount * 100),
          invoiceNumber: payInfo.invoiceNumber,
        };
        newPaidAmt += +Number(payInfo.amount * 100).toFixed(0);
        newPayableAmt += +Number(payInfo.amount * 100).toFixed(0);
        paymentInfoArr.push(paymentInfo);
      });

      const invoiceItem = {
        visitId: i.visitId,
        invoiceId: i.invoiceId,
        claimExpectedAmt: i.claim && Number(i.claim.claimExpectedAmt).toFixed(2) ,
        paymentInfos: paymentInfoArr,
        payableAmount: newPayableAmt,
        paidAmount: newPaidAmt,
        planId: i.planId
      };
      invoiceAdjEntities.push(invoiceItem);
    });

    let reqObj = {
      purchaseItemsAdj: purchaseItemsAdj,
      invoiceAdjEntities: invoiceAdjEntities,
      packageAdjEntities: [],
      primaryDoctorId: this.billAdjustmentFormGroup.get('primaryDoctorId').value,
      secondaryDoctorIds: this.billAdjustmentFormGroup.get('secondaryDoctorIds').value,
      remark: this.billAdjustmentFormGroup.get('remark').value,
      actionRemark: this.billAdjustmentFormGroup.get('actionRemark').value,
    }
    return reqObj;
  }

  addNewItem(){
    const purchaseItemsAdj = this.fb.group({
      itemRefId: ['', Validators.required],
      soldPrice: 0,
      purchaseQty: 0,
      dispenseQty: 0,
      salesItemId: '',
      itemCode: '',
      itemName: '',
      purchaseUom: '',
      isNew: true
    });
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
    formArray.push(purchaseItemsAdj);
  }

  onDiagnosisSelected(event, i){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');

    let item = formArray.controls[i];
    item.get('itemName').patchValue(event.name);
    item.get('purchaseQty').patchValue(event.dosageQty || 1);
    item.get('purchaseUom').patchValue(event.salesUom);
  }

  isValidItemForm(){
    return this.billAdjustmentFormGroup.get('purchaseItemsAdj').status === 'VALID';
  }

  onbtnDeleteClicked(item){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
    formArray.removeAt(formArray.value.findIndex(i=> i.itemRefId === item.itemRefId));
    this.setChargesAndPayableAmt();
  }

  onbtnNewItemDeleteClicked(index){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('invoiceAdjEntities');
    const directMethods = formArray.controls.find(item => item.get('invoiceType').value === 'DIRECT');
    if(directMethods){
      let paymentInfoArr = <FormArray>directMethods.get('paymentInfos');
      paymentInfoArr.removeAt(index);
    }
  }

  loadSavedFiles(billAdjItem?: any){
    if (billAdjItem) {
    let patientID = billAdjItem.patientId;
    this.exsistingfiles = [];
    this.store.getClinicList()[0].id;
    this.documentManagementService
      .getAllFilesInBillMangement(patientID, billAdjItem.billAdjId , this.store.getClinicList()[0].id)
      .subscribe(documents => {
        this.exsistingfiles = documents.filter(document => document.description.includes(billAdjItem.billAdjId));
      },
      err => {
      });
    }
  }

  public onDocumentClicked(file): void {
    this.documentManagementService.downloadDocumentToLocal(file, this.billAdjItem.patientId, this.store.getClinicList()[0].id);
  }

  onApprovalReject() {
    this.isBtnLoading = true;
    this.populateApprovalFormValue();
    this.apiPatientVisitService.billAdjustmentApprovalRejection(this.actionType,
      {...this.billAdjustmentFormGroup.value, secondaryDoctorIds: []} , this.billAdjItem).subscribe(
      res => {
        this.isBtnLoading = false;
        this.modalService.setDismissReason(res.payload);
        this.bsModalRef.hide();
      },
      err => this.alertService.error(JSON.stringify(err.error.message))
    )
  }
   populateApprovalFormValue() {
     let obj: InvoiceAdjEntities[] = [], pa: PurchaseItemsAdj[] = [];
     const data = <any>this.billAdjustmentFormGroup.getRawValue();

     data.purchaseItemsAdj.map((a) => a.soldPrice = parseFloat(a.soldPrice) * 100)
     data.invoiceAdjEntities.forEach((bill) => {
       obj.push(new InvoiceAdjEntities(bill));
     });
     this.billAdjustmentFormGroup.patchValue({
       secondaryDoctorIds: this.secondaryDoc,
       billAdjReasonCode: this.billAdjReasonCodeStr,
       invoiceAdjEntities: obj,
       purchaseItemsAdj: data.purchaseItemsAdj,
     })
  }
}
