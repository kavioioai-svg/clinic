import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseSummeryBillAdjDetailsComponent } from './case-summery-bill-adj-details.component';

describe('CaseSummeryBillAdjDetailsComponent', () => {
  let component: CaseSummeryBillAdjDetailsComponent;
  let fixture: ComponentFixture<CaseSummeryBillAdjDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseSummeryBillAdjDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseSummeryBillAdjDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
