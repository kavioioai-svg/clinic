import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimBillAdjustmentComponent } from './claim-bill-adjustment.component';

describe('ClaimBillAdjustmentComponent', () => {
  let component: ClaimBillAdjustmentComponent;
  let fixture: ComponentFixture<ClaimBillAdjustmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimBillAdjustmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimBillAdjustmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
