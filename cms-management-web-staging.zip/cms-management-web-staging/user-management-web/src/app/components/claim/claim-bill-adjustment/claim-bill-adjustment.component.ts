import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import moment = require('moment');
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Subject } from 'rxjs';
import { DISPLAY_DATE_FORMAT, DB_FULL_DATE_FORMAT } from '../../../constants/app.constants';
import { Page } from '../../../model/page';
import { Clinic } from '../../../objects/response/Clinic';
import { AlertService } from '../../../services/alert.service';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { StoreService } from '../../../services/store.service';
import { ClinicQuery } from '../../../state/clinic/clinic.query';
import { validateOrder } from '../../../validators/claim-payment-validator';
import { CaseSummeryBillAdjDetailsComponent } from './case-summery-bill-adj-details/case-summery-bill-adj-details.component';
import {BillAdjustmentStatus} from '../../../objects/BillAdjustmentStatus';
import {StockTakeApproveStatus} from '../../../objects/StockTakeApproveStatus';

@Component({
  selector: 'app-claim-bill-adjustment',
  templateUrl: './claim-bill-adjustment.component.html',
  styleUrls: ['./claim-bill-adjustment.component.scss']
})
export class ClaimBillAdjustmentComponent implements OnInit {

  searchStatusList = [
    'ALL',
    'SUBMITTED',
    'PENDING',
    'CANCELLED',
    'APPROVED',
    'REJECTED'
  ];

  clinics: Array<Clinic>;
  searchFormGroup: FormGroup;
  page = new Page();
  rows: any[] = [];
  maxDate = null;
  bsModalRef: BsModalRef;
  clinicGroups: any;
  groupedClinics: any;

  private componentDestroyed: Subject<void> = new Subject();
  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private store: StoreService,
    private apiPatientVisitService: ApiPatientVisitService,
    private router: Router,
    private bsModalService: BsModalService,
    private clinicQuery: ClinicQuery,
  ) { }

  ngOnInit() {
    this.newSearchFormGroup();
    this.populateData();
    this.onSearchRefundClicked();
    this.maxDate = new Date();
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  private populateData() {
    this.clinicQuery.selectAll().subscribe((data) => {
      this.clinics = data
      this.groupClinics();
    });
    // const clinicId = this.searchFormGroup.get('clinicIds').value;
    // this.searchFormGroup.get('clinicId').patchValue(clinicId && [clinicId]);
    const startDateControl = this.searchFormGroup.get('startDate');
    const endDateControl = this.searchFormGroup.get('endDate');

    this.searchFormGroup.get('startDate').setValidators(
      validateOrder(startDateControl, endDateControl, true)
    )

    this.searchFormGroup.get('endDate').setValidators(
      validateOrder(startDateControl, endDateControl, false)
    )

  }

  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      caseNumber: [],
      patientName: [],
      status: ["ALL"],
      clinicGroups: [],
      startDate: [
        moment()
          .subtract(1, 'month')
          .format(DISPLAY_DATE_FORMAT),
        Validators.required,
      ],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicIds: [[], Validators.required],
      clinicId: [],
    });
  }

  getMaxStartDate() {
    return moment(this.searchFormGroup.get('endDate').value).toDate();
  }

  onSearchRefundClicked(){
    const fromDate = moment(
      this.searchFormGroup.get('startDate').value,
      'DD-MM-YYYY'
    ).startOf('day').format(DB_FULL_DATE_FORMAT);
    const toDate = moment(
      this.searchFormGroup.get('endDate').value,
      'DD-MM-YYYY'
    ).endOf('day').format(DB_FULL_DATE_FORMAT);
    const caseNumber = this.searchFormGroup.get('caseNumber').value;
    const patientName = this.searchFormGroup.get('patientName').value;
    const clinicId = '7946546431313465465464';
    const status =  this.searchFormGroup.get('status').value &&  this.searchFormGroup.get('status').value != 'ALL' ?
                    this.searchFormGroup.get('status').value: '' ;
    const clinicIds = this.searchFormGroup.get('clinicIds').value;
    let req = {
      name: patientName,
      caseNumber: caseNumber,
      fromDate: fromDate,
      toDate: toDate,
      status: status,
      clinics: [...clinicIds],
    }

    //if(clinicIds){
      this.apiPatientVisitService.getAllBillAdjustments( 0 ,100, req)
        .subscribe( res => {
          if(res.statusCode === 'S0000'){
            this.rows = res.payload && res.payload.content;
            this.rows.forEach(element => {
              this.apiPatientVisitService.getAllBillAdjustmentByCaseId(element.caseId).subscribe({
                next: result => {
                 if(result.payload[0].actionRemark){
                  element.actionRemark = result.payload[0].actionRemark;
                 }else{
                  element.actionRemark = '';
                 }
                
                },
                error: error => {
                  this.alertService.error(error.error.message);
                }
              });
            })
          } else{
            this.alertService.error('Error occured while getting data');
          }
        },
        err => this.alertService.error(JSON.stringify(err.error.message)));
      }
 // }

  openApproveRejectModal(billAdjItem?: any , actionType?: string){
    billAdjItem.remark = billAdjItem.billAdjRemarks;

    const initialState = {
      isEdit: false,
      actionType: actionType,
      billAdjItem: billAdjItem
    };

    this.bsModalRef = this.bsModalService.show(
      CaseSummeryBillAdjDetailsComponent,
      {
        initialState,
        class: 'modal-lg'
      }
    );

    this.bsModalService.onHide.subscribe((element) => {
      if(element && element.length > 0) {
        let index = this.rows.findIndex(x => x.caseId === element[0].caseId);
        if(index  -1){
          this.rows[index] = element[0];
          this.rows =[...this.rows];
        }
      }
      this.onSearchRefundClicked();
    });
  }

  onClinicGroupSelect(event) {
    if (event) {
      // reset all clinics
      this.searchFormGroup.get('clinicIds').patchValue([]);
      // select all clinics
      const clinics = [];
      event.forEach((element) => {
        this.groupedClinics[element].forEach((clinic) => {
          clinics.push(clinic.id);
        });
      });
      this.searchFormGroup.get('clinicIds').patchValue(clinics);
    }
  }

  onClinicSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      // this.onDrugInputChanged();
    }
  }

  get BillAdjustmentStatus() {
    return BillAdjustmentStatus
  }


  getStatusClass(billAdjStatus: any) {
    let status = '';
      switch (billAdjStatus) {
        case BillAdjustmentStatus.SUBMITTED:
          status = `bg-orangey-yellow`;
          break;
        case BillAdjustmentStatus.APPROVED:
          status = `bg-bluish-green `;
          break;
        case BillAdjustmentStatus.REJECTED:
          status = `bg-lipstick `;
          break;
        case BillAdjustmentStatus.PENDING:
          status = `bg-black`;
          break;
        default:
          status = '';
      }
      return status;
    }

}
