import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, AbstractControl, FormControl, Validators } from '@angular/forms';
import { takeUntil, distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { cloneDeep } from 'lodash'
import { ChargeItemQuery } from '../../../../../state/charge-item/charge-item.query';
import { AdjustmentReasonQuery } from '../../../../../state/adjustment-reason/adjustment-reason.query';

@Component({
  selector: 'app-refund-item',
  templateUrl: './refund-item.component.html',
  styleUrls: ['./refund-item.component.scss']
})
export class RefundItemComponent implements OnInit {
  @Input() itemFormGroup: FormGroup;
  @Input() itemFormGroupInitial: FormGroup;

  batchNo: AbstractControl;
  expiryDate: AbstractControl;
  itemRefId: AbstractControl;
  isSelected: AbstractControl;
  purchaseQty: AbstractControl;
  purchaseUom: AbstractControl;
  oriTotalPrice: AbstractControl;
  refundAmt: AbstractControl;
  refundQty: AbstractControl;
  refundedQty: AbstractControl;
  refundReason: AbstractControl;

  initialQty;
  initialAmt;
  initialReason;

  
  reasonsList= [];

  // RefundAmtinDollars act as a standalone FormControl from FormGroup to mediate conversion of input
  // from string type and dollar unit to patch to refundAmt as int type and cents
  refundAmtInDollars: AbstractControl;
  unitPrice: AbstractControl;

  constructor(
    private chargeItemQuery: ChargeItemQuery,
    private adjustmentReasonQuery: AdjustmentReasonQuery
  ) { }

  ngOnInit() {
    this.reasonsList = this.adjustmentReasonQuery.getAll();
    this.initialiseValues();
    this.subscribeOnChanges();
    this.initialQty = cloneDeep(this.itemFormGroup.get('refundQty').value);
    this.initialAmt = cloneDeep(this.itemFormGroup.get('refundAmt').value);
    this.initialReason = cloneDeep(this.itemFormGroup.get('refundReason').value);
  }

  initialiseValues(){
    const get = (key: string) => this.itemFormGroup.get(key);

    this.batchNo = get('batchNo');
    this.expiryDate = get('expiryDate');
    this.itemRefId = get('itemRefId');
    this.isSelected = get('isSelected');
    this.refundedQty = get('refundedQty');
    this.purchaseQty = get('purchaseQty');
    this.purchaseUom = get('purchaseUom');
    this.oriTotalPrice = get('oriTotalPrice');
    this.refundAmt = get('refundAmt');
    this.refundQty = get('refundQty');
    this.refundReason = get('refundReason');
    this.refundAmtInDollars = get('refundAmtInDollars');
    this.unitPrice = get('sellingPrice').get('price');
    let reasonStr = this.getReason(get('refundReason').value);
    this.itemFormGroup.get('refundReason').patchValue(cloneDeep(reasonStr ? reasonStr: get('refundReason').value));
  }

  getReason(reasoncode) {
      let reasonObj = this.reasonsList.find(reason => reason.value === reasoncode);
      if(reasonObj){
        return reasonObj.label;
      }
    return null;
  }

  subscribeOnChanges(){
    this.isSelected
      .valueChanges
      .pipe(  
        distinctUntilChanged()
    ).subscribe(value =>{
      if(!value){
        this.itemFormGroup.get('refundQty').patchValue(cloneDeep(this.initialQty));
        this.itemFormGroup.get('refundAmt').patchValue(cloneDeep(this.initialAmt));
        this.itemFormGroup.get('refundReason').patchValue(cloneDeep(this.initialReason));
        this.initialiseValues();
      }
      // this.setValidations();
      this.allowEditing();
    });

    this.refundQty
      .valueChanges
      .pipe(
        distinctUntilChanged()
      )
      .subscribe( qty =>{
        if(qty <= this.purchaseQty.value){
          const refundAmt = qty * this.unitPrice.value;
          this.refundAmtInDollars.patchValue( refundAmt / 100 );
        }
      });

    
    this.refundAmtInDollars
      .valueChanges
      .pipe(
        //  debounceTime(500),
         distinctUntilChanged()
      )
      .subscribe( value =>{
        if( (value * 100 ) <= this.oriTotalPrice.value){
          this.refundAmtInDollars.patchValue(Number(value).toFixed(2), { emitEvent: false });
          this.refundAmt.patchValue(Number(value) * 100);
        }
      });

  }

  allowEditing(){
    const enable = (x: AbstractControl) => x.enable({emitEvent: false});
    const disable = (x: AbstractControl) => x.disable({emitEvent: false});

    let operator = this.isSelected.value ? enable : disable;

    operator(this.refundAmt);
    operator(this.refundQty);
    operator(this.refundReason);
    operator(this.refundAmtInDollars);
  }

  getItem(id){
    return this.chargeItemQuery.getItemById(id)? this.chargeItemQuery.getItemById(id).code : '';
  }

  // setValidations(){
  //   if(this.isSelected.value){
  //     this.refundAmtInDollars.setValidators(
  //       [validateRefundAmtOnItem(this.oriTotalPrice.value, false), Validators.required]
  //     );
  //     this.refundAmtInDollars.markAsTouched();

  //     this.refundQty.setValidators(
  //       [validateRefundQty(this.purchaseQty.value), Validators.required]
  //     );
  //     this.refundQty.markAsTouched();

  //   } else {
  //     this.refundAmt.clearValidators();
  //     this.refundAmtInDollars.clearValidators();
  //     this.refundQty.clearValidators();
  //   }
  // }


}
