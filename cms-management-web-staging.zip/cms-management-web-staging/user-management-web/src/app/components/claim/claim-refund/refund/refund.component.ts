import { Location } from '@angular/common';
import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, Input, ChangeDetectorRef } from '@angular/core';
import { FormGroup, AbstractControl, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { cloneDeep } from 'lodash';
import moment = require('moment');
import { Subject } from 'rxjs';
import { takeUntil, distinctUntilChanged } from 'rxjs/operators';
import { ApiDocumentService } from '../../../../services/api-document-service';
import { ApiPatientVisitService } from '../../../../services/api-patient-visit.service';
import { CaseRefundService } from './case-refund.service';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RefundComponent implements OnInit, OnDestroy {
  isEdit: boolean = false;
  @Input() historyRefundItem: any = null;
  checkAllValue: boolean = false;
  refundFormGroup: FormGroup;
  initialForm: FormGroup;
  displayBreakdown: boolean = false;
  isDisabled: boolean = false;

  purchaseItems$;
  invoices$;
  caseId$;

  totalInCentsWithoutGst: number = 0;
  totalGst: number;
  dataLoaded: boolean= false;

  // fileUploader: FileUploader;
  isRequesting$: Subject<boolean> = new Subject<boolean>();

  enableSubmit: AbstractControl;
  selectedItemsTotalChargeWithGst: AbstractControl;

  private componentDestroyed: Subject<void> = new Subject();
  state: any;
  caseID: any;
  refundId:any
  exsistingfiles: any;
  refundData: any;

  constructor(
    private caseRefundService: CaseRefundService,
    private apiPatientVisitService: ApiPatientVisitService,
    private router: Router,
    private location: Location,
    public activatedRoute: ActivatedRoute,
    public documentManagementService: ApiDocumentService,
    private cd: ChangeDetectorRef
  ) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation) {
      this.state = navigation.extras.state as {
        refundedDetails: any;
      };
    }

    if (this.activatedRoute.params) {
      this.activatedRoute.params.pipe(
        ).subscribe(params => {
          this.caseID = (params['caseID']);
          this.refundId=(params['refundID']);
        });
    }
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  ngOnInit() {
    if ((this.state && this.state.caseId) || this.caseID) {
      let caseid = (this.state && this.state.caseId) ? this.state.caseId : this.caseID;
      this.apiPatientVisitService.getCaseDetailsById(caseid).subscribe((res) => {
        if (res.statusCode === 'S0000') {
          if (!this.refundFormGroup) {           
            if (this.caseID) {
              this.getRefund(res);
            } else {

              let refundedDetails;
              if (this.historyRefundItem) {
                // view history item
                refundedDetails = this.historyRefundItem;
                this.refundData = refundedDetails;
                this.getDocument(refundedDetails, res);
              } else {
                // claim > refund
                if (this.state && this.state.refundedDetails) {
                  refundedDetails = this.state.refundedDetails;
                  this.refundData = refundedDetails;
                  this.getDocument(refundedDetails, res);
                }
              }
            }
          }
        }
      });
    }    
  }

  formCreate (res) {    
    this.refundFormGroup = this.caseRefundService.createRefundFormGroup(res.payload.salesOrder);
    this.initialForm = cloneDeep(this.refundFormGroup);
    this.initialise();
    this.subscribeOnFormChanges();

  }

  initialise() {
    const get = (key: string) => this.refundFormGroup.get(key);
    this.selectedItemsTotalChargeWithGst = get('selectedItemsTotalChargeWithGst');
    this.enableSubmit = get('enableSubmit');
    if (!this.isEdit) {
      this.refundFormGroup.disable();
      this.setRefundedDetails();
    }
  }

  getRefund(caseData) {
    this.apiPatientVisitService.getUniqueRefund(this.refundId, {}).subscribe(
      (res) => {
        this.historyRefundItem = res.payload; 
        this.refundData = this.historyRefundItem;    
        this.getDocument(this.historyRefundItem,caseData);
      }
    );
  }

  setRefundedDetails() {
    let refundedDetails;
    if (this.historyRefundItem) {
      // view history item
      refundedDetails = this.historyRefundItem;
      this.updateFormGroup(refundedDetails);
    } else {
      // claim > refund
      if (this.state && this.state.refundedDetails) {
        refundedDetails = this.state.refundedDetails;
        this.updateFormGroup(refundedDetails);
      }
    }
    
  }
  
  getDocument(refundedDetails, res) {
    if (refundedDetails) {
      let patientID = refundedDetails.patientId;
      this.exsistingfiles = [];
      this.documentManagementService
        .getAllFilesInBillMangement(patientID, refundedDetails.id, refundedDetails.clinicId)
        .subscribe(documents => {
          this.exsistingfiles = documents.filter(document => document.description.includes(refundedDetails.id));
          this.formCreate(res);
          this.dataLoaded = true;
          this.cd.detectChanges();
        },
        err => {
          this.formCreate(res);
          this.dataLoaded = true;
          this.cd.detectChanges();
        });
      }
  }

  updateFormGroup(refundedDetails) {

    const refundItems: FormArray = <FormArray>this.refundFormGroup.get('refundItems');
    let deleteRefArr = [];

    refundItems.controls.forEach((control, index) => {
      let selectedItem =
        refundedDetails &&
        refundedDetails.refundItems.find((item) => item.salesItem.itemRefId === control.get('itemRefId').value);
      if (selectedItem) {
        control.get('refundAmtInDollars').patchValue((selectedItem.refundAmount / 100).toFixed(2));
        control.get('refundQty').patchValue(selectedItem.returnQty);
        control.get('refundReason').patchValue(selectedItem.reason);
      } else {
        deleteRefArr.push(control.get('itemRefId').value);
      }
    });
    if (this.refundFormGroup.get('refundBreakdownFormGroup')) {
      this.refundFormGroup
        .get('refundBreakdownFormGroup')
        .get('remarks')
        .patchValue(refundedDetails && refundedDetails.remarks);
      this.refundFormGroup
        .get('refundBreakdownFormGroup')
        .get('accountNumber')
        .patchValue(refundedDetails && refundedDetails.accountNumber);
      this.refundFormGroup
        .get('refundBreakdownFormGroup')
        .get('accountDetails')
        .patchValue(refundedDetails && refundedDetails.accountDetails);
      this.refundFormGroup
        .get('refundBreakdownFormGroup')
        .get('cardNumberLast4Digits')
        .patchValue(refundedDetails && refundedDetails.cardNumberLast4Digits);
      this.refundFormGroup
        .get('refundBreakdownFormGroup')
        .get('refundableAmountTotal')
        .patchValue(refundedDetails && refundedDetails.totalRefundAmount);
    }

    const refundInvoices = refundedDetails && refundedDetails.refundInvoices;
    if (refundInvoices && refundInvoices.length > 0) {
      const paymentInfosPerInvoiceArray: FormArray = (<FormArray>(
        this.refundFormGroup.get('refundBreakdownFormGroup').get('paymentInfosPerInvoiceArray')
      )) as FormArray;
      paymentInfosPerInvoiceArray.controls.forEach((control: FormGroup) => {
        const paymentInfoArray: FormArray = control.get('paymentInfoArray') as FormArray;
        paymentInfoArray.controls.forEach((cont) => {
          let refItem = refundInvoices.find((it) => it.refundMode === cont.get('billMode').value);
          if (refItem) {
            cont
              .get('refundAmountInDollars')
              .patchValue(refItem.refundableAmount && (refItem.refundableAmount / 100).toFixed(2));
            cont.get('clinicRefundedAmount').patchValue(refItem.refundedAmountByClinic);
            cont
              .get('clinicRefundedAmountInDollars')
              .patchValue(refItem.refundedAmountByClinic && (refItem.refundedAmountByClinic / 100).toFixed(2));
          }
        });
      });
    }

    deleteRefArr.forEach((element) => {
      refundItems.removeAt(refundItems.value.findIndex((item) => item.itemRefId === element));
    });
    if (refundedDetails) {
      this.totalGst = refundedDetails && refundedDetails.taxRefundAmount;
      this.totalInCentsWithoutGst = refundedDetails.totalRefundAmount - refundedDetails.taxRefundAmount;
    }
  }

  subscribeOnFormChanges() {
    this.refundFormGroup
      .get('refundItems')
      .valueChanges.pipe(
        distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
        takeUntil(this.componentDestroyed)
      )
      .subscribe((items) => {
        const enableSubmit = items.some((item) => item.isSelected);
        this.enableSubmit.patchValue(enableSubmit, { emitEvent: false });

        this.totalInCentsWithoutGst = items.reduce((total, item) => {
          if (item.isSelected) {
            total += item.refundAmt;
          }
          return total;
        }, 0);

        this.totalGst = Math.round(Number(this.totalInCentsWithoutGst * 0.07));
        this.selectedItemsTotalChargeWithGst.setValue(this.totalGst + this.totalInCentsWithoutGst, {
          emitEvent: false,
        });
      });

    this.refundFormGroup.get('refundBreakdownFormGroup').valueChanges.subscribe((value) => {
      if (
        value.refundableAmountTotal > this.selectedItemsTotalChargeWithGst.value ||
        value.clinicRefundableTotal > 5000 ||
        !this.refundFormGroup.valid
      ) {
        this.enableSubmit.patchValue(false, { emitEvent: false });
      } else {
        this.enableSubmit.patchValue(true, { emitEvent: false });
      }
    });
  }

  onCheckAll() {
    if (this.checkAllValue) {
      const refundItems: FormArray = <FormArray>this.refundFormGroup.get('refundItems');
      refundItems.controls.forEach((control) => {
        if (control.get('refundedQty').value === 0) {
          control.get('isSelected').patchValue(this.checkAllValue);
        }
      });
    } else {
      this.resetToInitial();
    }
  }

  resetToInitial() {
    this.refundFormGroup = cloneDeep(this.initialForm);
    this.initialise();
    this.totalGst = 0;
    this.totalInCentsWithoutGst = 0;
    this.subscribeOnFormChanges();
  }

  showBreakdown() {
    this.displayBreakdown = true;
    this.isDisabled = true;
    const refundItems: FormArray = <FormArray>this.refundFormGroup.get('refundItems');
    refundItems.controls.forEach((control) => {
      control.disable({ emitEvent: false });
    });
  }

  onCancelClicked() {
    this.displayBreakdown = false;
    this.checkAllValue = false;
    this.isDisabled = false;
    this.resetToInitial();
  }

  onSubmitClicked() {}

  onFileSelected(event) {
    this.refundFormGroup.get('documents').setValue(event.target.files, { emitEvent: false });
  }

  uploadDoc() {}

  isNoRemainingAmountLeft() {
    let state = false;
    let refAmount =
      this.refundFormGroup.get('refundBreakdownFormGroup') &&
      this.refundFormGroup.get('refundBreakdownFormGroup').get('refundableAmountTotal').value;
    if (this.selectedItemsTotalChargeWithGst.value === refAmount) {
      state = true;
    }
    return state;
  }

  onBackClicked() {
    this.location.back();
  }

  public onDocumentClicked(file): void {
    this.documentManagementService.downloadDocumentToLocal(file, this.refundData.patientId, this.refundData.clinicId);
  }
}
