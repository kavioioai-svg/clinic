import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RefundPaymentItemComponent } from './refund-payment-item.component';

describe('RefundPaymentItemComponent', () => {
  let component: RefundPaymentItemComponent;
  let fixture: ComponentFixture<RefundPaymentItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RefundPaymentItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RefundPaymentItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
