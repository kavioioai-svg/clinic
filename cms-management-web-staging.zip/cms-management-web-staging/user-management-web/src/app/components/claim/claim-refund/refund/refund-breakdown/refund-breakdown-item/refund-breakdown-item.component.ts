import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, Form, FormArray, AbstractControl, FormControl } from '@angular/forms';

@Component({
  selector: 'app-refund-breakdown-item',
  templateUrl: './refund-breakdown-item.component.html',
  styleUrls: ['./refund-breakdown-item.component.scss']
})
export class RefundBreakdownItemComponent implements OnInit {
  @Input() formGroup: FormGroup;
  approvalRequired: boolean = false;
  
  constructor() { }

  ngOnInit() {
  }
}
