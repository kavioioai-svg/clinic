import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Page } from '../../../model/page';
import { Clinic } from '../../../objects/response/Clinic';
import { AlertService } from '../../../services/alert.service';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { StoreService } from '../../../services/store.service';
import moment = require('moment');
import { DISPLAY_DATE_FORMAT, DB_FULL_DATE_FORMAT } from '../../../constants/app.constants';
import { validateOrder } from '../../../validators/claim-payment-validator';
import { NavigationExtras, Router } from '@angular/router';
import { ClinicQuery } from '../../../state/clinic/clinic.query';

@Component({
  selector: 'app-claim-refund',
  templateUrl: './claim-refund.component.html',
  styleUrls: ['./claim-refund.component.scss'],
})
export class ClaimRefundComponent implements OnInit {
  clinics: Array<Clinic>;
  searchFormGroup: FormGroup;
  page = new Page();
  rows: any[] = [];
  maxDate = null;
  clinicGroups: any;
  groupedClinics: any;

  searchStatusList = [
    'ALL',
    'SUBMITTED',
    'PENDING_APPROVAL',
    'APPROVED',
    'REJECTED',
    'REFUNDED'
  ];

  private componentDestroyed: Subject<void> = new Subject();
  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private store: StoreService,
    private apiPatientVisitService: ApiPatientVisitService,
    private router: Router,
    private clinicQuery: ClinicQuery,
  ) {}

  ngOnInit() {
    this.newSearchFormGroup();
    this.populateData();
    this.onSearchRefundClicked();
    this.maxDate = new Date();
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  private populateData() {
    this.clinicQuery.selectAll().subscribe((data) => {
      this.clinics = data
      this.groupClinics();
    });
    const clinicId = this.searchFormGroup.get('clinicId').value;
    this.searchFormGroup.get('clinicId').patchValue(clinicId && [clinicId]);
    const startDateControl = this.searchFormGroup.get('startDate');
    const endDateControl = this.searchFormGroup.get('endDate');

    this.searchFormGroup.get('startDate').setValidators(validateOrder(startDateControl, endDateControl, true));

    this.searchFormGroup.get('endDate').setValidators(validateOrder(startDateControl, endDateControl, false));


  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      caseNumber: [],

      patientName: [],
      status: ["ALL"],
      clinicGroups: [],
      clinicId: [],
      startDate: [moment().subtract(1, 'month').format(DISPLAY_DATE_FORMAT), Validators.required],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicIds: [[], Validators.required],
    });
  }

  getMaxStartDate() {
    return moment(this.searchFormGroup.get('endDate').value).toDate();
  }

  onSearchRefundClicked() {
    const fromDate = moment(this.searchFormGroup.get('startDate').value, 'DD-MM-YYYY')
      .startOf('day')
      .format(DB_FULL_DATE_FORMAT);
    const toDate = moment(this.searchFormGroup.get('endDate').value, 'DD-MM-YYYY')
      .endOf('day')
      .format(DB_FULL_DATE_FORMAT);
    const caseNumber = this.searchFormGroup.get('caseNumber').value;
    const patientName = this.searchFormGroup.get('patientName').value;
    const clinicId = this.searchFormGroup.get('clinicId').value;
    const status = this.searchFormGroup.get('status').value &&  this.searchFormGroup.get('status').value != 'ALL' ?
                    this.searchFormGroup.get('status').value: '' ;
    const clinicIds = this.searchFormGroup.get('clinicIds').value;

    let req = {
      name: patientName,
      caseNumber: caseNumber,
      fromDate: fromDate,
      toDate: toDate,
      clinics:clinicIds,
      status:status
    };

    if (clinicIds) {
      this.apiPatientVisitService.getRefunds(0, 100, req).subscribe(
        (res) => {
          this.rows = res.payload;
          this.rows = this.rows.sort((a, b) => {
            const date1 = moment(a.caseStartDateTime, DISPLAY_DATE_FORMAT);
            const date2 = moment(b.caseStartDateTime, DISPLAY_DATE_FORMAT);

            if (date1.isBefore(date2)) {
              return 1;
            }
            if (date1.isAfter(date2)) {
              return -1;
            }

            // equal
            return 0;
          });
        },
        (err) => this.alertService.error(JSON.stringify(err.error.message))
      );
    }
  }

  goToRefund(caseId, id) {
    const navigationExtras: NavigationExtras = {
      state: {
        refundedDetails: this.rows.find((item) => item.id === id),
        caseId: caseId,
      },
    };
    localStorage.setItem('previousUrl', this.router.url);
    localStorage.setItem('previousTitle', 'Refund Listing');
    this.router.navigate([`/pages/claim/refund-breakdown/${caseId}/${id}`], navigationExtras);
    return false;
  }

  getRowClass(row) {
    return {
      'is-align-top': true,
    };
  }

  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }

  onClinicGroupSelect(event) {
    if (event) {
      // reset all clinics
      this.searchFormGroup.get('clinicIds').patchValue([]);
      // select all clinics
      const clinics = [];
      event.forEach((element) => {
        this.groupedClinics[element].forEach((clinic) => {
          clinics.push(clinic.id);
        });
      });
      this.searchFormGroup.get('clinicIds').patchValue(clinics);
    }
  }

  onClinicSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      // this.onDrugInputChanged();
    }
  }
}
