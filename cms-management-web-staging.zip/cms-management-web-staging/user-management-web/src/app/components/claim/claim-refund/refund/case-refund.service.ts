import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, AbstractControl, ValidatorFn, FormArray } from '@angular/forms';

@Injectable()
export class CaseRefundService {
  constructor(private fb: FormBuilder) {}

  createRefundFormGroup(data): FormGroup {
    return this.fb.group({
      refundItems: this.fb.array(
        data.purchaseItem
          ? data.purchaseItem
              .map((item) => this.createRefundItemFormGroup(item))
              .sort((a, b) => {
                return this.sortByRefundedStatus(a, b);
              })
          : []
      ),
      selectedItemsTotalChargeWithGst: 0,
      documents: undefined,
      refundBreakdownFormGroup: this.createPaymentBreakdownFormGroup(data.invoices),
      enableSubmit: false,
    });
  }

  sortByRefundedStatus(a, b) {
    if (a.get('refundedQty').value > 0) {
      return -1;
    } else {
      return 1;
    }
  }

  createRefundItemFormGroup(item) {
    return this.fb.group({
      batchNo: item ? (item.batchNo ? item.batchNo : '-') : '-',
      expiryDate: item ? (item.expireDate ? item.expireDate : '-') : '-',
      itemRefId: item ? item.itemRefId : undefined,
      isSelected: false,
      purchaseQty: item ? item.purchaseQty : undefined,
      purchaseUom: item ? (item.purchaseUom ? item.purchaseUom : undefined) : undefined,
      oriTotalPrice: item ? (item.soldPrice ? item.soldPrice : undefined) : undefined,
      refundAmt: { value: item ? (item.soldPrice ? item.soldPrice : 0) : 0, disabled: true },
      refundAmtInDollars: [
        { value: item ? (item.soldPrice ? (item.soldPrice / 100).toFixed(2) : 0) : 0, disabled: true },
        { updateOn: 'blur' },
      ],
      refundQty: { value: item ? item.purchaseQty : 0, disabled: true },
      refundedQty: item ? (item.refundQty ? item.refundQty : 0) : 0,
      refundReason: { value: '', disabled: true },
      salesItemId: item ? item.salesItemId : undefined,
      sellingPrice: this.fb.group({
        price: item ? item.sellingPrice.price : 0,
        taxIncluded: item ? item.sellingPrice.taxIncluded : false,
      }),
    });
  }

  createPaymentBreakdownFormGroup(data) {
    const paymentInfosPerInvoiceArray = this.fb.array([]);
    let summaryTotal = 0;
    let summaryTotalGst = 0;
    let summaryTotalWithGst = 0;
    let summaryTotalWithGstAndRounding = 0;
    let refundedAmountTotal = 0;
    let refundableAmountTotal = 0;
    let maxAllowableRefundTotal = 0;
    let clinicRefundableTotal = 0;
    let cashAdjustmentRoundingTotal = 0;

    data.forEach((invoice) => {
      const paymentInfoArray = this.fb.array([]);

      if (invoice.invoiceType === 'DIRECT') {
        invoice.paymentInfos.forEach((info) => {
          const refundedAmount = info ? (info.refundAmount ? info.refundAmount : 0) : 0;

          const item = this.createDirectPaymentItemFormGroup(info);
          summaryTotal += (info.amount / 107) * 100;
          summaryTotalGst += (info.amount / 107) * 100 * 0.07;
          summaryTotalWithGst += info.amount;
          summaryTotalWithGstAndRounding += info.amount + info.cashAdjustment;
          refundedAmountTotal += refundedAmount;
          maxAllowableRefundTotal += info.amount - refundedAmount;
          cashAdjustmentRoundingTotal += info.cashAdjustment;
          paymentInfoArray.push(item);
        });
      } else {
        const item = this.createCreditPaymentItemFormGroup(invoice);
        summaryTotal += (invoice.paidAmount / 107) * 100;
        summaryTotalGst += (invoice.paidAmount / 107) * 100 * 0.07;
        summaryTotalWithGst += invoice.paidAmount;
        summaryTotalWithGstAndRounding += invoice.paidAmount;
        refundedAmountTotal = 0;
        maxAllowableRefundTotal = 0;
        paymentInfoArray.push(item);
      }

      const paymentInfoPerInvoiceFormGroup = this.fb.group({
        invoiceId: invoice.invoiceId || undefined,
        invoiceTime: invoice.invoiceTime || undefined,
        paymentInfoArray: paymentInfoArray,
      });

      paymentInfosPerInvoiceArray.push(paymentInfoPerInvoiceFormGroup);
    });

    return this.fb.group({
      paymentInfosPerInvoiceArray: paymentInfosPerInvoiceArray,
      summaryTotal,
      summaryTotalGst,
      summaryTotalWithGst,
      summaryTotalWithGstAndRounding,
      refundedAmountTotal,
      maxAllowableRefundTotal,
      refundableAmountTotal,
      clinicRefundableTotal,
      cashAdjustmentRoundingTotal,
      remarks: '',
      accountNumber: '',
      accountDetails: '',
      cardNumberLast4Digits: '',
    });
  }

  createCreditPaymentItemFormGroup(invoice) {
    // const billMode = item ? item.billMode : undefined;
    // const amount = item ? item.amount : 0;
    // const planName = this.akitaMedicalCoverageQuery.getMedicalCoverageByPlanId(invoice.planId).name;
    const planName = '';

    return this.fb.group({
      approvalRequired: true,
      billTransactionId: undefined,
      billMode: planName,
      paidAmount: invoice ? Math.round((invoice.payableAmount / 107) * 100) : 0,
      gst: invoice ? Math.round((invoice.payableAmount / 107) * 100 * 0.07) : 0,
      paidAmountWithGst: invoice ? invoice.payableAmount : 0,
      invoiceNumber: invoice ? invoice.invoiceId : undefined,
      maxAllowableRefund: 0,
      refundedAmount: 0,
      refundAmount: { value: undefined, disabled: true }, //Include GST
      refundAmountInDollars: { value: undefined, disabled: true }, //Include GST
      clinicRefundedAmount: { value: undefined, disabled: true }, //Include GST
      clinicRefundedAmountInDollars: { value: undefined, disabled: true }, //Include GST
      cashAdjustment: 0,
    });
  }

  createDirectPaymentItemFormGroup(item) {
    const billMode = item ? item.billMode : undefined;
    const amount = item ? (item.amount ? item.amount : 0) : 0;
    const refundAmount = item ? (item.refundAmount ? item.refundAmount : 0) : 0;
    const maxAllowableRefund = amount - refundAmount;

    return this.fb.group({
      approvalRequired: this.checkApprovalRequired(billMode, amount),
      billTransactionId: item ? item.billTransactionId : undefined,
      billMode: billMode,
      paidAmount: (amount / 107) * 100,
      gst: (amount / 107) * 100 * 0.07,
      paidAmountWithGst: amount,
      invoiceNumber: item ? item.invoiceNumber : undefined,
      maxAllowableRefund: maxAllowableRefund,
      refundedAmount: refundAmount,
      refundAmount: undefined, //Include GST
      refundAmountInDollars: [undefined, validateRefundAmtOnPayment(maxAllowableRefund)], //Include GST
      clinicRefundedAmount: undefined, //Include GST
      clinicRefundedAmountInDollars: { value: undefined, disabled: item.billMode !== 'CASH' }, //Include GST,
      cashAdjustment: item ? item.cashAdjustment : 0,
    });
  }

  getRefundRequestObject(form: FormGroup) {
    let refundItems = [];
    const refundItemsArr: FormArray = <FormArray>form.get('refundItems');
    refundItemsArr.controls.forEach((item) => {
      if (item.get('isSelected').value) {
        let tempItem = '';
        refundItems.push({
          itemRefId: item.get('itemRefId').value,
          returnQty: item.get('refundQty').value,
          reason: item.get('refundReason').value,
          refundAmount: item.get('refundAmt').value || 0,
          salesItemId: item.get('salesItemId').value,
          batchNo: item.get('batchNo').value === '-' ? '' : item.get('batchNo').value,
          purchaseUom: item.get('purchaseUom').value,
          expireDate: item.get('expiryDate').value === '-' ? null : item.get('expiryDate').value,
          // itemType: tempItem ? tempItem.itemType : ""
        });
      }
    });

    let invoices = [];
    let invoiceNumbers = [];
    let refundInvoices = [];
    const paymentInfosPerInvoiceArray: FormArray = (<FormArray>(
      form.get('refundBreakdownFormGroup').get('paymentInfosPerInvoiceArray')
    )) as FormArray;
    paymentInfosPerInvoiceArray.controls.forEach((control: FormGroup) => {
      const paymentInfoArray: FormArray = control.get('paymentInfoArray') as FormArray;
      paymentInfoArray.value.forEach((item) => {
        if (
          (item.refundAmount && item.refundAmount > 0) ||
          (item.clinicRefundedAmount && item.clinicRefundedAmount > 0)
        ) {
          const refundInvoice = {
            invoiceNumber: item.invoiceNumber,
            billMode: item.billMode,
            refundAmount: item.refundAmount || 0,
            clinicRefundedAmount: item.clinicRefundedAmount || 0,
          };
          const refInv = {
            refundMode: item.billMode,
            refundableAmount: item.refundAmount || 0,
            refundedAmount: item.paidAmountWithGst || 0,
            taxAmount: item.paidAmountWithGst - item.refundAmount || 0,
            refundedAmountByClinic: +item.clinicRefundedAmountInDollars * 100 || 0,
          };
          invoices.push(refundInvoice);
          invoiceNumbers.push(item.invoiceNumber);
          refundInvoices.push(refInv);
        }
      });
    });

    return {
      refundItems: refundItems,
      invoiceNumbers: invoiceNumbers,
      refundInvoices: refundInvoices,
      remarks: form.get('refundBreakdownFormGroup').get('remarks').value,
      accountNumber: form.get('refundBreakdownFormGroup').get('accountNumber').value,
      accountDetails: form.get('refundBreakdownFormGroup').get('accountDetails').value,
      cardNumberLast4Digits: form.get('refundBreakdownFormGroup').get('cardNumberLast4Digits').value,
    };
  }

  checkApprovalRequired(billMode, amount) {
    if (billMode === 'CASH' && amount >= 5000) {
      return true;
    }
  }
}

export interface refundPageState {
  caseId: string;
  inRefundsPage: boolean;
}

export function validateRefundAmtOnItem(oriTotalPrice: number, valueInCents: boolean): ValidatorFn {
  return (control: AbstractControl) => {
    const refundAmtInCents = !valueInCents ? (Number(control.value) * 100).toFixed(2) : Number(control.value);
    if (refundAmtInCents > oriTotalPrice) {
      return {
        refundAmtGreaterThanOri: {
          value: control.value,
        },
      };
    } else {
      return null;
    }
  };
}

export function validateRefundQty(purchaseQty: number): ValidatorFn {
  return (refundQty: AbstractControl) => {
    if (refundQty.value > purchaseQty) {
      return {
        refundQtyGreaterThanDispensed: {
          value: refundQty.value,
        },
      };
    } else {
      return null;
    }
  };
}

export function validateRefundAmtOnPayment(paidAmount: number): ValidatorFn {
  return (control: AbstractControl) => {
    const refundAmtInCents = Math.round(Number(control.value) * 100);
    if (refundAmtInCents > paidAmount) {
      return {
        refundAmtGreaterThanMaxAllowable: {
          value: control.value,
        },
      };
    } else {
      return null;
    }
  };
}

export function validateClinicRefundedAmount(refundAmountInDollars: AbstractControl): ValidatorFn {
  return (control: AbstractControl) => {
    const clinicRefundAmtInCents = Number(control.value) * 100;
    const refundAmountInCents = refundAmountInDollars.value * 100;
    if (clinicRefundAmtInCents > refundAmountInCents) {
      return {
        clinicRefundAmtGreaterThanInput: {
          value: control.value,
        },
      };
    } else {
      return null;
    }
  };
}

export function validateClinicTotalRefundedAmount(): ValidatorFn {
  return (control: AbstractControl) => {
    const clinicTotalRefundAmtInCents = Number(control.value) * 100;
    if (clinicTotalRefundAmtInCents > 5000) {
      return {
        clinicRefundAmtGreaterThanFifty: {
          value: control.value,
        },
      };
    } else {
      return null;
    }
  };
}
