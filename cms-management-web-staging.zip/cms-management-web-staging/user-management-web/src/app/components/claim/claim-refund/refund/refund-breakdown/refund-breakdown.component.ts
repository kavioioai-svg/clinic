import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormArray, Form, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-refund-breakdown',
  templateUrl: './refund-breakdown.component.html',
  styleUrls: ['./refund-breakdown.component.scss']
})
export class RefundBreakdownComponent implements OnInit {
  @Input() refundBreakdownFormGroup: FormGroup;
  @Input() selectedItemsTotalChargeWithGst;
  @Input() isEdit: boolean = true;

  clinicRefundableExceeded: boolean = false;
  refundableAmountExceeded: boolean = false;

  summaryTotalWithGstAndRounding: AbstractControl;
  summaryTotalWithGst: AbstractControl;
  cashAdjustmentRoundingTotal: AbstractControl;
  refundedAmountTotal: AbstractControl;
  refundableAmountTotal: AbstractControl;
  maxAllowableRefundTotal: AbstractControl;
  clinicRefundableTotal: AbstractControl;

  constructor() { 
  }

  ngOnInit() {
    this.initialise();
    this.subscribeOnChanges();
    if(!this.isEdit){
      this.calculateRefundableTotalForView();
    }
  }

  initialise(){
    if(this.refundBreakdownFormGroup){
      const get = (key: string) => this.refundBreakdownFormGroup && this.refundBreakdownFormGroup.get(key);
      this.summaryTotalWithGstAndRounding = get('summaryTotalWithGstAndRounding');
      this.cashAdjustmentRoundingTotal = get('cashAdjustmentRoundingTotal');
      this.summaryTotalWithGst = get('summaryTotalWithGst');
      this.refundedAmountTotal = get('refundedAmountTotal');
      this.maxAllowableRefundTotal = get('maxAllowableRefundTotal');
      this.refundableAmountTotal = get('refundableAmountTotal');
      this.clinicRefundableTotal = get('clinicRefundableTotal');
    }
  }

  subscribeOnChanges(){
    if(this.refundBreakdownFormGroup){
      const paymentInfosPerInvoiceArray: FormArray = <FormArray> this.refundBreakdownFormGroup.get('paymentInfosPerInvoiceArray');
      paymentInfosPerInvoiceArray.valueChanges.subscribe( values =>{
        this.calculateRefundableTotal();
      });
    }
  }

  calculateRefundableTotal(){
    let refundableTotal = 0;
    let clinicRefundableTotal = 0;
    if(this.refundBreakdownFormGroup){
      const paymentInfosPerInvoiceArray: FormArray = <FormArray>this.refundBreakdownFormGroup.get('paymentInfosPerInvoiceArray');
      paymentInfosPerInvoiceArray.controls.forEach( (paymentInfo) =>{
        const paymentInfoArray = paymentInfo.value.paymentInfoArray;
        paymentInfoArray.forEach( (paymentInfo) =>{
          if(!!paymentInfo.refundAmount){
            refundableTotal += paymentInfo.refundAmount;
          }

          if(!!paymentInfo.clinicRefundedAmount){
            clinicRefundableTotal += paymentInfo.clinicRefundedAmount;
          }
        });
      });

      this.refundableAmountTotal.patchValue(refundableTotal, {emitEvent: false});
      this.clinicRefundableTotal.patchValue(clinicRefundableTotal, {emitEvent: false});

      if(this.refundableAmountTotal.value > this.selectedItemsTotalChargeWithGst ||
      this.refundableAmountTotal.value > this.maxAllowableRefundTotal.value){
        this.refundableAmountExceeded = true;
      } else {
        this.refundableAmountExceeded = false;
      }

      if(this.clinicRefundableTotal.value > 5000){
        this.clinicRefundableExceeded = true;
      } else {
        this.clinicRefundableExceeded = false;
      }
    }
  }

  calculateRefundableTotalForView(){
    let clinicRefundableTotal = 0;
    if(this.refundBreakdownFormGroup){
      const paymentInfosPerInvoiceArray: FormArray = <FormArray>this.refundBreakdownFormGroup.get('paymentInfosPerInvoiceArray');
      paymentInfosPerInvoiceArray.controls.forEach( (paymentInfo) =>{
        const paymentInfoArray = paymentInfo.value.paymentInfoArray;
        paymentInfoArray.forEach( (paymentInfo) =>{
          if(!!paymentInfo.clinicRefundedAmount){
            clinicRefundableTotal += paymentInfo.clinicRefundedAmount;
          }
        });
      });
      this.clinicRefundableTotal.patchValue(clinicRefundableTotal, {emitEvent: false});
    }
  }
}
