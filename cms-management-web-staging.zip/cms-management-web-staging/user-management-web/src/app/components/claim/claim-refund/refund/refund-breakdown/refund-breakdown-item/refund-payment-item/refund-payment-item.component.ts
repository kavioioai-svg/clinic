import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, AbstractControl } from '@angular/forms';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-refund-payment-item',
  templateUrl: './refund-payment-item.component.html',
  styleUrls: ['./refund-payment-item.component.scss']
})
export class RefundPaymentItemComponent implements OnInit {

  @Input() formGroup: FormGroup;

  refundAmount: AbstractControl;
  refundAmountInDollars: AbstractControl;
  clinicRefundedAmount: AbstractControl;
  clinicRefundedAmountInDollars: AbstractControl;
  paidAmountWithGst: AbstractControl;


  constructor() { }

  ngOnInit() {
    this.initialise();
    this.subscribeOnChanges();
  }

  initialise(){
    const get = (key: string) => this.formGroup.get(key);
    this.refundAmount = get('refundAmount');
    this.refundAmountInDollars = get('refundAmountInDollars');
    this.clinicRefundedAmount = get('clinicRefundedAmount');
    this.clinicRefundedAmountInDollars = get('clinicRefundedAmountInDollars');
    this.paidAmountWithGst = get('paidAmountWithGst');
  }

  subscribeOnChanges(){
    this.refundAmountInDollars
    .valueChanges
    .pipe(
       distinctUntilChanged()
    )
    .subscribe( value =>{
        this.refundAmount.patchValue(Math.round(Number(value) * 100), {emitEvent: false});
        this.clinicRefundedAmountInDollars.updateValueAndValidity();
    });

    this.clinicRefundedAmountInDollars
    .valueChanges
    .pipe(
       distinctUntilChanged()
    )
    .subscribe( value =>{
        this.clinicRefundedAmount.patchValue(Math.round(Number(value) * 100), {emitEvent: false});
    });
  }

}
