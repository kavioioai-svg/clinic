import { Clinic } from './../../../objects/response/Clinic';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { AlertService } from './../../../services/alert.service';
import * as moment from 'moment';
import { ApiPatientVisitService } from '../../../services/api-patient-visit.service';
import { DISPLAY_DATE_FORMAT, DB_FULL_DATE_FORMAT, TRUE_FALSE_ANWS } from './../../../constants/app.constants';

import { Subject } from 'rxjs';
import { Diagnosis } from '../../../objects/response/Diagnosis';
import { distinctUntilChanged, debounceTime, switchMap, tap, takeUntil } from 'rxjs/operators';
import { ApiCmsManagementService } from './../../../services/api-cms-management.service';
import { ClinicQuery } from '../../../state/clinic/clinic.query';
import { DoctorQuery } from '../../../state/doctor/doctor.query';
import { StoreStatusQuery } from '../../../state/store-status/store-status.query';

@Component({
  selector: 'app-claim-chas',
  templateUrl: './claim-chas.component.html',
  styleUrls: ['./claim-chas.component.scss'],
})
export class ClaimChasComponent implements OnInit, OnDestroy {
  @ViewChild('myTable', { static: true }) table: any;
  columns: any[] = [];
  rows: any[] = [];
  statusList = ['SUBMITTED', 'FAILED', 'APPROVED'];
  searchStatusList = [
    'ALL',
    'SUBMITTED',
    'PENDING',
    'REJECTED_PERMANENT',
    'REJECTED',
    'APPEALED',
    'APPROVED',
    'PAID',
    'FAILED',
  ];
  doctorList: any[] = [];
  clinics: Array<Clinic>;
  showEdit = false;

  submitting = {};

  formGroup: FormGroup;
  searchFormGroup: FormGroup;

  codes: Array<Diagnosis> = [];
  exsistingCodes: Array<Diagnosis> = [];
  codesTypeahead = new Subject<string>();
  diagnosisLoading = false;

  referredToInstitution: any[] = [];
  trueFalseAnws: any[] = TRUE_FALSE_ANWS;
  pCRTestKit: any[] = [];
  aRTTestKit: any[] = [];
  visitIndicator: any[] = [];

  private componentDestroyed: Subject<void> = new Subject();

  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private apiPatientVisitService: ApiPatientVisitService,
    private apiCmsManagementService: ApiCmsManagementService,
    private clinicQuery: ClinicQuery,
    private doctorQuery: DoctorQuery,
    private storeStatusQuery: StoreStatusQuery
  ) {}

  ngOnInit() {
    this.loadEnums();
    this.populateData();
    this.newFormGroup();
    this.newSearchFormGroup();

    this.onFilterInputChanged();

    this.storeStatusQuery
      .select()
      .pipe(takeUntil(this.componentDestroyed))
      .subscribe((val) => {
        if (val.isLoaded && !val.isReseting) {
          this.populateData();
          this.onSearchClaimClicked();
        }
      });
  }

  ngOnDestroy(): void {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  private loadEnums() {
    this.apiCmsManagementService.listSystemStoreValuesByKey('PHPC_SETUP_MAPPING').subscribe(
      	data => {
      		if (data.payload && data.payload.values) {
            this.referredToInstitution = data.payload.values.find(types => types.name === 'REFERRED_TO_INSTITUTION').values;            
            this.pCRTestKit = data.payload.values.find(types => types.name === 'PCR_TEST_KIT').values;
            this.aRTTestKit = data.payload.values.find(types => types.name === 'ART_TEST_KIT').values;
            const allList= data.payload.values.find(types => types.name === 'VISIT_INDICATOR').values;
            this.visitIndicator = allList.filter(item => item.cmsCode ==='W');
      		}
      	},
      	err => {
      		this.alertService.error(JSON.stringify(err.error.message));
      	}
      );
  }

  private populateData() {
    this.doctorList = this.doctorQuery.getAll();
    this.clinics = this.clinicQuery.getAll();
  }

  newFormGroup() {
    this.formGroup = this.fb.group({
      claimId: [{ value: '', disabled: true }, Validators.required],
      date: { value: '', disabled: true },
      HEcode: { value: '', disabled: true },
      clinic: { value: '', disabled: true },
      patientName: { value: '', disabled: true },
      payerName: { value: '', disabled: false },
      patientNric: { value: '', disabled: true },
      payerNric: { value: '', disabled: false },
      doctor: { value: '', disabled: false },
      referNo: { value: '', disabled: true },
      diagnosisCode: { value: '', disabled: false },
      receiptNo: { value: '', disabled: true },
      conAmt: { value: '', disabled: true },
      drugAmt: { value: '', disabled: true },
      labAmt: { value: '', disabled: true },
      otherAmt: { value: '', disabled: true },
      totAmt: { value: '', disabled: true },
      claimAmt: { value: '', disabled: false },
      status: { value: '', disabled: false },
      remarks: { value: '', disabled: false },
      claimedAmt: { value: '', disabled: false },
      claimRefNo: { value: '', disabled: false },
      claimRemarks: { value: '', disabled: false },
      claimStatus: { value: '', disabled: false },
      planId: { value: '', disabled: false },
      caseNumber: { value: '', disabled: false },
      mhcpPlanCategory: { value: '', disabled: false },
      referredToInstitution: { value: undefined, disabled: false },
      visitIndicator: { value: undefined, disabled: false },
      sashDone: { value: undefined, disabled: false },
      sashDeclaration: { value: undefined, disabled: false },
      pcrTestKit: { value: undefined, disabled: false },
      artTestKit: { value: undefined, disabled: false },
      coverageConsultAmt: { value: undefined, disabled: false },
      patientCoPayAmt: { value: undefined, disabled: false },
    });

    // Validation Checking
    this.formGroup
      .get('claimStatus')
      .valueChanges.pipe(takeUntil(this.componentDestroyed))
      .subscribe((val) => {
        const claimRefNoControl = this.formGroup.get('claimRefNo');
        const claimAmount = this.formGroup.get('claimedAmt');
        if (val === 'APPROVED') {
          claimAmount.setValidators(Validators.required);
          claimAmount.updateValueAndValidity({ onlySelf: true, emitEvent: false });
          claimAmount.markAsTouched({ onlySelf: true });
        } else {
          claimAmount.setValidators(null);
          claimAmount.updateValueAndValidity({ onlySelf: true, emitEvent: false });
          claimAmount.markAsTouched({ onlySelf: true });
        }

        if (val) {
          claimRefNoControl.setValidators(Validators.required);
          claimRefNoControl.updateValueAndValidity({ onlySelf: true, emitEvent: false });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        } else {
          claimRefNoControl.setValidators(null);
          claimRefNoControl.updateValueAndValidity({ onlySelf: true, emitEvent: false });
          claimRefNoControl.markAsTouched({ onlySelf: true });
        }
      });
  }

  newSearchFormGroup() {
    this.searchFormGroup = this.fb.group({
      startDate: [moment().subtract(1, 'days').format(DISPLAY_DATE_FORMAT), Validators.required],
      endDate: [moment().format(DISPLAY_DATE_FORMAT), Validators.required],
      clinicId: ['', Validators.required],
      status: this.searchStatusList[0],
    });
  }

  updateForm(row: any) {
    this.formGroup.patchValue({
      claimId: row.claimId,
      date: row.billDate,
      HEcode: row.HEcode,
      clinic: row.clinic,
      patientName: row.patientName,
      patientNric: row.patientNric,
      payerName: row.payerName,
      payerNric: row.payerNric,
      doctor: row.doctor,
      referNo: row.referNo,
      diagnosisCode: row.diagnosisCode,
      conAmt: row.conAmt,
      drugAmt: row.drugAmt,
      labAmt: row.labAmt,
      otherAmt: row.otherAmt,
      totAmt: row.totAmt,
      claimAmt: row.claimAmt,
      status: row.status,
      receiptNo: row.receiptNo,
      remarks: row.remarks,
      claimedAmt: row.claimedAmt,
      claimRefNo: row.claimRefNo,
      claimRemarks: row.claimRemarks,
      claimStatus: row.claimStatus,
      planId: row.planId,
      caseNumber: row.caseNumber,
      mhcpPlanCategory: row.mhcpPlanCategory,
      referredToInstitution: row.referredToInstitution,
      visitIndicator: row.visitIndicator,
      sashDone: row.sashDone,
      sashDeclaration: row.sashDeclaration,
      pcrTestKit: row.pcrTestKit,
      artTestKit: row.artTestKit,
      coverageConsultAmt: row.coverageConsultAmt,
      patientCoPayAmt: row.patientCoPayAmt,
    });
  }

  updateDefaultValues() {
    
    
    if (this.formGroup.get('mhcpPlanCategory').value === 'PHPC_FSS' &&  !this.formGroup.get('referredToInstitution').value) {
      // this.formGroup.get('referredToInstitution').patchValue('RSC');
      if (this.formGroup.get('sashDone').value === undefined) {
        this.formGroup.get('sashDone').patchValue(false);
      }
    }

    if (this.formGroup.get('mhcpPlanCategory').value === 'PHPC_SASH') {
      if (!this.formGroup.get('visitIndicator').value) {
        this.formGroup.get('visitIndicator').patchValue('W');
      }

      if (this.formGroup.get('sashDone').value === undefined) {
        this.formGroup.get('sashDone').patchValue(true);
      }

      if (!this.formGroup.get('pcrTestKit').value) {
        this.formGroup.get('pcrTestKit').patchValue('PCR');
      }

      if (!this.formGroup.get('artTestKit').value) {
        this.formGroup.get('artTestKit').patchValue('NONE');
      }

      if (this.formGroup.get('sashDeclaration').value === undefined) {
        this.formGroup.get('sashDeclaration').patchValue(true);
      }    
      
    } else {
      if (this.formGroup.get('sashDeclaration').value === undefined) {
        this.formGroup.get('sashDeclaration').patchValue(false);
      }  
    }
  }

  resetFormGroup() {
    this.showEdit = false;
    this.formGroup.reset();
    this.newFormGroup();
  }

  onEditUserClicked(row) {
    this.showEdit = true;
    this.updateForm(row);
    this.updateDefaultValues();
    window.scrollTo({ left: 0, top: 0, behavior: 'smooth' });
  }

  onChargePatientClicked(row: any, rowIndex) {
    this.submitting[rowIndex] = true;
    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before proceeding!');
      return;
    }
    this.apiPatientVisitService.rejectClaim(claimId).subscribe(
      (res) => {
        alert('Claim is rejected');
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  onSearchClaimClicked() {
    const startDateStr = moment(this.searchFormGroup.get('startDate').value, 'DD-MM-YYYY').format('DD-MM-YYYY');
    const endDateStr = moment(this.searchFormGroup.get('endDate').value, 'DD-MM-YYYY').format('DD-MM-YYYY');
    const status = this.searchFormGroup.get('status').value;
    let clinicId = '';

    // update clinicId in the form group
    const selectedClinic = this.searchFormGroup.get('clinicId').value;
    if (selectedClinic) {
      clinicId = selectedClinic;
    }

    if (clinicId && clinicId.length > 0) {
      this.apiPatientVisitService
        .listClaimsByClinlicByDate(clinicId, 'CHAS', status, startDateStr, endDateStr)
        .subscribe(
          (res) => {
            this.processChasData(res);
          },
          (err) => {
            this.alertService.error(JSON.stringify(err));
          }
        );
    } else {
      this.apiPatientVisitService.listClaimsByDate('CHAS', status, startDateStr, endDateStr).subscribe(
        (res) => {
          this.processChasData(res);
        },
        (err) => {
          this.alertService.error(JSON.stringify(err));
        }
      );
    }
  }

  private processChasData(data) {
    this.rows = this.mapPayloadToRows(data.payload);
    this.rows = this.rows.sort((a, b) => {
      const date1 = moment(a.billDate, DISPLAY_DATE_FORMAT);
      const date2 = moment(b.billDate, DISPLAY_DATE_FORMAT);
      if (date1.isBefore(date2)) {
        return -1;
      }
      if (date1.isAfter(date2)) {
        return 1;
      }
      // equal
      return 0;
    });
  }

  onSaveClicked() {
    const claim = this.mapFormGroupToClaimSave(this.formGroup);
    const claimId = this.formGroup.get('claimId').value;
    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }
    this.apiPatientVisitService.saveClaim(claimId, claim).subscribe(
      (res) => {
        alert('Claim is updated');
        this.resetFormGroup();
        this.onSearchClaimClicked();
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }

  onResubmitClicked(row: any, rowIndex) {
    this.onSubmitClicked(row, rowIndex);
  }

  onSubmitClicked(row: any, rowIndex) {
    this.submitting[rowIndex] = true;

    const claim = this.mapRowToClaimSubmit(row);
    const claimId = claim.claimId;
    if (!claimId && claimId === '') {
      alert('Please select a recored before save!');
      return;
    }
    this.apiPatientVisitService.submitClaim(claimId, claim).subscribe(
      (res) => {
        alert('Claim is submitted');
        this.resetFormGroup();
        this.onSearchClaimClicked();
        this.submitting[rowIndex] = false;
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
        this.submitting[rowIndex] = false;
      }
    );
  }

  /* Data Mapper */
  mapPayloadToRows(payload: any[]) {
    const clinlic = new Clinic();
    let diagnosisCodes = [];
    const arr = payload.map((res) => {
      const doctor = this.doctorQuery.getEntity(res.claim.claimDoctorId);
      const claimResult =
        res.payload && res.payload.claim && res.payload.claim.claimResult
          ? <ClaimResult>res.payload.claim.claimResult
          : new ClaimResult();

      const claimSubmissionResult =
        res.payload && res.payload.claim && res.payload.claim.submissionResult
          ? <ClaimSubmissionResult>res.payload.claim.submissionResult
          : new ClaimSubmissionResult();

      const claimedAmt =
        res.claim && res.claim.claimResult && res.claim.claimResult.amount ? res.claim.claimResult.amount / 100 : '';
      const claimRemarks = res.claim && res.claim.claimResult && res.claim.claimResult.remark;

      if (res.claim.diagnosisCodes) {
        diagnosisCodes = [...diagnosisCodes, ...res.claim.diagnosisCodes]
      }

      return {
        claimId: res.claim.claimId,
        billDate: res.billDate ? moment(res.billDate, DB_FULL_DATE_FORMAT).format(DISPLAY_DATE_FORMAT) : 'N/A',
        submitDate: res.claim.submissionDateTime
          ? moment({
              y: res.claim.submissionDateTime[0],
              M: res.claim.submissionDateTime[1] - 1,
              d: res.claim.submissionDateTime[2],
            }).format(DISPLAY_DATE_FORMAT)
          : 'N/A',
        HEcode: clinlic.heCode || 'N/A',
        clinic: res.clinicCode,
        patientName: res.patientsName,
        payerName: res.claim.payersName,
        doctor: res.claim.claimDoctorId,
        doctorName: doctor ? doctor.displayName + ' \n(' + (doctor.mcr ? doctor.mcr : '---') + ')' : 'N/A',
        referNo: res.claim.claimId,
        diagnosisCode: res.claim.diagnosisCodes,
        conAmt: res.claim.consultationAmt / 100,
        drugAmt: res.claim.medicationAmt / 100,
        labAmt: res.claim.medicalTestAmt / 100,
        otherAmt: res.claim.otherAmt / 100,
        totAmt: res.totalAmount / 100,
        claimAmt: res.claim.claimExpectedAmt / 100,
        status: res.claim.claimStatus,
        remark: this.getRemark(res.claim),
        patientNric: res.patientsNric,
        payerNric: res.claim.payersNric,
        receiptNo: res.billReceiptId,
        plan: (res.medicalCoverageName ? res.medicalCoverageName : '') + ' - \n' + (res.planName ? res.planName : ''),
        claimedAmt,
        claimRefNo: res.claim.submissionResult && res.claim.submissionResult.claimNo,
        claimRemarks: res.claimRemarks,
        claimStatus: res.claim.claimStatus,
        claimResult,
        claimSubmissionResult,
        planId: res.planId,
        caseNumber: res.caseNumber,
        mhcpPlanCategory: res.mhcpPlanCategory,
        coverageConsultAmt: res.claim.coverageConsultAmt ? res.claim.coverageConsultAmt /100 : undefined,
        patientCoPayAmt: res.claim.patientCoPayAmt ? res.claim.patientCoPayAmt /100 : undefined,
        referredToInstitution: res.claim.sashDetails && res.claim.sashDetails.referredToInstitution ? res.claim.sashDetails.referredToInstitution : undefined,
        visitIndicator: res.claim.sashClaimDetails && res.claim.sashClaimDetails.visitIndicator ? res.claim.sashClaimDetails.visitIndicator : undefined,
        sashDone: res.claim.sashDetails && res.claim.sashDetails.sashDone != undefined ? res.claim.sashDetails.sashDone : undefined,
        sashDeclaration: res.claim.sashDetails && res.claim.sashDetails.sashDeclaration != undefined ? res.claim.sashDetails.sashDeclaration : undefined,
        pcrTestKit: res.claim.sashDetails && res.claim.sashDetails.pcrTestKit ? res.claim.sashDetails.pcrTestKit : undefined,
        artTestKit: res.claim.sashDetails && res.claim.sashDetails.artTestKit ? res.claim.sashDetails.artTestKit : undefined,
      };
    });
    this.loadExistingDiagnosis(diagnosisCodes);
    return arr;
  }

  loadExistingDiagnosis(diagnosisCodes) {
    const removedDuplicates = diagnosisCodes.filter((value, index) => diagnosisCodes.indexOf(value) === index);

    this.apiCmsManagementService.searchDiagnosisByIcdCodes(removedDuplicates).subscribe(result => {
      if(result.statusCode === 'S0000') {
        this.exsistingCodes = result.payload;

        let missingCodes = [];

        removedDuplicates.forEach(code => {
          let codeEx = this.exsistingCodes.find(exCode => exCode.icd10Code === code);
          if (!codeEx) {
            missingCodes.push ( {
                id : code,
                icd10Id : code,
                snomedId : code,
                icd10Code : code,
                icd10Term : code,
                status : "ACTIVE",
                filterablePlanIds : [ ],
                invalidUsage : false
              } );            
          }
        });

        this.exsistingCodes = [...this.exsistingCodes, ...missingCodes];
        this.codes =  this.exsistingCodes;
        
      }
    }, error => {});
    
  }

  getRemark(claim) {
    const { submissionResult, claimResult } = claim;
    let remark = '';
    if (submissionResult && submissionResult.statusCode && claimResult && claimResult.remark) {
      // show claim result
      if (submissionResult.statusCode === 'OK' || submissionResult.statusCode === 'Success') {
        remark = claimResult.remark;
      } else {
        remark = submissionResult.statusDescription && submissionResult.statusDescription;
      }
    } else if (submissionResult && !claimResult) {
      remark = submissionResult.statusDescription && submissionResult.statusDescription;
    } else if (!submissionResult && claimResult) {
      remark = claimResult.remark && claimResult.remark;
    }
    return remark;
  }

  mapFormGroupToClaimSave(formGroup: FormGroup): ClaimSave {
    return new ClaimSave(
      formGroup.get('doctor').value,
      formGroup.get('payerNric').value,
      formGroup.get('payerName').value,
      formGroup.get('diagnosisCode').value,
      formGroup.get('HEcode').value,
      formGroup.get('claimAmt').value * 100,
      formGroup.get('claimRemarks').value,
      formGroup.get('claimedAmt').value * 100,
      formGroup.get('claimRefNo').value,
      formGroup.get('claimStatus').value,
      formGroup.get('coverageConsultAmt').value * 100,
      formGroup.get('patientCoPayAmt').value * 100,      
      this.getSashDetails(formGroup),
      this.getSashClaimDetails(formGroup),
    );
  }

  mapRowToClaimSubmit(row: any): ClaimSubmit {
    return new ClaimSubmit(
      row.doctor,
      row.payerNric,
      row.payerName,
      row.diagnosisCode,
      row.claimAmt * 100,
      row.claimId
    );
  }

  getSashDetails(formGroup: FormGroup): SashDetails {
    if (formGroup.get('mhcpPlanCategory').value === 'FSS' || true) {
      return new SashDetails(
        formGroup.get('referredToInstitution').value,
        formGroup.get('sashDone').value,
        formGroup.get('sashDeclaration').value,
        formGroup.get('pcrTestKit').value,
        formGroup.get('artTestKit').value,
      )
    }
  }

  getSashClaimDetails(formGroup: FormGroup): SashClaimDetails {
    if (formGroup.get('mhcpPlanCategory').value === 'SAH' || true) {
      return new SashClaimDetails(
       formGroup.get('visitIndicator').value
      )
   }

   return undefined;
  }

  onFilterInputChanged() {
    try {
      this.codesTypeahead
        .pipe(
          distinctUntilChanged((a, b) => b.trim().length === 0),
          debounceTime(400),
          tap(() => (this.diagnosisLoading = true)),
          switchMap((term: string) => {
            return this.apiCmsManagementService.searchDiagnosis(term, [this.formGroup.get('planId').value], true);
          })
        )
        .subscribe(
          (data) => {
            this.diagnosisLoading = false;

            if (data) {
              this.codes = [...this.exsistingCodes, ...data.payload];
              // this.codes.push(data.payload);
            }
          },
          (err) => {
            this.diagnosisLoading = false;
            if (err && err.error && err.error.message) {
              this.alertService.error(JSON.stringify(err.error.message));
            }
          }
        );
    } catch (err) {}
  }

  getRowClass(row) {
    return {
      'is-align-top': true,
    };
  }

  getEditAccessControl(row) {
    return (
      row.status === 'REJECTED_PERMANENT' || row.status === 'APPROVED' || row.status === 'PAID'
      // row.status === 'SUBMITTED'
    );
  }

  getSubmitAccessControl(row) {
    return row.status === 'PENDING' || row.status === 'FAILED' || row.status === 'REJECTED';
  }

  getChargePatientAccessControl(row) {
    return (
      row.status === 'SUBMITTED' || row.status === 'PENDING' || row.status === 'REJECTED' || row.status === 'FAILED'
    );
  }
}

class ClaimSave {
  claimDoctorId: string;
  payersNric: string;
  payersName: string;
  diagnosisCodes: string[];
  clinicHeCode: string;
  expectedClaimAmount: number;
  claimRemarks: string;
  claimedAmount: number;
  claimRefNo: string;
  claimStatus: string;
  coverageConsultAmt: any;
  patientCoPayAmt: any;
  sashDetails: SashDetails;
  sashClaimDetails:SashClaimDetails;
  constructor(
    claimDoctorId: string,
    payersNric: string,
    payersName: string,
    diagnosisCodes: string[],
    clinicHeCode: string,
    expectedClaimAmount: number,
    claimRemarks: string,
    claimedAmount: number,
    claimRefNo: string,
    claimStatus: string,
    coverageConsultAmt?: any,
    patientCoPayAmt?: any,
    sashDetails?: SashDetails,
    sashClaimDetails?: SashClaimDetails,
  ) {
    this.claimDoctorId = claimDoctorId;
    this.payersNric = payersNric;
    this.payersName = payersName;
    this.diagnosisCodes = diagnosisCodes;
    this.clinicHeCode = clinicHeCode;
    this.expectedClaimAmount = expectedClaimAmount;
    this.claimRemarks = claimRemarks;
    this.claimedAmount = claimedAmount;
    this.claimRefNo = claimRefNo;
    this.claimStatus = claimStatus;
    this.coverageConsultAmt = coverageConsultAmt;
    this.patientCoPayAmt = patientCoPayAmt;
    this.sashDetails = sashDetails;
    this.sashClaimDetails = sashClaimDetails;
  }
}

class SashDetails {
  referredToInstitution: string;
  sashDone: string;
  sashDeclaration: string;
  pcrTestKit: string;
  artTestKit: string;

  constructor (
    referredToInstitution: string,
    sashDone: string,
    sashDeclaration: string,
    pcrTestKit: string,
    artTestKit: string,
  ) {
    this.referredToInstitution = referredToInstitution;
    this.sashDone = sashDone;
    this.sashDeclaration = sashDeclaration;
    this.pcrTestKit = pcrTestKit;
    this.artTestKit = artTestKit;
  }
}

class SashClaimDetails {
  visitIndicator: string;

  constructor(
    visitIndicator: string
  ) {
    this.visitIndicator = visitIndicator;
  }
}

class ClaimSubmit {
  doctorId: string;
  payerNric: string;
  payerName: string;
  diagnosisCodes: string[];
  claimAmount: number;
  claimId: string;

  constructor(
    doctorId?: string,
    payerNric?: string,
    payerName?: string,
    diagnosisCodes?: string[],
    claimAmount?: number,
    claimId?: string
  ) {
    this.doctorId = doctorId;
    this.payerNric = payerNric;
    this.payerName = payerName;
    this.diagnosisCodes = diagnosisCodes;
    this.claimAmount = claimAmount;
    this.claimId = claimId;
  }
}

class ClaimResult {
  referenceNumber: string;
  resultDateTime: string;
  amount: number;
  statusCode: string;
  constructor(referenceNumber?: string, resultDateTime?: string, amount?: number, statusCode?: string) {
    this.referenceNumber = referenceNumber || '';
    this.resultDateTime = resultDateTime || '';
    this.amount = amount === undefined ? 0 : amount;
    this.statusCode = statusCode || '';
  }
}

class ClaimSubmissionResult {
  claimNo: string;
  statusCode: string;
  statusDescription: string;

  constructor(claimNo?: string, statusCode?: string, statusDescription?: string) {
    this.claimNo = claimNo || '';
    this.statusCode = statusCode || '';
    this.statusDescription = statusDescription || '';
  }
}
