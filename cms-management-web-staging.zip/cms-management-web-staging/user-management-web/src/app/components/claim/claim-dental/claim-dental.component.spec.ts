import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimDentalComponent } from './claim-dental.component';

describe('ClaimDentalComponent', () => {
  let component: ClaimDentalComponent;
  let fixture: ComponentFixture<ClaimDentalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimDentalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimDentalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
