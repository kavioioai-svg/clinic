import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-clear-filter-button',
  templateUrl: './clear-filter-button.component.html',
  styleUrls: ['./clear-filter-button.component.scss']
})
export class ClearFilterButtonComponent implements OnInit {
  @Input() isShow: boolean;
  @Output() removeFilter = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  clearFilter() {
    this.removeFilter.emit(true);
  }
}
