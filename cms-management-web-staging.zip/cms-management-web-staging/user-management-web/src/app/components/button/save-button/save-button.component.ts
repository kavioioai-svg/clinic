import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-save-button',
  templateUrl: './save-button.component.html',
  styleUrls: ['./save-button.component.scss']
})
export class SaveButtonComponent implements OnInit {
  @Output() onSaveClick = new EventEmitter();
  @Input()  disableBtn?: boolean;
  @Input()  btnClass?: string;
  @Input()  btnText?: string;

  constructor() { }

  ngOnInit() {
  }

  onSave() {
    this.onSaveClick.emit();
  }
}
