import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SelectItemListComponent } from '../select-item-list/select-item-list.component';
import { SelectListComponent } from './select-list.component';
import { SharedModule } from '../../shared.module';
import { SelectListNewComponent } from './selct-list-new/selct-list-new.component';
import { UnselectListNewComponent } from './unselect-list-new/unselect-list-new.component';


@NgModule({
  declarations: [
    SelectItemListComponent,
    SelectListComponent,
    SelectListNewComponent,
    UnselectListNewComponent
  ], imports: [
    CommonModule,
    SharedModule
  ], exports: [
    SelectItemListComponent,
    SelectListComponent,
    SelectListNewComponent,
    UnselectListNewComponent
  ]
})
export class SelectListModule { }
