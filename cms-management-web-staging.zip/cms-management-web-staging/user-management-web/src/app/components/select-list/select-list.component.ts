import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-select-list',
  templateUrl: './select-list.component.html',
  styleUrls: ['./select-list.component.scss'],
})
export class SelectListComponent implements OnChanges {
  @Input() label: string;
  @Input() fullList: Array<any>;
  @Input() selectedFormControl: FormControl;

  unselectedList = new Array<any>();
  selectedList = new Array<any>();

  leftFilterKeyword = new FormControl('');
  rightFilterKeyword = new FormControl('');

  toBeSelected = new FormControl(new Array<any>());
  toBeUnselected = new FormControl(new Array<any>());

  constructor() {}

  ngOnChanges(changes: SimpleChanges) {
    if (this.fullList === undefined) {
      this.leftFilterKeyword.patchValue('', { emitEvent: false });
      this.rightFilterKeyword.patchValue('', { emitEvent: false });
      this.leftFilterKeyword.disable();
      this.toBeSelected.disable();
      this.rightFilterKeyword.disable();
      this.toBeUnselected.disable();
    } else {
      this.leftFilterKeyword.enable();
      this.toBeSelected.enable();
      this.rightFilterKeyword.enable();
      this.toBeUnselected.enable();
    }

    this.updateList();
    this.valueChangesListener();
  }
  add() {
    const currentSelectedFormValue = [...this.selectedFormControl.value];
    this.toBeSelected.value.forEach((item) => {
      currentSelectedFormValue.push(item);
      this.fullList.forEach((each) => {
        if (each.value === item) {
          each.selected = true;
        }
      });
    });

    this.selectedFormControl.setValue(currentSelectedFormValue);
    this.updateList(true);
  }

  remove() {
    this.selectedFormControl.setValue(
      (<Array<any>>this.selectedFormControl.value).filter((item) => !this.toBeUnselected.value.includes(item))
    );
    this.fullList.forEach((item) => {
      if (this.toBeUnselected.value.includes(item.value)) {
        item.selected = false;
      }
    });

    this.updateList(true);
  }

  valueChangesListener() {
    this.leftFilterKeyword.valueChanges.subscribe((keyword) => {
      if (this.fullList) {
        const updatedKeyword = keyword !== undefined ? keyword.toLowerCase() : '';
        this.unselectedList = this.fullList.filter((item) => !item.selected && item.label !== undefined && item.label.toLowerCase().includes(updatedKeyword));
      }
    });

    this.rightFilterKeyword.valueChanges.subscribe((keyword) => {
      if (this.fullList) {
        const updatedKeyword = (keyword !== undefined ? keyword : '').toLowerCase();
        this.selectedList = this.fullList.filter(
          (item) => item.selected && item.label !== undefined && item.label.toLowerCase().includes(updatedKeyword)
        );
      }
    });
  }

  updateList(clearSelected = false) {
    this.unselectedList = [];
    this.selectedList = [];

    if (this.fullList) {
      this.fullList.forEach((item) => {
        if (item.selected) {
          this.selectedList.push(item);
        } else {
          this.unselectedList.push(item);
        }
      });
    }

    if (clearSelected) {
      this.toBeSelected.patchValue([], { emitEvent: false });
      this.toBeUnselected.patchValue([], { emitEvent: false });
    }
  }
}
