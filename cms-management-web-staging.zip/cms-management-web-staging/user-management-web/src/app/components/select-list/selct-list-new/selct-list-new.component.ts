import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-select-list-new',
  templateUrl: './selct-list-new.component.html',
  styleUrls: ['./selct-list-new.component.scss']
})
export class SelectListNewComponent implements OnInit , OnChanges{
    @Input() fullList;
    @Input() grouped = false;
    @Input() label: string;
    @Input() selectedFormControl: FormControl;

    selectedList;
    unselectedList;

    leftFilterKeyword = new FormControl('');
    rightFilterKeyword = new FormControl('');

    toBeSelected = new FormControl(new Array<any>());
    toBeUnselected = new FormControl(new Array<any>());

    constructor() { }

    ngOnInit() {
      if (!this.grouped) {
        this.selectedList = new Array<any>();
        this.unselectedList = new Array<any>();
      } else {
        this.selectedList = {};
        this.unselectedList = {};
      }

      this.updateList();
    }

    ngOnChanges(changes: SimpleChanges) {
      if (this.fullList === undefined) {
        this.leftFilterKeyword.patchValue('', { emitEvent: false });
        this.rightFilterKeyword.patchValue('', { emitEvent: false });

        this.leftFilterKeyword.disable();
        this.toBeSelected.disable();
        this.rightFilterKeyword.disable();
        this.toBeUnselected.disable();
      } else {
        this.leftFilterKeyword.enable();
        this.toBeSelected.enable();
        this.rightFilterKeyword.enable();
        this.toBeUnselected.enable();
      }

      this.updateList();
      this.valueChangesListener();
    }

    getSelectedListKeys() {
      return this.grouped ? Object.keys(this.selectedList) : [];
    }

    getUnselectedListKeys() {
      return this.grouped ? Object.keys(this.unselectedList) : [];
    }

    updateToBeSelected() {
      const groupList = this.toBeSelected.value.filter(value => this.getUnselectedListKeys().indexOf(value) !== -1);
      const entityList = this.toBeSelected.value.filter(value => this.getUnselectedListKeys().indexOf(value) === -1);

      let updatedGroupValue = [];
      groupList.forEach(group => {
        updatedGroupValue = updatedGroupValue.concat(this.unselectedList[group].map(entity => entity.value));
      });
      const updatedValueList = Array.from(new Set(updatedGroupValue.concat(entityList)));

      this.toBeSelected.patchValue(updatedValueList);
    }

    updateToBeUnselected() {
      const groupList = this.toBeUnselected.value.filter(value => this.getSelectedListKeys().indexOf(value) !== -1);
      const entityList = this.toBeUnselected.value.filter(value => this.getSelectedListKeys().indexOf(value) === -1);

      let updatedGroupValue = [];
      groupList.forEach(group => {
        updatedGroupValue = updatedGroupValue.concat(this.selectedList[group].map(entity => entity.value));
      });
      const updatedValueList = Array.from(new Set(updatedGroupValue.concat(entityList)));

      this.toBeUnselected.patchValue(updatedValueList);
    }

    checkGroupFullySelected(groupName, selected = false) {
      if (!selected) {
        return this.unselectedList[groupName].every(entity => this.toBeSelected.value.indexOf(entity.value) !== -1);
      } else {
        return this.selectedList[groupName].every(entity => this.toBeUnselected.value.indexOf(entity.value) !== -1);
      }
    }

    add() {
      const currentSelectedFormValue = [ ...this.selectedFormControl.value ];
      if (!this.grouped) {
        this.toBeSelected.value.forEach(item => {
          currentSelectedFormValue.push(item);
          this.fullList.forEach(each => {
            if (each.value === item) {
              each.selected = true;
            }
          });
        });
      } else {
        this.toBeSelected.value.forEach(item => {
          currentSelectedFormValue.push(item);

          Object.keys(this.fullList).forEach(group => {
            if (this.fullList[group].find(entity => entity.value === item)) {
              const entityList = [ ...this.fullList[group] ];
              const indexToBeUpdated = entityList.indexOf(entityList.find(entity => entity.value === item));
              entityList[indexToBeUpdated] = { ...this.fullList[group].find(entity => entity.value === item), selected: true };
              this.fullList[group] = entityList;
            }
          });
        });
      }

      this.selectedFormControl.setValue(currentSelectedFormValue);
      this.updateList(true);
    }

    remove() {
      const updatedValue = this.selectedFormControl.value.filter(item => this.toBeUnselected.value.indexOf(item) === -1);
      this.selectedFormControl.setValue(updatedValue);
      if (!this.grouped) {
        this.fullList.forEach(item => {
          if (this.toBeUnselected.value.includes(item.value)) {
            item.selected = false;
          }
        });
      } else {
        Object.keys(this.fullList).forEach(group => {
          this.fullList[group].forEach((entity, index) => {
            if (this.toBeUnselected.value.includes(entity.value)) {
              const entityList = [ ...this.fullList[group] ];
              entityList[index] = { ...entity, selected: false };
              this.fullList[group] = entityList;
            }
          });
        });
      }

      this.updateList(true);
    }

    valueChangesListener() {
      this.leftFilterKeyword.valueChanges.subscribe(keyword => {
        if (this.fullList) {
          const updatedKeyword = ((keyword !== undefined) ? keyword : '').toLowerCase();
          if (!this.grouped) {
            this.unselectedList = this.fullList.filter(item => !item.selected && item.label.toLowerCase().includes(updatedKeyword));
          } else {
            this.unselectedList = {};
            Object.keys(this.fullList).forEach(group => {
              if (this.fullList[group].filter(entity => !entity.selected && entity.label.toLowerCase().includes(updatedKeyword).length > 0)) {
                this.unselectedList[group] = this.fullList[group].filter(entity => !entity.selected && entity.label.toLowerCase().includes(updatedKeyword));
              }
            });
          }
        }
      });

      this.rightFilterKeyword.valueChanges.subscribe(keyword => {
        if (this.fullList) {
          const updatedKeyword = ((keyword !== undefined) ? keyword : '').toLowerCase();
          if (!this.grouped) {
            this.selectedList = this.fullList.filter(item => item.selected && item.label.toLowerCase().includes(updatedKeyword));
          } else {
            this.selectedList = {};
            Object.keys(this.fullList).forEach(group => {
              if (this.fullList[group].filter(entity => entity.selected && entity.label.toLowerCase().includes(updatedKeyword).length > 0)) {
                this.selectedList[group] = this.fullList[group].filter(entity => entity.selected && entity.label.toLowerCase().includes(updatedKeyword));
              }
            });
          }
        }
      });
    }

    updateList(clearSelected = false) {
      this.unselectedList = !this.grouped ? [] : {};
      this.selectedList = !this.grouped ? [] : {};

      if (this.fullList) {
        if (!this.grouped) {
          this.fullList.forEach(item => {
            if (item.selected) this.selectedList.push(item);
            else this.unselectedList.push(item);
          });
        } else {
          Object.keys(this.fullList).forEach(group => {
            const selectedGroupEntities = [ ...this.fullList[group].filter(entity => entity.selected) ];
            const unselectedGroupEntities = [ ...this.fullList[group].filter(entity => !entity.selected) ];

            if (selectedGroupEntities.length > 0) this.selectedList[group] = selectedGroupEntities;
            if (unselectedGroupEntities.length > 0) this.unselectedList[group] = unselectedGroupEntities;
          })
        }
      }

      if (clearSelected) {
        this.toBeSelected.patchValue([], { emitEvent: false });
        this.toBeUnselected.patchValue([], { emitEvent: false });
      }
    }

  }
