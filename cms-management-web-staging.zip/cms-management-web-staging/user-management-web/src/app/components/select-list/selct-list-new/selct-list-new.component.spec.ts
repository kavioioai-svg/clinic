import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelctListNewComponent } from './selct-list-new.component';

describe('SelctListNewComponent', () => {
  let component: SelctListNewComponent;
  let fixture: ComponentFixture<SelctListNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelctListNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelctListNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
