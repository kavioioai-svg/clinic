import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnselectListNewComponent } from './unselect-list-new.component';

describe('UnselectListNewComponent', () => {
  let component: UnselectListNewComponent;
  let fixture: ComponentFixture<UnselectListNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnselectListNewComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnselectListNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
