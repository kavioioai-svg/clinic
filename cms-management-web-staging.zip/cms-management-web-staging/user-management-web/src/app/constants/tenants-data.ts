export const DOMAIN_NAMES = ['localhost', 'mgmtnav.healthwaymedical.info', 'mgmt2.healthwaymedical.com.sg'];

export const DEFAULT_TENANT_ID = 'HMC_555b5f65e8041214de5f'