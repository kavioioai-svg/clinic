export const INVALID_TOKEN_ERROR_MESSAGE = 'Your session has expired and will be redirected to login page';
export const EMPTY_2FA_PIN = 'PIN cannot be empty';
export const MAX_2FA_PIN = 'PIN cannot contain more than 5 digits';
export const EMPTY_OLD_PASSWORD_ERROR = 'Password cannot be empty';
export const EMPTY_NEW_PASSWORD_ERROR = 'New password cannot be empty';
export const EMPTY_NEW_CONFIRM_PASSWORD_ERROR = 'Confirm new password cannot be empty';
export const NEW_PASSWORD_SAME_AS_OLD_PASSWORD_ERROR = 'New password cannot be as same as old password';
export const PASSWORDS_DO_NOT_MATCH_ERROR = 'Passwords do not match';