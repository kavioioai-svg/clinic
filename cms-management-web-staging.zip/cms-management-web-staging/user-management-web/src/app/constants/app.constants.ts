// export const API_URL = 'https://devserver.lippoinnolab.com';

export const API_DOMAIN = [
  'devserver.lippoinnolab.com',
  'cmsuatapi.lippoinnolab.com',
  'api.healthwaymedical.com.sg',
  'api2.healthwaymedical.com.sg',
  'admin.lippoinnolab.com',
  'reports2.healthwaymedical.com.sg',
  'reports.healthwaymedical.com.sg',
  'cmsapi.healthwaymedical.info',
  'digi.healthwaymedical.com.sg',
  'digi.healthwaymedical.com.sg',
  'localhost:9090',
  'localhost:8991'

];
// export const API_AA_URL = 'https://devserver.lippoinnolab.com/aacore';
// export const API_PATIENT_VISIT_URL = 'https://devserver.lippoinnolab.com/patient-visit';
// export const API_INVENTORY_SYSTEM_URL = 'http://127.0.0.1:8902';
// export const API_PATIENT_INFO_URL = 'https://devserver.lippoinnolab.com/patient-info';
// export const API_CMS_MANAGEMENT_URL = 'https://devserver.lippoinnolab.com/cms-management-proxy';

export const DISPLAY_DATE_FORMAT = 'DD-MM-YYYY';
export const DISPLAY_DATE_TIME_NO_SECONDS_FORMAT = 'DD-MM-YYYY HH:mm';
export const DB_FULL_DATE_FORMAT = 'DD-MM-YYYYTHH:mm:ss';
export const DB_FULL_DATE_FORMAT_NO_SECOND = 'DD-MM-YYYYTHH:mm';
export const DB_FULL_DATE_TIMEZONE = 'ddd MMM DD YYYY HH:mm:ss ZZ';
export const SINGAPORE_TIME = 'Asia/Singapore';

export const INPUT_DELAY = 500;
export const INPUT_DELAY_INVENTORY = 1000;

export const GST_MAP = [
  { cutOffDate: '31-12-2022', gstOnly: 0.07, withGst: 1.07, percentageString: '7' },
  { cutOffDate: '31-12-2023', gstOnly: 0.08, withGst: 1.08, percentageString: '8' },
  { cutOffDate: '31-12-2050', gstOnly: 0.09, withGst: 1.09, percentageString: '9' },
];

export const HEADER_TITLES = [
  { url: '/pages/welcome', value: 'Welcome' },
  { url: '/pages/user/doctor', value: 'User Doctor' },
  { url: '/pages/user/all', value: 'All Users' },
  { url: '/pages/group/all', value: 'All Groups' },
  { url: '/pages/module/all', value: 'All Module' },
  { url: '/pages/drug/master', value: 'Drugs' },
  { url: '/pages/drug/sig', value: 'Drugs' },
  { url: '/pages/report/search', value: 'Reports' },
  { url: '/pages/report', value: 'Reports' },
  { url: '/pages/inventory', value: 'Inventory' },
  { url: '/pages/supplier', value: 'Supplier' },
  { url: '/pages/master-data', value: 'Master Data' },
  { url: '/pages/medical-coverage', value: 'Medical Coverage' },
  { url: '/pages/claim/refund-bill', value: 'Bill Management' },
  { url: '/pages/claims', value: 'Claims' },
  { url: '/pages/clinic-item', value: 'Sales Price' },
  { url: '/pages/item', value: 'Item' },
  { url: '/pages/services', value: 'Services' },
  { url: '/pages/clinic/all', value: 'Clinic' },
  { url: '/pages/invoice', value: 'Invoice' },
];
export const PRIVATE_PATIENT_REPORTS = [
  {
    reportDisplayName: 'Normal',
    reportName: 'private_corporate_patient_listing',
  },
  {
    reportDisplayName: 'Paginated',
    reportName: 'private_corporate_patient_listing_paginated',
  },
  {
    reportDisplayName: 'Short',
    reportName: 'private_corporate_patient_listing_short',
  },
];
export const STATUS = ['ACTIVE', 'INACTIVE', 'BLOCKED'];

export const TRUE_FALSE_ANWS = [
  { value: true, label: 'Yes' },
  { value: false, label: 'No' }
];

export const REPORT_TYPES = [  
  { value: false, label: 'Normal' },
  { value: true, label: 'Details' }
];

// export const PRICE_ADJUSTMENT_TYPE = [{label: '$', value: 'DOLLAR'}, {label: '%', value: 'PERCENTAGE'} ];
export const PRICE_ADJUSTMENT_TYPE = [{ label: '$', value: 'DOLLAR' }];
export const GST = 1.07;
export enum ItemType {
  LABORATORY = 'LABORATORY',
  IMPLANTS = 'IMPLANTS',
  CONSULTATION = 'CONSULTATION',
  SERVICE = 'SERVICE',
  DRUG = 'DRUG',
  CONSUMABLE = 'CONSUMABLE',
  VACCINATION = 'VACCINATION',
  PROCEDURE = 'PROCEDURE',
  RADIOLOGY = 'RADIOLOGY',
  FACILITIES_FEE = 'FACILITIES_FEE',
  GENERAL_SCREENING = 'GENERAL_SCREENING',
  GENERAL_SCREEN = 'GENERAL_SCREEN',
  PACKAGE = 'PACKAGE',
  OTHER = 'OTHER'
}
export const ITEM_TYPE_DROPDOWN_LIST = ['Vaccination',
  'Laboratory',
  'Implants',
  'Consultation',
  'Service',
  'Drug',
  'Consumable',
  'Procedure',
  'Radiology',
  'Facilities_Fee',
  'General_Screening',
  'General_Screen',
  'Package',
  'Other'];

export const SFL_TEST_ORDER = [
  { value: 1, label: 'Initial Screen' },
  { value: 2, label: '1st Repeat Screen' },
  { value: 3, label: '2nd Repeat Screen' },
  { value: 4, label: 'Follow Up' },
];

export const WHATSAPP_NUMBER_PATTERN = /^[1-9][0-9]{6,14}$/; 