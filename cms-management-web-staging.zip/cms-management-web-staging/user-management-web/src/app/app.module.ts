import {ItemService} from './services/item.service';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {APP_INITIALIZER, NgModule} from '@angular/core';

import {AppConfigService} from './services/app-config.service';

import {AppComponent} from './app.component';
import {FullLayoutComponent} from './containers/full-layout';
import {SimpleLayoutComponent} from './containers/simple-layout';

import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {JwtModule} from '@auth0/angular-jwt';
import {NgxPermissionsModule, NgxPermissionsService} from 'ngx-permissions';

import {RouterModule, Routes} from '@angular/router';
import {SharedModule} from './shared.module';

import {ApiAAService} from './services/api-aa';
import {AlertService} from './services/alert.service';
import {AuthService} from './services/auth.service';
import {ConsoleLoggerService} from './services/console-logger.service';
import {LoggerService} from './services/logger.service';
import {StoreService} from './services/store.service';
import {UtilsService} from './services/utils.service';
import {API_DOMAIN} from './constants/app.constants';

import {AuthGuardService, AuthGuardService as AuthGuard} from './services/auth-guard.service';
import {
  PermissionsGuardService,
  PermissionsGuardService as PermissionsGuard
} from './services/permissions-guard.service';

import {AsideToggleDirective, ReplaceDirective, SIDEBAR_TOGGLE_DIRECTIVES} from './directives';

import {AkitaNgDevtools} from '@datorama/akita-ngdevtools';

import {
  APP_SIDEBAR_NAV,
  AppFooterComponent,
  AppHeaderComponent,
  AppSidebarComponent,
  AppSidebarFooterComponent,
  AppSidebarFormComponent,
  AppSidebarHeaderComponent,
  AppSidebarMinimizerComponent
} from './components';
import {ApiCmsManagementService} from './services/api-cms-management.service';
import {JwtInterceptor} from './services/jwt-interceptor';
import {environment} from '../environments/environment';
import {ApiDocumentService} from './services/api-document-service';

const APP_CONTAINERS = [FullLayoutComponent, SimpleLayoutComponent];

// Import directives
const APP_DIRECTIVES = [AsideToggleDirective, ReplaceDirective, SIDEBAR_TOGGLE_DIRECTIVES];

const APP_COMPONENTS = [
  AppFooterComponent,
  AppHeaderComponent,
  AppSidebarComponent,
  AppSidebarFooterComponent,
  AppSidebarFormComponent,
  AppSidebarHeaderComponent,
  AppSidebarMinimizerComponent,
  APP_SIDEBAR_NAV
];

export function getAccessToken() {
  return localStorage.getItem('access_token');
}

const appInitializerFn = (appConfig: AppConfigService) => {
  return () => {
    return appConfig.loadAppConfig();
  };
};

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'pages',
    component: FullLayoutComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: {
      title: 'Home'
    },
    children: [
      {
        path: 'user',
        loadChildren: './views/components/user/user.module#UserModule',
        data: {
          permissions: {
            only: ['ROLE_USER_CREATE']
          }
        }
      },
      {
        path: 'group',
        loadChildren: './views/components/group/group.module#GroupModule',
        data: {
          permissions: {
            only: ['ROLE_AA_ADMIN']
          }
        }
      },
      {
        path: 'module',
        loadChildren: './views/components/aamodule/aamodule.module#AAModuleModule',
        data: {
          permissions: {
            only: ['ROLE_AA_ADMIN']
          }
        }
      },
      {
        path: 'medical-coverage',
        loadChildren: './views/components/medical-coverage/medical-coverage.module#MedicalCoverageModule',
        data: {
          permissions: {
            only: ['ROLE_MEDICAL_COVERAGE_MANAGEMENT']
          }
        }
      },
      {
        path: 'item',
        loadChildren: './views/components/drug-master/drug-master.module#DrugMasterModule',
        data: {
          permissions: {
            only: ['ROLE_DRUG_CONTROLLER']
          }
        }
      },
      {
        path: 'clinic-item',
        loadChildren: './views/components/item-pricing-master/item-pricing-master.module#ItemPricingMasterModule',
        data: {
          permissions: {
            only: ['ROLE_VIEW_MEDICAL_COVERAGE']
          }
        }
      },
      {
        path: 'claims',
        loadChildren: './views/components/claim/claim.module#ClaimModule',
        data: {
          permissions: {
            only: ['ROLE_MHCP_LIST', 'ROLE_MHCP_LIST_HQ']
          }
        }
      },
      {
        path: 'claim',
        loadChildren: './views/components/claim/claim.module#ClaimModule',
        data: {
          permissions: {
            only: ['ROLE_SO_CORRECTION', 'ROLE_REFUND']
          }
        }
      },
      {
        path: 'report',
        loadChildren: './views/components/report/report.module#ReportModule',
        data: {
          permissions: {
            only: ['ROLE_REPORT_VIEWER']
          }
        }
      },
      {
        path: 'doctor',
        loadChildren: './views/components/doctor/doctor.module#DoctorModule',
        data: {
          permissions: {
            only: ['ROLE_DOCTOR_MANAGE']
          }
        }
      },
      {
        path: 'clinic',
        loadChildren: './views/components/clinic/clinic.module#ClinicModule',
        data: {
          permissions: {
            only: ['ROLE_CLINIC_MANAGE']
          }
        }
      },
      {
        path: 'services',
        loadChildren: './views/components/service/service.module#ServiceModule',
        data: {
          permissions: {
            only: ['ROLE_MWOC_UPPROJ', 'ROLE_NOTICEBOARD_MANAGE', 'ROLE_COMPANY_GROUPING_MANAGEMENT', 'ROLE_WEB_APPOINTMENT_MGMT_VIEW']
          }
        }
      },
      {
        path: 'welcome',
        loadChildren: './views/components/welcome/welcome.module#WelcomeModule'
      },
      {
        path: 'profile',
        loadChildren: './views/components/profile/profile.module#ProfileModule'
      },
      // {
      //   path: 'clinic-item',
      //   loadChildren: './views/components/charge-item/charge-item.module#ChargeItemModule',
      //   data: {
      //     permissions: {
      //       only: ['ROLE_ITEM_MANAGEMENT_CONTROLLER']
      //     }
      //   }
      // },
      {
        path: 'inventory',
        loadChildren: './views/components/inventory/inventory.module#InventoryModule',
        data: {
          permissions: {
            only: ['ROLE_INVENTORY_MANAGEMENT']
          }
        }
      },
      {
        path: 'master-data',
        loadChildren: './views/components/master-data/master-data.module#MasterDataModule',
        data: {
          permissions: {
            only: ['ROLE_INVENTORY_MANAGEMENT']
          }
        }
      },
      {
        path: 'supplier',
        loadChildren: './views/components/supplier/supplier.module#SupplierModule',
        data: {
          permissions: {
            only: ['ROLE_INVENTORY_MANAGEMENT']
          }
        }
      },
      {
        path: 'invoice',
        loadChildren: './views/components/invoice/invoice.module#InvoiceModule',
        data: {
          permissions: {
            only: ['ROLE_INVENTORY_MANAGEMENT']
          }
        }
      },
      // {
      //   path: 'item-master',
      //   loadChildren: './views/components/master-data/item-master-data.module#ItemMasterDataModule',
      //   data: {
      //     permissions: {
      //       only: ['ROLE_INVENTORY_MANAGEMENT']
      //     }
      //   }
      // },
    ]
  },
  {
    path: '',
    component: SimpleLayoutComponent,
    data: {
      title: 'Pages'
    },
    children: [
      {
        path: '',
        loadChildren: './views/pages/pages.module#PagesModule'
      }
    ]
  },

  { path: '**', redirectTo: '/pages/user/all' }
];

@NgModule({
  exports: [RouterModule],
  declarations: [AppComponent, ...APP_CONTAINERS, ...APP_COMPONENTS, ...APP_DIRECTIVES],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getAccessToken,
        whitelistedDomains: API_DOMAIN
      }
    }),
    NgxPermissionsModule.forRoot(),
    RouterModule.forRoot(routes, { useHash: true, enableTracing: true }),
    environment.production ? [] : AkitaNgDevtools.forRoot()
  ],
  providers: [
    AlertService,
    ApiAAService,
    ApiCmsManagementService,
    AuthService,
    AuthGuardService,
    PermissionsGuardService,
    StoreService,
    AppConfigService,
    UtilsService,
    NgxPermissionsService,
    ItemService,
    ApiCmsManagementService,
    ApiDocumentService,
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFn,
      multi: true,
      deps: [AppConfigService]
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: (ps: NgxPermissionsService) =>
        function () {
          return new Promise((resolve, reject) => {
            if (localStorage.getItem('roles')) {
              resolve(localStorage.getItem('roles'));
            } else {
              // reject('error');
              resolve('');
            }
          }).then((data: string) => {
            // authService.permissionsLoaded = true;
            if (data) {
              return ps.loadPermissions(JSON.parse(data));
            }
          });
        },
      deps: [NgxPermissionsService],
      multi: true
    },
    {
      provide: LoggerService,
      useClass: ConsoleLoggerService
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
