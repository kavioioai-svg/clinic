import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Injectable } from '@angular/core';

export interface DoctorSpecialityState extends EntityState<{ value: string; label: string }> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'doctor-speciality', idKey: 'value' })
export class DoctorSpecialityStore extends EntityStore<DoctorSpecialityState> {
  constructor() {
    super();
  }
}
