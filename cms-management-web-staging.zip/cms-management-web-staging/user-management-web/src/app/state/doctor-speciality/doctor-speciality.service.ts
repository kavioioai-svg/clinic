import { DoctorSpecialityStore } from './doctor-speciality.store';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';

@Injectable({ providedIn: 'root' })
export class DoctorSpecialityService {
  constructor(
    private doctorSpecialityStore: DoctorSpecialityStore,
    private apiCmsManagementService: ApiCmsManagementService
  ) {}

  getSpecialities() {
    return this.apiCmsManagementService
      .listSpecialities()
      .pipe(
        tap(res => this.doctorSpecialityStore.set((res.payload || []).map(item => ({ value: item, label: item }))))
      );
  }
}
