import { QueryEntity } from '@datorama/akita';
import { DoctorSpecialityStore, DoctorSpecialityState } from './doctor-speciality.store';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class DoctorSpecialityQuery extends QueryEntity<DoctorSpecialityState> {
  constructor(protected store: DoctorSpecialityStore) {
    super(store);
  }
}
