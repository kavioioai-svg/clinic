import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Injectable } from '@angular/core';
import { Doctor } from '../../objects/Doctor';

export interface DoctorState extends EntityState<Doctor> {}

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'doctor' })
export class DoctorStore extends EntityStore<DoctorState> {

  constructor() {
    super();
  }

}
