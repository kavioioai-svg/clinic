import { QueryEntity } from '@datorama/akita';
import { DoctorStore, DoctorState } from './doctor.store';
import { Injectable } from '@angular/core';
import { Doctor } from '../../objects/Doctor';

@Injectable({
  providedIn: 'root'
})
export class DoctorQuery extends QueryEntity<DoctorState> {
  constructor(protected store: DoctorStore) {
    super(store);
  }

  getActiveDoctor(): Doctor[] {
    return this.getAll({ filterBy: doctor => doctor.status === 'ACTIVE' });
  }

  getActiveAnchorDoctor(): Doctor[] {
    return this.getAll({ filterBy: doctor => doctor.status === 'ACTIVE' && doctor.doctorGroup === 'ANCHOR' });
  }
}
