import { Store, StoreConfig } from '@datorama/akita';
import { User } from '../../objects/response/User';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'auth-user', idKey: 'userName' })
export class AuthUserStore extends Store<User> {
  constructor() {
    super(new User());
  }
}
