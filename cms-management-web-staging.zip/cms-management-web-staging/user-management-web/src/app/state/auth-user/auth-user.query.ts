import { Query } from '@datorama/akita';
import { AuthUserStore } from './auth-user.store';
import { User } from '../../objects/response/User';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthUserQuery extends Query<User> {
  constructor(protected store: AuthUserStore) {
    super(store);
  }

  getUserLabel(): string {
    return this.getValue()
      ? this.getValue()
          .userName.slice(0, 1)
          .toUpperCase()
      : '';
  }
}
