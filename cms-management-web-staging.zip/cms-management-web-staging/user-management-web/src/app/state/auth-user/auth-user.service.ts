import { Injectable } from '@angular/core';
import { ID } from '@datorama/akita';
import { HttpClient } from '@angular/common/http';
import { AuthUserStore } from './auth-user.store';
import { tap } from 'rxjs/operators';
import { ApiAAService } from '../../services/api-aa';
import { User } from '../../objects/response/User';
import { NgxPermissionsService } from 'ngx-permissions';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthUserService {
  constructor(
    private authUserStore: AuthUserStore,
    private apiAAService: ApiAAService,
    private permissionsService: NgxPermissionsService,
    private router: Router
  ) {}

  getUser() {
    return this.apiAAService.getUser().pipe(tap(res => this.authUserStore._setState(state => res.payload)));
  }

  logoutClearUp() {
    this.authUserStore._setState(state => new User());
    this.permissionsService.flushPermissions();
    this.router.navigate(['login']);
  }
}
