import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { DrugCategoryStore, DrugCategoryState } from './drug-category.store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class DrugCategoryQuery extends QueryEntity<DrugCategoryState> {
  constructor(protected store: DrugCategoryStore) {
    super(store);
  }

  getCategoryStringArray(): Array<string> {
    return this.getAll().map(cat => cat.category);
  }

  selectCategoryStringArray(): Observable<Array<string>> {
    return this.selectAll().pipe(map(cats => cats.map(cat => cat.category)));
  }
}
