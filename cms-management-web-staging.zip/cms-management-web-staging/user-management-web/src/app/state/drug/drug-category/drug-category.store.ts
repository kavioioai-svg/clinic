import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';

export interface DrugCategoryState extends EntityState<{ category: string }> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drug-category', idKey: 'category' })
export class DrugCategoryStore extends EntityStore<DrugCategoryState> {
  constructor() {
    super();
  }
}
