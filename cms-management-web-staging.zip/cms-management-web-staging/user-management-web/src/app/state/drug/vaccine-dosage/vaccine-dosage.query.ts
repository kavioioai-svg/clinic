import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { VaccineDosageState, VaccineDosageStore } from './vaccine-dosage.store';

@Injectable({ providedIn: 'root' })
export class VaccineDosageQuery extends QueryEntity<VaccineDosageState> {

  constructor(protected store: VaccineDosageStore) {
    super(store);
  }

}
