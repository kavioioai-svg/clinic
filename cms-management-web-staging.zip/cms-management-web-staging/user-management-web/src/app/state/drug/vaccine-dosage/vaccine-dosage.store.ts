import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { VaccineDosage } from '../../../objects/request/Drug';

export interface VaccineDosageState extends EntityState<VaccineDosage> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'vaccine-dosage', idKey: 'code' })
export class VaccineDosageStore extends EntityStore<VaccineDosageState> {
  constructor() {
    super();
  }
}
