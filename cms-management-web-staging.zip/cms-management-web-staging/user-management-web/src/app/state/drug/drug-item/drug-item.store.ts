import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import {  Drug } from '../../../objects/request/Drug';

export interface DrugItemState extends EntityState<Drug> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drug-item', idKey: 'drugItem' })
export class DrugItemStore extends EntityStore<DrugItemState> {
  constructor() {
    super();
  }
}
