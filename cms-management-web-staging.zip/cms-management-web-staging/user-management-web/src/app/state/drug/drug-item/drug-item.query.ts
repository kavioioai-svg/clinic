import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import {DrugItemState, DrugItemStore} from './drug-item.store';

@Injectable({ providedIn: 'root' })
export class DrugItemQuery extends QueryEntity<DrugItemState> {

  constructor(protected store: DrugItemStore) {
    super(store);
  }

}
