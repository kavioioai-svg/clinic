import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';

export interface DrugCautionaryState extends EntityState<{ cautionary: string }> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drug-cautionary', idKey: 'cautionary' })
export class DrugCautionaryStore extends EntityStore<DrugCautionaryState> {
  constructor() {
    super();
  }
}
