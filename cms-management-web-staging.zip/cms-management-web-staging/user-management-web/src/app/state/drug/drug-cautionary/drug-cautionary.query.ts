import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { DrugCautionaryStore, DrugCautionaryState } from './drug-cautionary.store';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DrugCautionaryQuery extends QueryEntity<DrugCautionaryState> {
  constructor(protected store: DrugCautionaryStore) {
    super(store);
  }

  getCautionaryStringArray(): Array<string> {
    return this.getAll().map(cau => cau.cautionary);
  }

  selectCautionaryStringArray(): Observable<Array<string>> {
    return this.selectAll().pipe(map(caus => caus.map(cau => cau.cautionary)));
  }
}
