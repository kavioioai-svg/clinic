import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { DosageInstruction } from '../../../objects/request/Drug';

export interface DosageInstructionState extends EntityState<DosageInstruction> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'dosage-instruction', idKey: 'code' })
export class DosageInstructionStore extends EntityStore<DosageInstructionState> {
  constructor() {
    super();
  }
}
