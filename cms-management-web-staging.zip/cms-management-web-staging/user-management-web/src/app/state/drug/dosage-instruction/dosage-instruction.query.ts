import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { DosageInstructionStore, DosageInstructionState } from './dosage-instruction.store';

@Injectable({ providedIn: 'root' })
export class DosageInstructionQuery extends QueryEntity<DosageInstructionState> {

  constructor(protected store: DosageInstructionStore) {
    super(store);
  }

}
