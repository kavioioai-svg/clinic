import { Injectable } from '@angular/core';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';
import { tap } from 'rxjs/operators';
import { DosageInstructionStore } from './dosage-instruction/dosage-instruction.store';
import { DrugCategoryStore } from './drug-category/drug-category.store';
import { DrugCautionaryStore } from './drug-cautionary/drug-cautionary.store';
import { DrugUomStore } from './drug-uom/drug-uom.store';
import { DrugInstructionStore } from './drug-instruction/drug-instruction.store';
import { VaccineDosageStore } from './vaccine-dosage/vaccine-dosage.store';

@Injectable({
  providedIn: 'root'
})
export class DrugService {
  constructor(
    private drugInstructionStore: DrugInstructionStore,
    private dosageInstructionStore: DosageInstructionStore,
    private drugCategoryStore: DrugCategoryStore,
    private drugCautionaryStore: DrugCautionaryStore,
    private drugUomStore: DrugUomStore,
    private vaccineDosageStore: VaccineDosageStore,
    private apiCmsManagementService: ApiCmsManagementService
  ) {}

  getDrugInfo() {
    return this.apiCmsManagementService.listDrugInstructions().pipe(
      tap(res => {
        this.drugInstructionStore.set(res.payload.INSTRUCTIONS || []);
        this.dosageInstructionStore.set(res.payload.DOSAGE_INSTRUCTIONS || []);
        this.drugCategoryStore.set(res.payload.CATEGORIES || []);
        this.drugCautionaryStore.set(res.payload.CAUTIONARIES || []);
        this.drugUomStore.set(res.payload.DOSAGE_UOM || []);
        this.vaccineDosageStore.set(res.payload.VACCINE_DOSAGE_MASTER || []);
      })
    );
  }
}
