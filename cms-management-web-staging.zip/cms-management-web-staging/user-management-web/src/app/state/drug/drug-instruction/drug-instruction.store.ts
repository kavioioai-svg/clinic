import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Instruction } from '../../../objects/request/Drug';

export interface DrugInstructionState extends EntityState<Instruction> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drug-instruction', idKey: 'code' })
export class DrugInstructionStore extends EntityStore<DrugInstructionState> {
  constructor() {
    super();
  }
}
