import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { DrugInstructionStore, DrugInstructionState } from './drug-instruction.store';

@Injectable({ providedIn: 'root' })
export class DrugInstructionQuery extends QueryEntity<DrugInstructionState> {

  constructor(protected store: DrugInstructionStore) {
    super(store);
  }

}
