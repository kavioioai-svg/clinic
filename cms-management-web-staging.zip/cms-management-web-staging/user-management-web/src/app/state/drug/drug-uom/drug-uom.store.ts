import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Uom } from '../../../objects/request/Drug';

export interface DrugUomState extends EntityState<Uom> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drug-uom', idKey: 'uom' })
export class DrugUomStore extends EntityStore<DrugUomState> {
  constructor() {
    super();
  }
}
