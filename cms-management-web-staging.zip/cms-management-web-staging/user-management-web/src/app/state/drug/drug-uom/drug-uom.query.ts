import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { DrugUomStore, DrugUomState } from './drug-uom.store';

@Injectable({ providedIn: 'root' })
export class DrugUomQuery extends QueryEntity<DrugUomState> {

  constructor(protected store: DrugUomStore) {
    super(store);
  }

}
