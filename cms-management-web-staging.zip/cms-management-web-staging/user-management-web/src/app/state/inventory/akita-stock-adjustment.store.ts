import { Injectable } from '@angular/core';

import { EntityStore, StoreConfig } from '@datorama/akita';

import { AKITA_CACHE_DURATION } from '../../constants/akita.config';
import {InventoryInfo} from '../../objects/InventoryInfo';

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'stockadjustment',
  idKey: 'code',
  cache: { ttl: AKITA_CACHE_DURATION },
  resettable: true,
})
export class AkitaStockAdjustmentStore extends EntityStore<InventoryInfo> {
  constructor() {
    super();
  }
}
