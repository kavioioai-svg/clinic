import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';

export interface InventoryState extends EntityState<any> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'inventory' })
export class InventoryStore extends EntityStore<InventoryState> {

  constructor() {
    super();
  }

}
