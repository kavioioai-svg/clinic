import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { InventoryStore, InventoryState } from './inventory.store';

@Injectable({ providedIn: 'root' })
export class InventoryQuery extends QueryEntity<InventoryState> {

  constructor(protected store: InventoryStore) {
    super(store);
  }

}
