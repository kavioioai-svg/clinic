import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { map } from 'rxjs/operators';
import { MedicalCoverage } from '../../objects/MedicalCoverage';
import { MedicalCoverageStore, MedicalCoverageState } from './medical-coverage.store';

@Injectable({ providedIn: 'root' })
export class MedicalCoverageQuery extends QueryEntity<MedicalCoverageState> {

  constructor(protected store: MedicalCoverageStore) {
    super(store);
  }

  getMedicalCoveragePlan(planId) {
    let coveragePlan;

    this.getAll().forEach((medCoverage) => {
      medCoverage.coveragePlans.forEach(plan => {
        if (plan.id === planId) {
          coveragePlan = plan;
        }
      });
    });

    if (!coveragePlan) coveragePlan = undefined;
    return coveragePlan;
  }

  selectMedicalCoverages(planIds: Array<string>) {
    return this.selectAll().pipe(
      map(medicalCoverages => {
        return medicalCoverages.filter((medicalCoverage: MedicalCoverage) => {
          const mcPlanIds = medicalCoverage.coveragePlans.map(plan => plan.id);
          if (mcPlanIds.some(mcPlanId => planIds.indexOf(mcPlanId) !== -1)) return medicalCoverage;
        });
      })
    );
  }
}
