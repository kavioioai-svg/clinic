import { Injectable } from '@angular/core';
import { MedicalCoverageStore } from './medical-coverage.store';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MedicalCoverageService {
  constructor(
    private medicalCoverageStore: MedicalCoverageStore,
    private apiCmsManagementService: ApiCmsManagementService
  ) {}

  getMedicalCoverageList() {
    return this.apiCmsManagementService
      .listMedicalCoveragesWithPagination(0, 10000)
      .pipe(
        tap(res => this.medicalCoverageStore.set(res.payload.content))
      );
  }
}
