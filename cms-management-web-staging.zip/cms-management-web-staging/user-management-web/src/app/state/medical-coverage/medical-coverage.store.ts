import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { MedicalCoverage } from '../../objects/MedicalCoverage';

export interface MedicalCoverageState extends EntityState<MedicalCoverage> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'medical-coverage' })
export class MedicalCoverageStore extends EntityStore<MedicalCoverageState> {

  constructor() {
    super();
  }

}

