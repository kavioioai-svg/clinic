import { Injectable } from '@angular/core';
import { ClinicStore } from './clinic.store';
import { tap } from 'rxjs/operators';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';

@Injectable({ providedIn: 'root' })
export class ClinicService {
  constructor(private clinicStore: ClinicStore, private apiCmsManagementService: ApiCmsManagementService) {}

  getClinicList() {
    return this.apiCmsManagementService.listClinics().pipe(tap(res => this.clinicStore.set(res.payload || [])));
  }
}
