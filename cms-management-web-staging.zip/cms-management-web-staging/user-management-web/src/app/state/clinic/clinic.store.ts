import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Clinic } from '../../objects/response/Clinic';
import { Injectable } from '@angular/core';

export interface ClinicState extends EntityState<Clinic> {}

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'clinic' })
export class ClinicStore extends EntityStore<ClinicState> {
  constructor() {
    super();
  }
}
