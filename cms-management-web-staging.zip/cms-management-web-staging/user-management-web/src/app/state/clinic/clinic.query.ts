import { QueryEntity } from '@datorama/akita';
import { ClinicStore, ClinicState } from './clinic.store';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClinicQuery extends QueryEntity<ClinicState> {
  constructor(protected store: ClinicStore) {
    super(store);
  }
}
