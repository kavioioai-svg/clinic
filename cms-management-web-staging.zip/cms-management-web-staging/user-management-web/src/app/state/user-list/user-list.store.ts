import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { UserWithRole } from '../../objects/response/UserWithRole';
import { Injectable } from '@angular/core';

export interface UserListState extends EntityState<UserWithRole> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'user-list', idKey: 'userName' })
export class UserListStore extends EntityStore<UserListState> {
  constructor() {
    super();
  }
  
}
