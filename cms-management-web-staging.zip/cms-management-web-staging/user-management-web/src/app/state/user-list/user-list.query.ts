import { QueryEntity } from '@datorama/akita';
import { UserListStore, UserListState } from './user-list.store';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class UserListQuery extends QueryEntity<UserListState> {

  constructor(protected store: UserListStore) {
    super(store);
  }

}