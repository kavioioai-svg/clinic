import { ID } from '@datorama/akita';
import { UserListStore } from './user-list.store';
import { Injectable } from '@angular/core';
import { ApiAAService } from '../../services/api-aa';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class UserListService {
  constructor(private userListStore: UserListStore, private apiAAService: ApiAAService) {}

  getUserList() {
    return this.apiAAService.listUsersWithPagination().pipe(tap(res => this.userListStore.set(res.payload || [])));
  }
}
