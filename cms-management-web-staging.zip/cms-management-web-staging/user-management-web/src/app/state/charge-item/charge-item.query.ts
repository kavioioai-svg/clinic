import { Injectable } from '@angular/core';

import { QueryEntity } from '@datorama/akita';
import { ChargeItemStore, ChargeItemState } from './charge-item.store';
import { map } from 'rxjs/operators';
import { ChargeItem } from '../../objects/ChargeItem';


@Injectable({
  providedIn: 'root'
})
export class ChargeItemQuery extends QueryEntity<ChargeItemState> {
  constructor(protected store: ChargeItemStore) {
    super(store);
  }

  getDrugOrVaccineItem() {
    return this.getAll({ filterBy: item => item.itemType === 'DRUG' || item.itemType === 'VACCINATION' });
  }

  getInventoriedActiveChargeItems() {
    return this.getAll({ filterBy: item => item.inventoried && item.status === "ACTIVE" });
  }
  getAllInventoriedChargeItems() {
    return this.getAll({ filterBy: item => item.inventoried});
  }

  getPackageItem() {
    return this.getAll({ filterBy: item => item.itemType === 'PACKAGE' });
  }

  getAllItems() {
    return this.getAll()
  }

  getDrugItems() {
    return this.getAll({ filterBy: item => item.itemType === 'DRUG' });
  }

  selectItems() {
    return this.selectAll().pipe(
      map(data => data.map((item: ChargeItem) => ({ value: item.id, label: item.name })))
    );
  }

  selectItemType() {
    return this.selectAll().pipe(
      map(data => data.map(item => item.itemType).filter((value, index, self) => self.indexOf(value) === index && self !== undefined))
    );
  }

  selectItemCategory() {
    return this.selectAll({ filterBy: (entity: ChargeItem) => entity.category !== undefined && entity.category !== null && entity.category.length > 0 }).pipe(
      map(data => data.map(item => item.category).filter((value, index, self) => self.indexOf(value) === index && self !== undefined))
    );
  }

  getItemById(id){
    return this.getEntity(id);
  }
  getChargeItemByCode(code) {
    const chargeItem = <ChargeItem>this.getAll({
      filterBy: (entity: ChargeItem) => entity.code === code
    })[0];

    return chargeItem || undefined;
  }
}
