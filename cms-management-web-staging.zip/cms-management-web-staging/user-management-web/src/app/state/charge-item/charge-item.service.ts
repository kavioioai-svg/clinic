import { ChargeItemStore } from './charge-item.store';
import { Injectable } from '@angular/core';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';
import { tap } from 'rxjs/operators';
import { ChargeItem } from '../../objects/ChargeItem';

@Injectable({
  providedIn: 'root'
})
export class ChargeItemService {
  constructor(private chargeItemStore: ChargeItemStore, private apiCmsManagementService: ApiCmsManagementService) {}

  getChargeItems() {
    return this.apiCmsManagementService.listChargeItems().pipe(
      tap(res =>
        this.chargeItemStore.set(
          (<Array<ChargeItem>>res.payload.map(value => {
            value.item.nameCode = `${value.item.name}-${value.item.code}`;
            return value.item
          })).sort((a, b) => {
            const textA = a.name.toUpperCase();
            const textB = b.name.toUpperCase();
            return textA < textB ? -1 : textA > textB ? 1 : 0;
          })
        )
      )
    );
  }
}
