import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { ChargeItem } from '../../objects/ChargeItem';
import { Injectable } from '@angular/core';

export interface ChargeItemState extends EntityState<ChargeItem> {}

@Injectable({
  providedIn: 'root'
})
@StoreConfig({ name: 'charge-item' })
export class ChargeItemStore extends EntityStore<ChargeItemState> {
  constructor() {
    super();
  }
}
