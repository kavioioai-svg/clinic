import { ID } from '@datorama/akita';
import { StoreStatusStore } from './store-status.store';
import { Injectable } from '@angular/core';
import { StoreStatus } from '../../objects/StoreStatus';

@Injectable({ providedIn: 'root' })
export class StoreStatusService {
  constructor(private storeReadyStore: StoreStatusStore) {}

  setReseting() {
    this.storeReadyStore.update({ hasError: false, isLoaded: false, isReseting: true });
  }

  setLoaded() {
    this.storeReadyStore.update({ hasError: false, isLoaded: true, isReseting: false });
  }

  setError() {
    this.storeReadyStore.update({ hasError: true, isLoaded: true, isReseting: false });
  }
  setLoadingStatus(status) {
    this.storeReadyStore.update({ isLoaded: status });
  }
}
