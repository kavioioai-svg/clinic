import { Store, StoreConfig } from '@datorama/akita';
import { StoreStatus } from '../../objects/StoreStatus';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'store-status' })
export class StoreStatusStore extends Store<StoreStatus> {
  constructor() {
    super({ hasError: false, isLoaded: false, isReseting: false });
  }
}
