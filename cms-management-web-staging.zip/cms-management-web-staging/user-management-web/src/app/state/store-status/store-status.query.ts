import { Query } from '@datorama/akita';
import { StoreStatusStore } from './store-status.store';
import { Injectable } from '@angular/core';
import { StoreStatus } from '../../objects/StoreStatus';

@Injectable({ providedIn: 'root' })
export class StoreStatusQuery extends Query<StoreStatus> {
  constructor(protected store: StoreStatusStore) {
    super(store);
  }
}
