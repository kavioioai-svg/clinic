import { QueryEntity } from '@datorama/akita';
import { Injectable } from '@angular/core';
import { AdjustmentReasonState, AdjustmentReasonStore } from './adjustment-reason.store';

@Injectable({ providedIn: 'root' })
export class AdjustmentReasonQuery extends QueryEntity<AdjustmentReasonState> {
  constructor(protected store: AdjustmentReasonStore) {
    super(store);
  }
}
