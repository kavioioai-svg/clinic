import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { BillAdjustmentReason } from '../../objects/BillAdjustment';
import { ApiCmsManagementService } from '../../services/api-cms-management.service';
import { ApiInventoryService } from '../../services/api-inventory.service';
import { AdjustmentReasonStore } from './adjustment-reason.store';

@Injectable({ providedIn: 'root' })
export class AdjustmentReasonService {
  constructor(
    private adjustmentReasonStore: AdjustmentReasonStore,
    private apiInventoryService: ApiInventoryService
  ) {}

  getAdjustmentReasons() {
    return this.apiInventoryService
      .listAdjustmentReasons()
      .pipe(
        tap(res => this.adjustmentReasonStore.set((res.payload || []).map(item => ({ value: item.code, label: item.description }))))
        // tap(res => this.adjustmentReasonStore.set(res.payload || []))
      );
  }
}
