import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Injectable } from '@angular/core';

export interface AdjustmentReasonState extends EntityState<{ value: string; label: string }> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'adjustment-reason', idKey: 'value' })
export class AdjustmentReasonStore extends EntityStore<AdjustmentReasonState> {
  constructor() {
    super();
  }
}
