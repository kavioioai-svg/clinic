import { Component, OnInit } from '@angular/core';
import { StoreStatus } from '../../objects/StoreStatus';
import { StoreStatusQuery } from '../../state/store-status/store-status.query';

@Component({
  selector: 'app-dashboard',
  templateUrl: './full-layout.component.html',
})
export class FullLayoutComponent implements OnInit {
  isStoreReady = false;
  hasError = false;
  constructor(private storeStatusQuery: StoreStatusQuery) {
    this.storeReadinessSubscriptiuon();
  }

  ngOnInit() {}
  storeReadinessSubscriptiuon() {
    this.storeStatusQuery.select().subscribe((val: StoreStatus) => {
      this.isStoreReady = val.isLoaded && !val.isReseting;

      // if (!val) {
      this.hasError = val.hasError && val.isLoaded && !val.isReseting;
      // }
    });
  }
}
