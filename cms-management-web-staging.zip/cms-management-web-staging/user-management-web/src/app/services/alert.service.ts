import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable, Subject, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class AlertService {
  private subject = new Subject<any>();
  private errorMessages = new Observable<Subject<any>>();
  private keepAfterNavigationChange = false;

  constructor(private router: Router) {
    // clear alert message on route change
    router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (this.keepAfterNavigationChange) {
          // only keep for a single location change
          this.keepAfterNavigationChange = false;
        } else {
          // clear alert
          this.subject.next();
        }
      }
    });
  }

  success(message: string, keepAfterNavigationChange = false) {
    this.keepAfterNavigationChange = keepAfterNavigationChange;
    this.subject.next({ type: 'success', text: message });
    window.scrollTo(0, 0);
  }

  error(message: string, keepAfterNavigationChange = false) {
    this.keepAfterNavigationChange = keepAfterNavigationChange;
    let errorMessage = '';
    try {
      const error = JSON.parse(message);
      errorMessage = this.handleError(error);
    } catch (e) {
      errorMessage = message;
    }

    this.subject.next({ type: 'error', text: errorMessage });
    window.scrollTo(0, 0);
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }

  getErrorMessages(): Observable<any> {
    return this.errorMessages;
  }

  handleError(error: HttpErrorResponse): string {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${error.error.message}`;
      console.error('An error occurred:', error.error.message);
      return errorMessage;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Backend returned code ${error.status}, ` + `body was: ${this.decodeBackendError(error.error)}`;
      console.error(`Backend returned code ${error.status}, ` + `body was: ${JSON.stringify(error.error)}`);
      return errorMessage;
    }
    // return an observable with a user-facing error message

    // return throwError('Something bad happened; please try again later.');
  }

  decodeBackendError(err) {
    if (err.message) {
      return err.message;
    } else {
      return JSON.stringify(err);
    }
  }
}
