import { FormArray, FormBuilder, ValidatorFn, AbstractControl } from '@angular/forms';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { DISPLAY_DATE_FORMAT, GST_MAP } from '../constants/app.constants';

@Injectable()
export class UtilsService {
  constructor(private fb: FormBuilder) {}

  getDBDate(inputDate) {
    let date = moment(Date.now());
    if (inputDate) {
      date = moment(inputDate);
    }

    return date.format('DD-MM-YYYYTHH:mm:ss');
  }

  getDBDateOnly(inputDate) {
    let date = moment(Date.now());
    if (inputDate) {
      date = moment(inputDate);
    }

    return date.format('DD-MM-YYYY');
  }

  mapToDisplayOptions(array) {
    return array.map((data) => {
      return {
        value: data,
        label: this.convertToTitleCase(data),
      };
    });
  }

  convertUnixDateToDashFormat(date) {
    return moment.unix(date).format('DD-MM-YYYY');
  }

  convertToTitleCase(data) {
    let tempString: string = data + '';

    // If data is delimiter-separated ('_')
    tempString = tempString
      .split('_')
      .map((word) => {
        const length = word.length;
        return word.charAt(0).toUpperCase() + word.slice(1, length).toLowerCase();
      })
      .join(' ');

    // For other naming conventions or data types in future, add accordingly

    return tempString;
  }

  formatToE164PhoneNumber(number: string) {
    if (number.charAt(0) !== '+') {
      return '+' + number;
    } else {
      return number;
    }
  }

  convertToTitleCaseUsingSpace(data) {
    let tempString: string = data + '';

    // If data is delimiter-separated ('_')
    tempString = tempString
      .split(' ')
      .map((word) => {
        const length = word.length;
        return word.charAt(0).toUpperCase() + word.slice(1, length).toLowerCase();
      })
      .join(' ');

    // For other naming conventions or data types in future, add accordingly

    return tempString;
  }

  convertStringArrayToMenuOptions(array) {
    const menu = array.map((data) => {
      return {
        value: data,
        label: this.convertToTitleCase(data),
      };
    });
    return menu;
  }

  round(number, precision) {
    const factor = Math.pow(10, precision);
    return Math.round(number * factor) / factor;
  }

  ////////////////////////////     Applicable GST      ////////////////////////////
  static getGSTOnly(date?: string) {
    if (!date) {
      date = moment().format(DISPLAY_DATE_FORMAT);
    }
    date = moment(date, DISPLAY_DATE_FORMAT).format(DISPLAY_DATE_FORMAT);
    return this.getGSTObject(date).gstOnly;
  }

  static getGST(date?: string) {
    if (!date) {
      date = moment().format(DISPLAY_DATE_FORMAT);
    }
    date = moment(date, DISPLAY_DATE_FORMAT).format(DISPLAY_DATE_FORMAT);
    return this.getGSTObject(date).withGst;
  }

  static getGSTLabel(date?: string) {
    if (!date) {
      date = moment().format(DISPLAY_DATE_FORMAT);
    }
    date = moment(date, DISPLAY_DATE_FORMAT).format(DISPLAY_DATE_FORMAT);
    return this.getGSTObject(date).percentageString;
  }

  private static getGSTObject(date) {
    for (let gstData of GST_MAP) {
      const cutOffDate = moment(gstData.cutOffDate, DISPLAY_DATE_FORMAT).endOf('day');
      if (moment(date, DISPLAY_DATE_FORMAT).isBefore(cutOffDate)) {
        return gstData;
      }
    }
  }
}

export function whiteSpaceValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    return ((control.value as string) || '').includes(' ') ? { haveWhiteSpace: { haveWhiteSpace: true } } : null;
  };
}

export function adjustDownPrice(value) {
  if (!value || isNaN(value)) return '0.00';
  const amount = (Number.parseFloat(value) * 0.01).toFixed(2);
  if (amount) return amount;
  return '0.00';
}

export function adjustUpPrice(value) {
  if (!value) return 0;
  return value * 100;
}


