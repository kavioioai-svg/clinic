import { Injectable } from '@angular/core';
import {StockListFilter} from '../objects/StockListFilter';
import {Page} from '../model/page';
import {BehaviorSubject, Observable} from 'rxjs';
import {ApiInventoryService} from './api-inventory.service';
import {StoreService} from './store.service';
import {SearchParams} from '../objects/searchParams';
import {StockAdjustmentListFilter} from '../objects/StockAdjustmentListFilter';
import {StockAdjustmentListItem} from '../objects/StockAdjustmentListItem';
import {map, tap} from 'rxjs/operators';
import {StockTake} from '../objects/StockTake';
import {ChargeItemQuery} from '../state/charge-item/charge-item.query';
import {SyncQueueFilter} from '../objects/SyncQueue';
import {PurchaseOrderFilter} from '../objects/purchaseOrder-filter';
import {ItemService} from './item.service';
import * as moment from "moment";
import {DISPLAY_DATE_FORMAT} from "../constants/app.constants";
import { StockDisposalListFilter } from '../objects/StockDisposalListFilter';
import { StockTakeListFilter } from '../objects/StockTakeListFilter';
import { PurchaseReturnOrderFilter } from '../objects/purchaseReturnOrder-filter';
import { HttpResponseBody } from "../objects/response/HttpResponseBody";

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  private pageFilterState = new BehaviorSubject<any[]>([]);
  private pageFilterState$ = this.pageFilterState.asObservable();

  constructor( private apiInventoryService: ApiInventoryService,
               private store: StoreService,
               private itemService: ItemService,
               private akitaChargeItemQuery: ChargeItemQuery,) { }


  /* STOCK LIST */
  getCurrentStockList(
    params: SearchParams,
    filter: StockListFilter,
    page: Page
  ): Observable<any> {
    return this.apiInventoryService
      .listCurrentStockGroupByItem(
      //  this.store.getClinicList()[0].id,
       // '5b55aabd0550de0021097bef',
        params,
        filter,
        page
      );
  }

  downloadCurrentStockList(
    params: SearchParams,
    filter: StockListFilter,
    page: Page
  ): Observable<any> {
    return this.apiInventoryService
      .downloadCurrentStockGroupByItem(
        params,
        filter,
        page
      );
  }

  getStockAdjustmentList(
    filter: StockAdjustmentListFilter,
    page: Page
  ): Observable<StockAdjustmentListItem[]> {
    return this.apiInventoryService.listStockAdjustmentList(
      filter,
      page
    ).pipe(
      tap(res => {
        page.pageNumber = res['pageNumber'];
        page.totalPages = res['totalPages'];
        page.totalElements = res['totalElements'];
      }),
       map(res => {
        if (!res.payload) {
          return [];
        }
        return this.changeObjectModel(res);
      })
    );
  }

  getStockTakeList(
    filter: StockTakeListFilter,
    page: Page
  ): Observable<StockAdjustmentListItem[]> {
    return this.apiInventoryService.listStockTakeList(
      filter,
      page
    ).pipe(
      tap(res => {
        page.pageNumber = res.payload.pageable['pageNumber'];
        page.totalPages = res.payload['totalPages'];
        page.totalElements = res.payload['totalElements'];
      }),
        map(res => {
        if (!res.payload) {
          return [];
        }
        let itemList = res.payload.content;
        itemList.forEach((item) => {
          item.approveRejectDate = item.approvedDate || item.rejectedDate;
        });
        return itemList;
      })
    );
  }

  getStockDisposalList(
    filter: StockDisposalListFilter,
    page: Page
  ): Observable<StockAdjustmentListItem[]> {
    return this.apiInventoryService.listStockDisposalList(
      filter,
      page
    ).pipe(
      tap(res => {
        if (!res.payload) {
          return [];
        }
        page.pageNumber = res.payload.pageable['pageNumber'];
        page.totalPages = res.payload['totalPages'];
        page.totalElements = res.payload['totalElements'];
      }),
       map(res => {
        if (!res.payload) {
          return [];
        }
        return res.payload.content;
      })
    );
  }

  calculateStockAdjustmentVariance(item) {
    const adjustedQuantity = !!item.adjustedQuantity
      ? item.adjustedQuantity
      : 0;
    const availableCount = !!item.availableCount ? item.availableCount : 0;
    return adjustedQuantity - availableCount;
  }
  stockAdjustmentApproveRejection(isApprove , body ,stockTakeId):Observable<any> {
    return this.apiInventoryService
      .stockAdjustmentApproveRejection(isApprove , body ,stockTakeId);
  }

  stockTakeApproval(body):Observable<any> {
    return this.apiInventoryService
      .stockTakeApproval(body);
  }

  stockTakeReject(body):Observable<any> {
    return this.apiInventoryService
      .stockTakeReject(body);
  }

  stockDisposalApproveRejection( body):Observable<any> {
    return this.apiInventoryService
      .stockDisposalApproveRejection(body);
  }

  getStockAdjustmentById(stockTakeId): Observable<any> {
    return this.apiInventoryService.getStockAdjustmentById(stockTakeId);
  }

  changeObjectModel(res) {
    const a = res.payload.map(stockTake => new StockTake().adapt(stockTake));
    const b = a.reduce((items: Array<StockAdjustmentListItem>, stockTake: StockTake) => {
      return items.concat(stockTake.stockCountItems.map(item => {
        const listItem = item.toStockAdjustmentListItem(this.store, this.akitaChargeItemQuery);
        listItem.stockTakeId = stockTake.id;
        listItem.status = stockTake.approveStatus;
        listItem.requestDate = stockTake.startDate;
        listItem.createdDate = stockTake.createdDate;
        listItem.transactionNo = stockTake.transactionNo;
        listItem.navIntegrationResult = stockTake.navIntegrationResult;
        listItem.approvedDate = stockTake.approvedDate;
        listItem.rejectedDate = stockTake.rejectedDate;
        listItem.approveRejectDate = stockTake.approvedDate || stockTake.rejectedDate;
        listItem.clinicId = stockTake.clinicId;
        return listItem;
      }));
    }, []);

    return b;
  }

  getSyncQueue(page: Page) : Observable<any> {
    return this.apiInventoryService.getSyncQueue(page);
  }

  getThreadHoldsStatus(obj: any) : Observable<any> {
    return this.apiInventoryService.getThreadHoldsStatus(obj);
  }

  refreshSyncQueue(id: string) {
    return this.apiInventoryService.refreshSyncQueue(id);
  }

  filterSyncQueue(filter: SyncQueueFilter, page:Page) {
    return this.apiInventoryService.filterSyncQueue(filter , page);
  }

  retryStockAdjustment(id: string) {
    return this.apiInventoryService.retryStockAdjustment(id);
  }
  getPurchaseOrderList(filter: PurchaseOrderFilter , page: Page) {
    return this.apiInventoryService.getPurchaseOrderList(filter , page);
  }
  getPurchaseReturnOrderList(filter: PurchaseReturnOrderFilter , page: Page) {
    return this.apiInventoryService.getPurchaseReturnOrderList(filter , page);
  }
  getPurchaseOrderById(id: string) {
    return this.apiInventoryService.getPurchaseOrderById(id);
  }
  getPurchaseReturnOrderById(id: string) {
    return this.apiInventoryService.getPurchaseReturnOrderById(id);
  }

  getPoEPrintTemplate(id: string) {
    return this.apiInventoryService.getPoEPrintTemplate(id);
  }

  public convertUom(request: any): Observable<HttpResponseBody> {
    return this.apiInventoryService.convertUom(request);
  }

  changeToggleIcon(index) {
    let ele = document.getElementById(index);
    if (ele.classList.contains('icon-up-open')) {
      ele.classList.toggle('icon-down-open');
    } else {
      ele.classList.toggle('icon-up-open');
    }
  }

  getPageFilterState(): Observable<any> {
    return this.pageFilterState$;
  }

  setPageFilterState(val: any) {
    let page = this.pageFilterState.value.find(r => r.pageIndex == val.pageIndex);
    if(page) {
      return this.pageFilterState.value.find(r => r.pageIndex == val.pageIndex).searchForm  = val.searchForm
    } else {
      return this.pageFilterState.next([...this.pageFilterState.getValue() , ...val]);

    }
  }

  isItemExpired(expiryDateStr) {
    if (!expiryDateStr || expiryDateStr === '31-12-0001') return false;
    const expiryDate = moment(expiryDateStr, DISPLAY_DATE_FORMAT);
    return expiryDate.isBefore(moment()) && expiryDate.format(DISPLAY_DATE_FORMAT) !== moment().format(DISPLAY_DATE_FORMAT);
  }
}
