import { NgxPermissionsService } from 'ngx-permissions';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfigService } from './app-config.service';
import { HttpResponseBody } from '../objects/response/HttpResponseBody';
import {BehaviorSubject, Observable} from 'rxjs';
import {StockListFilter} from '../objects/StockListFilter';
import {Page} from '../model/page';
import {SearchParams} from '../objects/searchParams';
import {StockAdjustmentListFilter} from '../objects/StockAdjustmentListFilter';
import {SyncQueueFilter} from '../objects/SyncQueue';
import {PurchaseRequestFilter} from '../objects/PurchaseRequestFilter';
import {Order} from "../objects/Supplier";
import {PurchaseOrderFilter} from '../objects/purchaseOrder-filter';
import {PurchaseRequestItemView} from "../objects/PurchaseRequestItemView";
import { StockDisposalListFilter } from '../objects/StockDisposalListFilter';
import { StockTakeListFilter } from '../objects/StockTakeListFilter';
import { PurchaseReturnOrderFilter } from '../objects/purchaseReturnOrder-filter';

@Injectable({
  providedIn: 'root',
})
export class ApiInventoryService {
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${localStorage.getItem('access_token')}`
  });
  private API_INVENTORY_URL;

  private selectedItem = new BehaviorSubject(null);
  selectedItemObs$ = this.selectedItem.asObservable()

  constructor(
    private http: HttpClient,
    private appConfig: AppConfigService,
    private permissionService: NgxPermissionsService,

  ) {
    this.API_INVENTORY_URL = appConfig.getConfig().API_INVENTORY_URL;
  }

  listAdjustmentReasons(): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/list/adjustment/reason`,
      {},
      { headers: this.headers }
    );
  }

  listCurrentStockGroupByItem(
    params: SearchParams,
    filter: StockListFilter,
    page: Page
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/search/item/${params.clinicId}/${params.itemGroup}/${page.pageNumber}/${page.size}`,
      JSON.stringify(filter), { headers: this.headers }
    );
  }

  downloadCurrentStockGroupByItem(
    params: SearchParams,
    filter: StockListFilter,
    page: Page
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/search/item/${params.clinicId}/${params.itemGroup}/${page.pageNumber}/${page.size}`,
      JSON.stringify(filter), { headers: this.headers , responseType: 'blob' as 'json',}
    );
  }

  listStockAdjustmentList(
    filter: StockAdjustmentListFilter,
    page: Page
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/list/adjustment/byCriteria/${page.pageNumber}/${page.size}`,
      JSON.stringify(filter),{ headers: this.headers }
    );
  }

  listStockTakeList(
    filter: StockTakeListFilter,
    page: Page
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/search/stock-take/${page.pageNumber}/${page.size}`,
      JSON.stringify(filter),{ headers: this.headers }
    );
  }

  listStockDisposalList(
    filter: StockDisposalListFilter,
    page: Page
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/disposal/list/${page.pageNumber}/${page.size}`,
      JSON.stringify(filter),{ headers: this.headers }
    );
  }

  getStockAdjustmentReason(queue = false): Observable<HttpResponseBody> {
    const url = `${this.API_INVENTORY_URL}/stock/list/adjustment/reason`;
    console.log(this.headers)
    return this.http.post<HttpResponseBody>(
      url, { headers: this.headers }
    );
    // return queue
    //   ? this.backendService.invoke(url, body, options)
    //   : this.http.post<HttpResponseBody>(url, body);
  }

  stockAdjustmentApproveRejection(isApprove, body ,stockTakeId): Observable<HttpResponseBody> {
    const action = isApprove ? 'approve' : 'reject';
    const url = `${this.API_INVENTORY_URL}/stock/submit/${action}/stock-adjustment/${stockTakeId}`;
    return this.http.post<HttpResponseBody>(
      url,
      body ,
      { headers: this.headers }
    );
  }

  stockTakeApproval(body): Observable<HttpResponseBody> {
    const url = `${this.API_INVENTORY_URL}/stock/approve/stock-count-item`;
    return this.http.post<HttpResponseBody>(
      url,
      body ,
      { headers: this.headers }
    );
  }

  stockTakeReject(body): Observable<HttpResponseBody> {
    const url = `${this.API_INVENTORY_URL}/stock/reject/stock-count-item`;
    return this.http.post<HttpResponseBody>(
      url,
      body ,
      { headers: this.headers }
    );
  }

  stockDisposalApproveRejection(body): Observable<HttpResponseBody> {
    const url = `${this.API_INVENTORY_URL}/disposal/mark/complete`;
    return this.http.post<HttpResponseBody>(
      url,
      body ,
      { headers: this.headers }
    );
  }

  getStockAdjustmentById(stockTakeId: string): Observable<HttpResponseBody> {
    const url = `${this.API_INVENTORY_URL}/stock/get/stock-take/${stockTakeId}`;
    return this.http.post<HttpResponseBody>(
      url, '',{ headers: this.headers }
    );
  }

  getSyncQueue(page: Page) {
    const url = `${this.API_INVENTORY_URL}/navQueue/syncInfo/list/${page.pageNumber}/${page.size}`;
    return this.http.post<HttpResponseBody>(
      url, '',{ headers: this.headers } ,
    );
  }

  getThreadHoldsStatus(obj: any) {
    const url = `${this.API_INVENTORY_URL}/stock/isExceeds/stock-adjustment/${obj.stockTakeId}/${obj.itemRefId}`;
    return this.http.post<HttpResponseBody>(
      url, '',{ headers: this.headers } ,
    );
  }

  refreshSyncQueue(id: string) {
    const url = `${this.API_INVENTORY_URL}/navQueue/retrySyncToNav/${id}`;
    return this.http.post<HttpResponseBody>(
      url, '',{ headers: this.headers } ,
    );
  }

  filterSyncQueue(filter: SyncQueueFilter, page: Page) {
    const url = `${this.API_INVENTORY_URL}/navQueue/syncInfo/filter/${page.pageNumber}/${page.size}`;
    return this.http.post<HttpResponseBody>(
      url, filter,{ headers: this.headers } ,
    );
  }

  retryStockAdjustment(id: string) {
    const url = `${this.API_INVENTORY_URL}/navQueue/retryStockAdjustmentSyncToNav/${id}`;
    return this.http.post<HttpResponseBody>(
      url, '',{ headers: this.headers } ,
    );
  }
  getPurchaseRequestList(filters: PurchaseRequestFilter) {
    const url = `${this.API_INVENTORY_URL}/purchase/requests/`;
    return this.http.post<HttpResponseBody>(
      url, filters,{ headers: this.headers } ,
    );
  }
  getPurchaseRequestById(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/requests/${id}`;
    return this.http.get<HttpResponseBody>(
      url,{ headers: this.headers } ,
    );
  }

  rejectSavePurchaseRequest(action: string ,pId: string , obj?: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/${action}/request/${pId}`;
    return this.http.post<HttpResponseBody>(
      url,obj ,{ headers: this.headers } ,
    );

  }

  setSelectedItems(data: any) {
    this.selectedItem.next(data)
  }

  createOrders(type: string, variant: string, data: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/requests/create-orders/${type}/${variant}`;
    return this.http.post<HttpResponseBody>(
      url, data,{ headers: this.headers } ,
    );
  }

  savePurchaseOrder(purchaseOrder: Order, sendEmail?: boolean) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/save` + (sendEmail ? '?sendEmail=true' : '');
    return this.http.post<HttpResponseBody>(
      url, purchaseOrder,{ headers: this.headers } ,
    );
  }

  saveAndApprovePurchaseReturnOrder(purchaseReturnOrder: Order) {
    const url = `${this.API_INVENTORY_URL}/purchase/edit/return-order`;
    return this.http.post<HttpResponseBody>(
      url, purchaseReturnOrder,{ headers: this.headers } ,
    );
  }

  issuePurchaseOrder(purchaseOrder: Order) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/issue`;
    return this.http.post<HttpResponseBody>(
      url, purchaseOrder,{ headers: this.headers } ,
    );
  }

  savePurchaseOrderWithEmail(purchaseOrder: Order, email?: Array<any>) {
    const emails = email.toString()
    const url = `${this.API_INVENTORY_URL}/purchase/order/issue` + (email ? '?email='+emails : '');
    return this.http.post<HttpResponseBody>(
      url, purchaseOrder,{ headers: this.headers } ,
    );
  }

  savePurchaseOrderDraft(purchaseOrder: Order) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/save/draft`;
    return this.http.post<HttpResponseBody>(
      url, purchaseOrder,{ headers: this.headers } ,
    );
  }

  deleteOrder(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/delete/${id}`;
    return this.http.post<HttpResponseBody>(
      url, {},{ headers: this.headers } ,
    );
  }

  getPurchaseOrderList(filter: PurchaseOrderFilter, page: Page) {
    const url = `${this.API_INVENTORY_URL}/order-request/list/${page.pageNumber}/${page.size}`;
    return this.http.post<HttpResponseBody>(
      url, filter,{ headers: this.headers } ,
    );
  }
  getPurchaseReturnOrderList(filter: PurchaseReturnOrderFilter, page: Page) {
    const url = `${this.API_INVENTORY_URL}/order-request/list/return-order/${page.pageNumber}/${page.size}`;
    return this.http.post<HttpResponseBody>(
      url, filter,{ headers: this.headers } ,
    );
  }
  getPurchaseOrderById(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/get/order/${id}`;
    return this.http.post<HttpResponseBody>(
      url, {},{ headers: this.headers } ,
    );
  }
  getPurchaseReturnOrderById(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/get/grvn/${id}`;
    return this.http.post<HttpResponseBody>(
      url, {},{ headers: this.headers } ,
    );
  }
  getPoEPrintTemplate(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/${id}/print-content`;
    return this.http.post<HttpResponseBody>(
      url, {},{ headers: this.headers } ,
    );
  }
  getPoEMailTemplate(id: string) {
    const url = `${this.API_INVENTORY_URL}/purchase/order/${id}/email`;
    return this.http.post<HttpResponseBody>(
      url, {},{ headers: this.headers } ,
    );
  }

  calculateGst(order: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/calculate/gst`;
    return this.http.post<HttpResponseBody>(
      url, order,{ headers: this.headers } ,
    );
  }

  searchPurchaseOrderItems(filter: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/request-items`;
    return this.http.post<HttpResponseBody>(
      url, filter,{ headers: this.headers } ,
    );
  }

  findClinicsByItemRefIds(strings: string[]) {
    const url = `${this.API_INVENTORY_URL}/inventory/find/clinics/by/items`;
    return this.http.post<HttpResponseBody>(
      url, strings,{ headers: this.headers } ,
    );
  }

  findItemsByClinicId(senderClinicId: any) {
    const url = `${this.API_INVENTORY_URL}/inventory/find/inventory/by/clinic/${senderClinicId}`;
    return this.http.get<HttpResponseBody>(
      url, { headers: this.headers } ,
    );
  }

  rejectRequests(data: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/requests/reject`;
    return this.http.post<HttpResponseBody>(
      url, data,{ headers: this.headers } ,
    );
  }

  rejectOrders(data: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/orders/reject`;
    return this.http.post<HttpResponseBody>(
      url, data,{ headers: this.headers } ,
    );
  }
  saveOrder(item: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/orders/issue`;
    return this.http.post<HttpResponseBody>(
      url, item,{ headers: this.headers } ,
    );
  }
  issuePurchaseReturnOrder(item: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/approve/return-order`;
    return this.http.post<HttpResponseBody>(
      url, item,{ headers: this.headers } ,
    );
  }
  rejectPurchaseReturnOrder(item: any) {
    const url = `${this.API_INVENTORY_URL}/purchase/reject/return-order`;
    return this.http.post<HttpResponseBody>(
      url, item,{ headers: this.headers } ,
    );
  }

  deleteIncompleteStockTake(id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/stock/delete/stock-take/${id}`,
      JSON.stringify({})
    );
  }

  public convertUom(request: any): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_INVENTORY_URL}/purchase/uom/convert`,
      JSON.stringify(request),
      { headers: this.headers }
    );
  }
}
