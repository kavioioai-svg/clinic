import {FormBuilder, Validators} from '@angular/forms';
import {Drug, MultiCostSubItem, Price, Strength, SubItems} from '../objects/request/Drug';
import {HttpResponseBody} from '../objects/response/HttpResponseBody';

import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, Subject} from 'rxjs';
import {valueTrimmedRequiredValidator} from './form.service';
import {DrugInstructionQuery} from '../state/drug/drug-instruction/drug-instruction.query';
import {DosageInstructionQuery} from '../state/drug/dosage-instruction/dosage-instruction.query';
import {DrugCategoryQuery} from '../state/drug/drug-category/drug-category.query';
import {DrugCautionaryQuery} from '../state/drug/drug-cautionary/drug-cautionary.query';
import {AppConfigService} from './app-config.service';
import {CurrentDrugItemStore} from '../views/components/drug-master/state/current-drug-item.store';
import {ItemFilter} from '../objects/ItemFilter';
import {ItemType} from '../constants/app.constants';
import { VaccineDosageQuery } from '../state/drug/vaccine-dosage/vaccine-dosage.query';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private API_CMS_MANAGEMENT_URL;
  private API_PACKAGE_ITEM_INFO_URL ;

  instructionOptionsStore: Subject<any> = new Subject();
  dosageInstructionOptionsStore: Subject<any> = new Subject();
  vaccineDosageOptionsStore: Subject<any> = new Subject();

  categoryOptionStore: Subject<any> = new Subject();
  cautionaryOptionStore: Subject<any> = new Subject();
   items: BehaviorSubject<HttpResponseBody> = new BehaviorSubject<HttpResponseBody>(null);

   private selectedItem = new BehaviorSubject(null);
   getSelectedItem$ = this.selectedItem.asObservable();

  constructor(
    private http: HttpClient,
    private appConfig: AppConfigService,
    private fb: FormBuilder,
    private drugInstructionQuery: DrugInstructionQuery,
    private dosageInstructionQuery: DosageInstructionQuery,
    private drugCategoryQuery: DrugCategoryQuery,
    private drugCautionaryQuery: DrugCautionaryQuery,
    private currentDrugItemStore: CurrentDrugItemStore,
    private vaccineDosageQuery: VaccineDosageQuery,
  ) {
    this.API_CMS_MANAGEMENT_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL;
    this.API_PACKAGE_ITEM_INFO_URL = appConfig.getConfig().API_PACKAGE_ITEM_INFO_URL;

    this.drugInstructionQuery.selectAll().subscribe(data => {
      this.instructionOptionsStore.next(
        data.map(item => {
          return { value: item.code, label: item.instruct };
        })
      );
    });

    this.dosageInstructionQuery.selectAll().subscribe(data => {
      this.dosageInstructionOptionsStore.next(
        data.map(item => {
          return { value: item.code, label: item.instruct };
        })
      );
    });

    this.vaccineDosageQuery.selectAll().subscribe(data => {
      this.vaccineDosageOptionsStore.next(
        data.map(item => {
          return { value: item.code, label: item.name };
        })
      );
    });

    this.drugCategoryQuery.selectCategoryStringArray().subscribe(data => {
      this.categoryOptionStore.next(
        data.map(item => {
          return { value: item, label: item };
        })
      );
    });

    this.drugCautionaryQuery.selectCautionaryStringArray().subscribe(data => {
      this.cautionaryOptionStore.next(
        data.map(item => {
          return { value: item, label: item };
        })
      );
    });
  }

  addDrug(drug) {
    let url ='';
    switch (drug.item.itemType) {
      case ItemType.VACCINATION:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/add/vaccine`;
        break;
      case ItemType.DRUG:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/add/drug`;
        break;

      default:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/add/item`;
        break;
    }
    return this.http.post<HttpResponseBody>(
      url,
      JSON.stringify(drug),
      {
        headers: this.headers
      }
    );
  }

  editDrug(drugId: string, drug) {
    let url ='';
    switch (drug.item.itemType) {
      case ItemType.VACCINATION:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/modify/vaccine/${drugId}`;
        break;
      case ItemType.DRUG:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/modify/drug/${drugId}`;
        break;

      default:
        url = `${this.API_PACKAGE_ITEM_INFO_URL}/modify/item/${drugId}`;
        break;
    }
    return this.http.post<HttpResponseBody>(
      url,
      JSON.stringify(drug),
      {headers: this.headers}
    );
  }

  listAllItems(page?: any, override: boolean = false) {
    if (page) {
      let url = `${this.API_PACKAGE_ITEM_INFO_URL}/list/${page.pageNumber}/${page.size}`
      return this.http.post<HttpResponseBody>(
        url,
        {},
        {headers: this.headers}
      );
    }

    if (override || this.items.value === null) {
      let url = `${this.API_PACKAGE_ITEM_INFO_URL}/list`
      this.http.post<HttpResponseBody>(
        url,
        {},
        {headers: this.headers}
      ).subscribe(data => {
        this.items.next(data);
      });
    }
    return this.items.asObservable();
  }

  removeDrug(drugId) {
    const request = this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/drug/remove/${drugId}`,
      {},
      { headers: this.headers }
    );
    return request;
  }

  getItemById(itemId) {
    return this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/search/by-id/${itemId}`,
      {},
      {headers: this.headers}
    );
  }

  searchItem(keyword: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/filter/${keyword}`,
      {},
      { headers: this.headers }
    );
  }

  listAllSuppliers(page?) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/supplier/list/all`,
      {},
      {headers: this.headers}
    );
  }

  getInstructionsOptions() {
    return this.drugInstructionQuery.getAll().map(item => {
      return { value: item.code, label: item.instruct };
    });
  }

  getDosageInstructionsOptions() {
    return this.dosageInstructionQuery.getAll().map(item => {
      return { value: item.code, label: item.instruct };
    });
  }

  getVaccineDosageOptions() {
    return this.vaccineDosageQuery.getAll().map(item => {
      return { value: item.code, label: item.name };
    });
  }

  getCategoryOptions() {
    return this.drugCategoryQuery.getCategoryStringArray().map(item => {
      return { value: item, label: item };
    });
  }

  getCautionaryOptions() {
    return this.drugCautionaryQuery.getCautionaryStringArray().map(item => {
      return { value: item, label: item };
    });
  }

  /** FORM **/
  getDrugMasterForm(itemType?: string) {
    return this.fb.group({
      id: [],
      name: ['', valueTrimmedRequiredValidator()],
      code: ['', valueTrimmedRequiredValidator()],
      description: ['', [valueTrimmedRequiredValidator(), Validators.pattern(/^[A-Z0-9a-z]/)]],
      baseUom: ['', valueTrimmedRequiredValidator()],
      salesUom: ['', valueTrimmedRequiredValidator()],
      purchaseUom: ['', valueTrimmedRequiredValidator()],
      dosageUom: ['', ['DRUG', 'VACCINATION'].includes(itemType) ? valueTrimmedRequiredValidator() : undefined],
      category: [],
      inventoried: [['DRUG', 'VACCINATION'].includes(itemType)],
      allowNegativeInventory: [false],
      itemFilter: this.fb.group({
        clinicIds: [[]],
        clinicGroupNames: [['Healthway Medical Group']]
      }),
      supplierId: [, itemType !== 'SERVICE' ? valueTrimmedRequiredValidator() : null],
      itemType: [itemType],
      status: ['ACTIVE'],
      standardDispenseAmount: [0, Validators.min(0)],
      brandName: [],
      genericName: [],
      printDrugLabel: [['DRUG', 'VACCINATION'].includes(itemType)],
      dosageQty: [0, ['DRUG', 'VACCINATION'].includes(itemType) ? Validators.pattern(/^\d*(?:[.,]\d{1,2})?$/) : undefined],
      frequency: [],
      frequencyCode: [],
      dosageInstructionCode: [],
      dosageInstruction: [],
      precautionaryInstructions: [],
      indications: [],
      controlledDrug: [false],
      dispensingMultiples: [0, Validators.pattern(/^\d*(?:[.,]\d{1,2})?$/)],
      drugType: [],
      drugBrandedType: [],
      allergyGroupCode: [],
      allergyGroupCode1: [],
      allergyGroupCode2: [],
      allergyGroupCode3: [],
      allergyGroupCode4: [],
      foodAllergyGroupCode1: [],
      foodAllergyGroupCode2: [],
      foodAllergyGroupCode3: [],
      genericNameJapanese: [],
      genericNameChinese: [],
      mimsClassification: [],
      brandNameJapanese: [],
      precInstructionInJapanese: [],
      effectInJapanese: [],
      remarkInJapanese: [],
      indicationInJapanese: [],
      remarks: [],
      externalCode: [],
      outOfStockRemarks: [],
      priceAdjustmentType: ['FIXED'],
      packageType: ['PRE'],
      drugGroup: [],
      dosages: this.fb.array([this.getDosageFormGroup()]),
      multiCostSubItems: this.fb.array([this.getMultiCostSubItem(false)]),
      trackingCode: [['DRUG', 'VACCINATION'].includes(itemType)],
      sddCode: [],
      genericSddCode: [],
      smstDoseFormCode: [],
      purchasingBlocked: [false],
      dispensingBlocked: [false],
      blockReason: [],
      brandNameChinese: [],
      routeOfAdministration: [],
      doseUomStrength: this.getDoseUomStrengthFormGroup(),
      subItems: this.fb.array([this.getPackageFormGroup()]),
      multiVaccineSubItems: this.fb.array([this.getMultiVacSubFormGroup()]),
    });
  }

  populateDrugMasterForm(drug: Drug) {
    let itemType = drug.itemType;
    return this.fb.group({
      id: [drug.id],
      name: [drug.name, valueTrimmedRequiredValidator()],
      code: [drug.code, valueTrimmedRequiredValidator()],
      description: [drug.description, [valueTrimmedRequiredValidator(), Validators.pattern(/^[A-Z0-9a-z]/)]],
      baseUom: [drug.baseUom, valueTrimmedRequiredValidator()],
      salesUom: [drug.salesUom, valueTrimmedRequiredValidator()],
      purchaseUom: [drug.purchaseUom, valueTrimmedRequiredValidator()],
      dosageUom: [drug.dosageUom, ['DRUG', 'VACCINATION'].includes(itemType) ? valueTrimmedRequiredValidator() : undefined],
      category: [drug.category],
      cost: this.populatePriceFormGorup(drug.cost),
      sellingPrice: this.populatePriceFormGorup(drug.sellingPrice),
      inventoried: [drug.inventoried],
      allowNegativeInventory: [drug.allowNegativeInventory],
      itemFilter: this.fb.group({
        clinicIds: [drug.itemFilter ? drug.itemFilter.clinicIds || [] : []],
        clinicGroupNames: [drug.itemFilter ? drug.itemFilter.clinicGroupNames || [] : []]
      }),
      supplierId: [drug.supplierId, itemType !== 'SERVICE' ? valueTrimmedRequiredValidator() : null],
      itemType: [drug.itemType],
      status: [drug.status],
      standardDispenseAmount: [drug.standardDispenseAmount, Validators.min(0)],
      brandName: [drug.brandName],
      genericName: [drug.genericName],
      printDrugLabel: [drug.printDrugLabel],
      dosageQty: [drug.dosageQty, ['DRUG', 'VACCINATION'].includes(itemType) ? Validators.pattern(/^\d*(?:[.,]\d{1,2})?$/) : undefined],
      frequency: [drug.frequency],
      frequencyCode: [drug.frequencyCode ],
      dosageInstructionCode: [drug.dosageInstructionCode ],
      dosageInstruction: [drug.dosageInstruction ],
      precautionaryInstructions: [drug.precautionaryInstructions],
      indications: [drug.indications],
      controlledDrug: [drug.controlledDrug],
      dispensingMultiples: [drug.dispensingMultiples, Validators.pattern(/^\d*(?:[.,]\d{1,2})?$/)],
      trackingCode: [drug.trackingCode],
      sddCode: [drug.sddCode],
      genericSddCode: [drug.genericSddCode],
      smstDoseFormCode: [drug.smstDoseFormCode ? drug.smstDoseFormCode : ''],
      purchasingBlocked: [drug.purchasingBlocked],
      drugType: [drug.drugType],
      drugBrandedType: [drug.drugBrandedType],
      allergyGroupCode: [drug.externalCode],
      allergyGroupCode1: [drug.allergyGroupCode1],
      allergyGroupCode2: [drug.allergyGroupCode2],
      allergyGroupCode3: [drug.allergyGroupCode3],
      allergyGroupCode4: [drug.allergyGroupCode4],
      foodAllergyGroupCode1: [drug.foodAllergyGroupCode1],
      foodAllergyGroupCode2: [drug.foodAllergyGroupCode2],
      foodAllergyGroupCode3: [drug.foodAllergyGroupCode3],
      genericNameJapanese: [drug.genericNameJapanese],
      genericNameChinese: [drug.genericNameChinese],
      mimsClassification: [drug.mimsClassification],
      brandNameJapanese: [drug.brandNameJapanese],
      precInstructionInJapanese: [drug.precInstructionInJapanese],
      effectInJapanese: [drug.effectInJapanese],
      remarkInJapanese: [drug.remarkInJapanese],
      indicationInJapanese: [drug.indicationInJapanese],
      remarks: [drug.remarks],
      externalCode: [drug.externalCode],
      outOfStockRemarks: [drug.outOfStockRemarks],
      priceAdjustmentType: [drug.priceAdjustmentType],
      packageType: [drug.packageType],
      drugGroup: [drug.drugGroup],
      dispensingBlocked: [drug.dispensingBlocked],
      blockReason: [drug.blockReason],
      brandNameChinese: [drug.brandNameChinese],
      routeOfAdministration: [drug.routeOfAdministration],
      dosages: this.fb.array([this.getDosageFormGroup(false ,drug.dosages)]),
      doseUomStrength: this.getDoseUomStrengthFormGroup(drug.doseUomStrength),
      multiCostSubItems: this.fb.array(drug.multiCostSubItems.map(this.populateMultiostSubItem.bind(this))),
      multiVaccineSubItems: this.fb.array([this.getMultiVacSubFormGroup(true ,drug.multiVaccineSubItems)]),
      subItems: this.fb.array(drug.subItems.map(this.populateSubItems.bind(this))),
    });
  }

  populateMultiostSubItem(obj: MultiCostSubItem) {
    return this.fb.group({
      itemRefId: [obj.itemRefId],
      quantity: [obj.quantity]
    });
  }

  populateSubItems(obj: SubItems) {
    return this.fb.group({
      itemRefId: [obj.itemRefId],
      quantity: [obj.quantity],
      sellingPrice: this.fb.group({
        price: [obj.sellingPrice ? obj.sellingPrice.price / 100 : undefined],
        taxIncluded: [obj.sellingPrice ? obj.sellingPrice.taxIncluded : undefined]
      }),
      sessionNo: [obj.sessionNo],
    });
  }

  getPriceFormGorup() {
    return this.fb.group({
      price: ['', /*[valueTrimmedRequiredValidator(), Validators.min(0.05)]*/],
      taxIncluded: [false]
    });
  }
  getDoseUomStrengthFormGroup(data?: Strength) {
    return this.fb.group({
      value: [ data ? data.value : 0],
      unit:  [ data ? data.unit : '']
    });
  }
  getMultiCostSubItem(isEdit?: boolean , obj?: MultiCostSubItem) {
    return this.fb.group({
      itemRefId: [isEdit? obj.itemRefId : ''],
      quantity: [isEdit? obj.quantity : 0]
    });
  }

  populatePriceFormGorup(price: Price) {
    return this.fb.group({
      price: [price.price ? parseFloat((price.price / 100).toFixed(2)) : 0],
      taxIncluded: [price.taxIncluded]
    });
  }
  getDosageFormGroup(isView?: boolean , dosage?: any[]) {
    if(isView && dosage.length === 0) {

    } else {
      return this.fb.group({
        doseId: [''],
        name: [''],
        status: ['ACTIVE'],
        description: [''],
        recommendedAge: [''],
        intervalToNextDoseInDays: [''],
      });
    }
  }

  getMultiVacSubFormGroup(isEdit?: boolean , data?: any) {
    return this.fb.group({
      code: [''],
      description: [''],
      dosages:this.fb.array([this.getDosageFormGroup()]),
    });
  }
  getPackageFormGroup(isEdit?: boolean) {
    return this.fb.group({
      itemRefId: [''],
      sellingPrice: this.getPriceFormGorup(),
      quantity: [''],
      sessionNo: [''],
    });
  }

  getDrugSearchFormControl() {
    return this.fb.control('');
  }

  /** DATA SUBMISSION CLEAN UP */
  processDataBeforeSubmission(data: Drug) {
    if (!data.id) {
      delete data.id;
    }

    if (data.category === null) {
      data.category = '';
    }

    if (data.cost && data.cost.price) {
      data.cost.price = parseInt((data.cost.price * 100).toFixed());
    }

    if (data.sellingPrice && data.sellingPrice.price) {
      data.sellingPrice.price = parseInt((data.sellingPrice.price * 100).toFixed());
    }

    if (data.subItems && data.subItems.length > 0) {
      for (let subItem of data.subItems) {
        if (subItem.sellingPrice && subItem.sellingPrice.price) {
          subItem.sellingPrice.price = parseInt((subItem.sellingPrice.price * 100).toFixed());
        }
      }
    }

    return { item: data };
  }

  /** DATA SUBMISSION CLEAN UP */

  getDrugMasterTestForm() {
    return this.fb.group({
      id: [''],
      code: ['AATD', Validators.required],
      name: ['AA Test Drug', Validators.required],
      uom: ['TABLET', Validators.required],
      price: this.fb.group({
        price: [2, Validators.required],
        taxIncluded: [false]
      }),
      instruction: this.fb.group({
        code: [''],
        frequencyPerDay: [''],
        instruct: [''],
        cautionary: ['']
      }),
      dosageInstruction: this.fb.group({
        code: [''],
        instruct: ['']
      }),
      priceAdjustment: this.fb.group({
        decreaseValue: [0],
        increaseValue: [''],
        paymentType: ['DOLLAR']
      }),
      recommendedDose: [2, Validators.required],
      basePrice: this.fb.group({
        price: [2, Validators.required],
        taxIncluded: [false]
      }),
      ingredients: this.fb.array([
        this.fb.group({
          name: [''],
          uom: [''],
          dose: ['']
        })
      ]),
      supplierIds: this.fb.array([]),
      category: ['RELAXANT', Validators.required],
      packSize: [4, Validators.required],
      minimumDispenseAmount: [3]
    });
  }
  setCurrentDrugItemId(itemId:string) {
    localStorage.setItem('currentItemId', itemId);
    this.currentDrugItemStore.update({ id: itemId });
  }
  getCurrentDrugItemId() {
    return localStorage.getItem('currentItemId');
  }
  clearItemStorage() {
    localStorage.removeItem('currentItemId');
  }

  booleanSelection = [
    { value: true, label: 'YES' },
    { value: false, label: 'NO' }
  ];


  changeStatus(id, status) {
    return this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/status/change/${id}/${status}`,
      {},
      {headers: this.headers}
    );
  }

  searchItemWithFilter(filter: ItemFilter ,page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/search-by-criteria/${page.pageNumber}/${page.size}`,
      filter,
      {headers: this.headers}
    );
  }

  patchDropDawnForm(form: any , data: any) {
    return form.patch({
      data: data
    })
  }

  listRoutesOfAdministrations(key: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/system-config/list/${key}`,
      {}
    );
  }

  setSelectedItem(val: any) {
    this.selectedItem.next(val)
  }
}
