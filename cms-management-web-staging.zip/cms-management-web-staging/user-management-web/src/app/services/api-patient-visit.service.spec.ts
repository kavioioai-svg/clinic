import { TestBed, inject } from '@angular/core/testing';

import { ApiPatientVisitService } from './api-patient-visit.service';

describe('ApiPatientVisitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiPatientVisitService]
    });
  });

  it('should be created', inject([ApiPatientVisitService], (service: ApiPatientVisitService) => {
    expect(service).toBeTruthy();
  }));
});
