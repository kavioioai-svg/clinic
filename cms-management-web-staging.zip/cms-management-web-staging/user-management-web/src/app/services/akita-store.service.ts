import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ID } from '@datorama/akita';
import {catchError, filter, mergeMap, tap} from 'rxjs/operators';
import {AkitaStockAdjustmentQuery} from '../state/inventory/akita-stock-adjustment.query';
import {ApiInventoryService} from './api-inventory.service';
import {AkitaStockAdjustmentStore} from '../state/inventory/akita-stock-adjustment.store';
import {StoreService} from './store.service';
import {AkitaAppStore} from '../state/app/akita-app.store';
import {API_STATUS, createApiState} from '../state/app/ApiState';

@Injectable({ providedIn: 'root' })
export class AkitaStoreService {

  constructor(private http: HttpClient,
              private akitaStockAdjustmentQuery: AkitaStockAdjustmentQuery,
              private apiInventorySvc: ApiInventoryService,
              private akitaStockAdjustmentStore: AkitaStockAdjustmentStore,
              private store: StoreService,
              private akitaAppStore: AkitaAppStore) {
  }

  getStockAdjustment(bypass = false) {

    this.akitaStockAdjustmentQuery
      .selectHasCache()
      .pipe(
        filter(hasCache => !hasCache || bypass),
        mergeMap(hasCache =>
          this.apiInventorySvc.getStockAdjustmentReason(true)
        ),
        mergeMap(data => {
          if (data) {
            this.akitaStockAdjustmentStore.set(data.payload);
            this.store.afterInventoryStockAdjustmentReasonList(data);
          }
          return this.akitaStockAdjustmentQuery.selectLoading();
        }),
        catchError(err => this.akitaStockAdjustmentQuery.selectLoading())
      )
      .subscribe(loading => {
        if (!loading) this.updateSuccess('stockAdjustment');
        else this.updateFailure('stockAdjustment');
      });


  }
  updateSuccess(key) {
    this.akitaAppStore.update(key, createApiState(key, API_STATUS.SUCCESS));
  }

  updateFailure(key) {
    this.akitaAppStore.update(key, createApiState(key, API_STATUS.FAILURE));
  }
}
