import { TestBed, inject } from "@angular/core/testing";

import { ItemService } from "./item.service";
import { TestingModule } from "../test/testing.module";

describe("ItemService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [ItemService]
    });
  });

  it("should be created", inject([ItemService], (service: ItemService) => {
    expect(service).toBeTruthy();
  }));
});
