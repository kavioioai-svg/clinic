import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { AlertService } from './alert.service';
import { AppConfigService } from './app-config.service';
import { HttpResponseBody } from '../objects/response/HttpResponseBody';

@Injectable({
  providedIn: 'root',
})
export class ApiPatientInfoService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private API_PATIENT_INFO_URL;

  constructor(private http: HttpClient, private alertService: AlertService, private appConfig: AppConfigService) {
    this.API_PATIENT_INFO_URL = appConfig.getConfig().API_PATIENT_INFO_URL;
  }

  search(searchString: string): Observable<HttpResponseBody> {
    return this.http
      .post<HttpResponseBody>(`${this.API_PATIENT_INFO_URL}/patient/like-search/${searchString}`, JSON.stringify({}), {
        observe: 'response',
      })
      .pipe(
        map((res) => {
          return res.body;
        })
      );
  }
}
