import { TestBed, inject } from "@angular/core/testing";

import { AuthGuardService } from "./auth-guard.service";
import { TestingModule } from "../test/testing.module";

describe("AuthGuardService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [AuthGuardService]
    });
  });

  it("should be created", inject(
    [AuthGuardService],
    (service: AuthGuardService) => {
      expect(service).toBeTruthy();
    }
  ));
});
