import { AppConfigFile } from './../objects/AppConfigFile';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable()
export class AppConfigService {
  private appConfig: AppConfigFile;

  constructor(private http: HttpClient) {
    // this.appConfig = new AppConfigFile();
  }

  loadAppConfig() {
    return this.http
      .get('/assets/data/' + environment.appConfigFileName)
      .toPromise()
      .then(data => {
        this.appConfig = <AppConfigFile>data;
      });
  }

  getConfig(): AppConfigFile {
    return this.appConfig;
  }
}
