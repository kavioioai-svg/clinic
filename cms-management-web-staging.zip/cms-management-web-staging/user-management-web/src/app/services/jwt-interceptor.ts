import { tap } from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpResponse,
  HttpErrorResponse,
} from '@angular/common/http';
import { AuthService } from './auth.service';
import { INVALID_TOKEN_ERROR_MESSAGE } from '../constants/auth.constants';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  exceptionUrl = 'aacore/login';
  authService: AuthService;

  constructor(private router: Router, private injector: Injector) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    let tenantID = localStorage.getItem('tenantId');
      if (!!tenantID) {
        request = request.clone({
          setHeaders: {
            "X-Tenant": tenantID
          },
        });
      }

    return next.handle(request).pipe(
      tap(
        (event: HttpEvent<any>) => {
          if (event instanceof HttpResponse) {
            // do stuff with response if you want
          }
        },
        (err: any) => {
          if (err instanceof HttpErrorResponse) {
            if (err.status === 401 || err.status === 403) {
              // redirect to the login route
              // or show a modal

              if (
                !err.url.includes('aacore/user/login') &&
                !err.url.includes('aacore/user/logout') &&
                !err.url.includes('aacore/login') &&
                !err.url.includes('aacore/user/2fa') && // added unmasking for token for 2fa
                !err.url.includes('aacore/logout') &&
                err.error.status !== 'FORBIDDEN'
              ) {
                if (!this.authService) {
                  this.authService = <AuthService>this.injector.get(AuthService);
                }
                this.authService.triggerLogout();
                alert(INVALID_TOKEN_ERROR_MESSAGE);
                this.router.navigate(['login']);
              }
              let defaultTenantID = localStorage.getItem('tenantId');

              localStorage.clear();
              localStorage.setItem('tenantId', defaultTenantID);

              const temp_access_token: string = sessionStorage.getItem('temp_access_token');
              if(temp_access_token) localStorage.setItem('access_token', temp_access_token);
            }
          }
        }
      )
    );
  }
}