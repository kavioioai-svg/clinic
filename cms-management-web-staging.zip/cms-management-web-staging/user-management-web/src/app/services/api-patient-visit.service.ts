import { HttpResponseBody } from './../objects/response/HttpResponseBody';
import { AppConfigService } from './app-config.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import {BillAdjustmentStatus} from '../objects/BillAdjustmentStatus';

@Injectable({
  providedIn: 'root'
})
export class ApiPatientVisitService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private API_PATIENT_VISIT_URL;
  private API_INVENTORY_SYSTEM_URL;
  private API_CLAIM_URL;
  private API_CMS_MANAGEMENT_URL;
  private API_DOCUMENT_URL;

  constructor(private http: HttpClient, private appConfig: AppConfigService) {
    this.API_PATIENT_VISIT_URL = appConfig.getConfig().API_PATIENT_VISIT_URL;
    this.API_INVENTORY_SYSTEM_URL = appConfig.getConfig().API_INVENTORY_SYSTEM_URL;
    this.API_CLAIM_URL = appConfig.getConfig().API_CLAIM_URL;
    this.API_CMS_MANAGEMENT_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL;
    this.API_DOCUMENT_URL = appConfig.getConfig().API_DOCUMENT_URL;
  }

  checkMhcpBalance(clinicId: string, planId: string, nric: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/mhcp-claim/balance/${clinicId}/${planId}/${nric}`,
      {},
      { headers: this.headers }
    );
  }

  listClaimsByDate(
    medicalCoverageType: string,
    status: string,
    startDate: string,
    endDate: string
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/mhcp-claim/list-by-type/${medicalCoverageType}/${status}/${startDate}/${endDate}/`,
      [],
      { headers: this.headers }
    );
  }

  listClaimsByClinlicByDate(
    clinicId: string,
    medicalCoverageType: string,
    status: string,
    startDate: string,
    endDate: string
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${
        this.API_CLAIM_URL
      }/mhcp-claim/list-by-type/${clinicId}/${medicalCoverageType}/${status}/${startDate}/${endDate}/`,
      {},
      { headers: this.headers }
    );
  }

  saveClaim(claimId: string, claim): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/mhcp-claim/save/${claimId}/`,
      JSON.stringify(claim),
      { headers: this.headers }
    );
  }

  submitClaim(claimId: string, claim): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/mhcp-claim/submit/${claimId}/`,
      JSON.stringify(claim),
      { headers: this.headers }
    );
  }

  rejectClaim(claimId: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/mhcp-claim/reject/${claimId}/REJECTED_PERMANENT`,
      { headers: this.headers }
    );
  }

  listClaimPaymentDetails(
    clinicIds: string[],
    medicalCoverageId: string,
    medicalCoverageType: string,
    startDate: string,
    endDate: string,
    pageNumber: number,
    pageSize: number
  ) {
    const payLoad = {
      medicalCoverageId: medicalCoverageId,
      startDate: startDate,
      endDate: endDate,
      clinicIdList: clinicIds,
    };

    if (!!medicalCoverageType) {
      payLoad['coverageType'] = medicalCoverageType;
    }
    let url = `${this.API_CMS_MANAGEMENT_URL}/claim/list/claim-payment-details/${pageNumber}/${pageSize}`;
    return this.http.post<HttpResponseBody>(url, JSON.stringify(payLoad), { headers: this.headers });
  }

  getUniqueRefund(
    refundId: string,
    request: any
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/refund/get/${refundId}`,
      JSON.stringify(request),
      { headers: this.headers }
    );
  }

   getRefunds(
    page: number,
    size: number,
    request: any
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/get/all/refunds/${page}/${size}`,
      JSON.stringify(request),
      { headers: this.headers }
    );
  }

  getAllBillAdjustments(
    page: number,
    size: number,
    reqObj: any
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/billadjustment/list/${page}/${size}`,
      JSON.stringify(reqObj),
      { headers: this.headers }
    );
  }

  getAllBillAdjustmentByID(
    caseID: any,
    adjustmentId: any,
    reqObj?: any
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/billadjustment/get/${caseID}/${adjustmentId}`,
      JSON.stringify(reqObj),
      { headers: this.headers }
    );
  }

  getAllBillAdjustmentByCaseId(
    caseID: any
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/billadjustment/get/${caseID}`,
      {},
      { headers: this.headers }
    );
  }

  getCaseDetailsById(caseId: string, visitId = '') {
    let url: string;
    if (visitId === '')
      url = `${this.API_CMS_MANAGEMENT_URL}/case/get-case-details/${caseId}`;
    else
      url = `${this.API_CMS_MANAGEMENT_URL}/case/get-case-details/${caseId}/${visitId}`;

    return this.http.post<HttpResponseBody>(url, JSON.stringify({}), { headers: this.headers });
  }

  listAllFiles(
    patientId: string,
    startDate: string,
    endDate: string,
    clinicId: any
  ): Observable<HttpResponseBody> {

    let headers = new HttpHeaders({
      'X-LOGGED-IN-CLINIC-ID': clinicId });
      let options = { headers: headers };
    return this.http.post<HttpResponseBody>(
      `${this.API_DOCUMENT_URL}/list/patient/${patientId}/${startDate}/${endDate}`,
      {},options
    );
  }

  listAllFilesInBillMangement(
    patientId: string,
    reference: string,
    clinicId: any
  ): Observable<HttpResponseBody> {

    let headers = new HttpHeaders({
      'X-LOGGED-IN-CLINIC-ID': clinicId });
      let options = { headers: headers };
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/sales-order/bill-management/list/documents/${patientId}/${reference}`,
      {},options
    );
  }

  downloadDocument(
    config: string,
    id: string,
    fileId: string,
    clinicId: any
  ): Observable<HttpResponseBody> {
    let headers = new HttpHeaders({
      'X-LOGGED-IN-CLINIC-ID': clinicId });
      let options = { headers: headers, responseType: 'blob' as 'json' };
    return this.http.post<HttpResponseBody>(
      `${this.API_DOCUMENT_URL}/download/${config}/${id}/${fileId}`,
      {},options
    );
  }

  downloadNonVisitDocument(
    patientId: string,
    fileId: string,
    clinicId: any
  ): Observable<HttpResponseBody> {
    let headers = new HttpHeaders({
      'X-LOGGED-IN-CLINIC-ID': clinicId });
      let options = { headers: headers, responseType: 'blob' as 'json' };
    return this.http.post<HttpResponseBody>(
      `${this.API_DOCUMENT_URL}/download/patient/${patientId}/${fileId}`,
      {},
      options
    );
  }

  billAdjustmentApprovalRejection(type:string ,data?:any, editedValue?:any) {
    let request = type === BillAdjustmentStatus.APPROVED ? 'adjust-and-approve' : 'adjust-and-reject';

    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/sales-order/billadjustment/${request}/${editedValue.caseId}/${editedValue.billAdjId}`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  listSFLClaimHistory(
    clinicId: string,
    patientNric: string,
    slfCategory: string
  ): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL
      }/mhcp-claim/sfl-history/${clinicId}/${patientNric}/${slfCategory}`,
      {}
    );
  }
}
