import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AppConfigService} from '../app-config.service';
import {Observable} from 'rxjs';
import {HttpResponseBody} from '../../objects/response/HttpResponseBody';
import {InvoiceRef} from '../../objects/eClaims/invoice-ref';
import {PaymentRef} from '../../objects/eClaims/payment-ref';
import {GeneratedInvoice} from '../../objects/eClaims/generated-invoice';
import {Page} from '../../model/page';
import {InvoiceFilter} from '../../objects/eClaims/invoice-filter';

@Injectable({
  providedIn: 'root'
})
export class ApiInvoiceService {
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${localStorage.getItem('access_token')}`,
  });
  private API_CLAIM_URL;

  constructor( private http: HttpClient,
               private appConfig: AppConfigService,) {
    this.API_CLAIM_URL = appConfig.getConfig().API_ECLAIM_URL;
  }

  listAllGeneratedInvoices(): Observable<GeneratedInvoice> {
    return this.http.get<GeneratedInvoice>(
      `${this.API_CLAIM_URL}/generated-invoice/list`,
      { headers: this.headers }

    );
  }


  listAllInvoices(filter: InvoiceFilter ,page: Page) {
    return this.http.post<GeneratedInvoice>(
      `${this.API_CLAIM_URL}/invoice/search/${page.pageNumber ? page.pageNumber : 0}/${page.size}`,
      JSON.stringify(filter),
      { headers: this.headers }
    );
  }

  getGeneratedInvoicesById(id: string): Observable<HttpResponseBody> {
    console.log(this.headers)
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}`,
      {},
      { headers: this.headers }
    );
  }

  deleteInvoiceById(id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/delete`,
      {},
      { headers: this.headers }
    );
  }

  createGeneratedInvoice(invoice: any[]): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/create`,
      invoice,
      { headers: this.headers }
    );
  }

  searchGeneratedInvoice(filters: any, page: Page): Observable<HttpResponseBody> {
    console.log(page)
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/search/${page.pageNumber}/${page.size}`,
      filters,
      { headers: this.headers }
    );
  }

  patchInvoice(invoice: GeneratedInvoice , id: string): Observable<HttpResponseBody> {
    return this.http.patch<HttpResponseBody>(
      `${this.API_CLAIM_URL}/update?id=${id}`,
      invoice,
      { headers: this.headers }
    );
  }

  createInvoiceRef( invoiceRef: InvoiceRef , id: string): Observable<HttpResponseBody> {
    return this.http.patch<HttpResponseBody>(
      `${this.API_CLAIM_URL}/${id}/invoice-ref/add`,
      {invoiceRef},
      { headers: this.headers }
    );
  }

  createPaymentRef(paymentRef: PaymentRef , id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/payment-ref/add`,
      paymentRef,
      { headers: this.headers }
    );
  }


  approveInvoice(generatedInvoice: any, id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/approve`,
      generatedInvoice,
      { headers: this.headers }
    );
  }

  printInvoice(id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/print`,
      {},
      { headers: this.headers }
    );
  }

  emailInvoice(id: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/email`,
      {},
      { headers: this.headers }
    );
  }

  deletePaymentRef(refId: string, id: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CLAIM_URL}/generated-invoice/${id}/payment-ref/${refId}/delete`,
      {},
      { headers: this.headers }
    );

  }
}
