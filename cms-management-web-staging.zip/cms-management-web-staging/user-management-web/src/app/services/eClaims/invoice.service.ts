import { Injectable } from '@angular/core';
import {Page} from '../../model/page';
import {Observable} from 'rxjs';
import {InvoiceRef} from '../../objects/eClaims/invoice-ref';
import {PaymentRef} from '../../objects/eClaims/payment-ref';
import {GeneratedInvoice} from '../../objects/eClaims/generated-invoice';
import {InvoiceFilter} from '../../objects/eClaims/invoice-filter';
import {ApiInvoiceService} from './api-invoice.service';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  constructor(private apiInvoiceService: ApiInvoiceService) { }

  listAllGeneratedInvoices(): Observable<GeneratedInvoice> {
    return this.apiInvoiceService.listAllGeneratedInvoices();
  }

  listAllInvoices(filter: InvoiceFilter, page: Page): Observable<GeneratedInvoice> {
    return this.apiInvoiceService.listAllInvoices(filter, page);
  }

  getGeneratedInvoicesById(id: string) : Observable<any> {
    return this.apiInvoiceService.getGeneratedInvoicesById(id);
  }

  deleteInvoiceById(id: string) : Observable<any> {
    return this.apiInvoiceService.deleteInvoiceById(id);
  }

  createGeneratedInvoice(invoice: InvoiceRef[]) : Observable<any> {
    return this.apiInvoiceService.createGeneratedInvoice(invoice);
  }

  searchGeneratedInvoice(filter: any, page: Page) : Observable<any> {
    return this.apiInvoiceService.searchGeneratedInvoice(filter, page);
  }

  patchInvoice(invoice: GeneratedInvoice, id: string) : Observable<any> {
    return this.apiInvoiceService.patchInvoice(invoice, id);
  }

  createInvoiceRef(invoiceRef: InvoiceRef, id: string) : Observable<any> {
    return this.apiInvoiceService.createInvoiceRef(invoiceRef, id);
  }

  createPaymentRef(paymentRef: PaymentRef, id: string) : Observable<any> {
    return this.apiInvoiceService.createPaymentRef(paymentRef, id);
  }
  deletePaymentRef(refId: string, id: string) : Observable<any> {
    return this.apiInvoiceService.deletePaymentRef(refId, id);
  }

  approveInvoice(generatedInvoice: any, id: string) : Observable<any> {
    return this.apiInvoiceService.approveInvoice(generatedInvoice, id);
  }

  printInvoice(id: string) : Observable<any> {
    return this.apiInvoiceService.printInvoice(id);
  }

  emailInvoice(id: string) : Observable<any> {
    return this.apiInvoiceService.emailInvoice(id);
  }


}
