import { TestBed, inject } from "@angular/core/testing";

import { ApiCmsManagementService } from "./api-cms-management.service";
import { TestingModule } from "../test/testing.module";

describe("ApiCmsManagementService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [ApiCmsManagementService]
    });
  });

  it("should be created", inject(
    [ApiCmsManagementService],
    (service: ApiCmsManagementService) => {
      expect(service).toBeTruthy();
    }
  ));
});
