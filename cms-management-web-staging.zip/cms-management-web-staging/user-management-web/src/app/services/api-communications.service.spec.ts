import { TestBed } from '@angular/core/testing';

import { ApiCommunicationsService } from './api-communications.service';

describe('ApiCommunicationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ApiCommunicationsService = TestBed.get(ApiCommunicationsService);
    expect(service).toBeTruthy();
  });
});
