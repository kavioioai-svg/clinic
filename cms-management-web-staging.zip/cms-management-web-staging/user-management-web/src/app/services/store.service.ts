import { UserWithRole } from './../objects/response/UserWithRole';
import { StoreStatus } from './../objects/StoreStatus';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { Injectable, OnDestroy } from '@angular/core';
import { NgxPermissionsService } from 'ngx-permissions';
import { LoggerService } from './logger.service';
import { AuthService } from './auth.service';
import { AlertService } from '../services/alert.service';
import { ApiAAService } from './api-aa';
import { ApiCmsManagementService } from './api-cms-management.service';
import { Instruction, DosageInstruction, Uom } from '../objects/request/Drug';
import { AuthUserService } from '../state/auth-user/auth-user.service';
import { DoctorService } from '../state/doctor/doctor.service';
import { DoctorSpecialityService } from '../state/doctor-speciality/doctor-speciality.service';
import { ClinicService } from '../state/clinic/clinic.service';
import { MedicalCoverageService } from '../state/medical-coverage/medical-coverage.service';
import { DrugService } from '../state/drug/drug.service';
import { UserListService } from '../state/user-list/user-list.service';
import { ChargeItemService } from '../state/charge-item/charge-item.service';
import { StoreStatusService } from '../state/store-status/store-status.service';
import { Clinic } from '../objects/response/Clinic';
import { AdjustmentReasonService } from '../state/adjustment-reason/adjustment-reason.service';
import {StockAdjustmentReason} from '../objects/StockAdjustment';

@Injectable()
export class StoreService implements OnDestroy {
  currentConsultationRoute = 'route1';
  authorizedClinicList = [];

  errorMessages = [];
  doctorList = [];
  clinicList = [];
  communicationTypes = [];

  // Store Status
  private totalApiCalls = 0;
  private storeSuccessCount = 0;
  private storeFailCount = 0;
  private stockAdjustmentReason: Array<StockAdjustmentReason> = [];
  constructor(
    private permissionsService: NgxPermissionsService,
    private authService: AuthService,
    private apiAAService: ApiAAService,
    private apiCmsManagementService: ApiCmsManagementService,
    private alertService: AlertService,
    private logger: LoggerService,
    private router: Router,
    private clinicService: ClinicService,
    private doctorService: DoctorService,
    private authUserService: AuthUserService,
    private drugService: DrugService,
    private doctorSpecialityService: DoctorSpecialityService,
    private medicalCoverageService: MedicalCoverageService,
    private userListService: UserListService,
    private chargeItemService: ChargeItemService,
    private storeStatusService: StoreStatusService,
    private adjustmentReasonService: AdjustmentReasonService,

  ) {
    if (localStorage.getItem('access_token')) {
    } else {
    }
    this.preInit();
  }

  preInit() {
    this.storeSuccessCount = 0;
    this.storeFailCount = 0;
    this.storeStatusService.setReseting();
    if (this.authService.isAuthenticated()) {
      this.authUserService.getUser().subscribe(
        (res) => {
          localStorage.setItem('roles', JSON.stringify(res.payload.roles));
          this.permissionsService.loadPermissions(res.payload.roles);

          this.permissionsService.permissions$.subscribe((permissions) => {
            if (permissions && Object.keys(permissions).length > 0) {
              this.authService.permissionsLoaded = true;

              const to_route = localStorage.getItem('TO_ROUTE');
              setTimeout(() => {
                localStorage.removeItem('TO_ROUTE');
              }, 2000);

              if(to_route) {
                let {url, queryParams} = JSON.parse(to_route);
                this.router.navigate([url], {queryParams});
              } else {
                this.router.navigate(['pages/welcome']);
              }

              this.initStore();
            }
          });
        },
        (error) => {
          if(error.error.status === 'FORBIDDEN') {
            this.router.navigate(['/reset-password']);
          } else {
            this.alertService.error(error.error.message);
          }
        }
      );
    }
  }

  ngOnDestroy() {}

  initStore() {
    this.totalApiCalls = 0;
    this.alertService.getMessage().subscribe((msg) => console.log(msg));

    if (this.permissionsService.getPermission('ROLE_USER_CREATE')) {
      this.totalApiCalls++;
      this.retrieveUsers();
    }
    if (this.permissionsService.getPermission('ROLE_VIEW_DOCTOR')) {
      this.totalApiCalls++;
      this.retrieveDoctorSpeciality();
    }
    if (this.permissionsService.getPermission('ROLE_VIEW_ITEM')) {
      this.totalApiCalls++;
      this.retrieveDrugInstructions();
    }
    if (this.permissionsService.getPermission('ROLE_MEDICAL_COVERAGE_MANAGEMENT')) {
      this.totalApiCalls++;
      this.retrieveMedicalCoverage();
    }
    if (this.permissionsService.getPermission('ROLE_VIEW_CLINIC')) {
      this.totalApiCalls++;
      this.retrieveClinics();
    }
    if (this.permissionsService.getPermission('ROLE_VIEW_DOCTOR')) {
      this.totalApiCalls++;
      this.retrieveDoctors();
    }
    if (this.permissionsService.getPermission('ROLE_VIEW_ITEM')) {
      this.totalApiCalls++;
      this.retrieveItems();
    }
    if  (this.permissionsService.getPermission('ROLE_PR_PO_INVENTORY_NAV')) {
      this.totalApiCalls++;
      this.retrieveAdjustmentReason();
    }

    this.authService.isLogout().subscribe((data) => {
      this.authUserService.logoutClearUp();
    });
  }

  /** STORE INIT */
  setStoreReady(hasSucceeded: boolean) {
    if (hasSucceeded) {
      this.storeSuccessCount++;
    } else {
      this.storeFailCount++;
    }
    if (this.storeSuccessCount >= this.totalApiCalls) {
      this.storeStatusService.setLoaded();
    } else if (this.storeSuccessCount + this.storeFailCount === this.totalApiCalls) {
      this.storeStatusService.setError();
    }
  }
  /** STORE INIT */

  /** DOCTOR */
  retrieveDoctors() {
    this.doctorService.getDoctorList().subscribe(
      (res) => {
        this.doctorList = res.payload;
        this.setStoreReady(true);
      },
      (err) => {
        this.setStoreReady(false);
        this.alertService.error(JSON.stringify(err));
        this.errorMessages['listDoctorsByClinic'] = err;
      }
    );
  }
  /** DOCTOR */

  /**DOCTORE SPECIALITTY */
  retrieveDoctorSpeciality() {
    this.doctorSpecialityService.getSpecialities().subscribe(
      (data) => {
        this.setStoreReady(true);
      },
      (err) => {
        this.alertService.error(JSON.stringify(err.error.message));
        this.setStoreReady(false);
      }
    );
  }
  /**DOCTORE SPECIALITTY */

  /**Adjustment Reasons */
  retrieveAdjustmentReason() {
    this.adjustmentReasonService.getAdjustmentReasons().subscribe(
      (data) => {
        this.setStoreReady(true);
      },
      (err) => {
        this.alertService.error(JSON.stringify(err.error.message));
        this.setStoreReady(false);
      }
    );
  }
  /**Adjustment Reasons */

  /**INSTRUCTION, DOSAGE INSTRUCTION, CAUTIONARIES, DRUG CATEGORIES */
  retrieveDrugInstructions() {
    this.drugService.getDrugInfo().subscribe(
      (res) => {
        this.setStoreReady(true);
      },
      (err) => {
        this.setStoreReady(false);
      }
    );
  }
  /**INSTRUCTION, DOSAGE INSTRUCTION, CAUTIONARIES, DRUG CATEGORIES */

  /**  ITEMS */
  retrieveItems() {
    this.chargeItemService.getChargeItems().subscribe(
      (res) => {
        this.setStoreReady(true);
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
        this.errorMessages['listChargeItems'] = err;
        this.setStoreReady(false);
      }
    );
  }

  /** CLINIC */
  retrieveClinics() {
    this.clinicService.getClinicList().subscribe(
      (res) => {
        this.clinicList = res.payload;
        this.setStoreReady(true);
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
        this.errorMessages['listClinics'] = err;
        this.setStoreReady(false);
      }
    );
  }
  /** CLINIC */

  /** MEDICAL COVERAGE */
  retrieveMedicalCoverage() {
    this.medicalCoverageService.getMedicalCoverageList().subscribe(
      (res) => {
        this.setStoreReady(true);
      },
      (err) => {
        this.setStoreReady(false);
        this.alertService.error(JSON.stringify(err));
        this.errorMessages['listMedicalCoveragesWithPagination'] = err;
      }
    );
  }
  /** MEDICAL COVERAGE */

  /** PO */
    retrievePO() {
      this.medicalCoverageService.getMedicalCoverageList().subscribe(
        (res) => {
          this.setStoreReady(true);
        },
        (err) => {
          this.setStoreReady(false);
          this.alertService.error(JSON.stringify(err));
          this.errorMessages['listMedicalCoveragesWithPagination'] = err;
        }
      );
    }
    /** PO */

  retrieveUsers() {
    if (this.permissionsService.getPermission('ROLE_USER_CREATE')) {
      this.userListService.getUserList().subscribe(
        (res) => {
          this.setStoreReady(true);
        },
        (err) => {
          this.setStoreReady(false);
          this.alertService.error(JSON.stringify(err));
          this.errorMessages['listUsersWithPagination'] = err;
        }
      );
    } else {
      this.totalApiCalls--;
    }
  }

  getDoctors() {
    return this.doctorList;
  }

  findDoctorById(doctorId: string) {
    return this.doctorList.find((element) => element.id === doctorId);
  }

  getClinic(clinicId): Clinic {
    return this.clinicList.find((clinic) => clinic.id === clinicId);
  }

  getClinicList(page: number = 0, size: number = 10000) {
    return this.clinicList.slice(size * page, size * (page + 1));
  }

  getMedicalCoverageByPlanId(planId) {
    return '';
  }
  getStockAdjustmentReasonList(): Array<StockAdjustmentReason> {
    return this.stockAdjustmentReason;
  }
  afterInventoryStockAdjustmentReasonList(data) {
    this.stockAdjustmentReason = data.payload.map(item =>
      new StockAdjustmentReason().adapt(item)
    );
  }

  afterCommunicationTypes(data) {
    this.communicationTypes = data;
  }
}
