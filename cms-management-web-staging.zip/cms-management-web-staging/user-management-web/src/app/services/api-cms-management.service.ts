import { CoverageSelected, MedicalCoverage } from './../objects/MedicalCoverage';
import { NgxPermissionsService } from 'ngx-permissions';
import { Clinic } from './../objects/response/Clinic';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfigService } from './app-config.service';
import { HttpResponseBody } from '../objects/response/HttpResponseBody';
import { Observable, EMPTY } from 'rxjs';
import { share, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ApiCmsManagementService {
  private headers = new HttpHeaders().set('Content-Type', 'application/json').set('Authorization',`Bearer ${localStorage.getItem('access_token')}`);
  private API_URL;
  private API_CMS_MANAGEMENT_URL;
  private API_PACKAGE_ITEM_INFO_URL;
  private API_PCN_URL;
  private API_NPHS_URL;
  private API_NPHS_LABEL_URL;
  private API_AA_URL;
  private API_REPORT_URL;

  constructor(
    private http: HttpClient,
    private appConfig: AppConfigService,
    private permissionService: NgxPermissionsService
  ) {
    this.API_URL = appConfig.getConfig().API_URL;
    this.API_CMS_MANAGEMENT_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL;
    this.API_PACKAGE_ITEM_INFO_URL = appConfig.getConfig().API_PACKAGE_ITEM_INFO_URL;
    this.API_PCN_URL = appConfig.getConfig().API_PCN_URL;
    this.API_NPHS_URL = appConfig.getConfig().API_NPHS_URL;
    this.API_NPHS_LABEL_URL = appConfig.getConfig().API_NPHS_LABEL_URL;
    this.API_AA_URL = appConfig.getConfig().API_AA_URL;
    this.API_REPORT_URL = appConfig.getConfig().REPORT_URL;
  }

  /** DOCTOR */
  listDoctors(): Observable<HttpResponseBody> {
    if (this.permissionService.getPermission('ROLE_VIEW_DOCTOR')) {
      return this.http.post<HttpResponseBody>(
        `${this.API_CMS_MANAGEMENT_URL}/doctor/list/all`,
        {},
        { headers: this.headers }
      );
    } else {
      return EMPTY;
    }
  }

  listSpecialities(): Observable<HttpResponseBody> {
    if (this.permissionService.getPermission('ROLE_VIEW_DOCTOR')) {
      return this.http.post<HttpResponseBody>(
        `${this.API_CMS_MANAGEMENT_URL}/system-config/list/speciality`,
        {},
        { headers: this.headers }
      );
    } else {
      return EMPTY;
    }
  }

  listSFLSetupMapping(): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/system-config/list/SFL_SETUP_MAPPING`,
      {}
    );
  }

  searchDiagnosisByIcdCodes(codes: String[]): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/diagnosis/search/bycode`,
      codes
    );
  }

  searchDiagnosisByIds(ids: String[]): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/diagnosis/search`,
      ids
    );
  }

  listDoctorSpeciality(): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/doctor/list/speciality`,
      {},
      { headers: this.headers }
    );
  }

  addDoctor(requestBody): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(`${this.API_CMS_MANAGEMENT_URL}/doctor/add`, JSON.stringify(requestBody), {
      headers: this.headers,
    });
  }

  modifyDoctor(id: string, requestBody): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/doctor/modify/${id}`,
      JSON.stringify(requestBody),
      { headers: this.headers }
    );
  }
  /** DOCTOR */

  /** CLINIC */
  addClinic(clinic: Clinic): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(`${this.API_CMS_MANAGEMENT_URL}/clinic/add`, JSON.stringify(clinic), {
      headers: this.headers,
    });
    return list;
  }

  modifyClinic(clinicId: string, clinic: Clinic): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/clinic/modify/${clinicId}`,
      JSON.stringify(clinic),
      { headers: this.headers }
    );
    return list;
  }

  removeClinic(clinicId: string): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/clinic/modify/${clinicId}`,
      {},
      { headers: this.headers }
    );
    return list;
  }

    listClinics(): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/clinic/list/all`,
      {},
      {headers: this.headers}
    );
  }
  /** CLINIC */

  /** MEDICAL COVERAGE */
  listMedicalCoveragesWithPagination(page: number = 0, size: number = 10000): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/list/${page}/${size}/false`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  searchCoverage(value: string): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/search/${value}/false`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  listSystemStoreValuesByKey(key: string): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/system-config/list/${key}`,
      {}
    );
  }

  searchCoverageAsObject(value: string): Observable<MedicalCoverage[]> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/search/${value}/false`,
      {},
      { headers: this.headers }
    );
    return list.pipe(map((val) => val.payload));
  }
  /** MEDICAL COVERAGE */

  /** DRUG INSTRUCTION */
  listDrugInstructions(): Observable<HttpResponseBody> {

    if (this.permissionService.getPermission('ROLE_VIEW_ITEM')) {
      return this.http.post<HttpResponseBody>(
        `${this.API_PACKAGE_ITEM_INFO_URL}/list/instructions`,
        {},
        { headers: this.headers }
      );
    } else {
      return EMPTY;
    }
  }

  /** DIAGNOSIS */
  searchDiagnosis(
    term: string,
    planIds?: Array<string>,
    globalSearch?: boolean,
    clinicId: string = null
  ): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/diagnosis/search/${term}`,
      { planIds, globalSearch, clinicId },
      {
        headers: this.headers,
      }
    );
  }

  /** SDD CODES */
  searchSddCodes(
    term: string,
  ): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/item/sdd/search/${term}`,
      {},
      {
        headers: this.headers,
      }
    );
  }

  /** ITEMS */
  listChargeItems(): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_PACKAGE_ITEM_INFO_URL}/list`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  downloadPCNReport(reqBody): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(`${this.API_PCN_URL}`, JSON.stringify(reqBody), {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        "X-Tenant": localStorage.getItem('tenantId'),
      }),
      responseType: 'blob' as 'json',
    });
  }

  downloadPrivateCorpReport(reqBody): Observable<HttpResponseBody> {

    return this.http
      .post<HttpResponseBody>(`${this.API_REPORT_URL}excel-generate`, reqBody, {
        headers: this.headers,
        responseType: 'blob' as 'json',
      })
      .pipe(share());
  }

  downloadNPHSHE2Report(reqBody): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(`${this.API_NPHS_URL}/he2`, JSON.stringify(reqBody), {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        "X-Tenant": localStorage.getItem('tenantId'),
      }),
      responseType: 'blob' as 'json',
    });
  }

  downloadNPHSHE3Report(reqBody): Observable<HttpResponseBody> {
    return this.http.post<HttpResponseBody>(`${this.API_NPHS_URL}/he3`, JSON.stringify(reqBody), {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        "X-Tenant": localStorage.getItem('tenantId'),
      }),
      responseType: 'blob' as 'json',
    });
  }

  downloadHealthScreenReport(reqBody): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_NPHS_LABEL_URL}/${reqBody.clinicId}/${reqBody.patientIdentifier}/${reqBody.startDate}/${reqBody.endDate}/${reqBody.templateName}`,
      {}, { headers: this.headers }
    );
  }

  printTemplate(template: string, isPreview = false) {
    const openWindowBtn = document.createElement('BUTTON');
    openWindowBtn.onclick = () => {
      const w = window.open();
      w.document.open();
      w.document.write(template);
      w.document.close();
      if (!isPreview) {
        w.onload = () => {
          w.window.print();
        };
        w.onafterprint = () => {
          w.close();
        };
      }
    };
    openWindowBtn.click();
  }

  /** MEDICAL COVERAGE */
  addMedicalCoverage(medicalCoverage: MedicalCoverage): Observable<HttpResponseBody> {

    const medicalCoverageItem = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/add/`,
      JSON.stringify(medicalCoverage),
      {
        headers: this.headers,
      }
    );
    return medicalCoverageItem;
  }

  modifyMedicalCoverage(medicalCoverageId: string, medicalCoverage: MedicalCoverage): Observable<HttpResponseBody> {

    const medicalCoverageItem = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/update/${medicalCoverageId}`,
      JSON.stringify(medicalCoverage),
      {
        headers: this.headers,
      }
    );
    return medicalCoverageItem;
  }

  addMedicalCoveragePlan(
    medicalCoverageId: string,
    medicalCoveragePlan: CoverageSelected
  ): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/add/plan/${medicalCoverageId}`,
      JSON.stringify(medicalCoveragePlan),
      { headers: this.headers }
    );

    return list;
  }

  modifyMedicalCoveragePlan(
    medicalCoverageId: string,
    planId: string,
    medicalCoveragePlan: CoverageSelected
  ): Observable<HttpResponseBody> {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/update/plan/${medicalCoverageId}/${planId}`,
      JSON.stringify(medicalCoveragePlan),
      { headers: this.headers }
    );

    return list;
  }

  addMedicalCoverageItems(medicalCoverageId: string, planId: string, itemList: Array<any>) {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/plan/add/medical-coverage-item/${medicalCoverageId}/${planId}`,
      JSON.stringify(itemList),
      { headers: this.headers }
    );
    return list;
  }

  searchMedicalCoverageItems(medicalCoverageId: string, planId: string) {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/plan/list/medical-coverage-item/${medicalCoverageId}/${planId}`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  addMedicalCoverageExclusions(medicalCoverageId: string, planId: string, itemList: Array<any>) {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/plan/add/medical-coverage-exclusion/${medicalCoverageId}/${planId}`,
      JSON.stringify(itemList),
      { headers: this.headers }
    );
    return list;
  }

  searchMedicalCoverageExclusions(medicalCoverageId: string, planId: string) {

    const list = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/coverage/plan/list/medical-coverage-exclusion/${medicalCoverageId}/${planId}`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  listMims(): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/system-config/list/mims`,
      {},
      { headers: this.headers }
    );
  }

  /** MEDICAL COVERAGE */

  /* CLINIC ITEM */

  listChargeItemsByGroup(groupName): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/item-management/list/clinic-group-item-price/${encodeURI(groupName)}`,
      {},
      { headers: this.headers }
    );
  }

  listChargeItemByClinicId(clinicId): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/item-management/list/clinic-item-price/${clinicId}`,
      {},
      { headers: this.headers }
    );
  }

  modifyChargeItemByGroup(groupName, chargeItems): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/item-management/update/clinic-group-item-price/${encodeURI(groupName)}`,
      JSON.stringify(chargeItems),
      { headers: this.headers }
    );
  }

  modifyChargeItemByClinicId(clinicId, chargeItems): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/item-management/update/clinic-item-price/${clinicId}`,
      JSON.stringify(chargeItems),
      { headers: this.headers }
    );
  }

  public getAllClinicFeatures(): Observable<HttpResponseBody> {

    return this.http.post<HttpResponseBody>(`${this.API_CMS_MANAGEMENT_URL}/clinic/list/clinic-features/all`, {}, { headers: this.headers });
  }
}
