import { HttpResponseBody } from '../objects/response/HttpResponseBody';
import { AppConfigService } from './app-config.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { saveAs } from 'file-saver';
import { Observable, Subject } from 'rxjs';
import { DB_FULL_DATE_FORMAT, DISPLAY_DATE_FORMAT, INPUT_DELAY } from '../constants/app.constants';
import moment = require('moment');
import { ApiPatientVisitService } from './api-patient-visit.service';
import {
  debounceTime,
  distinctUntilChanged,
  takeUntil,
  tap,
  map,
} from 'rxjs/operators';
import { FormBuilder } from '@angular/forms';
import { StoreService } from './store.service';
import { AlertService } from './alert.service';

@Injectable({
  providedIn: 'root'
})
export class ApiDocumentService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private API_PATIENT_VISIT_URL;
  private API_INVENTORY_SYSTEM_URL;
  private API_CLAIM_URL;
  private API_CMS_MANAGEMENT_URL;

  private componentDestroyed: Subject<void> = new Subject();

  constructor(
    private http: HttpClient, 
    private appConfig: AppConfigService,
    private fb: FormBuilder,
    private store: StoreService,
    private alertService: AlertService,
    private apiPatientVisitService: ApiPatientVisitService,
    
    ) {
    this.API_PATIENT_VISIT_URL = appConfig.getConfig().API_PATIENT_VISIT_URL;
    this.API_INVENTORY_SYSTEM_URL = appConfig.getConfig().API_INVENTORY_SYSTEM_URL;
    this.API_CLAIM_URL = appConfig.getConfig().API_CLAIM_URL;
    this.API_CMS_MANAGEMENT_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL;
  }

  getAllDocumentListByPatientId(patientId, start, end, clinicID) {
    const startDate = moment(start).format(DISPLAY_DATE_FORMAT);
    const endDate = moment(end).format(DISPLAY_DATE_FORMAT);
    return this.apiPatientVisitService
      .listAllFiles(patientId, startDate, endDate, clinicID)
      .pipe(
        debounceTime(INPUT_DELAY),
        distinctUntilChanged(),
        takeUntil(this.componentDestroyed)
      )
      .pipe(map(res => this.processDocumentResponse(res)));
  }

  getAllFilesInBillMangement(patientId, reference, clinicID) {
    return this.apiPatientVisitService
      .listAllFilesInBillMangement(patientId, reference, clinicID)
      .pipe(
        debounceTime(INPUT_DELAY),
        distinctUntilChanged(),
        takeUntil(this.componentDestroyed)
      )
      .pipe(map(res => res.payload));
  }

  processDocumentResponse(res) {
    const { payload } = res;

    const flattenPayload = payload.reduce((documents, documentGroup) => {
      if (documentGroup.fileMetadataEntities) {
        documentGroup.fileMetadataEntities.forEach(file => {
          file.localDate = documentGroup.localDate;
          //file.listType = !!file.listType ? file.listType : documentGroup.listType;
          file.patientVisitId = file.patientVisitId || '';
        });
        documents = documents.concat(documentGroup.fileMetadataEntities);
      }
      return documents;
    }, []);
    const allDocuments = flattenPayload.reduce(
      (allDocuments, documents) => allDocuments.concat(documents),
      []
    );
    allDocuments.sort((a, b) => this.compareDate(a, b));
    return allDocuments;
  }

  compareDate(a, b) {
    const momentA = moment(a.uploadDate, DB_FULL_DATE_FORMAT);
    const momentB = moment(b.uploadDate, DB_FULL_DATE_FORMAT);

    if (momentA && momentB) {
      if (moment(a.uploadDate, DB_FULL_DATE_FORMAT).isBefore(b.uploadDate)) {
        return -1;
      } else {
        return 1;
      }
    } else {
      return -1;
    }
  }

  
  downloadDocumentToLocal(file, patientid, clinicId) {
    // the listType only PATIENT and VISIT
 

    const isVisitFile = file.patientVisitId && file.patientVisitId !== '';

    let config = isVisitFile ? 'visit' : 'patient';
    let idByType = isVisitFile
      ? file.patientVisitId
        ? file.patientVisitId
        : ''
      : patientid;

    let fileId = file.fileId;

    if (!isVisitFile) {
      this.apiPatientVisitService
        .downloadNonVisitDocument(idByType, fileId, clinicId)
        .subscribe(
          res => {
     
            saveAs(res, file.fileName);
          },
          err => this.alertService.error(JSON.stringify(err))
        );
    } else {
      this.apiPatientVisitService
        .downloadDocument(config, idByType, fileId, clinicId)
        .subscribe(
          res => {
      
            saveAs(res, file.fileName);
          },
          err => this.alertService.error(JSON.stringify(err))
        );
    }
  }

//   downloadDocumentToLocal(file, patientid) {
//     // the listType only PATIENT and VISIT
 

//     const isVisitFile = file.patientVisitId && file.patientVisitId !== '';

//     let config ='patient';

//     let fileId = file.fileId;

   
//       this.apiPatientVisitService
//         .downloadDocument(config, patientid, fileId)
//         .subscribe(
//           res => {      
//             saveAs(res, file.fileName);
//           },
//           err => this.alertService.error(JSON.stringify(err))
//         );
    
//   }
// }
// function saveAs(res: any, fileName: any) {
//   throw new Error('Function not implemented.');
}

