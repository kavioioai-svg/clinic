import { AppConfigService } from './app-config.service';
import { Subject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { HttpResponseBody } from '../objects/response/HttpResponseBody';

@Injectable()
export class AuthService {
  permissionsLoaded = false;
  private logoutEvent = new Subject();
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  private API_AA_URL;

  constructor(private http: HttpClient, public jwtHelper: JwtHelperService, private appConfig: AppConfigService) {
    this.API_AA_URL = appConfig.getConfig().API_AA_URL;
  }

  public isAuthenticated(): boolean {
    const token = localStorage.getItem('access_token');
    if (token == null) {
      return false;
    }
    // Check whether the token is expired and return
    // true or false
    return !this.jwtHelper.isTokenExpired(token);
  }

  public isPermissionsLoaded(): boolean {
    return this.permissionsLoaded;
  }

  public logout() {
    this.http.post(`${this.API_AA_URL}/user/logout`, {}, { headers: this.headers }).subscribe(
      (res) => {
        this.clearLocalStorage();
        this.logoutEvent.next();
      },
      (err) => {
        this.clearLocalStorage();
        this.logoutEvent.next();
      }
    );
  }

  private clearLocalStorage(): void {
    localStorage.removeItem('access_token');
    localStorage.removeItem('TO_ROUTE');
  }

  triggerLogout() {
    this.logoutEvent.next();
  }

  isLogout() {
    return this.logoutEvent.asObservable();
  }

  changePassword(oldPassword: string, newPassword: string): Observable<HttpResponseBody> {
    return this.http.post(
      `${this.API_AA_URL}/user/change/password`,
      {
        oldPassword: oldPassword,
        newPassword: newPassword
      }
    );
  }
}
