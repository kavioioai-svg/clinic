import { TestBed, inject } from "@angular/core/testing";

import { AuthService } from "./auth.service";
import { TestingModule } from "../test/testing.module";

describe("AuthService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [AuthService]
    });
  });

  it("should be created", inject([AuthService], (service: AuthService) => {
    expect(service).toBeTruthy();
  }));
});
