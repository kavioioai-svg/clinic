import { Injectable } from '@angular/core';
import { ValidatorFn, AbstractControl, FormGroup, FormControl } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FormService {
  constructor() {}
}

export function valueTrimmedRequiredValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const value = (control.value === null || control.value === undefined ? '' : control.value).toString().trim();
    return value.length === 0 ? { required: 'required' } : null;
  };
}

export function markFormGroupTouched(formGroup: FormGroup) {
  if (formGroup.controls) {
    formGroup.markAsTouched();
    const keys = Object.keys(formGroup.controls);
    keys.forEach(key => {
      const control = formGroup.controls[key];
      if (control instanceof FormControl) {
        control.markAsTouched();
      } else if (control instanceof FormGroup) {
        markFormGroupTouched(control);
      }
    });
  }
}
