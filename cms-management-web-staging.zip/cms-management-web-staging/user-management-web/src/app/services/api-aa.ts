import { AppConfigService } from './app-config.service';
import { Observable } from 'rxjs';
import { HttpResponseBody } from './../objects/response/HttpResponseBody';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserLogin } from '../objects/User';

@Injectable()
export class ApiAAService {
  private headers =  new HttpHeaders().set('Content-Type', 'application/json');
  private API_URL;
  private API_AA_URL;

  constructor(private http: HttpClient, private appConfig: AppConfigService) {
    this.API_URL = appConfig.getConfig().API_URL;
    this.API_AA_URL = appConfig.getConfig().API_AA_URL;
  }

  login(user: UserLogin) {
    return this.http.post(`${this.API_AA_URL}/login`, JSON.stringify(user), { observe: 'response' });
  }

  public loginWithTwoFA(data: { token: string; twoFactorPin: string }): Observable<HttpResponseBody> {
    return this.http.post(`${this.API_AA_URL}/user/2fa`, JSON.stringify(data), { headers: this.headers });
  }

  signUp(userSignUp: String) {
    return this.http.post(`${this.API_AA_URL}/user/sign-up`, userSignUp, { headers: this.headers });
  }

  updateUser(userUpdate: String) {
    return this.http.post(`${this.API_AA_URL}/user/update`, userUpdate, { headers: this.headers });
  }

  getUser(): Observable<HttpResponseBody> {
    return this.http.post(`${this.API_AA_URL}/user`, {});
  }

  changePassword(oldPassword: string, newPassword: string): Observable<HttpResponseBody> {
    return this.http.post(`${this.API_AA_URL}/user/change/password/${oldPassword}/${newPassword}`, {});
  }

  resetPassword(username: string, password: string): Observable<HttpResponseBody> {
    return this.http.post(`${this.API_AA_URL}/admin/management/set/password/${username}/`, password);
  }

  updateUserCMSContext(userName: String, cmsContextId: String) {
    return this.http.post(`${this.API_AA_URL}/user/change/cms-context/${userName}/${cmsContextId}`, {
      headers: this.headers,
    });
  }

  addGroup(group: String) {
    return this.http.post(`${this.API_AA_URL}/admin/groups/add`, group, { headers: this.headers });
  }

  editGroup(group: String) {
    return this.http.post(`${this.API_AA_URL}/admin/groups/edit`, group, { headers: this.headers });
  }

  listUsersWithPagination(page: number = 0, size: number = 10000): Observable<HttpResponseBody> {
    const list = this.http.post<HttpResponseBody>(
      `${this.API_AA_URL}/admin/management/list/users/${page}/${size}`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  listGroupsWithPagination(page: number = 0, size: number = 10000): Observable<HttpResponseBody> {
    const list = this.http.post<HttpResponseBody>(
      `${this.API_AA_URL}/admin/management/list/groups/${page}/${size}`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  listModulesWithPagination(): Observable<HttpResponseBody> {
    const list = this.http.post<HttpResponseBody>(
      `${this.API_AA_URL}/admin/management/list/modules`,
      {},
      { headers: this.headers }
    );
    return list;
  }

  listRoleByModule(moduleName: String): Observable<HttpResponseBody> {
    const list = this.http.post<HttpResponseBody>(
      `${this.API_AA_URL}/admin/roles/list-by-module`,
      {
        moduleName: moduleName,
      },
      { headers: this.headers }
    );
    return list;
  }

  listRoles(): Observable<HttpResponseBody> {
    const list = this.http.post<HttpResponseBody>(`${this.API_AA_URL}/admin/roles/list`, {}, { headers: this.headers });
    return list;
  }
}
