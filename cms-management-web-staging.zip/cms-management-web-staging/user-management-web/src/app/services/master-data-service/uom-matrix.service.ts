import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AppConfigService} from '../app-config.service';
import {FormBuilder, Validators} from '@angular/forms';
import {HttpResponseBody} from '../../objects/response/HttpResponseBody';
import {Page} from '../../model/page';
import {MasterDataService} from './master-data.service';

@Injectable({
  providedIn: 'root'
})
export class UomMatrixService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  API_CMS_MANAGEMENT_URL;
  matrixURL = '/uommatrix'

  constructor(private appConfig: AppConfigService,
              private http: HttpClient,
              private masterDataService: MasterDataService,
              private fb: FormBuilder)
  {
    this.API_CMS_MANAGEMENT_URL =   this.masterDataService.getManagementApiBaseUrl();
  }

  listAllUomMatrix(page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/list/all/${page.pageNumber}/${page.size}`,
      {},
      {headers: this.headers}
    );
  }

  getUomMatrixById(id: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/by-id/${id}`,
      {},
      {headers: this.headers}
    );
  }

  addUomMatrix(data: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/create`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editUomMatrix(id: string, uom: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/update/${id}`,
      JSON.stringify(uom),
      {headers: this.headers}
    );
  }

  changeStatus(id:string , status: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/changestatus/${id}/${status}`,
      {},
      {headers: this.headers}
    );
  }


  getUomMatrixForm(initData?: string) {
    return this.fb.group({
      id:[''],
      uomCode:[initData ? initData :'' , Validators.required],
      status:['ACTIVE'],
      exchangeRatio:  this.fb.array([this.getRatioFormGroup()]),
    });
  }

  getRatioFormGroup() {
    return this.fb.group({
      key:['' , Validators.required],
      value:[0],
    });
  }

  itemSearch(filter: any, page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.matrixURL}/search-by-criteria/${page.pageNumber}/${page.size}`,
      filter,
      {headers: this.headers}
    );
  }
}
