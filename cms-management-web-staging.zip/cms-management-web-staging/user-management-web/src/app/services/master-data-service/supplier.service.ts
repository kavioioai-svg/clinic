import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AppConfigService} from '../app-config.service';
import {HttpResponseBody} from '../../objects/response/HttpResponseBody';
import {FormBuilder, Validators} from '@angular/forms';
import {ClinicMinPurchaseAmounts, Supplier, Items, PurchaseBonuses, BonusDetails,  SupplierItem} from '../../objects/Supplier';
import {CorporateAddress} from '../../objects/CorporateAddress';
import {ContactPerson} from '../../objects/ContactPerson';
import {Page} from '../../model/page';
import {valueTrimmedRequiredValidator} from '../form.service';
import {validatecontactNumber, validatePhoneNumber} from '../../validators/PhoneNumberValidator';
import {validateEmail} from '../../validators/email-validator';
import {MasterDataService} from './master-data.service';
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class SupplierService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  API_CMS_MANAGEMENT_URL;
  supplierURL = '/supplier'
  API_INVENTORY_URL;
  private selectedSupplier = new BehaviorSubject(null);
  getSelectedSupplier$ = this.selectedSupplier.asObservable();

  constructor(private appConfig: AppConfigService,
              private http: HttpClient,
              private masterDataService: MasterDataService,
              private fb: FormBuilder)
  {
    this.API_CMS_MANAGEMENT_URL =   this.masterDataService.getManagementApiBaseUrl();
    this.API_INVENTORY_URL = appConfig.getConfig().API_INVENTORY_URL;
  }



  getSupplierDataForm() {
    return this.fb.group({
      id:[''],
      name:['' , Validators.required],
      supplierNo:['', Validators.required],
      status:['ACTIVE'],
      address: this.getAddressFormGroup(),
      contacts:  this.fb.array([this.getContactsFormGroup()]),
      laboratory:[false],
      labQRCodeRequire:[false],
      labRequestFormLabel:[''],
      interCompany:[false],

    });
  }

  getAddressFormGroup(data?: CorporateAddress) {
    return this.fb.group({
      attentionTo:[''],
      address:[''],
      postalCode:[''],
    });
  }

  getContactsFormGroup(data?: ContactPerson[]) {
    return this.fb.group({
      name:[''],
      title:[''],
      directNumber:['' , validatecontactNumber],
      mobileNumber:['' , validatecontactNumber],
      faxNumber:['', validatecontactNumber],
      email:['' , [ validateEmail]],
      primary:[null],
    });
  }

  getClinicMinPurFormGroup(data?: ClinicMinPurchaseAmounts) {
    if(data) {
      return this.fb.group({
        clinicId:[data.clinicId],
        global:[data.global],
        minPurchaseAmount:[data.minPurchaseAmount/100],
      });
    } else {
      return this.fb.group({
        clinicId:['' , Validators.required],
        global:[false],
        minPurchaseAmount:[''],
      });
    }

  }

  getSupplierItemsFormGroup(isEdit?: Items[]) {
    return this.fb.group({
      itemId:['' , Validators.required],
      minPurchaseQuantity:[, Validators.min(1)],
      purchaseCode:[],
      unitPrice: this.getPriceFormGroup(),
      bonusDetails:this.fb.array([this.getBonusDetailsFormGroup()]),
      purchaseUom: [],
      status: ['ACTIVE']
    });
  }

  getPurchaseBonusFormGroup(data?: PurchaseBonuses[]) {
    return this.fb.group({
      itemId:[''],
      clinicId:[''],
      bonusDetails:this.fb.array([this.getBonusDetailsFormGroup()]),
    });
  }

  getPurchaseBonusFormArrayGroup() {
    return this.fb.group({
      itemId:[''],
      clinicId:[''],
      bonusDetails:this.fb.array([this.getBonusDetailsFormGroup()]),
    });
  }
  getItemFormGroup(data?: Items[]) {
    return this.fb.group({
      itemId:[''],
      minPurchaseQuantity:[''],
      bonusDetails:this.fb.array([this.getBonusDetailsFormGroup()]),
    });
  }
  getBonusDetailsFormGroup(data?: BonusDetails[]) {
    return this.fb.group({
      purchaseQuantity:[''],
      bonusQuantity:[''],
      uom:[''],
    });
  }
  getPriceFormGroup() {
    return this.fb.group({
      price: ['', [valueTrimmedRequiredValidator(), Validators.min(0.05)]],
      taxIncluded: [false]
    });
  }

  listAllSuppliers(page?) {
    let url = page ? `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/list/all/${page.pageNumber}/${page.size}` :
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/list/all`
    return this.http.post<HttpResponseBody>(
      url,
      {},
      {headers: this.headers}
    );
  }

  getSupplierById(id: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/by-id/${id}`,
      {},
      {headers: this.headers}
    );
  }

  addSupplier(data: Supplier) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/create`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editSupplier(id: string, supplier: Supplier) {
    const request = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/update/${id}`,
      JSON.stringify(supplier),
      { headers: this.headers }
    );
    return request;
  }

  changeStatus(id:string,  status: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/change-status/${id}/${status}`,
      {},
      {headers: this.headers}
    );
  }


  processDataBeforeSubmission(data: Supplier) {
    if (data.id === '') {
      delete data.id;
    }
    return data
  }

  searchItem(filter: any, page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/search-by-criteria/${page.pageNumber}/${page.size}`,
      filter,
      {headers: this.headers}
    );
  }

  listAllSupplierItems(sId?: string, page?: Page, ) {
    let url = page ?  `${this.API_CMS_MANAGEMENT_URL}/id/list/${page.pageNumber}/${page.size}`
      : `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/items`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  listAllItemsSupplier(itemId: string, page?: Page, ) {
    let url = page ?  `${this.API_CMS_MANAGEMENT_URL}/id/list/${page.pageNumber}/${page.size}`
      : `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/items/id/${itemId}`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  getSupplierItemById(subId: string, id: string) {
    let url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${subId}/items/${id}`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  addSupplierItem(data: SupplierItem, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/items/add`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editSupplierItem(data: SupplierItem, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/items/update`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  listAllPurchaseBonuses(sId?: string, page?: Page) {
    let url = page ?  `${this.API_CMS_MANAGEMENT_URL}/id/list/${page.pageNumber}/${page.size}`
      : `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  getPurchaseBonusesById(subId: string, itemId: string, clinicId: string) {
    let url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${subId}/purchase-bonuses/${itemId}/${clinicId}`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  addPurchaseBonuses(data: PurchaseBonuses, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/update`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editPurchaseBonuses(data: PurchaseBonuses, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/add`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  deletePurchaseBonuses(itemId: string, clinicId: string, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/delete/${itemId}/${clinicId}`,
      {},
      {headers: this.headers}
    );
  }

  listAllMinimumPurchaseAmounts(sId?: string, page?: Page, ) {
    let url = page ?  `${this.API_CMS_MANAGEMENT_URL}/id/list/${page.pageNumber}/${page.size}`
      : `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/minimum-purchase-amounts`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  getMinimumPurchaseAmountsById(subId: string, id: string) {
    let url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${subId}/minimum-purchase-amounts/${id}`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  addMinimumPurchaseAmounts(data: ClinicMinPurchaseAmounts[], sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/minimum-purchase-amounts/add`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editMinimumPurchaseAmounts(data: ClinicMinPurchaseAmounts, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/minimum-purchase-amounts/update`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  deleteMinimumPurchaseAmounts(id: string, sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/items/delete/${id}`,
      {},
      {headers: this.headers}
    );
  }


  addEditPurchaseBonuses(action: string, data: PurchaseBonuses[], sId: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/${action}`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  getSupplierPurchaseBonuseById(sId: string, itemId: string,clinicId: string) {
    return this.http.get<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/${itemId}/${clinicId}`,
      {headers: this.headers}
    );
  }

  listAllSupplierPurchase(sId?: string, page?: Page,) {
    let url = page ?  `${this.API_CMS_MANAGEMENT_URL}/id/list/${page.pageNumber}/${page.size}`
      : `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses`
    return this.http.get<HttpResponseBody>(
      url,
      {headers: this.headers}
    );
  }

  deleteSupplierItem(sId: string ,item: any , itemType: string) {
    let url = ''
    switch (itemType) {
       case 'item':
         url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/items/delete/${item.itemId}`
         break;
       case 'clinic':
         let id = item.global ? 'global' : item.clinicId
         url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/minimum-purchase-amounts/delete/${id}`
         break;
       case 'bonus':
         url = `${this.API_CMS_MANAGEMENT_URL}${this.supplierURL}/id/${sId}/purchase-bonuses/delete/${item.itemId}/${item.clinicId}`
         break;
    }
    return this.http.post<HttpResponseBody>(
      url,
      {},
      {headers: this.headers}
    );
  }

  getSupplierByItemsId(items: any) {
    let url = `${this.API_INVENTORY_URL}${this.supplierURL}/list-by-items`
    return this.http.post<HttpResponseBody>(
      url,items,
      {headers: this.headers}
    );
  }
  setSelectedSupplier(val: any) {
    this.selectedSupplier.next(val)
  }
}

