import { Injectable } from '@angular/core';
import {Page} from "../../model/page";
import {HttpClient, HttpHeaders, HttpResponseBase} from "@angular/common/http";
import {FormBuilder, Validators} from '@angular/forms';
import {AppConfigService} from "../app-config.service";
import {HttpResponseBody} from "../../objects/response/HttpResponseBody";
import {MasterDataService} from './master-data.service';

@Injectable({
  providedIn: 'root'
})
export class InstructionsService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  API_CMS_MANAGEMENT_URL;
  url = '/system-config/single/INSTRUCTIONS'

  constructor(
    private appConfig: AppConfigService,
    private http: HttpClient,
    private masterDataService: MasterDataService,
    private fb: FormBuilder
  ) {
    this.API_CMS_MANAGEMENT_URL = this.masterDataService.getManagementApiBaseUrl();
  }

  listAll(page: Page) {
    console.log(page)
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        page: page.pageNumber || 0,
        size: page.size
      },
      {headers: this.headers}
    )
  }

  getInstructionForm(init?: any) {
    return this.fb.group( {
      code: [init ? init : '' , Validators.required],
      description: [''],
      status: ['ACTIVE'],
      instruct: [''],
      externalCode: [''],
      externalDescription: [''],
      i18nDescription: this.fb.array([this.geti18FormGroup()]),
    });
  }

  geti18FormGroup() {
    return this.fb.group({
      key:[''],
      value:[''],
    });
  }

  getInstructionByCode(code: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/get`,
      code,
      {headers: this.headers},
    );
  }

  update(rawValue: any, code: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/update`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }

  create(rawValue: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/add`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }
  searchItem(value: any, page: Page, sort: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        searchParams: value,
        page: page.pageNumber || 0,
        size: page.size,
        ...(sort ? sort : {})
      },
      {headers: this.headers}
    );
  }
}
