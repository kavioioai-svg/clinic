import { TestBed } from '@angular/core/testing';

import { ItemPricingMasterService } from './item-pricing-master.service';

describe('ItemPricingMasterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ItemPricingMasterService = TestBed.get(ItemPricingMasterService);
    expect(service).toBeTruthy();
  });
});
