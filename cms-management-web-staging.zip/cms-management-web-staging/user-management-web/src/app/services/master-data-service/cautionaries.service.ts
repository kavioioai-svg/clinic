import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {AppConfigService} from "../app-config.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Page} from "../../model/page";
import {HttpResponseBody} from "../../objects/response/HttpResponseBody";
import {MasterDataService} from './master-data.service';

@Injectable({
  providedIn: 'root'
})
export class CautionariesService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  API_CMS_MANAGEMENT_URL;
  url = '/system-config/single/CAUTIONARIES'

  constructor(
    private appConfig: AppConfigService,
    private http: HttpClient,
    private fb: FormBuilder,
    private masterDataService: MasterDataService
  ) {
    this.API_CMS_MANAGEMENT_URL = this.masterDataService.getManagementApiBaseUrl();
  }

  listAll(page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        page: page.pageNumber || 0,
        size: page.size
      },
      {headers: this.headers}
    )
  }

  getInstructionForm(init?: any) {
    return this.fb.group(init ? init : {
      cautionary: ['' , Validators.required]
    });
  }

  getInstructionByCode(code: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/get`,
      code,
      {headers: this.headers},
    );
  }

  update(rawValue: any, code: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/update`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }

  create(rawValue: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/add`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }

  deleteItem(code: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/delete`,
       code,
      {headers: this.headers}
    );
  }

  searchItem(value: any, page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        searchParams: value,
        page: page.pageNumber || 0,
        size: page.size
      },
      {headers: this.headers}
    );
  }
}
