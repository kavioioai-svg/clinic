import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {AppConfigService} from "../app-config.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Page} from "../../model/page";
import {HttpResponseBody} from "../../objects/response/HttpResponseBody";
import {MasterDataService} from './master-data.service';

@Injectable({
  providedIn: 'root'
})
export class DosageInstructionsService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  API_CMS_MANAGEMENT_URL;
  url = '/system-config/single/DOSAGE_INSTRUCTIONS'

  constructor(
    private appConfig: AppConfigService,
    private http: HttpClient,
    private masterDataService: MasterDataService,
    private fb: FormBuilder
  ) {
    this.API_CMS_MANAGEMENT_URL = this.masterDataService.getManagementApiBaseUrl();
  }

  listAll(page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        page: page.pageNumber || 0,
        size: page.size
      },
      {headers: this.headers}
    )
  }

  getInstructionForm(val?: string) {
    return this.fb.group({
      code: [val ? val : '' , Validators.required],
      description: [''],
      status: ['ACTIVE'],
      instruct: [''],
      externalCode: [''],
      externalDescription: [''],
      i18nDescription: this.fb.array([this.geti18FormGroup()]),
    });
  }

  geti18FormGroup() {
    return this.fb.group({
      key:[''],
      value:[''],
    });
  }

  getInstructionByCode(code: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/get`,
      code,
      {headers: this.headers},
    );
  }

  update(rawValue: any, code: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/update`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }

  create(rawValue: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/add`,
      JSON.stringify(rawValue),
      {headers: this.headers}
    );
  }
  searchItem(filter: any, page: Page, sort: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.url}/search`,
      {
        searchParams: filter,
        page: page.pageNumber || 0,
        size: page.size,
        ...(sort ? sort : {})
      },
      {headers: this.headers}
    );
  }
}
