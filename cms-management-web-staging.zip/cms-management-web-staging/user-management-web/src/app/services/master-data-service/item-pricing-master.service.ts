import { Injectable } from '@angular/core';
import {AppConfigService} from "../app-config.service";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {FormBuilder} from "@angular/forms";
import {Page} from "../../model/page";
import {PriceItem} from "../../objects/PriceItem";
import {HttpResponseBody} from "../../objects/response/HttpResponseBody";
import {ClinicItemPrice} from "../../objects/ClinicItemPrice";
import {ClinicGroupItemPrice} from "../../objects/ClinicGroupItemPrice";
import {ItemCoverageScheme} from "../../objects/ItemCoverageScheme";

@Injectable({
  providedIn: 'root'
})
export class ItemPricingMasterService {
  private API_URL: string;
  private headers = new HttpHeaders(
    { 'Content-Type': 'application/json',
      Authorization: `Bearer ${localStorage.getItem('access_token')}` });
  url = '/item-management'
  constructor(
    private appConfig: AppConfigService,
    private http: HttpClient,
    private fb: FormBuilder
  ) {
    this.API_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL
  }
  search(searchReq: PriceItemSearchRequest) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/search`,
      searchReq,
      {headers: this.headers}
    )
  }
  addSingleClinicItem(clinicId: string, clinicItem: ClinicItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/add-single/clinic-item-price/${clinicId}`,
      clinicItem,
      {headers: this.headers}
    )
  }
  getSingleClinicItem(itemRefId: string, clinicId: string) {
    return this.http.get<HttpResponseBody>(
      `${this.API_URL}${this.url}/get-single/clinic-item-price/${clinicId}/${itemRefId}`,
      {headers: this.headers}
    )
  }
  updateSingleClinicItem(clinicId: string, clinicItem: ClinicItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/update-single/clinic-item-price/${clinicId}`,
      clinicItem,
      {headers: this.headers}
    )
  }

  deleteSingleClinicItem(clinicId: string, clinicItem: ClinicItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/delete-single/clinic-item-price/${clinicId}`,
      clinicItem,
      {headers: this.headers}
    )
  }

  addSingleClinicGroupItem(groupName: string, clinicItem: ClinicGroupItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/add-single/clinic-group-item-price/${groupName}`,
      clinicItem,
      {headers: this.headers}
    )
  }

  getSingleClinicGroupItem(itemRefId: string, groupName: string) {
    return this.http.get<HttpResponseBody>(
      `${this.API_URL}${this.url}/get-single/clinic-group-item-price/${encodeURIComponent(groupName)}/${itemRefId}`,
      {headers: this.headers}
    )
  }

  updateSingleClinicGroupItem(groupName: string, clinicItem: ClinicGroupItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/update-single/clinic-group-item-price/${groupName}`,
      clinicItem,
      {headers: this.headers}
    )
  }

  deleteSingleClinicGroupItem(groupName: string, clinicItem: ClinicGroupItemPrice) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/delete-single/clinic-group-item-price/${groupName}`,
      clinicItem,
      {headers: this.headers}
    )
  }
  addSingleMedicalCoverageItem(planId: string, clinicItem: ItemCoverageScheme) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/add-single/medical-coverage-item-price/${planId}`,
      clinicItem,
      {headers: this.headers}
    )
  }

  getSingleMedicalCoverageItem(itemRefId: string, planId: string) {
    return this.http.get<HttpResponseBody>(
      `${this.API_URL}${this.url}/get-single/medical-coverage-item-price/${planId}/${itemRefId}`,
      {headers: this.headers}
    )
  }

  updateSingleMedicalCoverageItem(planId: string, clinicItem: ItemCoverageScheme) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/update-single/medical-coverage-item-price/${planId}`,
      clinicItem,
      {headers: this.headers}
    )
  }
  deleteSingleMedicalCoverageItem(planId: string, clinicItem: ItemCoverageScheme) {
    return this.http.post<HttpResponseBody>(
      `${this.API_URL}${this.url}/delete-single/medical-coverage-item-price/${planId}`,
      clinicItem,
      {headers: this.headers}
    )
  }
}
