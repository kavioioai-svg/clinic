import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {AppConfigService} from '../app-config.service';
import {FormBuilder, Validators} from '@angular/forms';
import {Page} from '../../model/page';
import {HttpResponseBody} from '../../objects/response/HttpResponseBody';
import {ItemService} from '../item.service';
import {MasterDataService} from './master-data.service';

@Injectable({
  providedIn: 'root'
})
export class AllergyGroupService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  API_CMS_MANAGEMENT_URL;
  allergyURL = '/allergy-management'

  constructor(private appConfig: AppConfigService,
              private http: HttpClient,
              private fb: FormBuilder,
              private masterDataService: MasterDataService,
              private itemService: ItemService)
  {
    this.API_CMS_MANAGEMENT_URL =   this.masterDataService.getManagementApiBaseUrl();
  }

  listAllAllergyGroup(page: Page) {
    return this.http.post<HttpResponseBody>(
     `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/list/all-groups/${page.pageNumber}/${page.size}`,
      {},
      {headers: this.headers}
    );
  }

  getAllergyGroupById(id: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/by-id/${id}`,
      {},
      {headers: this.headers}
    );
  }

  addAllergyGroup(data: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/create/group`,
      JSON.stringify(data),
      {headers: this.headers}
    );
  }

  editAllergyGroup(id: string, uom: any) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/modify/group/${id}`,
      JSON.stringify(uom),
      {headers: this.headers}
    );
  }

  changeStatus(id:string , status: string) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/status/change/${id}/${status}`,
      {},
      {headers: this.headers}
    );
  }

  getAllergyFormGroup(val: string) {
    return this.fb.group({
      id:[''],
      groupCode:[val ? val : '' , Validators.required],
      description:['' ,Validators.required],
      drugIds:['' , Validators.required],
      status:['ACTIVE'],
      isFoodAllergy:[val ? val : false]
    });

  }


  searchItem(filter: any, page: Page) {
    return this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}${this.allergyURL}/search-by-criteria/${page.pageNumber}/${page.size}`,
      filter,
      {headers: this.headers}
    );
  }
}
