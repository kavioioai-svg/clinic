import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedDataService {
  private data = new BehaviorSubject<any>(null);
    data$ = this.data.asObservable();

    setData(data: any) {
      this.data.next(data);
    }
}
