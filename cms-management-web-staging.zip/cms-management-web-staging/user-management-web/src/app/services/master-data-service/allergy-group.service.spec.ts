import { TestBed } from '@angular/core/testing';

import { AllergyGroupService } from './allergy-group.service';

describe('AllergyGroupService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AllergyGroupService = TestBed.get(AllergyGroupService);
    expect(service).toBeTruthy();
  });
});
