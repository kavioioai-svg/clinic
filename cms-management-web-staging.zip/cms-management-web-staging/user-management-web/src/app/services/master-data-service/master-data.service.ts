import { Injectable } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {Supplier} from '../../objects/Supplier';
import { Router } from '@angular/router';
import {ItemService} from '../item.service';
import {AppConfigService} from '../app-config.service';
import {BehaviorSubject} from 'rxjs';
import {InventoryTab} from '../../model/enum/enums';
import {InventoryService} from '../inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';

@Injectable({
  providedIn: 'root'
})
export class MasterDataService {
  private onTabChange = new BehaviorSubject(null);
  onTabChange$ = this.onTabChange.asObservable();

  constructor(private fb: FormBuilder,
              private router: Router,
              private inventoryService: InventoryService,
              private appConfig: AppConfigService,
              private itemService: ItemService,) { }


  statusTypeList =    [
    { value: 'ACTIVE', label: 'Active' },
    { value: 'INACTIVE', label: 'Inactive' },
  ];
  statuses = [
    { value: 'ACTIVE', label: 'ACTIVE' },
    { value: 'INACTIVE', label: 'INACTIVE' },
    { value: 'BLOCKED', label: 'BLOCKED' },
  ];

  processDataBeforeSubmission(data: any) {
    if (data.id === '') {
      delete data.id;
    }
    return data
  }

  goBack(path: string) {
    this.router.navigate([path]);
  }

  getControlValueForPatch(name: string , data: any){
    return data[name]
  }

  getAllItemList(): any {
    let items = []
     this.itemService.listAllItems('',true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          items =  res.payload.map((item) => item.item);
        }
      }
    );

  }
  getManagementApiBaseUrl(): string {
    return this.appConfig.getConfig().API_CMS_MANAGEMENT_URL
  }

  isOnTabChange(val: boolean) {
    this.onTabChange.next(val)
  }
  setSearchFilterState(tabIndex ,searchFrm) {
    this.inventoryService.setPageFilterState({pageIndex:tabIndex , searchForm: searchFrm});
  }

  setCurrentPageIndex(table: DatatableComponent , index){
    table.bodyComponent.updateOffsetY(index);
    table.offset = index;
    return table;
  }
}
