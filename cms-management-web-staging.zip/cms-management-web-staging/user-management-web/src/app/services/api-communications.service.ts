import { Injectable } from '@angular/core';
import { HttpResponseBody } from '../objects/response/HttpResponseBody';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfigService } from './app-config.service';

@Injectable({
  providedIn: 'root'
})
export class ApiCommunicationsService {
  private headers = new HttpHeaders().set('Content-Type', 'application/json').set('Authorization',`Bearer ${localStorage.getItem('access_token')}`);
  private API_CMS_MANAGEMENT_URL;
  constructor(
    private http: HttpClient,
    private appConfig: AppConfigService,
  ) { 
    this.API_CMS_MANAGEMENT_URL = this.appConfig.getConfig().API_CMS_MANAGEMENT_URL;
  }

  searchLogs(payload, page): Observable<HttpResponseBody> {
    const logs = this.http.post<HttpResponseBody>(
      `${this.API_CMS_MANAGEMENT_URL}/smart-cms/search/submissions/${page.pageNumber}/${page.size}`,
      JSON.stringify(payload),
      { headers: this.headers }
    );
    return logs;
  }
}
