export enum InventoryTab {
  CURRENT_STOCK = 0,
  STOCK_ADJUSTMENT,
  SYNC_QUEUE ,
  PURCHASE_REQUEST ,
  ORDER_REQUEST ,
  PURCHASE_RETURN_APPROVAL,
  STOCK_DISPOSAL ,
  STOCK_TAKE ,
}

export enum TemplateFucType {
  IsDrugVaccine = 'IsDrugVaccine',
  DisplayDate   = 'displayDate',
  DisplayClinic   = 'displayClinic',
  ConvertTimeZone   = 'ConvertTimeZone',
  calculateVariance    = 'calculateVariance',
  StatusLabelColor   = 'statusLabelColor',
}
export enum Status {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  BLOCKED   = 'BLOCKED',
  APPROVED   = 'APPROVED',
  REQUESTED   = 'REQUESTED',
  REJECTED   = 'REJECTED',
  DRAFT   = 'DRAFT',
  FAILED   = 'FAILED',
  PARTIAL_APPROVED   = 'PARTIAL_APPROVED',
  TRANSFER   = 'TRANSFER',
  StatusLabelColor   = 'statusLabelColor',
  INITIAL   = 'INITIAL',
  PARTIAL_RECEIVED   = 'PARTIAL_RECEIVED',
  FULL_RECEIVED   = 'FULL_RECEIVED',
  DELETED   = 'DELETED',
  SUBMITTED   = 'SUBMITTED',
  PENDING   = 'PENDING',
  CONFIRM   = 'CONFIRM',
  RETURNED   = 'RETURNED',
}

export enum itemTab {
  GENERAL = 0,
  SALES_INFO ,
  PURCHASE_INFO ,
}

export enum SupplierTab {
  SUPPLIER = 0,
  ITEM ,
  CLINIC ,
}
export enum MasterDataTab {
  ALLERGY = 0,
  UOM ,
  MATRIX ,
  INSTRUCTION ,
  DOS_INSTRUCTION ,
  VACCINE_DOSAGE ,
  CAUTIONARY ,
  CATEGORIES ,
  ROUTE_OF_ADMIN ,
}
export enum MedicalCoverageTab{
  PROFILE_TAB ,
  PLAN_TAB
}
export enum MedicalPlanTab{
  MEDICAL_PLAN_TAB  ,
  ITEM_PRICE_TAB  ,
  EXCLUDED_ITEM_TAB
}

export enum InvoiceTab {
  INVOICE = 0,
  GENERATED_INVOICE = 1
}

