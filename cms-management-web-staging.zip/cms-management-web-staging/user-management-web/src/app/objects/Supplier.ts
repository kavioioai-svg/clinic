import {ContactPerson} from './ContactPerson';
import {CorporateAddress} from './CorporateAddress';
import {Uom} from './request/Drug';

export class Supplier {

  id?: string;
  name?: string;
  supplierNo?: string;
  address?: CorporateAddress;
  contacts?: ContactPerson[];
  //clinicMinPurchaseAmounts?: ClinicMinPurchaseAmounts[];
  items?: Items[];
  status?: 'ACTIVE'| 'INACTIVE' | 'BLOCKED';
  purchaseBonuses?: PurchaseBonuses[];
  laboratory?: boolean;
  labQRCodeRequire?: boolean;
  labRequestFormLabel?: string;
  interCompany?: boolean;
  minPurchaseAmounts?: any[];
  clinicMinPurchaseAmounts?: any[];

  constructor(obj: any) {
    this.id = obj.id;
    this.name = obj.name;
    this.supplierNo = obj.supplierNo;

    return this
  }

}

export class ClinicMinPurchaseAmounts{
  clinicId?: string;
  global?: string;
  minPurchaseAmount?: number;

  constructor(obj?: any) {

    if(!obj){
      return
    }
    this.clinicId = obj.clinicId;
    this.global= obj.global;
    this.minPurchaseAmount= obj.minPurchaseAmount * 100;

  }
}
export class  Items{
  itemId?: string;
  minPurchaseQuantity?: number;
  unitPrice?: {price: number, taxIncluded: boolean};
}
export class PurchaseBonuses{
  itemId?: string;
  clinicId?: string;
  bonusDetails?: BonusDetails[];
}

export class  SupplierItem{
  itemId?: string;
  minPurchaseQuantity?: number;
  purchaseCode?: string;
  unitPrice?: string;
  purchaseBonuses: PurchaseBonuses[]
}
export class  BonusDetails{
  purchaseQuantity?: number
  bonusQuantity?: number
  uom?:Uom;
}

export class  SupplierClinics {
  clinicId: string;
  isGlobal: boolean;
  minPurchaseAmount: number;
}

export class  SupplierFilter {
  status: string;
  supplier: string;
  name: string;
  sort: {
    dir: string,
    prop: string
  }

  constructor(obj?: any){

  }
}
export interface ClinicFilter {
  clinics: any[];
}

export interface UnitPrice {
  price: number;
  taxIncluded: boolean;
}

export interface GoodPurchasedItem {
  lineNo?: string;
  receiverClinicId?: string;
  itemRefId: string;
  supplierId: string;
  uom: string;
  quantity: number;
  unitPrice: UnitPrice;
  purchaseRequestId?: string;
  isBonusItem?: boolean;
  bonusItem?: boolean;
}

export interface TransferRequestItem {
  lineNo: string;
  itemRefId: string;
  uom: string;
  quantity: number;
  purchaseRequestId: string;

  batchNumber: string
}

export interface Order {
  requestId?: string;
  id?: string;
  requestClinicId?: string;
  orderType: 'PURCHASE' | 'TRANSFER';
  orderNo?: string;
  orderDate?: string;
  requestDate?: string;
  requestNo?: string;
  goodReceivedNotes: GoodReceivedNote[];
  orderStatus: 'DRAFT' | 'INITIAL' | 'PARTIAL_RECEIVED' | 'FULL_RECEIVED' | 'REJECTED' | 'DELETED';
  supplierId?: string;
  clinicFilter?: ClinicFilter;
  goodPurchasedItems: GoodPurchasedItem[];
  transferRequestItems: TransferRequestItem[];
  returnItems: any[];
  senderClinicId?: string;
  deliveryNotes: DeliveryNote[];
  cPTransfer?: boolean;
  interComp?: boolean;
  remark?:string;
}

export interface RequestItem {
  itemRefId: string;
  supplierId: string;
  uom: string;
  quantity: number;
  approvedQuantity: number;
  unitPrice: UnitPrice;
  approvedUom: string;
  requestItemStatus: string;
  cpRemarks: string;
}

export interface NavIntegrationResult {
  status: string;
}

export interface PurchaseRequest {
  id: string;
  createdDate: Date;
  lastModifiedDate: Date;
  lastModifiedBy: string;
  requestClinicId: string;
  requestType: string;
  requestNo: string;
  createDate: string;
  requestDate: string;
  requiredBeforeDate: string;
  requestItems: RequestItem[];
  justificationForPurchase: string;
  requestStatus: string;
  userName: string;
  navIntegrationResult: NavIntegrationResult;
}

export interface ReceivedItem {
  lineNo: string;
  itemRefId: string;
  uom: string;
  batchNumber: string;
  quantity: number;
  receiptDate: string;
  expiryDate: string;
}

export interface GoodReceivedNote {
  id: string;
  grnDate: string;
  createDate: string;
  delivererId: string;
  receiverId: string;
  grnNo: string;
  receivedItems: ReceivedItem[];
  status: string;
  fileMetaData: any[];
  userId: string;
  dnDate: string;
  dnNo: string;
  prNo: string;
  prDate: string;
}

export interface ClinicFilter {
  clinics: any[];
}

export interface TransferRequestItem {
  lineNo: string;
  itemRefId: string;

  batchNumber: string;
  uom: string;
  quantity: number;
}

export interface TransferSendItem {
  lineNo: string;
  itemRefId: string;
  uom: string;
  batchNumber: string;
  quantity: number;
  expiryDate: string;
}

export interface DeliveryNote {
  id: string;
  delivererId: string;
  receiverId: string;
  createDate: string;
  sendDate: string;
  dnNo: string;
  transferSendItems: TransferSendItem[];
  status: string;
  userId: string;
}
