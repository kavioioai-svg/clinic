import * as moment from 'moment';
import {DISPLAY_DATE_FORMAT} from '../constants/app.constants';

export class PurchaseReturnOrderFilter {
  startDate: string;
  endDate: string;
  clinicId: string;
  requestStatus: string;
  orderNo: string;
  TRANSFER_PURCHASE_TYPE: OrderType;
  supplierId: string;
  itemRefId?: string;
  ORDER_IDS: string[];
  prNo: string[];
  grvnNo: string;
}


export enum OrderType {
  PURCHASE_ORDER = "PURCHASE_ORDER",
  TRANSFER_ORDER = "TRANSFER_ORDER",
  ALL = "ALL",
}
