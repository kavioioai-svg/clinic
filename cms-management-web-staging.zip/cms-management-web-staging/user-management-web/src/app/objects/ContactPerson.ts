export class ContactPerson {
  name?: string
  title?: string
  directNumber?: string
  mobileNumber?: string
  faxNumber?: string
  email?: string
  primary?: boolean
}
