export class AppConfigFile {
  API_URL: string;
  API_DOMAIN: string;
  API_AA_URL: string;
  API_PATIENT_VISIT_URL: string;
  API_INVENTORY_SYSTEM_URL: string;
  API_PATIENT_INFO_URL: string;
  API_CMS_MANAGEMENT_URL: string;
  API_CLAIM_URL: string;
  API_ECLAIM_URL: string;
  API_PACKAGE_ITEM_INFO_URL: string;
  REPORT_URL: string;
  REPORT_URL_NEW: string;
  SHOW_COPY_PRESCRIPTION_AFTER: string;
  API_PCN_URL: string;
  API_NPHS_URL: string;
  API_NPHS_LABEL_URL: string;
  API_CMS_MANAGEMENT_USER_GROUPING: string;
  API_DOCUMENT_URL: string;
  API_INVENTORY_URL: string;

  constructor(
    API_URL?: string,
    API_DOMAIN?: string,
    API_AA_URL?: string,
    API_PATIENT_VISIT_URL?: string,
    API_INVENTORY_SYSTEM_URL?: string,
    API_PATIENT_INFO_URL?: string,
    API_CMS_MANAGEMENT_URL?: string,
    API_CLAIM_URL?: string,
    API_PACKAGE_ITEM_INFO_URL?: string,
    REPORT_URL?: string,
    REPORT_URL_NEW?: string,
    SHOW_COPY_PRESCRIPTION_AFTER?: string,
    API_PCN_URL?: string,
    API_NPHS_URL?: string,
    API_NPHS_LABEL_URL?: string,
    API_CMS_MANAGEMENT_USER_GROUPING?:string,
    API_DOCUMENT_URL?: string,
    API_INVENTORY_URL?: string
  ) {
    this.API_URL = API_URL || '';
    this.API_DOMAIN = API_DOMAIN || '';
    this.API_AA_URL = API_AA_URL || '';
    this.API_PATIENT_VISIT_URL = API_PATIENT_VISIT_URL || '';
    this.API_INVENTORY_SYSTEM_URL = API_INVENTORY_SYSTEM_URL || '';
    this.API_PATIENT_INFO_URL = API_PATIENT_INFO_URL || '';
    this.API_CMS_MANAGEMENT_URL = API_CMS_MANAGEMENT_URL || '';
    this.API_CLAIM_URL = API_CLAIM_URL || '';
    this.API_PACKAGE_ITEM_INFO_URL = API_PACKAGE_ITEM_INFO_URL ||'';
    this.REPORT_URL = REPORT_URL || '';
    this.REPORT_URL_NEW = REPORT_URL_NEW || '';
    this.SHOW_COPY_PRESCRIPTION_AFTER = SHOW_COPY_PRESCRIPTION_AFTER || '';
    this.API_PCN_URL = API_PCN_URL || '';
    this.API_NPHS_URL = API_NPHS_URL || '';
    this.API_NPHS_LABEL_URL = API_NPHS_LABEL_URL || '';
    this.API_CMS_MANAGEMENT_USER_GROUPING = API_CMS_MANAGEMENT_USER_GROUPING || '';
    this.API_DOCUMENT_URL = API_DOCUMENT_URL || '';
    this.API_INVENTORY_URL = API_INVENTORY_URL || '';
  }
}
