export default class PrivateCorporateExcel {
  clinicIds: string[];
  statuses: string[];
  coverageType: string[];
  coverageIds: string[];
  doctorIds: string[];
  patientIndentityNumber: string;
  // dd-MM-yyyyTHH::mm || DB_FULL_DATE_FORMAT_NO_SECOND
  startDate: string;
  endDate: string;
  reportType: string;

  constructor(
    clinicIds?: string[],
    statuses?: string[],
    coverageType?: string[],
    coverageIds?: string[],
    doctorIds?: string[],
    patientIndentityNumber?: string,
    startDate?: string,
    endDate?: string,
    reportType?: string
  ) {
    this.clinicIds = clinicIds === undefined ? new Array<string>() : clinicIds;
    this.statuses = statuses === undefined ? new Array<string>() : statuses;
    this.coverageType = coverageType === undefined ? new Array<string>() : coverageType;
    this.coverageIds = coverageIds === undefined ? new Array<string>() : coverageIds;
    this.doctorIds = doctorIds === undefined ? new Array<string>() : doctorIds;
    this.patientIndentityNumber = patientIndentityNumber || '';
    this.startDate = startDate || '';
    this.endDate = endDate || '';
    this.reportType = reportType || '';
  }
}
