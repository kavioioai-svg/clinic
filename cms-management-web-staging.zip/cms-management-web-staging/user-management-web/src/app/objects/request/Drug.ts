import {Dosage} from '../Dosage';

export class Drug {
  id?: string;
  name: string;
  code: string;
  description: string;
  baseUom: string;
  salesUom: string;
  purchaseUom: string;
  dosageUom: string;
  category: string;
  cost: Price;
  sellingPrice: Price;
  reorderPoint: number;
  reorderQty: number;
  minimumOrderQty: number;
  maximumOrderQty: number;
  safetyStockQty: number;
  inventoried: boolean;
  allowNegativeInventory: boolean;
  itemFilter: ItemFilter;
  itemType: string;
  status: string
  standardDispenseAmount: number;
  brandName: string;
  genericName: string;
  printDrugLabel: boolean;
  dosageQty: number;
  frequency: string;
  frequencyCode: string;
  dosageInstructionCode: string;
  dosageInstruction: string;
  precautionaryInstructions: string;
  indications: string;
  controlledDrug: boolean;
  dispensingMultiples: number;
  supplierId?: string;
  priceAdjustmentType: 'PACKAGE'| 'SUB_ITEM'| 'FIXED';
  purchasingBlocked: boolean;
  dispensingBlocked: boolean;
  blockReason: string;
  packageType: string;
  remarks: string;
  trackingCode: boolean;
  multiCostSubItems: any;
  externalCode: string;
  outOfStockRemarks: string;
  drugGroup: string;
  brandNameJapanese: string;
  brandNameChinese: string;
  genericNameJapanese: string;
  genericNameChinese: string;
  mimsClassification: string;
  drugType: string;
  drugBrandedType: string;
  allergyGroupCode: string;
  allergyGroupCode1: string;
  allergyGroupCode2: string;
  allergyGroupCode3: string;
  allergyGroupCode4: string;
  foodAllergyGroupCode1: string;
  foodAllergyGroupCode2: string;
  foodAllergyGroupCode3: string;
  effectInJapanese: string;
  remarkInJapanese: string;
  indicationInJapanese: string;
  precInstructionInJapanese: string;
  dosages: Dosage[];
  sddCode: string;
  genericSddCode: string;
  smstDoseFormCode?: string;
  subItems: SubItems[];
  routeOfAdministration: String;
  doseUomStrength: Strength;
  multiVaccineSubItems: SubVaccineItem[];


  constructor(
    id?: string,
    name?: string,
    code?: string,
    description?: string,
    baseUom?: string,
    salesUom?: string,
    purchaseUom?: string,
    dosageUom?: string,
    category?: string,
    cost?: Price,
    sellingPrice?: Price,
    reorderPoint?: number,
    reorderQty?: number,
    minimumOrderQty?: number,
    maximumOrderQty?: number,
    safetyStockQty?: number,
    inventoried?: boolean,
    allowNegativeInventory?: boolean,
    itemFilter?: ItemFilter,
    itemType?: string,
    status?: string,
    standardDispenseAmount?: number,
    brandName?: string,
    genericName?: string,
    printDrugLabel?: boolean,
    dosageQty?: number,
    frequency?: string,
    frequencyCode?: string,
    dosageInstructionCode?: string,
    dosageInstruction?: string,
    precautionaryInstructions?: string,
    indications?: string,
    controlledDrug?: boolean,
    dispensingMultiples?: number,
    multiCostSubItems?: any[],
    trackingCode?: boolean,
    sddCode?: string,
    genericSddCode?: string,
    smstDoseFormCode?: string,
    purchasingBlocked?: boolean,
    dispensingBlocked?: boolean,
    blockReason?: string,
    brandNameChinese?: string,
    routeOfAdministration?: string,
    doseUomStrength?: Strength,
  ) {
    this.id = id || '';
    this.name = name || '';
    this.code = code || '';
    this.description = description || '';
    this.baseUom = baseUom || '';
    this.salesUom = salesUom || '';
    this.purchaseUom = purchaseUom || '';
    this.dosageUom = dosageUom || '';
    this.category = category || '';
    this.cost = cost || new Price();
    this.sellingPrice = sellingPrice || new Price();
    this.reorderPoint = reorderPoint || 0;
    this.reorderQty = reorderQty || 0;
    this.minimumOrderQty = minimumOrderQty || 0;
    this.maximumOrderQty = maximumOrderQty || 0;
    this.safetyStockQty = safetyStockQty || 0;
    this.inventoried = inventoried || true;
    this.allowNegativeInventory = allowNegativeInventory || false;
    this.itemFilter = itemFilter || new ItemFilter();
    this.itemType = itemType || '';
    this.status = status || '';
    this.standardDispenseAmount = standardDispenseAmount || 0;
    this.brandName = brandName || '';
    this.genericName = genericName || '';
    this.printDrugLabel = printDrugLabel || true;
    this.dosageQty = dosageQty || 0;
    this.frequency = frequency || '';
    this.frequencyCode = frequencyCode || '';
    this.dosageInstructionCode = dosageInstructionCode || '';
    this.dosageInstruction = dosageInstruction || '';
    this.precautionaryInstructions = precautionaryInstructions || '';
    this.indications = indications || '';
    this.controlledDrug = controlledDrug || false;
    this.dispensingMultiples = dispensingMultiples || 1;
    this.multiCostSubItems = multiCostSubItems || new MultiCostSubItem();
    this.trackingCode = trackingCode || false;
    this.sddCode = sddCode || '';
    this.genericSddCode = genericSddCode || '';
    this.smstDoseFormCode = smstDoseFormCode || '';
    this.purchasingBlocked = purchasingBlocked || false;
    this.dispensingBlocked = dispensingBlocked || false;
    this.blockReason = blockReason || '';
    this.brandNameChinese = brandNameChinese || '';
    this.routeOfAdministration = routeOfAdministration || '';
    this.doseUomStrength = doseUomStrength || new Strength();
  }
}

export class Price {
  price: number;
  taxIncluded: boolean;

  constructor(price?: number, taxIncluded?: boolean) {
    this.price = price === undefined ? 0 : price;
    this.taxIncluded = taxIncluded === undefined ? false : taxIncluded;
  }
}

export class DosageInstruction {
  code: string;
  instruct: string;
  description: string;

  constructor(code?: string, instruct?: string, description?: string) {
    this.code = code || '';
    this.instruct = instruct || '';
    this.description= description || '';
  }
}

export class VaccineDosage {
  code: string;
  name: string;
  description: string;

  constructor(code?: string, name?: string, description?: string) {
    this.code = code || '';
    this.name = name || '';
    this.description= description || '';
  }
}

export class Instruction {
  code: string;
  frequencyPerDay: number;
  instruct: string;
  cautionary: string;

  constructor(code?: string, frequencyPerDay?: number, instruct?: string, cautionary?: string) {
    this.code = code || '';
    this.frequencyPerDay = frequencyPerDay === undefined ? 0 : frequencyPerDay;
    this.instruct = instruct || '';
    this.cautionary = cautionary || '';
  }
}

export class Uom {
  uom: string;
  multiply: string;

  constructor(uom?: string, multiply?: string) {
    this.uom = uom || '';
    this.multiply = multiply || '';
  }
}

export class SubItems {
  itemRefId: string;
  sellingPrice: Price;
  quantity: number;
  sessionNo: number;

  constructor(obj?) {
    if(!obj){
      return
    }
    this.itemRefId = obj.itemRefId;
    this.sellingPrice = obj.sellingPrice;
    this.quantity = obj.quantity;
    this.sessionNo = obj.sessionNo;
  }
}
export class MultiCostSubItem {
  itemRefId: string;
  quantity: number;

  constructor(itemRefId?: string, quantity?: number) {
    this.itemRefId = itemRefId || '';
    this.quantity = quantity || 0;
  }
}
export class Strength {
  value: number;
  unit: string;

  constructor(obj?: any) {
    if(!obj){
      return
    }

    Object.assign(this,obj)
  }
}

export class ItemFilter {
  clinicIds: Array<string>;
  clinicGroupNames: Array<string>;

  constructor(clinicIds?: Array<string>, clinicGroupNames?: Array<string>) {
    this.clinicIds = clinicIds || [];
    this.clinicGroupNames = clinicGroupNames || [];
  }

}

export class SubVaccineItem {
  code: string;
  description: string;
  dosages: Dosage[];

  constructor(){}
}
