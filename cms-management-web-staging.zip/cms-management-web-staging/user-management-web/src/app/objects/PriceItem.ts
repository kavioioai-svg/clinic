/*
public class PriceItem {
    private String itemRefId;
    private String clinicId;
    private String groupName;
    private double price;
    private String planId;
}

 */
export class PriceItem {
  itemRefId: string
  clinicId: string
  groupName: string
  price: number
  planId: string
}
