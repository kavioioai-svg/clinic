export class ChargeItem {
  [x: string]: any;
  id: string;
  createdDate: string;
  name: string;
  code: string;
  baseUom: string;
  salesUom: string;
  purchaseUom: string;
  cost: ChargeItemPrice;
  sellingPrice: ChargeItemPrice;
  reorderPoint: number;
  reorderQty: number;
  minimumOrderQty: number;
  maximumOrderQty: number;
  safetyStockQty: number;
  inventoried: boolean;
  allowNegativeInventory: boolean;
  itemFilter: ChargeItemClinicFilter;
  itemType: string;
  status: string;
  standardDispenseAmount: number;
  printDrugLabel: boolean;
  dosageQty: number;
  frequency: number;
  frequencyCode: string;
  dosageInstructionCode: string;
  dosageInstruction: string;
  precautionaryInstructions: string;
  indications: string;
  controlledDrug: boolean;
  dispensingMultiples: number;
}

export class ChargeItemPrice {
  price: number;
  taxIncluded: boolean;
}

export class ChargeItemClinicFilter {
  clinicIds: Array<string>;
  clinicGroupNames: Array<string>;
}
