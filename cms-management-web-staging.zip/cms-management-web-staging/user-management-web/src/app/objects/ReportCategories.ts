export class ReportCategories {
  reportCategories: ReportCategory[];

  constructor(reportCategories?: ReportCategory[]) {
    this.reportCategories = reportCategories;
  }
}

export class ReportCategory {
  categoryName?: string;
  reports?: Report[];

  constructor(categoryName?: string, reports?: Report[]) {
    this.categoryName = categoryName || '';
    this.reports = reports ? reports : new Array<Report>();
  }
}

export class Report {
  reportName: string;
  reportDisplayName: string;
  params: string[];
  roles: string[];
  newUrl: boolean;

  constructor(reportName?: string, reportDisplayName?: string, params?: string[], roles?: string[], newUrl?: boolean) {
    this.reportName = reportName || '';
    this.reportDisplayName = reportDisplayName || '';
    this.params = params ? params : [];
    this.roles = roles ? roles : [];
    this.newUrl = newUrl ? newUrl : false;
  }
}
