import * as moment from 'moment';
import {DISPLAY_DATE_FORMAT} from '../constants/app.constants';

export class stockAdjustmentApproveRejection {
    id:string;
    inventoryId :string;
    itemCode:string;
    batchNumber:string;
    baseUom:string;
    expiryDate:string;
    adjustedQuantity:string;
    purposeOfAdjustmentCode:string;
    itemRefId:string;
    itemName:string;
    cpRemarks:string;

    constructor(obj? :any , stockItems?:any) {
      this.inventoryId = stockItems.inventoryId ? stockItems.inventoryId : null;
      this.itemCode= obj.itemCode;
      this.batchNumber= obj.batchNumber;
      this.baseUom= obj.baseUom;
      this.expiryDate= moment(obj.expiryDate , DISPLAY_DATE_FORMAT).format(DISPLAY_DATE_FORMAT) === 'Invalid date' ? obj.expiryDate :
                       moment(obj.expiryDate , DISPLAY_DATE_FORMAT).format(DISPLAY_DATE_FORMAT);
      this.adjustedQuantity= obj.adjustedQuantity;
      this.purposeOfAdjustmentCode= obj._purposeOfAdjustmentCode;
      this.itemRefId= stockItems.itemRefId;
      this.itemName= obj.itemName;
      this.id= stockItems.stockCountItemId;
      this.cpRemarks= obj.cpRemark;

    }
}
