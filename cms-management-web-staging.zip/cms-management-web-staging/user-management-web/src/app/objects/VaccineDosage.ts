export interface VaccineDosage {
  code: string;
  name: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE' | 'BLOCKED';
}