export class StockDisposalListFilter {
  disposeStatuses: any;
  clinicId: string[];
  startDate: string;
  endDate: string;
}
