export interface PurchaseRequestItemView {
  [x: string]: any;
	id: string;
	createdDate: string;
	lastModifiedDate: string;
	lastModifiedBy: string;
	requestNo: string;
	createDate: string;
	requiredBeforeDate: string;
	itemRefId: string;
	supplierId: string;
	uom: string;
	quantity: number;
	approvedQuantity: number;
	unitPrice: PurchaseRequestItemViewUnitPrice;
	remark: string;
  requestClinicId: string;
  requestItemStatus: string;
}
export interface PurchaseRequestItemViewUnitPrice {
	price: number;
	taxIncluded: boolean;
}
