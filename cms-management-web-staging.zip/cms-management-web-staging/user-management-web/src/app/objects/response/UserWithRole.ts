export class UserWithRole {
  createDate: string;
  lastUpdate: string;
  userName: string;
  firstName: string;
  lastName: string;
  email: string;
  status: string;
  numberOfLoginAttempts: number;
  lastLogout: number;
  groups: Group[];
  context: Context;

  constructor(createDate?: string,
    lastUpdate?: string,
    userName?: string,
    firstName?: string,
    lastName?: string,
    email?: string,
    status?: string,
    numberOfLoginAttempts?: number,
    lastLogout?: number,
    groups?: Group[],
    context?: Context) {
    this.createDate = createDate || '';
    this.lastUpdate = lastUpdate || '';
    this.userName = userName || '';
      this.firstName = firstName || '';
        this.lastName = lastName || '';
          this.email = email || '';
            this.status = status || '';
              this.numberOfLoginAttempts = numberOfLoginAttempts === undefined ? 0 : numberOfLoginAttempts;
                this.lastLogout = lastLogout === undefined ? 0 : lastLogout;
    this.groups = groups === undefined ? new Array<Group>() : groups      ;
                    this.context = context === undefined ? new Context() : context   ;

    }

}

class Group {
  createDate: string;
  lastUpdate: string;
  name: string;
  roles: Role[];
  description: string;

  constructor(createDate?: string,
    lastUpdate?: string,
    name?: string,
    roles?: Role[],
    description?: string) {
    this.createDate = createDate || '';
    this.lastUpdate = lastUpdate || '';
    this.name = name || '';
    this.roles = roles === undefined ? new Array<Role>() : roles   ;
    this.description = description || '';
    }
}

class Role {
  createDate: string;
  lastUpdate: string;
  role: string;
  description: string;

  constructor(createDate: string,
    lastUpdate: string,
    role: string,
    description: string) {
    this.createDate = createDate || '';
    this.lastUpdate = lastUpdate || '';
    this.role = role || '';
    this.description = description || '';
  }
}


class Context {
  'cms-user-id': string;

  constructor(cmsUserId?: string) {
    this['cms-user-id'] = cmsUserId || '';
  }
}
