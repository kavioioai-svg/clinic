export class User {
  createDate: string;
  lastUpdate: string;
  userName: string;
  password: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
  status: string;
  oldPasswords: string;
  numberOfLoginAttempts: number;
  roles: string[];
  context: Context;
  enabled2FA: boolean;
  passwordExpiryEnabled: boolean;
  logoutInactiveSessionsEnabled: boolean;
  suspendInactiveAccountEnabled: boolean;

  constructor(
    createDate?: string,
    lastUpdate?: string,
    userName?: string,
    password?: string,
    firstName?: string,
    lastName?: string,
    phoneNumber?: string,
    email?: string,
    status?: string,
    oldPasswords?: string,
    numberOfLoginAttempts?: number,
    roles?: string[],
    context?: Context,
    enabled2FA?: boolean,
    passwordExpiryEnabled?: boolean,
    logoutInactiveSessionsEnabled?: boolean,
    suspendInactiveAccountEnabled?: boolean,
  ) {
    this.createDate = createDate || '';
    this.lastUpdate = lastUpdate || '';
    this.userName = userName || '';
    this.password = password || '';
    this.firstName = firstName || '';
    this.lastName = lastName || '';
    this.phoneNumber = phoneNumber || '';
    this.email = email || '';
    this.status = status || '';
    this.oldPasswords = oldPasswords || '';
    this.numberOfLoginAttempts = numberOfLoginAttempts === undefined ? 0 : numberOfLoginAttempts;
    this.roles = roles === undefined ? new Array<string>() : roles;
    this.context = context === undefined ? new Context() : context;
    this.enabled2FA = enabled2FA === undefined ? true : enabled2FA;
    this.passwordExpiryEnabled = passwordExpiryEnabled ===  undefined ? true : passwordExpiryEnabled;
    this.logoutInactiveSessionsEnabled = logoutInactiveSessionsEnabled === undefined ? true : logoutInactiveSessionsEnabled;
    this.suspendInactiveAccountEnabled = suspendInactiveAccountEnabled === undefined ? true : suspendInactiveAccountEnabled;
  }
}

class Context {
  'cms-user-id': string;

  constructor(cmsUserId?: string) {
    this['cms-user-id'] = cmsUserId || '';
  }
}
