export class Clinic {
  id: string;
  name: string;
  groupName: string;
  emailAddress: string;
  address: Address;
  faxNumber: string;
  contactNumber: string;
  status: string;
  heCode: string;
  uen: string;
  clinicCode: string;
  anchorDoctors: string[];
  attendingDoctorId: string[];
  clinicStaffUsernames: string[];
  clinicGroupLegalName: string;
  clinicFeatures: string[];
  stockAutoApprovalEnabled:any;
  stockAutoApprovalMaxAmount:any;
  whatsAppNumber: string;

  constructor(id?: string, name?: string,
    groupName?: string,
    emailAddress?: string,
    address?: Address,
    faxNumber?: string,
    contactNumber?: string,
    status?: string,
    heCode?: string,
    uen?: string,
    clinicCode?: string,
    anchorDoctors?: string[],
    attendingDoctorId?: string[],
    clinicStaffUsernames?: string[],
    clinicGroupLegalName?:string,
    stockAutoApprovalEnabled?:any,
    stockAutoApprovalMaxAmount?:any,
    whatsAppNumber?: string,
    ) {
    this.id = id || '';
    this.name = name || '';
    this.groupName = groupName || '';
    this.emailAddress = emailAddress || '';
    this.address = address === undefined ? new Address() : address;
    this.faxNumber = faxNumber || '';
    this.contactNumber = contactNumber || '';
    this.status = status || '';
    this.heCode = heCode || '';
    this.uen = uen || '';
    this.clinicCode = clinicCode || '';
    this.anchorDoctors = anchorDoctors === undefined ? new Array<string>() : anchorDoctors;
    this.attendingDoctorId = attendingDoctorId === undefined ? new Array<string>() : attendingDoctorId;
    this.clinicStaffUsernames = clinicStaffUsernames === undefined ? new Array<string>() : clinicStaffUsernames;
    this.clinicGroupLegalName = clinicGroupLegalName || '';
    this.stockAutoApprovalEnabled = stockAutoApprovalEnabled || undefined;
    this.stockAutoApprovalMaxAmount = stockAutoApprovalMaxAmount || undefined;
    this.whatsAppNumber = whatsAppNumber || '';
  }
}

class Address {
  attentionTo: string;
  address: string;
  postalCode: string;
  unit: string; // added to allow UI to keyin but will be merged to address when submit to API

  constructor(attentionTo?: string,
    address?: string,
    postalCode?: string,
    unit?: string) {
    this.attentionTo = attentionTo || '';
    this.address = address || '';
    this.postalCode = postalCode || '';
    this.unit = unit || '';
  }
}
