export interface IClaimPaymentDetail {
  adminFee: number;
  totalPaymentAmount: number;
  totalAmountReceived: number;
  medicalCoverageId: string;
  medicalCoverageName?: string;
  bankName?: string;
  referenceNumber?: string;
  PaymentType: Payment_Type,
  paymentDate: string;
}

export const enum Payment_Type {
  'GIRO' = 'GIRO',
  'CHEQUE' = 'CHEQUE',
  'CASH' = 'CASH'
}

export interface IClaimInvoice {
  caseNumber: string;
  invoiceNumber: string;
  totalAmount: number;
  medicalCoverageId?: string;
  medicalCoverageName: string;
  paidAmount: number;
  outstandingAmount: number;
  // paymentDate: string;
  amountReceived: number;
  referenceNumber: string;
  patientName: string;
  nric: string;
}

export class ClaimInvoice implements IClaimInvoice {

  constructor(
    public caseNumber: string,
    public invoiceNumber: string,
    public totalAmount: number,
    public medicalCoverageId: string,
    public medicalCoverageName: string,
    public paidAmount: number,
    public outstandingAmount: number,
    public amountReceived = 0,
    public referenceNumber = '',
    public patientName = '',
    public nric = ''
  ) {

  }
}