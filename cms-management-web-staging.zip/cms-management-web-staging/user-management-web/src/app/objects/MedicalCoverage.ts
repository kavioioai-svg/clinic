export class MedicalCoverage {
  id: string;
  name: string;
  code: string;
  accountManager: string;
  type: string;
  startDate: string;
  endDate: string;
  creditTerms: number;
  payAtClinic?: boolean;
  policyHolderCount?: number;
  website: string;
  trackAttendance: boolean;
  usePatientAddressForBilling: boolean;
  medicineRefillAllowed: boolean;
  showDiscount: boolean;
  showMemberCard: boolean;
  address: Address;
  contacts: ContactPerson[];
  status?: string;
  coveragePlans?: CoverageSelected[];
  costCenters?: Array<any>;
  costCenter?: string;
  allowedAccessLevel?: Array<string>;
  parentCompanyName?: string;
  displayName?: string;
  rpaEnabled?: boolean;
  hrPortalAccessList?: string;
  isBusinessOfficeClaim?: boolean;
  isAlertOnChangingPlan?: boolean;
  isSuppressSurcharge?: boolean;
  financialClass?: string;
  ignoreSystemBalanceCheck?: boolean;
  medicalService?: string;
  medicalCoverageExtraDetail?: MedicalCoverageExtraDetail;

  constructor(
    id?: string,
    name?: string,
    code?: string,
    accountManager?: string,
    type?: string,
    startDate?: string,
    endDate?: string,
    creditTerms?: number,
    payAtClinic?: boolean,
    policyHolderCount?: number,
    website?: string,
    trackAttendance?: boolean,
    usePatientAddressForBilling?: boolean,
    medicineRefillAllowed?: boolean,
    showDiscount?: boolean,
    showMemberCard?: boolean,
    address?: Address,
    contacts?: ContactPerson[],
    status?: string,
    coveragePlans?: CoverageSelected[],
    costCenters?: Array<any>,
    costCenter?: string,
    allowedAccessLevel?: Array<string>,
    parentCompanyName?: string,
    displayName?: string,
    rpaEnabled?: boolean,
    hrPortalAccessList?: string,
    isBusinessOfficeClaim?: boolean,
    isAlertOnChangingPlan?: boolean,
    isSuppressSurcharge?: boolean,
    financialClass?: string,
    ignoreSystemBalanceCheck?: boolean,
    medicalService?: string,
    medicalCoverageExtraDetail?: MedicalCoverageExtraDetail
  ) {
    this.id = id || '';
    this.name = name || '';
    this.code = code || '';
    this.accountManager = accountManager || '';
    this.type = type || '';
    this.startDate = startDate || '';
    this.endDate = endDate || '';
    this.creditTerms = creditTerms === undefined ? 0 : creditTerms;
    this.payAtClinic = payAtClinic === undefined ? false : payAtClinic;
    this.policyHolderCount = policyHolderCount === undefined ? 0 : policyHolderCount;
    this.website = website || '';
    this.trackAttendance = trackAttendance === undefined ? false : trackAttendance;
    this.usePatientAddressForBilling = usePatientAddressForBilling === undefined ? false : usePatientAddressForBilling;
    this.medicineRefillAllowed = medicineRefillAllowed === undefined ? false : medicineRefillAllowed;
    this.showDiscount = showDiscount === undefined ? false : showDiscount;
    this.showMemberCard = showMemberCard === undefined ? false : showMemberCard;
    this.address = address === undefined ? new Address() : address;
    this.contacts = contacts === undefined ? new Array<ContactPerson>() : contacts;
    this.status = status || '';
    this.coveragePlans = coveragePlans === undefined ? new Array<CoverageSelected>() : coveragePlans;
    this.costCenters = costCenters === undefined ? [] : costCenters;
    this.costCenter = costCenter || '';
    this.allowedAccessLevel = allowedAccessLevel || new Array<string>();
    this.parentCompanyName = parentCompanyName || '';
    this.displayName = displayName || '';
    this.rpaEnabled = rpaEnabled || false;
    this.hrPortalAccessList = hrPortalAccessList || '';
    this.isBusinessOfficeClaim = isBusinessOfficeClaim || false;
    this.isAlertOnChangingPlan = isAlertOnChangingPlan || false;
    this.isSuppressSurcharge = isSuppressSurcharge || false;
    this.financialClass = financialClass || '';
    this.ignoreSystemBalanceCheck = ignoreSystemBalanceCheck || false;
    this.medicalService = medicalService || '';
    this.medicalCoverageExtraDetail = medicalCoverageExtraDetail || new MedicalCoverageExtraDetail();
  }
}

export class CoverageSelected {
  id?: string;
  name?: string;
  capPerVisit?: CapPerVisit;
  capPerDay?: CapPerVisit;
  capPerWeek?: CapPerVisit;
  capPerMonth?: CapPerVisit;
  capPerYear?: CapPerVisit;
  capPerLifeTime?: CapPerVisit;
  copayment?: Copayment;
  limitResetType?: string;
  code?: string;
  startDate?: string;
  endDate?: string;
  remarks?: string;
  clinicRemarks?: string;
  registrationRemarks?: string;
  paymentRemarks?: string;
  excludedClinics?: any[];
  excludeAllByDefault?: boolean;
  includedMedicalServiceSchemes?: any[];
  excludedMedicalServiceSchemes?: any[];
  allowedRelationship?: any[];
  salesDiscount: SalesDiscount;
  maximumNumberOfDiagnosisCodes: number;
  planType: string;
  extraChargeAddOnAmount: number;
  usableOnTeleConsult: boolean;
  listOnTeleConsult: boolean;
  teleConsultRemark: boolean;
  externalUniquePlanCode: boolean;
  allowSelectWithChasPlan: boolean;

  constructor(
    id?: string,
    name?: string,
    capPerVisit?: CapPerVisit,
    capPerDay?: CapPerVisit,
    capPerWeek?: CapPerVisit,
    capPerMonth?: CapPerVisit,
    capPerYear?: CapPerVisit,
    capPerLifeTime?: CapPerVisit,
    copayment?: Copayment,
    limitResetType?: string,
    code?: string,
    startDate?: string,
    endDate?: string,
    remarks?: string,
    clinicRemarks?: string,
    registrationRemarks?: string,
    paymentRemarks?: string,
    excludedClinics?: any[],
    excludeAllByDefault?: boolean,
    includedMedicalServiceSchemes?: any[],
    excludedMedicalServiceSchemes?: any[],
    allowedRelationship?: any[],
    salesDiscount?: SalesDiscount,
    maximumNumberOfDiagnosisCodes?: number,
    planType?: string,
    extraChargeAddOnAmount?: number,
    usableOnTeleConsult?: boolean,
    listOnTeleConsult?: boolean,
    teleConsultRemark?: boolean,
    externalUniquePlanCode?: boolean,
    allowSelectWithChasPlan?: boolean
  ) {
    this.id = id || '';
    this.name = name || '';
    this.capPerVisit = capPerVisit || new CapPerVisit();
    this.capPerDay = capPerDay || new CapPerVisit();
    this.capPerWeek = capPerWeek || new CapPerVisit();
    this.capPerMonth = capPerMonth || new CapPerVisit();
    this.capPerYear = capPerYear || new CapPerVisit();
    this.capPerLifeTime = capPerLifeTime || new CapPerVisit();
    this.copayment = copayment || new Copayment();

    this.limitResetType = limitResetType || '';
    this.code = code || '';
    this.startDate = startDate || '';
    this.endDate = endDate || '';
    this.remarks = remarks || '';
    this.clinicRemarks = clinicRemarks || '';
    this.registrationRemarks = registrationRemarks || '';
    this.paymentRemarks = paymentRemarks || '';
    this.excludedClinics = excludedClinics || new Array();
    this.excludeAllByDefault = excludeAllByDefault || false;
    this.includedMedicalServiceSchemes = includedMedicalServiceSchemes || new Array();
    this.excludedMedicalServiceSchemes = excludedMedicalServiceSchemes || new Array();
    this.allowedRelationship = allowedRelationship || new Array();
    this.salesDiscount = salesDiscount || new SalesDiscount();
    this.maximumNumberOfDiagnosisCodes = maximumNumberOfDiagnosisCodes || 0;
    this.planType = planType;
    this.extraChargeAddOnAmount = extraChargeAddOnAmount;
    this.usableOnTeleConsult = usableOnTeleConsult;
    this.listOnTeleConsult = listOnTeleConsult;
    this.teleConsultRemark = teleConsultRemark;
    this.externalUniquePlanCode = externalUniquePlanCode;
    this.allowSelectWithChasPlan = allowSelectWithChasPlan;
  }
}

export interface IncludedMedicalServiceScheme {
  medicalServiceItemID: string;
}

export class SalesDiscount {
  discountType?: string;
  discountValue?: number;

  constructor(discountType = '', discountValue = 0) {
    this.discountType = discountType;
    this.discountValue = discountValue;
  }
}

export class Copayment {
  value?: number;
  paymentType?: string;

  constructor(value?: number, paymentType?: string) {
    this.value = value || 0;
    this.paymentType = paymentType || '';
  }
}

export class CapPerVisit {
  visits?: number;
  limit?: number;

  constructor(visits?: number, limit?: number) {
    this.visits = visits || 0;
    this.limit = limit || 0;
  }
}

export class ContactPerson {
  name: string;
  title: string;
  directNumber: string;
  mobileNumber: string;
  faxNumber: string;
  email: string;

  constructor(
    name?: string,
    title?: string,
    directNumber?: string,
    mobileNumber?: string,
    faxNumber?: string,
    email?: string
  ) {
    this.name = name || '';
    this.title = title || '';
    this.directNumber = directNumber || '';
    this.mobileNumber = mobileNumber || '';
    this.faxNumber = faxNumber || '';
    this.email = email || '';
  }
}

export class Address {
  attentionTo: string;
  street: string;
  unit: string;
  postalCode: string;
  name: string;
  title: string;
  directNumber: string;
  mobileNumber: string;
  faxNumber: string;
  email: string;

  constructor(attentionTo?: string, street?: string, unit?: string, postalCode?: string) {
    this.attentionTo = attentionTo || '';
    this.street = street || '';
    this.unit = unit || '';
    this.postalCode = postalCode || '';
  }
}

export class MedicalCoverageExtraDetail {
  id: string;
  medicalCoverageId: string;
  tpaName: string;
  logoFileDbData: LogoFileDbData[];
  termAndCondition: string;
  isTPA: boolean;
  updateName: string;
  skipNehrSubmission: boolean;

  constructor(
    id?: string,
    medicalCoverageId?: string,
    tpaName?: string,
    logoFileDbData?: LogoFileDbData,
    isTPA?: boolean,
    updateName?: string,
    skipNehrSubmission?: boolean
  ) {
    this.id = id || '';
    this.medicalCoverageId = medicalCoverageId || '';
    this.tpaName = tpaName || '';
   // this.logoFileDbData = logoFileDbData || null;
    this.isTPA = isTPA || false;
    this.updateName = updateName || '';
    this.skipNehrSubmission = skipNehrSubmission || false;
  }
}

export class LogoFileDbData {
  base64Str: string;
  name: string;
  fileName: string;
  uploader: string;
  clinicId: string;
  type: string;
  size: string;
  description: string;
}
