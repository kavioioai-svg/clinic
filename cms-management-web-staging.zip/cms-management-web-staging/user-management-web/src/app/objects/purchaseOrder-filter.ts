import * as moment from 'moment';
import {DISPLAY_DATE_FORMAT} from '../constants/app.constants';

export class PurchaseOrderFilter {
  CREATED_DATE_MORE: string;
  CREATED_DATE_LESS: string;
  CLINIC_ID: string;
  STATUS: string;
  ORDER_REQUEST_NO: string;
  TRANSFER_PURCHASE_TYPE: OrderType;
  VENDOR_ID: string;
  ITEMREF_ID?: string;
  ORDER_IDS: string[];
  PR_NOS: string[];

  // constructor(obj?: any) {
  //   if(!obj)return
  //
  //   this.CLINIC_ID = obj.clinicId.value;
  //   this.CREATED_DATE_LESS = obj.fromDate.value ? moment(obj.fromDate.value).format(DISPLAY_DATE_FORMAT) : null;
  //   this.CREATED_DATE_MORE = obj.endDate.value ? moment(obj.endDate.value).format(DISPLAY_DATE_FORMAT) : null;
  //   this.STATUS = obj.status.value;
  //  // this.ORDER_REQUEST_NO = obj.status.value;
  //   this.TRANSFER_PURCHASE_TYPE = obj.orderType.value ;
  // }
}


export enum OrderType {
  PURCHASE_ORDER = "PURCHASE_ORDER",
  TRANSFER_ORDER = "TRANSFER_ORDER",
  ALL = "ALL",
}
