export class stockDisposalApproveRejection {
  disposeItemRefId:string;
  batchNo :string;
  clinicId :string;

    cpRemark:string;

    constructor(obj? :any , stockDisposalItems?:any) {
      this.batchNo = stockDisposalItems.batchNo ? stockDisposalItems.batchNo : null;
      this.clinicId = stockDisposalItems.clinicId ? stockDisposalItems.clinicId : null;
      this.disposeItemRefId= stockDisposalItems.disposeItemRefId;
      this.cpRemark= obj.cpRemark;
    }
}
