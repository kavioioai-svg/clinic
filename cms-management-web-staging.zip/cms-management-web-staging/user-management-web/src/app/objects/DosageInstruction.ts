export interface DosageInstruction {
  code: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE' | 'BLOCKED';
  instruct: string;
  i18Description: [{key:string, value: number}]
}

