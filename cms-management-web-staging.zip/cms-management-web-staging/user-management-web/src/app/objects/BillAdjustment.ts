export class BillAdjustmentReason {
    code: string;
    instruct: string;
    description: string;
  
    adapt(obj?): BillAdjustmentReason {
      if (!obj) {
        return this;
      }
  
      this.code = obj.code;
      this.instruct = obj.instruct;
      this.description = obj.description;
  
      return this;
    }
  }