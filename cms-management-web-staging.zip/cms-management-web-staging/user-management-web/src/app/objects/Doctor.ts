export class Doctor {
  id: string;
  name: string;
  displayName: string;
  username: string;
  mcr: string;
  nric: string;
  education: string;
  doctorGroup: string;
  speciality: string;
  status: string;
  consultationTemplates: Array<any>;
  constructor(
    id?: string,
    name?: string,
    displayName?: string,
    username?: string,
    mcr?: string,
    nric?: string,
    education?: string,
    doctorGroup?: string,
    speciality?: string,
    status?: string,
    consultationTemplates?: Array<any>
  ) {
    this.id = id || '';
    this.name = name || '';
    this.displayName = displayName || '';
    this.username = username || '';
    this.mcr = mcr || '';
    this.nric = nric || '';
    this.education = education || '';
    this.doctorGroup = doctorGroup || '';
    this.speciality = speciality || '';
    this.status = status || '';
    this.consultationTemplates = consultationTemplates || [];
  }
}
