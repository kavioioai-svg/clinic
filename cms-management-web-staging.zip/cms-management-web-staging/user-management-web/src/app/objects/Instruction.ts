interface Instruction {
  code: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE' | 'BLOCKED';
  instruct: string;
  i18nDescription: [{key:string, value: number}]
}

