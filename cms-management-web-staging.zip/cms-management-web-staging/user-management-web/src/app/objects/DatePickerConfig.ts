export default class DatePickerConfig {
  label: string;
  maxDate: Date;
  minDate: Date;
  datePickerPlacement: any;
  labelPlacement: string;
  placeholder: string;
  dateInputFormat?: string;

  constructor(
    label?: string,
    maxDate?: Date,
    minDate?: Date,
    datePickerPlacement?: string,
    labelPlacement?: string,
    placeholder?: string,
    dateInputFormat?: string
  ) {
    this.label = label || '';
    this.maxDate = maxDate || null;
    this.minDate = minDate || null;
    this.datePickerPlacement = datePickerPlacement || 'bottom';
    this.labelPlacement = labelPlacement || 'left';
    this.placeholder = placeholder || '';
    this.dateInputFormat = dateInputFormat || '';
  }
}
