import { StockTakeApproveStatus } from './StockTakeApproveStatus';
import { Validators } from '@angular/forms';
import * as moment from 'moment';
import { DISPLAY_DATE_FORMAT } from '../constants/app.constants';

export class SyncQueue {
  id: string;
  serviceKey: string;
  recordStatus: string;
  navResponse: string;
  sentOn: string;
  statusCssClass: string;
  referenceNo: string;
  sentOnStr: string;
  isLoading: boolean;

  constructor(obj?: any) {
    if (!obj) return this;

    this.id = obj.id;
    this.serviceKey = obj.serviceName;
    this.recordStatus = obj.recordStatus;
    this.navResponse = obj.navResponse;
    this.sentOn = obj.sentOn;
    this.isLoading = false;
    this.statusCssClass = this.updateStatusLabelAndCssClass(obj.recordStatus);
    this.referenceNo = obj.referenceNo;
    this.sentOnStr = obj.sentOnStr;
  }

  updateStatusLabelAndCssClass(status) {
    switch (status) {
      case SyncQueueStatus.QUEUED:
        return `bg-orangey-yellow`;
      case SyncQueueStatus.FIRED:
        return `bg-lipstick`;
      case SyncQueueStatus.SUCCESS:
        return `bg-bluish-green`;
      case SyncQueueStatus.FAILED:
        return `bg-black`;
      default:
        return '';
    }
  }
}

export enum SyncQueueStatus {
  QUEUED = 'QUEUED',
  FIRED = 'FIRED',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
}

export enum SyncQueueServiceKey {
  GOOD_RECEIVED_NOTE = 'GOOD_RECEIVED_NOTE',
  PURCHASE_RETURN_ORDER = 'PURCHASE_RETURN_ORDER',
  TRANSFER_SHIPMENT = 'TRANSFER_SHIPMENT',
  TRANSFER_RECEIPT = 'TRANSFER_RECEIPT',
  STOCK_TAKE = 'STOCK_TAKE',
  STOCK_ADJUSTMENT = 'STOCK_ADJUSTMENT',
  SALES_ORDER_SAVE = 'SALES_ORDER_SAVE',
  SALES_ORDER_UPDATE = 'SALES_ORDER_UPDATE',
  SALES_ORDER_CORRECTION = 'SALES_ORDER_CORRECTION',
  SALES_ORDER_REFUND = 'SALES_ORDER_REFUND',
  CLAIMS = 'CLAIMS',
}

export class SyncQueueFilter {
  referenceNo: string;
  sentOnStart: string;
  sentOnEnd: string;
  serviceName: string;
  status: string;

  constructor(obj?: any) {
    if (!obj) {
      return;
    }

    this.referenceNo = obj.referenceNo.value;
    this.sentOnStart = moment(obj.sentOnStart.value).format(DISPLAY_DATE_FORMAT);
    this.sentOnEnd = moment(obj.sentOnEnd.value).format(DISPLAY_DATE_FORMAT);
    this.serviceName = obj.serviceName.value;
    this.status = obj.status.value;
    this.status = obj.status.value === 'ALL' || !obj.status.value ? '' : obj.status.value;
  }
}
