export interface StoreStatus {
  isReseting: boolean;
  isLoaded: boolean;
  hasError: boolean;
}
