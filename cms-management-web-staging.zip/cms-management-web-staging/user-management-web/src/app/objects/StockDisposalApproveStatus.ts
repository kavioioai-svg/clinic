export enum StockDisposalApproveStatus {
  REQUESTED = 'REQUESTED',
  COMPLETED = 'COMPLETED',
}
