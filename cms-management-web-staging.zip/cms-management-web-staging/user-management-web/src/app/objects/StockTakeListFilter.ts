export class StockTakeListFilter {
  itemRefId?: string;
  stockTakeKeyword?: string;
  itemCode?: string;
  itemName?: string;
  approveStatus?: any;
  stockTakeStatus?: any;
  status?: any;
  clinicIds: string[];
  startDateFrom: string;
  startDateTo: string;
}
