export class UomMatrix {
  id?:string;
  uomCode: string;
  status: string;
  exchangeRatio: {[k: string]: number};

  constructor(obj?: any) {
    if (!obj){
      return
    }
    this.id = obj.id;
    this.status = obj.status;
    this.exchangeRatio = obj.exchangeRatio;
    if(obj.uomCode.label) {
      this.uomCode = obj.uomCode.label.toUpperCase();
    } else {
      this.uomCode = obj.uomCode;
    }
  }
}
