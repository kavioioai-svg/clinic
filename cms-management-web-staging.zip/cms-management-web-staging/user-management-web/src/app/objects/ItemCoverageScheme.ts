/*
private String itemId;
    private ChargeBigDeci price; = {
private BigDecimal price;

	private boolean taxIncluded;
    }
 */
export class ItemCoverageScheme {
    itemId: string;
    price: {
      price: number;
      taxIncluded?: boolean;
    };
}
