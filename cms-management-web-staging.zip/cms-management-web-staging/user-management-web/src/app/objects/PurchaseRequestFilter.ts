import * as moment from 'moment';
import {Page} from '../model/page';

export class PurchaseRequestFilter {
    requestNo?: string;
    requestType?: string;
    requestStatus?: string;
 //   userName: string;
    fromDate?: string;
    toDate?: string;
    requiredBeforeDateStart?: string;
    requiredBeforeDateEnd?: string;
    sortBy?: string;
    sortOrder?: string;
    supplierId?: string;
    pageNo?: number;
    pageSize?: number;
    itemId?: string
    requestClinicId?:string;
    requestIds?: any[];

   constructor(obj?: any, page?: Page) {
     if(!obj) {
       return
     }
     this.fromDate = obj.fromDate ? String(moment(obj.fromDate).format('YYYY-MM-DD')) : null;
     this.toDate = obj.toDate ? String(moment(obj.toDate).format('YYYY-MM-DD')) : null;
     this.itemId = obj.itemId ? obj.itemId : null;
     this.supplierId = obj.supplierId ? obj.supplierId : null;
     this.sortBy = obj.sortBy ? obj.sortBy : null;
     this.sortOrder = obj.sortOrder ? obj.sortOrder : null;
     this.requestClinicId = obj.requestClinicId ? obj.requestClinicId : null;
     this.pageNo = page.pageNumber;
     this.pageSize = page.size;
     this.requestStatus = obj.requestStatus &&  obj.requestStatus != 'ALL' ? obj.requestStatus : null;
   }
}
//credit@card.sampath.lk
// 0115600600
