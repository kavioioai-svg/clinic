export const TransactionTypes =
[
    {name :'Purchase Requisition', code : 'PR'}, 
    {name :'Purchase Order', code : 'PO'}, 
    {name :'Transfer order Outgoing', code : 'TO_OUTGOING'}, 
    {name :'Transfer order Incoming', code : 'TO_INCOMING'}];