export class InvoiceFilter {
  startDate: string;
  endDate: string;
  clinicId: string;
  medicalCoverageType: string;
  status:  'INITIAL' | 'INVOICED' | 'PARTIALLY_PAID'| 'PAID';
  statuses:  'INITIAL' | 'INVOICED' | 'PARTIALLY_PAID'| 'PAID'[];
  sortBy: string;
  sortOrder: 'ASC' | 'DESC';
  private invoiceNos: any;
  private type: any;
  payerId:string;

  constructor(obj?: any, sortEvent?: any, type?: any) {
    if(!obj){
      return
    }
    this.startDate = obj.startDate;
    this.endDate = obj.endDate;
    this.medicalCoverageType = obj.medicalCoverageType;
    this.invoiceNos = obj.invoiceNos;
    this.payerId =obj.payerId;
    if (obj.invoiceNumber) {
      this.invoiceNos = this.invoiceNos || []
      this.invoiceNos = obj.invoiceNumber.split(',')
    }
    if(type =='generated') {
      this.statuses = obj.status === 'ALL' ? [] : [obj.status];
    } else {
      this.status = obj.status === 'ALL' ? null : obj.status;
      this.clinicId = obj.clinicId;
    }
    if (sortEvent) {
      this.sortBy = sortEvent.column && sortEvent.column.prop;
      this.sortOrder = sortEvent.newValue === 'asc' ? 'ASC' : 'DESC';
    }
  }
}
