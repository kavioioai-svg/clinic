import {PaymentRef} from './payment-ref';
import {InvoiceRef} from './invoice-ref';


export class GeneratedInvoice {

  id: string;
  date: string;
  invoicesData: any[];
  payments: PaymentRef[];
  status:  'INITIAL' | 'INVOICED' | 'PARTIALLY_PAID'| 'PAID';
  createDate: string;
  invoicedDate: string;
  medicalCoverageId: string;
  planId:string;
  invoiceNumber: string;
  medicalCoverageType: string;
  medicalCoverage: any;
  amount:number;
  tax: number;
  taxPercentage: number;
  email:string;
  receivedAmount:number;
}
