

export class Invoice {
  visitId: string;
  invoiceNumber: number;
  invoiceType: string;
  paymentInfos: any;
  invoiceTime: string;
  paidTime: string;
  payableAmount: number;
  paidAmount: number;
  taxAmount: number;
  cashAdjustmentRounding: number;
  planId: string;
  planName: string;
  invoiceState: string;
  reasonForDelete: string;
  claim: string;
  discount: string;
  visitAmount: string;
  salesOrderId: string;
  clinicGroupLegalName:string;


  constructor(obj?: any) {
    if(!obj) {
      return
    }
  }

  // @ts-ignore // @ts-ignore
}
