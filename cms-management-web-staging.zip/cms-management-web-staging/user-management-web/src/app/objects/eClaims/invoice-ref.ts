

export class InvoiceRef{
  salesOrderId: string;
  invoiceNo: string;
}
