export class PaymentRef{
  id:string;
  paymentDate:string;
  paymentType:string;
  bankDetails: any;
  referenceOfPayment:string;
  description :string;
  remark :string;
  amount: number;
  adminFee: number;
  chequeNo: string;
  trxNumber: string;
}
