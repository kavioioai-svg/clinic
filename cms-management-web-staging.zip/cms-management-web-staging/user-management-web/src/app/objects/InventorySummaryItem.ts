export class InventorySummaryItem {
  supplierId: string;
  supplierName: string;
  minimumPurchaseAmount: number;
  purchasedAmount: number;
  reachMinimum: boolean;
  variance: string;

  constructor(
   supplier?: any,
   total?: number,
   minPurchaseAmount?: any,
  ) {
    if(!supplier) {
      return
    }
    this.supplierId = supplier.id;
    this.supplierName = supplier.name;
    this.minimumPurchaseAmount = minPurchaseAmount.minPurchaseAmount;
    this.purchasedAmount = total;

    this.reachMinimum = this.purchasedAmount >= minPurchaseAmount.minPurchaseAmount;
    this.variance = !this.reachMinimum
      ? `$${(Math.abs(( minPurchaseAmount.minPurchaseAmount - total)) / 100).toFixed(2)}`
      : '';
  }
}
