export interface InventoryInfo {
  code: string;
  description: string;
  instruct: string;
  billAdjustmentIdentifier: any
}

export function createInventoryInfo({
  code = '',
  description = '',
  instruct = '',
  billAdjustmentIdentifier = false,
} = {}) {
  return {
    code,
    description,
    instruct,
    billAdjustmentIdentifier,
  } as InventoryInfo;
}
