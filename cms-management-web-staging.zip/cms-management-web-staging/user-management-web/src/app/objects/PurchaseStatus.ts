export const PurchaseStatus =
[
    {name :'Initial', code : 'INITIAL'}, 
    {name :'Partial Received', code : 'PARTIAL_RECEIVED'}, 
    {name :'Full Received', code : 'FULL_RECEIVED'}, 
    {name :'Rejected', code : 'REJECTED'}, 
    {name :'Deleted', code : 'DELETED'}, 
    {name :'Draft', code : 'DRAFT'}, 
    {name :'Requested', code : 'REQUESTED'}, 
    {name :'Approved', code : 'APPROVED'}, 
    {name :'Partial Approved', code : 'PARTIAL_APPROVED'}, 
    {name :'Rejected', code : 'REJECTED'}, 
    {name :'Submitted', code : 'SUBMITTED'}, 
    {name :'Pending', code : 'PENDING'}, 
    {name :'Failed', code : 'FAILED'}];