
export class PurchaseRequestItem {
  requestItems: any;
  constructor(obj?: any) {
    if(!obj) return;
    this.requestItems= [];
    obj.requestItems.forEach(r => {
      this.requestItems.push(new Item(r , obj))
    });
    return this.requestItems;

  }
}

export class Item {
  approvedQuantity: number;
  approvedUom: string;
  itemRefId: string;
  quantity: number;
  requestItemStatus: string;
  supplierId: string;
  unitPrice: any
  uom: string;
  requestData: Request;

  constructor(obj?: any , item?: any) {
    if(!obj) return;
    this.approvedQuantity = obj.approvedQuantity;
    this.approvedUom = obj.approvedUom;
    this.itemRefId = obj.itemRefId;
    this.quantity = obj.quantity;
    this.requestItemStatus = obj.requestItemStatus;
    this.supplierId = obj.supplierId;
    this.unitPrice = obj.unitPrice
    this.uom = obj.uom
    this.requestData = new Request(item);

  }
}

export  class Request {
  createDate: string;
  createdDate: string;
  id: string;
  justificationForPurchase: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
  requestClinicId:string;
  requestDate:string;
  requestNo: string;
  requestStatus: string;
  requestType: string;
  requiredBeforeDate: string;
  userName: string;
  constructor(item?: any) {
    if (!item) return;

    this.createDate = item.createDate;
    this.createdDate = item.createdDate;
    this.id = item.id;
    this.justificationForPurchase = item.justificationForPurchase;
    this.lastModifiedBy = item.lastModifiedBy;
    this.lastModifiedDate = item.lastModifiedDate;
    this.requestClinicId = item.requestClinicId;
    this.requestDate = item.requestDate;
    this.requestNo = item.requestNo;
    this.requestStatus = item.requestStatus;
    this.requestType = item.requestType;
    this.requiredBeforeDate = item.requiredBeforeDate;
    this.userName = item.userName;
  }
}
