export interface RouteOfAdministration {
  name: string;
  nehrCodeDispensedMed: string;
  nehrCodeVaccine: string;
  bodySiteRequired: boolean;
  i18nDescription: [{key:string, value: number}]
}
