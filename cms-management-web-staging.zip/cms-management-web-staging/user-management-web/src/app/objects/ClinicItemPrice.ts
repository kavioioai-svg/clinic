
export class ClinicItemPrice {
    itemRefId: string;
    price: number;
}
