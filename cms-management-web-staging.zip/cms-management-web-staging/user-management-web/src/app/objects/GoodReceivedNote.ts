export interface GoodReceivedNote {
	id: string;
	grnDate: string;
	createDate: string;
	delivererId: string;
	receiverId: string;
	grnNo: string;
	receivedItems: GoodReceivedNoteReceivedItems[];
	status: 'DRAFT' | 'CONFIRM' | 'CANCEL' | 'FAILED';
	fileMetaData: any[];
	navIntegrationResult: GoodReceivedNoteNavIntegrationResult;
	userId: string;
	dnDate: string;
	dnNo: string;
  additionalRemark: string;
}
export interface GoodReceivedNoteReceivedItems {
	lineNo: string;
	itemRefId: string;
	uom: string;
	batchNumber: string;
	quantity: number;
	receiptDate: string;
	expiryDate: string;
  comment?: string;
}
export interface GoodReceivedNoteNavIntegrationResult {
	status: string;
}
