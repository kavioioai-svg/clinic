

export class BillAdjustmentLatest {
  caseId: string;
  caseNumber: string;
  caseDate: string;
  patientId: string;
  patientName: string;
  patientIdNumber: string;
  soId: string;
  billAdjId: string;
  billAdjStatus: string;
  billAdjDate: string;
  billAdjCreatedBy: string;
  purchaseItemsAdj: PurchaseItemsAdj[]
  packageAdjEntities: PackageAdjEntities[];
  invoiceAdjEntities: InvoiceAdjEntities[];
  primaryDoctorId: string;
  totalDiscount: number;

  constructor(obj?: any ) {
    if(!obj){
      return
    }

    this.caseId = obj.caseId;
    this.caseNumber = obj.caseNumber;
    this.caseDate = obj.caseDate;
    this.patientId = obj.patientId;
    this.patientName = obj.patientName;
    this.patientIdNumber = obj.patientIdNumber;
    this.soId = obj.soId ;
    this.billAdjId = obj.billAdjId;
    this.billAdjStatus = obj.billAdjStatus;
    this.billAdjDate = obj.billAdjDate;
    this.billAdjCreatedBy = obj.billAdjCreatedBy;
    this.purchaseItemsAdj = [];
    this.invoiceAdjEntities = [];
    this.primaryDoctorId = obj.primaryDoctorId;
    this.totalDiscount = obj.totalDiscount;

    if(obj.purchaseItemsAdj.length > 0) {
      obj.purchaseItemsAdj.forEach(purchaseItem => {
        obj.purchaseItemsAdj.push(new PurchaseItemsAdj(purchaseItem));
      })
    }
    if(obj.invoiceAdjEntities.length > 0) {
      obj.invoiceAdjEntities.forEach(purchaseItem => {
        obj.invoiceAdjEntities.push(new InvoiceAdjEntities(purchaseItem));
      })
    }


  }
}


export class  PurchaseItemsAdj {
  itemRefId: string;
  soldPrice: number;
  purchaseQty: number;
  dispenseQty: number;
  salesItemId: string;
  itemCode: string;
  itemName: string;
  salesUom: string;

  constructor(obj?: any)
  {
    if(!obj ){
      return
    }

    Object.assign(this, obj);
    this.soldPrice = obj.soldPrice > 0 ? obj.soldPrice * 100 : 0;
  }
}

class PackageAdjEntities{

}

export class InvoiceAdjEntities {
  visitId: string;
  invoiceId: string;
  paymentInfos: PaymentInfos[];
  payableAmount: number;
  paidAmount: number;
  planId: string;
  coverageCode: string;
  coverageName: string;
  planCode: string;
  planName: string;

  constructor(obj?: any) {
    if(!obj) {
      return
    }
    Object.assign(this, obj);
    this.paidAmount = obj.paidAmount > 0 ? obj.paidAmount * 100 : 0;
    this.paymentInfos = obj.paymentInfos.map(a => {
      a.amount = parseFloat(a.amount) * 100
      return a
    })
  }
}

class PaymentInfos{
  billTransactionId: string;
  billMode: string;
  amount: number;
  invoiceNumber: string;
}
