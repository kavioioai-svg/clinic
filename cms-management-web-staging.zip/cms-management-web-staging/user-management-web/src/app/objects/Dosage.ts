export class Dosage {
  id?: string;
  name?: string;
  status?: string;
  description?: string;
  recommendedAge?: string;
  intervalToNextDoseInDays?: string;
  doseId?: string;

}
