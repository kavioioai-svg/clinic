export class ItemFilter {
  code: string;
  name: string;
  category: string;
  type: string;
  status: string;
  withBrokenUomMatrix: boolean;
  withBrokenIntegration: boolean;
  sort?:{
    dir: string;
    prop: string;
  }
}
