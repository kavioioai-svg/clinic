export class SearchParams {
  itemGroup: string;
  clinicId: string;
  startDate: string;
  endDate: string;
  clinicGroupId: string;
}
