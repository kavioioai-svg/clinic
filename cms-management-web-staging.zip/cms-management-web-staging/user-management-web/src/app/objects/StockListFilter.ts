export class StockListFilter {
  STOCK_ALERT: string;
  SUPPLIER_NAME_REGEX: string;
  ITEM_NAME_REGEX: string;
  ITEM_CODE_REGEX: string;
}
