import {StockTakeApproveStatus} from './StockTakeApproveStatus';

export class StockAdjustmentListFilter {
  itemName: string;
  itemCode: string;
  approveStatus: any;
  clinicIds: string[];
 // CLINIC_GROUP: string;
  startDateFrom: string;
  startDateTo: string;
}
