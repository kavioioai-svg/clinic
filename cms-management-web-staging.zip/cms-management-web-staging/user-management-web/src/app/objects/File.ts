export class UploadFile {
  id?: string;
  fileName?: string;
  size?: number;
  type?: string;
  base64Str?: string;
  newIndex?: any;

  constructor(obj?: any) {
    if(!obj){
     return
    }
    this.id = obj.id;
    this.fileName = obj.fileName;
    this.size= obj.size;
    this.type= obj.type;
    this.base64Str= obj.base64Str;
  }
}
