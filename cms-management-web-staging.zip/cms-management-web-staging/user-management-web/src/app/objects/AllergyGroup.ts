import { Drug } from "./request/Drug";

export class AllergyGroup {
  id: string;
  groupCode: string;
  description: string;
  drugIds: Array<Drug>;
  drugNameList?: any;
  drugName?: any;
  status: "ACTIVE" | "INACTIVE" | "BLOCKED";
  isFoodAllergy: boolean;

}
