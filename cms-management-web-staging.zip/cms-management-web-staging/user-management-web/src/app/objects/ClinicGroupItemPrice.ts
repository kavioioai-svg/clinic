
export class ClinicGroupItemPrice {
    itemRefId: string;
    price: number;
}
