class PriceItemSearchRequest {
  itemRefId: string
  clinicId: string
  groupName: string
  planId: string
  page: number
  size: number
}
