
export class CorporateAddress {
  attentionTo?: string;
  address?: string;
  postalCode?: string;
}
