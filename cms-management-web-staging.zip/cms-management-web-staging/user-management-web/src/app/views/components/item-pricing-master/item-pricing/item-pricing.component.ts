import { Component, Input, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {Drug} from "../../../../objects/request/Drug";
import {ItemService} from "../../../../services/item.service";
import {ClinicQuery} from "../../../../state/clinic/clinic.query";
import {MedicalCoverageQuery} from "../../../../state/medical-coverage/medical-coverage.query";
import {StoreStatusQuery} from "../../../../state/store-status/store-status.query";
import {ItemPricingMasterService} from "../../../../services/master-data-service/item-pricing-master.service";
import {Page} from "../../../../model/page";
import {BsModalService} from "ngx-bootstrap";
import {ClinicItemMasterFormComponent} from "./clinic-item-master-form/clinic-item-master-form.component";
import {
  ClinicGroupItemMasterFormComponent
} from "./clinic-group-item-master-form/clinic-group-item-master-form.component";
import {
  MedicalCoverageItemMasterFormComponent
} from "./medical-coverage-item-master-form/medical-coverage-item-master-form.component";
import {AlertService} from "../../../../services/alert.service";
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-item-pricing',
  templateUrl: './item-pricing.component.html',
  styleUrls: ['./item-pricing.component.scss']
})
export class ItemPricingComponent implements OnInit {
  @Input() isCurrentItem : boolean;
  currentItemRefId = this.itemService.getCurrentDrugItemId();
  searchFrm: FormGroup;
  drugList: Array<Drug> = [];
  types: any[];
  clinics: any[];
  clinicGroups: any;
  private groupedClinics: any;
  medicalCoverages: any;
  plansMap: any;
  searchType: any;
  isLoading: boolean;
  list: any[];
  page: Page = new Page(0, 10);
  private items: any;
  private items2: any;
  plans: any[] = [];
  ngSelectValue = [];
  actionButtonList = [
    {
      action:'view',
      label:'View'
    },
    {
      action:'edit',
      label:'Edit'
    },
    {
      action:'delete',
      label:'Delete'
    }
  ];

  constructor(
    private itemService: ItemService,
    private fb: FormBuilder,
    private clinicQuery: ClinicQuery,
    private medicalCoverageQuery: MedicalCoverageQuery,
    private storeStatusQuery: StoreStatusQuery,
    private itemPricingMasterService: ItemPricingMasterService,
    private modalService: BsModalService,
    private alertService: AlertService
  ) {

  }

  ngOnInit() {
    this.searchFrm = this.fb.group({
      itemRefId: [],
      type: [],
      clinicId: [],
      groupName: [],
      planId: [],
      medicalCoverage: []
    })
    if(this.isCurrentItem){
      this.searchFrm.value.itemRefId = this.currentItemRefId;
    }
    
    this.types = filterOptionsJson.itemPricingSearchType
    this.loadDrug()
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll();
        this.groupClinics()
        this.medicalCoverages = this.medicalCoverageQuery.getAll()
        let planMap = {}
        this.medicalCoverages.forEach((medicalCoverage) => {
          medicalCoverage.coveragePlans.forEach((plan) => {
            planMap[plan.id] = {
              id: plan.id,
              name: plan.name,
              medicalCoverage: medicalCoverage.name,
              label: `${plan.name} (${medicalCoverage.name})`
            }
          })
        })
        this.plansMap = planMap
      })

    this.searchFrm.valueChanges.subscribe(e => {
      this.searchType = e.type
    })
    this.refreshList()
    this.searchFrm.get('medicalCoverage').valueChanges.subscribe(e => {
      let medicalCoverageItem = this.medicalCoverages.find(value => value.id === e);
      this.plans = medicalCoverageItem ? medicalCoverageItem.coveragePlans : [];
      if (this.plans[0]) {
        this.searchFrm.patchValue({
          planId: this.plans[0].planId
        })
      }
    })
  }

  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }

  loadDrug() {
    this.itemService.listAllItems().subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.drugList = res.payload.map((item) => item.item);
          // @ts-ignore
          this.items = Object.fromEntries(res.payload.map((item) => [item.item.id, item.item.code]))

          // @ts-ignore
          this.items2 = Object.fromEntries(res.payload.map((item) => [item.item.id, item.item.name]))
          this.refreshList()
        }
      },
      (err) => {
      }
    );
  }

  onSubmitSearch() {
    this.itemPricingMasterService.search({
      ...this.searchFrm.value,
      page: 0,
      size: 10
    }).subscribe(value => {
      this.list = value.payload.content;
      this.page.pageNumber = value.payload.number
      this.page.totalPages = value.payload.totalPages
      this.page.totalElements = value.payload.totalElements
      this.page.limit = value.payload.limit
      this.page.size = value.payload.size
    })
  }

  addNewItem(menu: any) {
    switch (menu.value) {
      case "CLINIC":
        this.addNewClinicItem()
        break;
      case "CLINIC_GROUP":
        this.addNewClinicGroupItem()
        break;
      case "PLAN":
        this.addNewPlanItem()
        break;
    }
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset
    this.refreshList();
  }

  private refreshList() {
    if(this.isCurrentItem){
      this.searchFrm.value.itemRefId = this.currentItemRefId;
    }
    this.itemPricingMasterService.search({
      ...this.searchFrm.value,
      page: this.page.pageNumber,
      size: this.page.size
    }).subscribe(value => {
      this.list = value.payload.content;
      this.page.pageNumber = value.payload.number
      this.page.totalPages = value.payload.totalPages
      this.page.totalElements = value.payload.totalElements
      this.page.limit = value.payload.limit
      this.page.size = value.payload.size
    })
  }

  resolveItemId(itemRefId: any) {
    if (!this.items) return itemRefId
    // @ts-ignore
    return this.items[itemRefId] || itemRefId
  }
  resolveItemName(itemRefId: any) {
    if (!this.items2) return itemRefId
    // @ts-ignore
    return this.items2[itemRefId] || itemRefId
  }

  resolveClinicCode(clinicId: any) {
    if (!this.clinics) return clinicId
    // @ts-ignore
    let clinic = this.clinics.find(value => value.id === clinicId);
    return (clinic ? clinic.clinicCode : clinicId) || clinicId
  }

  resolvePlan(planId: any) {
    let planData = this.plansMap[planId];
    return planData ? planData.name : ''
  }

  resolveMedicalCoverage(planId: any) {
    let planData = this.plansMap[planId];
    return planData ? planData.medicalCoverage : ''
  }

  private addNewClinicItem() {
    let ref = this.modalService.show(ClinicItemMasterFormComponent, {
      initialState: {
        method: 'CREATE',
        isDisableItem: this.isCurrentItem,
        itemRefId: this.currentItemRefId,
        onClose: (status) => {
          if (!!status) {
            if (status === 'S0000') {
              this.alertService.success('Create clinic item successfully')
            } else {
              this.alertService.error('Create clinic item failed')
            }
          }
          this.refreshList()
          ref.hide()
        }
      },
      class: 'modal-lg item-master-select-popup'
    });
  }

  private addNewClinicGroupItem() {
    let ref = this.modalService.show(ClinicGroupItemMasterFormComponent, {
      initialState: {
        method: 'CREATE',
        isDisableItem: this.isCurrentItem,
        itemRefId: this.currentItemRefId,
        onClose: (status) => {
          if (!!status) {
            if (status === 'S0000') {
              this.alertService.success('Create clinic group item successfully')
            } else {
              this.alertService.error('Create clinic group item failed')
            }
          }
          this.refreshList()
          ref.hide()
        }
      },
      class: 'modal-lg item-master-select-popup'
    });
  }

  private addNewPlanItem() {
    let ref = this.modalService.show(MedicalCoverageItemMasterFormComponent, {
      initialState: {
        method: 'CREATE',
        isDisableItem: this.isCurrentItem,
        itemRefId: this.currentItemRefId,
        onClose: (status) => {
          if (!!status) {
            if (status === 'S0000') {
              this.alertService.success('Create plan item successfully')
            } else {
              this.alertService.error('Create plan item failed')
            }
          }
          this.refreshList()
          ref.hide()
        }
      },
      class: 'modal-lg item-master-select-popup'
    });
  }

  onActionChange($event: string, row: any, rowIndex: number) {
    switch ($event) {
      case "edit":
        this.editItem(row)
        break;
      case "view":
        this.viewItem(row)
        break;
      case "delete":
        this.deleteItem(row)
    }
    this.ngSelectValue[rowIndex] = null;
  }

  private editItem(row: any) {
    if (row.clinicId) {
      let ref = this.modalService.show(ClinicItemMasterFormComponent, {
        initialState: {
          method: 'UPDATE',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: (status) => {
            if (!!status) {
              if (status === "S0000") {
                this.alertService.success("Pricing item updated successfully")
              } else {
                this.alertService.error("Error updating Pricing item")
              }
            }
            this.refreshList();
            ref.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    } else if (row.groupName) {
      let ref1 = this.modalService.show(ClinicGroupItemMasterFormComponent, {
        initialState: {
          method: 'UPDATE',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: (status) => {
            if (!!status) {
              if (status === "S0000") {
                this.alertService.success("Pricing item updated successfully")
              } else {
                this.alertService.error("Error updating Pricing item")
              }
            }
            this.refreshList();
            ref1.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    } else if (row.planId) {
      let ref2 = this.modalService.show(MedicalCoverageItemMasterFormComponent, {
        initialState: {
          method: 'UPDATE',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: (status) => {
            if (!!status) {
              if (status === "S0000") {
                this.alertService.success("Pricing item updated successfully")
              } else {
                this.alertService.error("Error updating Pricing item")
              }
            }
            this.refreshList();
            ref2.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    }
  }

  private viewItem(row: any) {
    if (row.clinicId) {
      let ref = this.modalService.show(ClinicItemMasterFormComponent, {
        initialState: {
          method: 'VIEW',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: () => {
            ref.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    } else if (row.groupName) {
      let ref1 = this.modalService.show(ClinicGroupItemMasterFormComponent, {
        initialState: {
          method: 'VIEW',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: () => {
            ref1.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    } else if (row.planId) {
      let ref2 = this.modalService.show(MedicalCoverageItemMasterFormComponent, {
        initialState: {
          method: 'VIEW',
          clinicId: row.clinicId,
          groupName: row.groupName,
          planId: row.planId,
          itemRefId: row.itemRefId,
          onClose: () => {
            ref2.hide()
          }
        },
        class: 'modal-lg item-master-select-popup'
      });
    }
  }

  private deleteItem(row: any) {
    if (row.clinicId) {
      this.itemPricingMasterService.deleteSingleClinicItem(row.clinicId, row).subscribe(value => {
        this.alertService.success('Item deleted successfully')
        this.refreshList()
      })
    } else if (row.groupName) {
      this.itemPricingMasterService.deleteSingleClinicGroupItem(row.groupName, row).subscribe(value => {
        this.alertService.success('Item deleted successfully')
        this.refreshList()
      })
    } else if (row.planId) {
      this.itemPricingMasterService.deleteSingleMedicalCoverageItem(row.planId, {
        itemId: row.itemRefId,
        price: {
          price: row.price,
          taxIncluded: false
        }
      }).subscribe(value => {
        this.alertService.success('Item deleted successfully')
        this.refreshList()
      })
    }
  }

  convertPrice(price: number) {
    return "" + price * 100
  }

  resolveType(row: any) {
    return row.clinicId ? 'Clinic' : row.groupName ? 'Clinic Group' : 'Medical Coverage'
  }
}
