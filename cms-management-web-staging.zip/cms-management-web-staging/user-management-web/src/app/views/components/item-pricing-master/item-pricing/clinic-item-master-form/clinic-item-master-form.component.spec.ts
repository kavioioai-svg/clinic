import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicItemMasterFormComponent } from './clinic-item-master-form.component';

describe('ClinicItemMasterFormComponent', () => {
  let component: ClinicItemMasterFormComponent;
  let fixture: ComponentFixture<ClinicItemMasterFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClinicItemMasterFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicItemMasterFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
