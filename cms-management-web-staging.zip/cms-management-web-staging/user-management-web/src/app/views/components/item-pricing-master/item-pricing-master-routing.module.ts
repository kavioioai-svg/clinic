import {NgModule} from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {ItemPricingComponent} from "./item-pricing/item-pricing.component";

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Item Pricing'
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'master' },
      { path: 'master', component: ItemPricingComponent},
    ]
  }
]

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ItemPricingMasterRoutingModule { }
