import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { ItemPricingComponent } from './item-pricing/item-pricing.component';
import {SharedModule} from "../../../shared.module";
import {ItemPricingMasterRoutingModule} from "./item-pricing-master-routing.module";
// import { ClinicItemMasterFormComponent } from './item-pricing/clinic-item-master-form/clinic-item-master-form.component';
// import { MedicalCoverageItemMasterFormComponent } from './item-pricing/medical-coverage-item-master-form/medical-coverage-item-master-form.component';
// import {
//   ClinicGroupItemMasterFormComponent
// } from "./item-pricing/clinic-group-item-master-form/clinic-group-item-master-form.component";

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SharedModule,
    ItemPricingMasterRoutingModule
  ],
  entryComponents: [
    // ClinicItemMasterFormComponent,
    // ClinicGroupItemMasterFormComponent,
    // MedicalCoverageItemMasterFormComponent
  ]
})
export class ItemPricingMasterModule { }
