import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Drug} from "../../../../../objects/request/Drug";
import {ItemService} from "../../../../../services/item.service";
import {MedicalCoverageQuery} from "../../../../../state/medical-coverage/medical-coverage.query";
import {StoreStatusQuery} from "../../../../../state/store-status/store-status.query";
import {ItemPricingMasterService} from "../../../../../services/master-data-service/item-pricing-master.service";
import {combineLatest} from "rxjs-compat/operator/combineLatest";
import {AlertService} from "../../../../../services/alert.service";

@Component({
  selector: 'app-medical-coverage-item-master-form',
  templateUrl: './medical-coverage-item-master-form.component.html',
  styleUrls: ['./medical-coverage-item-master-form.component.scss']
})
export class MedicalCoverageItemMasterFormComponent implements OnInit {
  formGroup: FormGroup;
  drugList: Array<Drug> = [];
  medicalCoverages: any;
  plans: any;
  @Input() method: 'CREATE' | 'UPDATE' | 'VIEW'
  @Input() itemRefId: string | undefined
  @Input() planId: string | undefined
  @Input() onClose: (value: string) => void
  @Input() isDisableItem: boolean = false;
  isReadOnly: boolean;
  constructor(private fb: FormBuilder,
              private itemService: ItemService,
              private medicalCoverageQuery: MedicalCoverageQuery,
              private storeStatusQuery: StoreStatusQuery,
              private itemPricingMasterService: ItemPricingMasterService,
              private alertService: AlertService,
              ) { }

  ngOnInit() {
    this.formGroup = this.fb.group({
      itemRefId: [this.itemRefId ? this.itemRefId : null, Validators.required],
      medicalCoverage: [, Validators.required],
      planId: [, Validators.required],
      price: [, Validators.required]
    })
    if (this.method === 'VIEW' || this.method === 'UPDATE') {
      this.itemPricingMasterService.getSingleMedicalCoverageItem(this.itemRefId, this.planId)
        .subscribe(value => {
          this.formGroup.patchValue({
            price: value.payload.price ? value.payload.price.price : null
          })
        })
    }
    this.loadDrug();
    this.formGroup.get('medicalCoverage').valueChanges.subscribe(e => {
      let medicalCoverageItem = this.medicalCoverages.find(value => value.id === e);
      this.plans = medicalCoverageItem ? medicalCoverageItem.coveragePlans : [];
    })
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.medicalCoverages = this.medicalCoverageQuery.getAll()
        if (this.method === 'VIEW' || this.method === 'UPDATE') {
          this.medicalCoverages.forEach((medicalCoverage) => {
            medicalCoverage.coveragePlans.forEach((plan) => {
              if (plan.id === this.planId) {
                this.formGroup.patchValue({
                  medicalCoverage: medicalCoverage.id,
                  planId: plan.id
                })
              }
            })
          })
        }
      })
  }

  loadDrug() {
    this.itemService.listAllItems().subscribe(
      (res) => {
        if (res.statusCode === 'S0000') {
          this.drugList = res.payload.map((item) => item.item);
          // @ts-ignore
          this.items = Object.fromEntries(res.payload.map((item) => [item.item.id, item.item.name]))
        }
      },
      (err) => {
      }
    );
  }


  onCreate() {
    this.itemPricingMasterService.addSingleMedicalCoverageItem(this.formGroup.get("planId").value, {
      itemId: this.formGroup.get("itemRefId").value,
      price: {
        price: this.formGroup.get("price").value,
        taxIncluded: false
      }
    })
      .subscribe(value => {
        if (this.onClose)
          this.onClose(value.statusCode);
        this.formGroup.reset()
      }, error => {
        if (error && error.error) {
          this.alertService.error(error.error.message)
        }
      })
  }

  onUpdate() {
    this.itemPricingMasterService.updateSingleMedicalCoverageItem(this.formGroup.get("planId").value, {
      itemId: this.formGroup.get("itemRefId").value,
      price: {
        price: this.formGroup.get("price").value,
        taxIncluded: false
      }
    })
      .subscribe(value => {
        if (this.onClose)
          this.onClose(value.statusCode);
        this.formGroup.reset()
      }, error => {
        if (error && error.error) {
          this.alertService.error(error.error.message)
        }
      })
  }

  closeModal() {
    this.onClose(undefined)
    this.formGroup.reset()
  }
}
