import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageItemMasterFormComponent } from './medical-coverage-item-master-form.component';

describe('MedicalCoverageItemMasterFormComponent', () => {
  let component: MedicalCoverageItemMasterFormComponent;
  let fixture: ComponentFixture<MedicalCoverageItemMasterFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageItemMasterFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageItemMasterFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
