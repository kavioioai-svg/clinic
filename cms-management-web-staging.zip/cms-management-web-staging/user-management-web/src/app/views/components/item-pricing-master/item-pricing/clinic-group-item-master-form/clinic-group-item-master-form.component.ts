import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Drug} from "../../../../../objects/request/Drug";
import {ItemService} from "../../../../../services/item.service";
import {ClinicQuery} from "../../../../../state/clinic/clinic.query";
import {StoreStatusQuery} from "../../../../../state/store-status/store-status.query";
import {ClinicGroupItemPrice} from "../../../../../objects/ClinicGroupItemPrice";
import {ItemPricingMasterService} from "../../../../../services/master-data-service/item-pricing-master.service";
import {AlertService} from "../../../../../services/alert.service";

@Component({
  selector: 'app-clinic-group-item-master-form',
  templateUrl: './clinic-group-item-master-form.component.html',
  styleUrls: ['./clinic-group-item-master-form.component.scss']
})
export class ClinicGroupItemMasterFormComponent implements OnInit {
  formGroup: FormGroup;
  drugList: Array<Drug> = [];
  clinics: any;
  clinicGroups: any;
  @Input() method: 'CREATE' | 'UPDATE' | 'VIEW'
  @Input() itemRefId: string | undefined
  @Input() groupName: string | undefined
  @Input() isDisableItem: boolean = false;
  @Input() onClose?: (value: string | undefined) => void
  private groupedClinics: any;
  isReadOnly: boolean;
  constructor(
    private fb: FormBuilder,
    private itemService: ItemService,
    private clinicQuery: ClinicQuery,
    private storeStatusQuery: StoreStatusQuery,
    private itemPricingMasterService: ItemPricingMasterService,
    private alertService: AlertService,
  ) {

  }

  ngOnInit() {
    this.formGroup = this.fb.group({
      itemRefId: [this.itemRefId ? this.itemRefId : null, Validators.required],
      groupName: [this.groupName ? this.groupName : null, Validators.required],
      price: [, Validators.required]
    })

    if (this.method === 'VIEW' || this.method === 'UPDATE') {
      this.itemPricingMasterService.getSingleClinicGroupItem(this.itemRefId, this.groupName)
        .subscribe(value => {
          this.formGroup.patchValue({
            price: value.payload.price
          })
        })
    }

    this.loadDrug();
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll();
      })
    this.groupClinics()
  }

  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics).sort((a, b) => a < b ? -1 : (a > b ? 1 : 0));
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }


  loadDrug() {
    this.itemService.listAllItems().subscribe(
      (res) => {
        if (res.statusCode === 'S0000') {
          this.drugList = res.payload.map((item) => item.item);
          // @ts-ignore
          this.items = Object.fromEntries(res.payload.map((item) => [item.item.id, item.item.name]))
        }
      },
      (error) => {
        if (error && error.error) {
          this.alertService.error(error.error.message)
        }
      }
    );
  }

  onCreate() {
    this.itemPricingMasterService.addSingleClinicGroupItem(this.formGroup.get('groupName').value, {
      itemRefId: this.formGroup.get('itemRefId').value,
      price: this.formGroup.get('price').value
    }).subscribe((res) => {
      if (this.onClose)
        this.onClose(res.statusCode)
      this.formGroup.reset()
    }, error => {
      if (error && error.error) {
        this.alertService.error(error.error.message)
      }
    })
  }

  onUpdate() {
    this.itemPricingMasterService.updateSingleClinicGroupItem(this.formGroup.get('groupName').value, {
      itemRefId: this.formGroup.get('itemRefId').value,
      price: this.formGroup.get('price').value
    }).subscribe((res) => {
      if (this.onClose)
        this.onClose(res.statusCode)
      this.formGroup.reset()
    }, error => {
    })
  }

  closeModal() {
    this.onClose(undefined)
    this.formGroup.reset()
  }
}
