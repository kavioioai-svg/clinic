import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicGroupItemMasterFormComponent } from './clinic-group-item-master-form.component';

describe('ClinicGroupItemMaster.FormComponent', () => {
  let component: ClinicGroupItemMasterFormComponent;
  let fixture: ComponentFixture<ClinicGroupItemMasterFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClinicGroupItemMasterFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicGroupItemMasterFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
