import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Drug} from "../../../../../objects/request/Drug";
import {ItemService} from "../../../../../services/item.service";
import {ClinicQuery} from "../../../../../state/clinic/clinic.query";
import {MedicalCoverageQuery} from "../../../../../state/medical-coverage/medical-coverage.query";
import {StoreStatusQuery} from "../../../../../state/store-status/store-status.query";
import {ItemPricingMasterService} from "../../../../../services/master-data-service/item-pricing-master.service";
import {AlertService} from "../../../../../services/alert.service";

@Component({
  selector: 'app-clinic-item-master-form',
  templateUrl: './clinic-item-master-form.component.html',
  styleUrls: ['./clinic-item-master-form.component.scss']
})
export class ClinicItemMasterFormComponent implements OnInit {
  formGroup: FormGroup;
  drugList: Array<Drug> = [];
  clinics: any;
  @Input() method: 'CREATE' | 'UPDATE' | 'VIEW'
  @Input() itemRefId: string | undefined
  @Input() clinicId: string | undefined
  @Input() onClose?: (value: string) => void
  @Input() isDisableItem: boolean = false;
  isReadOnly: boolean;
  constructor(
    private fb: FormBuilder,
    private itemService: ItemService,
    private clinicQuery: ClinicQuery,
    private storeStatusQuery: StoreStatusQuery,
    private itemPricingMasterService: ItemPricingMasterService,
    private alertService: AlertService,
  ) {

  }

  ngOnInit() {
    this.formGroup = this.fb.group({
      itemRefId: [this.itemRefId ? this.itemRefId : null, Validators.required],
      clinicId: [this.clinicId ? this.clinicId : null, Validators.required],
      price: [, Validators.required]
    })

    if (this.method === 'VIEW' || this.method === 'UPDATE') {
      this.itemPricingMasterService.getSingleClinicItem(this.itemRefId, this.clinicId)
        .subscribe(value => {
          this.formGroup.patchValue({
            price: value.payload.price
          })
        })
    }

    this.loadDrug();
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll().sort((a, b) => (a.status < b.status ? -1 : (a.status > b.status ? 1 : 0)) ||
        (a.groupName < b.groupName ? -1 : (a.groupName > b.groupName ? 1 : 0)) || 
        (a.clinicCode < b.clinicCode ? -1 : (a.clinicCode > b.clinicCode ? 1 : 0))
        );
      })
  }

  loadDrug() {
    this.itemService.listAllItems().subscribe(
      (res) => {
        if (res.statusCode === 'S0000') {
          this.drugList = res.payload.map((item) => item.item);
          console.log(this.drugList)
          // @ts-ignore
          this.items = Object.fromEntries(res.payload.map((item) => [item.item.id, item.item.name]))
        }
      },
      (err) => {
      }
    );
  }

  onCreate() {
    this.itemPricingMasterService.addSingleClinicItem(this.formGroup.get("clinicId").value, {
      itemRefId: this.formGroup.get("itemRefId").value,
      price: this.formGroup.get("price").value
    })
      .subscribe(value => {
        if (this.onClose)
          this.onClose(value.statusCode);
        this.formGroup.reset()
      }, error => {
        if (error && error.error) {
          this.alertService.error(error.error.message)
        }
      })
  }

  onUpdate() {
    this.itemPricingMasterService.updateSingleClinicItem(this.formGroup.get("clinicId").value, {
      itemRefId: this.formGroup.get("itemRefId").value,
      price: this.formGroup.get("price").value
    })
      .subscribe(value => {
        if (this.onClose)
          this.onClose(value.statusCode);
        this.formGroup.reset()
      }, error => {
        if (error && error.error) {
          this.alertService.error(error.error.message)
        }
      })
  }

  closeModal() {
    this.onClose(undefined)
    this.formGroup.reset()
  }
}
