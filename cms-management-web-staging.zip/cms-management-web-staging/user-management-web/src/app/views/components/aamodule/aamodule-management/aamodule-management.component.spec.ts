import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AAModuleManagementComponent } from "./aamodule-management.component";
import { TestingModule } from "../../../../test/testing.module";

describe("AAModuleManagementComponent", () => {
  let component: AAModuleManagementComponent;
  let fixture: ComponentFixture<AAModuleManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      declarations: [AAModuleManagementComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AAModuleManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
