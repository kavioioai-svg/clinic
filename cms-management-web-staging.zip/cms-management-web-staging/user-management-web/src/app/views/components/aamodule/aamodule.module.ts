import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../shared.module';
import { AAModuleRoutingModule } from './aamodule-routing.module';
import { AAModuleManagementComponent } from './aamodule-management/aamodule-management.component';

@NgModule({
  imports: [CommonModule, SharedModule, AAModuleRoutingModule],
  declarations: [AAModuleManagementComponent],
})
export class AAModuleModule { }
