import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../../services/auth.service';
import { AlertService } from '../../../../services/alert.service';
import { Alert } from 'selenium-webdriver';
import { ApiAAService } from '../../../../services/api-aa';
// import { Angular5Csv } from 'angular5-csv/Angular5-csv';

@Component({
  selector: 'app-aamodule-management',
  templateUrl: './aamodule-management.component.html',
  styleUrls: ['./aamodule-management.component.scss'],
})
export class AAModuleManagementComponent implements OnInit {
  formGroup: FormGroup;
  moduleList;
  selectedModule = '';

  rows; // Items will be shown
  tempRows; // Cache the list

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private alertService: AlertService,
    private router: Router,
    private apiAAService: ApiAAService
  ) {}

  ngOnInit() {
    this.getAllModulesList();

    this.formGroup = this.fb.group({
      password: '',
      newPassword: '',
      confirmNewPassword: '',
    });

    this.moduleList = ['CMS', 'Smart Home', 'eWallet'];
  }

  getAllModulesList() {
    this.apiAAService.listModulesWithPagination().subscribe(
      (res) => {
        const newArr = res.payload.map((val, index, arr) => {
          return {
            name: val.name,
            description: val.description,
            groups: val.groups,
            status: 'N/A',
          };
        });

        this.rows = newArr;
        this.tempRows = newArr;
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }

  updateInputFilter(event) {
    const val = event.target.value.toLowerCase();

    // filter our data
    const temp = this.tempRows.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || d.description.toLowerCase().indexOf(val) !== -1 || !val;
    });

    // update the rows
    this.rows = temp;
  }

  exportCSV() {
    //   const options = {
    //     headers: ['Name', 'Description', 'Groups', 'Status']
    //   };
    //   const csvArr = this.tempRows.map((val, index, arr) => {
    //     return {
    //       name: val.name,
    //       description: val.description,
    //       groups: val.groups.map(value => value.name).toString(),
    //       status: 'N/A'
    //     };
    //   });
    //   new Angular5Csv(csvArr, 'Modules', options);
  }
}
