import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgxPermissionsGuard } from 'ngx-permissions';

import { AAModuleManagementComponent } from './aamodule-management/aamodule-management.component';

const routes: Routes = [
  {
    path: '',
    canActivateChild: [NgxPermissionsGuard],
    data: {
      title: 'AA Module',
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'all' },
      { path: 'all',
        component: AAModuleManagementComponent
      },
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AAModuleRoutingModule { }
