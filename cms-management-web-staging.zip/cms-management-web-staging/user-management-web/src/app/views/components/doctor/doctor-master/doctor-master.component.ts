import { Component, OnInit } from '@angular/core';
import { DoctorFormService } from '../doctor-form.service';
import { FormGroup, ValidatorFn, AbstractControl } from '@angular/forms';
import { Doctor } from '../../../../objects/Doctor';
import { StoreService } from '../../../../services/store.service';
import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { AlertService } from '../../../../services/alert.service';
import { User } from '../../../../objects/response/User';
import { ApiAAService } from '../../../../services/api-aa';
import { NgxPermissionsService } from 'ngx-permissions';
import { markFormGroupTouched } from '../../../../services/form.service';
import { DoctorQuery } from '../../../../state/doctor/doctor.query';
import { UserListQuery } from '../../../../state/user-list/user-list.query';

@Component({
  selector: 'app-doctor-master',
  templateUrl: './doctor-master.component.html',
  styleUrls: ['./doctor-master.component.scss'],
})
export class DoctorMasterComponent implements OnInit {
  formGroup: FormGroup;
  doctorList: Array<Doctor> = new Array();
  rows: Array<Doctor> = new Array();

  aaDoctorUser = [];

  searchFieldInput = '';
  groupFilterSelctedValue = '';
  specialityFilterSelctedValue = '';
  statusFilterSelctedValue = '';

  hasPermissionEditUserName: Boolean = false;

  constructor(
    private doctorFormService: DoctorFormService,
    private apiCmsManagementService: ApiCmsManagementService,
    private apiAAService: ApiAAService,
    private alert: AlertService,
    private store: StoreService,
    private permission: NgxPermissionsService,
    private doctorQuery: DoctorQuery,
    private userListQuery: UserListQuery
  ) {
    this.formGroup = doctorFormService.createDoctorMasterFormGroup();
    permission.hasPermission('ROLE_DOCTOR_EDIT_USER_NAME').then((role) => {
      this.hasPermissionEditUserName = role;
    });
  }

  ngOnInit() {
    this.loadDoctorList(true);
  }

  loadDoctorList(reload = false) {
    this.doctorList = [];

    if (reload) {
      this.store.retrieveDoctors();
      this.store.retrieveUsers();
    }

    this.doctorList = this.doctorQuery.getAll();
    this.updateFilterResult();
    this.loadAADoctorList();

    this.doctorQuery.selectAll().subscribe((val: Array<Doctor>) => {
      this.doctorList = val;
      this.updateFilterResult();
      this.loadAADoctorList();
    });
  }

  loadAADoctorList() {
    this.aaDoctorUser = [];

    const selectedDoctorUserNameList: Array<string> = this.doctorList.map((item) => item.username);

    this.aaDoctorUser = this.userListQuery
      .getAll()
      .filter((item) => {
        const roles: Array<string> = (item.groups as Array<any>)
          .map((group) => group.roles)
          .reduce((arr, group) => arr.concat(group), [])
          .map((group) => group.role);

        return roles.includes('ROLE_DOCTOR') && !roles.includes('ROLE_AA_ADMIN');
      })
      .map((item) => {
        return {
          userName: item.userName,
          disabled: selectedDoctorUserNameList.includes(item.userName),
        };
      });

    this.userListQuery.selectAll().subscribe((val) => {
      this.aaDoctorUser = (val as Array<any>)
        .filter((item) => {
          const roles: Array<string> = (item.groups as Array<any>)
            .map((group) => group.roles)
            .reduce((arr, group) => arr.concat(group), [])
            .map((group) => group.role);

          return roles.includes('ROLE_DOCTOR') && !roles.includes('ROLE_AA_ADMIN');
        })
        .map((item) => {
          return {
            userName: item.userName,
            disabled: selectedDoctorUserNameList.includes(item.userName),
          };
        });
    });
  }

  searchDoctor(event) {
    this.searchFieldInput = event.target.value.toLowerCase();
    this.updateFilterResult();
  }

  onEditDoctorClicked(value) {
    let newValue = Object.assign({}, value);

    if (!this.aaDoctorUser.map((item) => item.userName).includes(newValue.username)) {
      newValue.username = '';
    }

    this.formGroup = this.doctorFormService.createDoctorMasterFormGroup();
    this.formGroup.patchValue({
      ...newValue,
    });
    if (!this.hasPermissionEditUserName) {
      this.formGroup.get('username').disable();
    }

    markFormGroupTouched(this.formGroup);
    window.scrollTo(0, 0);
  }

  onCancelBtnClick() {
    this.formGroup.get('username').enable();
    this.formGroup = this.doctorFormService.createDoctorMasterFormGroup();
  }

  onBtnClick() {
    const value = Object.assign({}, this.formGroup.getRawValue());
    delete value.doctorGroups;
    delete value.specialities;
    delete value.statuses;

    if (value.id) {
      const id = value.id;
      delete value.id;

      const aaDoctor = this.aaDoctorUser.find((d) => d.userName.toLowerCase() === value.username.toLowerCase());
      value.consultationTemplates =
        (this.doctorList.find((doctor) => doctor.id === id) || { consultationTemplates: [] }).consultationTemplates ||
        [];

      if (!aaDoctor) {
        this.alert.error('User Name not exist');
        this.onCancelBtnClick();
        return;
      }

      this.apiCmsManagementService.modifyDoctor(id, value).subscribe(
        (res) => {
          this.alert.success('Edit doctor info successfully');
          this.formGroup.get('username').enable();
          this.formGroup = this.doctorFormService.createDoctorMasterFormGroup();
          this.loadDoctorList(true);

          const userNameAA = res.payload.username;
          const contextId = res.payload.id;
          this.modifyAAUserContext(userNameAA, contextId);
        },
        (error) => this.alert.error(JSON.stringify(error))
      );
    } else {
      delete value.id;
      value.consultationTemplates = [];

      this.apiCmsManagementService.addDoctor(value).subscribe(
        (res) => {
          this.alert.success('Add doctor info successfully');
          this.formGroup.get('username').enable();
          this.formGroup = this.doctorFormService.createDoctorMasterFormGroup();
          this.loadDoctorList(true);

          const userNameAA = res.payload.username;
          const contextId = res.payload.id;
          this.modifyAAUserContext(userNameAA, contextId);
        },
        (error) => this.alert.error(JSON.stringify(error))
      );
    }
  }

  modifyAAUserContext(username, contextId) {
    this.apiAAService.updateUserCMSContext(username, contextId).subscribe(
      (res) => {
        alert('Add doctor success');
      },
      (error) => this.alert.error(JSON.stringify(error))
    );
  }

  onGroupFilterChange(group) {
    this.groupFilterSelctedValue = (group || { value: '' }).value;
    this.updateFilterResult();
  }

  onSpecialityFilterChange(speciality) {
    this.specialityFilterSelctedValue = (speciality || { value: '' }).value;
    this.updateFilterResult();
  }

  onStatusFilterChange(speciality) {
    this.statusFilterSelctedValue = (speciality || { value: '' }).value;
    this.updateFilterResult();
  }

  updateFilterResult() {
    this.rows = this.doctorList.filter((item) => {
      const group = this.groupFilterSelctedValue ? item.doctorGroup === this.groupFilterSelctedValue : true;
      const speciality = this.specialityFilterSelctedValue
        ? item.speciality === this.specialityFilterSelctedValue
        : true;
      const status = this.statusFilterSelctedValue ? item.status === this.statusFilterSelctedValue : true;

      const searchKeyword =
        (item.name || '').toLowerCase().includes(this.searchFieldInput) ||
        (item.displayName || '').toLowerCase().includes(this.searchFieldInput) ||
        (item.username || '').toLowerCase().includes(this.searchFieldInput);

      return group && speciality && status && searchKeyword;
    });
  }
}
