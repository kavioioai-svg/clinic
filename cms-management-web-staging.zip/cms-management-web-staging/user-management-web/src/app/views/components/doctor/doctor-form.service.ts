import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Doctor } from '../../../objects/Doctor';
import { User } from '../../../objects/response/User';
import { whiteSpaceValidator } from '../../../services/utils.service';
import { valueTrimmedRequiredValidator } from '../../../services/form.service';
import { DoctorSpecialityQuery } from '../../../state/doctor-speciality/doctor-speciality.query';
import { validatecontactNumber, validatePhoneNumber } from '../../../validators/PhoneNumberValidator';

@Injectable()
export class DoctorFormService {
  specialities = [{ value: 'GP', label: 'GP' }];

  doctorGroups = [
    { value: 'LOCUM', label: 'LOCUM' },
    { value: 'FLOATING', label: 'FLOATING' },
    { value: 'ANCHOR', label: 'ANCHOR' },
  ];

  statuses = [
    { value: 'ACTIVE', label: 'ACTIVE' },
    { value: 'INACTIVE', label: 'INACTIVE' },
    { value: 'BLOCKED', label: 'BLOCKED' },
  ];

  constructor(private fb: FormBuilder, private doctorSpecialityQuery: DoctorSpecialityQuery) {}

  createDoctorMasterFormGroup(): FormGroup {
    return this.fb.group({
      id: '',
      name: ['', valueTrimmedRequiredValidator()],
      displayName: ['', valueTrimmedRequiredValidator()],
      username: ['', [valueTrimmedRequiredValidator(), whiteSpaceValidator()]],
      mcr: ['', valueTrimmedRequiredValidator()],
      nric: [''],
      education: [''],
      doctorGroups: { values: this.doctorGroups },
      doctorGroup: ['', valueTrimmedRequiredValidator()],
      specialities: { values: this.doctorSpecialityQuery.getAll() },
      speciality: ['', valueTrimmedRequiredValidator()],
      statuses: { values: this.statuses },
      status: ['', valueTrimmedRequiredValidator()],
      enabled2FA: [true, valueTrimmedRequiredValidator()],
      passwordExpiryEnabled: [true, valueTrimmedRequiredValidator()],
      logoutInactiveSessionsEnabled: [true, valueTrimmedRequiredValidator()],
      suspendInactiveAccountEnabled: [true, valueTrimmedRequiredValidator()],
    });
  }

  createDoctorFormGroup(user: User = null, doctor: Doctor = null, rolesArray: Array<string> = []): FormGroup {
    return this.fb.group({
      id: doctor ? doctor.id : '',
      username: [
        doctor && !user ? '' : doctor ? doctor.username : user ? user.userName : '',
        [valueTrimmedRequiredValidator(), whiteSpaceValidator(), Validators.pattern(/^([a-zA-Z0-9\x5F\x2E _.-]+)$/)],
      ],
      password: ['', valueTrimmedRequiredValidator()],
      email: [user ? user.email : '', [valueTrimmedRequiredValidator(), whiteSpaceValidator()]],
      firstName: [user ? user.firstName : '', valueTrimmedRequiredValidator()],
      lastName: [user ? user.lastName : '', valueTrimmedRequiredValidator()],
      phoneNumber: [user ? user.phoneNumber : '', [valueTrimmedRequiredValidator(), validatecontactNumber]],
      populateGroups: '',
      groups: [rolesArray ? rolesArray : '', valueTrimmedRequiredValidator()],
      doctorGroup: [doctor ? doctor.doctorGroup : '', valueTrimmedRequiredValidator()],
      status: [doctor ? doctor.status : user ? user.status : '', valueTrimmedRequiredValidator()],
      name: [doctor ? doctor.name : '', valueTrimmedRequiredValidator()],
      displayName: [doctor ? doctor.displayName : '', valueTrimmedRequiredValidator()],
      mcr: [doctor ? doctor.mcr : '', valueTrimmedRequiredValidator()],
      nric: [doctor ? doctor.nric : '', valueTrimmedRequiredValidator()],
      speciality: [doctor ? doctor.speciality : '', valueTrimmedRequiredValidator()],
      education: [doctor ? doctor.education : ''],
      enabled2FA: [user ? user.enabled2FA : true, valueTrimmedRequiredValidator()],
      passwordExpiryEnabled: [user ? user.passwordExpiryEnabled : true, valueTrimmedRequiredValidator()],
      logoutInactiveSessionsEnabled: [user ? user.logoutInactiveSessionsEnabled : true, valueTrimmedRequiredValidator()],
      suspendInactiveAccountEnabled: [user ? user.suspendInactiveAccountEnabled : true, valueTrimmedRequiredValidator()],
    });
  }
}
