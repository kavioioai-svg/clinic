import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DoctorMasterComponent } from "./doctor-master.component";
import { TestingModule } from "../../../../test/testing.module";

describe("DoctorMasterComponent", () => {
  let component: DoctorMasterComponent;
  let fixture: ComponentFixture<DoctorMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      declarations: [DoctorMasterComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
