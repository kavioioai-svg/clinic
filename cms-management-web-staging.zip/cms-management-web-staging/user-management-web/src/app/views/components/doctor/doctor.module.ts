import { NgModule, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../../shared.module";
import { DoctorRoutingModule } from "./doctor-routing.module";
import { DoctorMasterComponent } from "./doctor-master/doctor-master.component";
import { FormGroup } from "@angular/forms";
import { DoctorFormService } from "./doctor-form.service";

@NgModule({
  imports: [CommonModule, SharedModule, DoctorRoutingModule],
  declarations: [DoctorMasterComponent],
  providers: [DoctorFormService]
})
export class DoctorModule implements OnInit {

  formGroup: FormGroup

  ngOnInit() {

  }
}
