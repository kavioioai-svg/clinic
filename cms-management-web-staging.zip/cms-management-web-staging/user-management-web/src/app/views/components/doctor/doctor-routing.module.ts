import { NgxPermissionsGuard } from "ngx-permissions";
import { DoctorMasterComponent } from "./doctor-master/doctor-master.component";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

const routes: Routes = [
  {
    path: "",
    canActivateChild: [NgxPermissionsGuard],
    data: {
      title: "Doctor Module"
    },
    children: [
      { path: "", pathMatch: "full", redirectTo: "all" },
      {
        path: "all",
        component: DoctorMasterComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctorRoutingModule {}
