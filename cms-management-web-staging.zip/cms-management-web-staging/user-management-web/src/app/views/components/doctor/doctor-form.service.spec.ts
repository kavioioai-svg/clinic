import { TestBed, inject } from '@angular/core/testing';

import { DoctorFormService } from './doctor-form.service';
import { TestingModule } from '../../../test/testing.module';
import { FormBuilder } from '@angular/forms';
import { valueTrimmedRequiredValidator } from '../../../services/form.service';
import { whiteSpaceValidator } from '../../../services/utils.service';
import { ApiCmsManagementService } from '../../../services/api-cms-management.service';
import { Doctor } from '../../../objects/Doctor';
import { Observable } from 'rxjs';
import { StoreService } from '../../../services/store.service';
import { DoctorSpecialityQuery } from '../../../state/doctor-speciality/doctor-speciality.query';

describe('DoctorFormService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [DoctorFormService, DoctorSpecialityQuery]
    });
  });

  it('should be created', inject([DoctorFormService], (service: DoctorFormService) => {
    expect(service).toBeTruthy();
  }));

  it('should create doctor master formgroup', inject(
    [DoctorFormService],
    (service: DoctorFormService, doctorSpecialityQuery: DoctorSpecialityQuery) => {
      const expectFomgGroup = new FormBuilder().group({
        id: '',
        name: ['', valueTrimmedRequiredValidator()],
        displayName: ['', valueTrimmedRequiredValidator()],
        username: ['', [valueTrimmedRequiredValidator(), whiteSpaceValidator()]],
        mcr: ['', valueTrimmedRequiredValidator()],
        education: [''],
        doctorGroups: { values: service.doctorGroups },
        doctorGroup: ['', valueTrimmedRequiredValidator()],
        specialities: { values: doctorSpecialityQuery.getAll() },
        speciality: ['', valueTrimmedRequiredValidator()],
        statuses: { values: service.statuses },
        status: ['', valueTrimmedRequiredValidator()]
      });

      expect(service.createDoctorMasterFormGroup().value).toEqual(expectFomgGroup.value);
    }
  ));

  it('should list doctor success', inject(
    [DoctorFormService, ApiCmsManagementService],
    (service: DoctorFormService, apiCmsManagementService: ApiCmsManagementService, done: DoneFn) => {
      const apiResponse = {
        payload: [
          new Doctor(
            'id',
            'name',
            'displayName',
            'userName',
            'mcr',
            'education',
            'doctorGroup',
            'speciality',
            'status'
          ),
          new Doctor(
            'id2',
            'name2',
            'displayName2',
            'userName2',
            'mcr2',
            'education2',
            'doctorGroup2',
            'speciality2',
            'status2'
          )
        ]
      };

      // spyOn(apiCmsManagementService, 'listDoctors').and.returnValue(Observable.of(apiResponse));
      // service.listDoctors().subscribe(doctors => {
      //   expect(doctors).toEqual(apiResponse.payload);
      //   done();
      // });
    }
  ));

  it('test get Doctor Speciality Options sucess', inject(
    [DoctorFormService, StoreService],
    (service: DoctorFormService, doctorSpecialityQuery: DoctorSpecialityQuery) => {
      const specialityList = ['speciality 1', 'speciality 2', 'speciality 3', 'speciality 4'];
      spyOn(doctorSpecialityQuery, 'getAll').and.returnValue(specialityList);
      const specialityOptions = doctorSpecialityQuery.getAll();
      const expectOptionsList = specialityList.map(item => {
        return { label: item, value: item };
      });

      expect(specialityOptions).toEqual(expectOptionsList);
    }
  ));

  it('test get Doctor Speciality Options empty list', inject(
    [DoctorFormService, StoreService],
    (service: DoctorFormService, doctorSpecialityQuery: DoctorSpecialityQuery) => {
      const specialityList = [];
      spyOn(doctorSpecialityQuery, 'getAll').and.returnValue(specialityList);
      const specialityOptions = doctorSpecialityQuery.getAll();

      expect(specialityOptions).toEqual([]);
    }
  ));

  it('test get Doctor Speciality Options store return null', inject(
    [DoctorFormService, StoreService],
    (service: DoctorFormService, doctorSpecialityQuery: DoctorSpecialityQuery) => {
      spyOn(doctorSpecialityQuery, 'getAll').and.returnValue(null);
      const specialityOptions = doctorSpecialityQuery.getAll();

      expect(specialityOptions).toEqual([]);
    }
  ));
});
