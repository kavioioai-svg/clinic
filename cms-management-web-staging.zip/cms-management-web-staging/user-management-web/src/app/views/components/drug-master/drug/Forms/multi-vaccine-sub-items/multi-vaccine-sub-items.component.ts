import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {ItemService} from '../../../../../../services/item.service';

@Component({
  selector: 'app-multi-vaccine-sub-items',
  templateUrl: './multi-vaccine-sub-items.component.html',
  styleUrls: ['./multi-vaccine-sub-items.component.scss']
})
export class MultiVaccineSubItemsComponent implements OnInit ,OnChanges{
  @Input() drugFormGroup: FormGroup;
  @Input() mode: string;
  @Input() listItems: any;
  isReadOnly: boolean ;

  constructor( private itemService: ItemService) { }

  ngOnInit() {
  }


  ngOnChanges(changes: SimpleChanges) {

    if (changes.listItems && this.listItems) {
     this.populateForm(this.listItems.multiVaccineSubItems);
    } if (changes.mode && this.mode) {
      this.isReadOnly = (this.mode === 'view');
    }

  }

  get getMultiVaccineSubItem(): FormArray {
    return this.drugFormGroup.get('multiVaccineSubItems') as FormArray;
  }

   getMultiVaccineSubItemFormGroup(): FormArray {
    return this.drugFormGroup.get('multiVaccineSubItems') as FormArray;
  }

  dosagesDetails(empIndex: number): FormArray {
    return this.getMultiVaccineSubItemFormGroup()
      .at(empIndex)
      .get('dosages') as FormArray;
  }
  deleteGroupItem(i: number, type: string , childIndex?: number) {
    switch (type) {
      case 'subItem':
        this.getMultiVaccineSubItem.removeAt(i);
        break;
      case 'dosage':
        this.removeDosageFiled(i , childIndex);
        break;
    }
  }

  addMore(type: string , index?: number) {
    switch (type) {
      case 'subItem':
        this.getMultiVaccineSubItem.push(this.itemService.getMultiVacSubFormGroup());
        break;
      case 'dosage':
        this.dosagesDetails(index).push(this.itemService.getDosageFormGroup());
        break;
    }
  }
  removeDosageFiled(i , childIndex) {
    this.dosagesDetails(i).removeAt(childIndex);
  }
  readOnly() {
    return this.isReadOnly;
  }

  populateForm(data: any) {
    (this.drugFormGroup.get('multiVaccineSubItems') as FormArray).clear();
    data.forEach(c => {
      const pb = this.itemService.getMultiVacSubFormGroup();
      pb.patchValue(c);

      (pb.get('dosages') as FormArray).clear();
      c.dosages.forEach((lb) => {
        const bonus = this.itemService.getDosageFormGroup();
        bonus.patchValue(lb);
        (pb.get('dosages') as FormArray).push(bonus);
      });
      (this.drugFormGroup.get('multiVaccineSubItems') as FormArray).push(pb);
    });
  }
}
