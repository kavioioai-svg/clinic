import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterTabListComponent } from './master-tab-list.component';

describe('MasterTabListComponent', () => {
  let component: MasterTabListComponent;
  let fixture: ComponentFixture<MasterTabListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterTabListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterTabListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
