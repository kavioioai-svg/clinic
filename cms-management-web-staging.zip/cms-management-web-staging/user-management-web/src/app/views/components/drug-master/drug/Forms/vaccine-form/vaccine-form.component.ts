import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {ControlContainer, FormArray, FormBuilder, FormGroup} from '@angular/forms';
import { Drug } from '../../../../../../objects/request/Drug';
import { ItemService } from '../../../../../../services/item.service';
import { VaccineDosageQuery } from '../../../../../../state/drug/vaccine-dosage/vaccine-dosage.query';

@Component({
  selector: 'app-vaccine-form',
  templateUrl: './vaccine-form.component.html',
  styleUrls: ['./vaccine-form.component.scss']
})
export class VaccineFormComponent implements OnInit ,OnChanges {

 // form: FormGroup;
  @Input () listItems: Drug;
  @Input () isResetForm: boolean;
  @Input () mode: string;
  @Input() drugFormGroup: FormGroup;

  vaccineDosages = [];

  constructor(private controlContainer: ControlContainer,
              private fb: FormBuilder,
              private itemService: ItemService,
              private vaccineDosageQuery: VaccineDosageQuery) { }

  ngOnInit() {
   // this.drugFormGroup = <FormGroup>this.controlContainer.control;
    this.vaccineDosages = this.itemService.getVaccineDosageOptions();
    this.itemService.vaccineDosageOptionsStore.subscribe((options) => (this.vaccineDosages = [...options]));
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.listItems && this.listItems) {
     // this.drugFormGroup = this.itemService.populateDrugMasterForm(this.listItems);
      this.populateForm();
    }
    if (changes.isResetForm && this.isResetForm) {
      this.drugFormGroup.reset();
    }
  }

  deleteDosageGroup(i: number) {
    const add = this.drugFormGroup.get('dosages') as FormArray;
    add.removeAt(i);
  }


  addDosage(): void {
    this.dosages.push(this.itemService.getDosageFormGroup());
  }

  get dosages(): FormArray {
    return this.drugFormGroup.get('dosages') as FormArray;
  }

   populateForm() {
     this.dosages.clear();
     if(this.listItems.dosages.length > 0) {
       this.listItems.dosages.forEach(c => {
         const vaccineForm = this.itemService.getDosageFormGroup();
         vaccineForm.patchValue(c);
        this.dosages.push(vaccineForm);
       });
     }
     if(this.mode === 'view') {
       this.drugFormGroup.disable();
     }
   }

   onVaccineDosageChange(vaccineDosageCode, index) {
    if(vaccineDosageCode) {
      const vaccineDosage = this.vaccineDosageQuery
        .getAll()
        .find((item) => item.code === vaccineDosageCode);

      if (vaccineDosage) {
        let dosages = this.drugFormGroup.get('dosages') as FormArray;
        dosages.controls[index].get('name').patchValue(vaccineDosage.name);
        dosages.controls[index].get('description').patchValue(vaccineDosage.description);
      }
    }
   }
}
