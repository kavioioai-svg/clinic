import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {ControlContainer, FormControl, FormGroup} from '@angular/forms';
import {DrugUomQuery} from '../../../../../../state/drug/drug-uom/drug-uom.query';
import {ItemService} from '../../../../../../services/item.service';
import {DrugInstructionQuery} from '../../../../../../state/drug/drug-instruction/drug-instruction.query';
import {DosageInstructionQuery} from '../../../../../../state/drug/dosage-instruction/dosage-instruction.query';
import {Drug} from '../../../../../../objects/request/Drug';
import { cloneDeep } from 'lodash';
import { ApiCmsManagementService } from '../../../../../../services/api-cms-management.service';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';
import { Subject, of } from 'rxjs';
import { AlertService } from '../../../../../../services/alert.service';
import { AllergyGroupService } from '../../../../../../services/master-data-service/allergy-group.service';
import { Page } from '../../../../../../model/page';
import { HttpResponseBody } from '../../../../../../objects/response/HttpResponseBody';
@Component({
  selector: 'app-drug-from',
  templateUrl: './drug-from.component.html',
  styleUrls: ['./drug-from.component.scss']
})
export class DrugFromComponent implements OnInit , OnChanges{

  @Input() drugFormGroup: FormGroup;

  UOM;
  dosageUomList;
  instructions = [];
  dosageInstructions = [];
  cautionary = [];
  booleanSelection = [];
  routeOfAdministrators = [];
  smstDoseFormMaster = [];
  mimsClassificationList$;
  mimsClassificationList = [];
  sddCodesList = [];
  genericSddCodesList = [];
  codesTypeahead = new Subject<string>();
  genericCodesTypeahead = new Subject<string>();
  codeLoading = false;
  private allergyGroupData: any;

  @Input () listItems: Drug;
  @Input () isResetForm: boolean;

  constructor(private controlContainer: ControlContainer,
              private drugUomQuery: DrugUomQuery,
              private itemService: ItemService,
              private apiCmsManagementService: ApiCmsManagementService,
              private drugInstructionQuery: DrugInstructionQuery,
              private dosageInstructionQuery: DosageInstructionQuery,
              private alertService: AlertService,
              private allergyGroupService: AllergyGroupService,
              ) { 
                this.onSddCodeChanged();
                this.onGenericSddCodeChanged();
              }

  ngOnInit() {
   // this.form = <FormGroup>this.controlContainer.control;
    this.UOM = this.drugUomQuery.getAll().map((uom) => uom.uom);
    this.dosageUomList = this.drugUomQuery.getAll();

    this.instructions = this.itemService.getInstructionsOptions();
    this.dosageInstructions = this.itemService.getDosageInstructionsOptions();
    this.cautionary = this.itemService.getCautionaryOptions();
    this.itemService.instructionOptionsStore.subscribe((options) => (this.instructions = [...options]));
    this.itemService.dosageInstructionOptionsStore.subscribe((options) => (this.dosageInstructions = [...options]));
    this.itemService.cautionaryOptionStore.subscribe((options) => (this.cautionary = [...options]));

    this.booleanSelection = [
      { value: true, label: 'YES' },
      { value: false, label: 'NO' }
    ];
   this.listRouteOfAdministrations();
   this.listOfSMSTDoseFormMaster();
   this.listMimsClassifications();
   this.onLoadSearchSddCodes();
   this.onLoadSearchGenericSddCodes();
  }

  onLoadSearchSddCodes(){
    setTimeout(() => {
      this.onSearchSddCodes(this.drugFormGroup.get('sddCode').value)
        .subscribe(res=> {
          this.sddCodesList = [...res.payload];
        })
    }, 1000);
  }

  onLoadSearchGenericSddCodes(){
    setTimeout(() => {
      this.onSearchSddCodes(this.drugFormGroup.get('genericSddCode').value)
        .subscribe(res=> {
          this.genericSddCodesList = [...res.payload];
        })
    }, 1000);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.listItems && this.listItems) {
     // this.drugFormGroup = this.itemService.populateDrugMasterForm(this.listItems);
     if(this.listItems.id !== null) {
      this.findAllergyGroupCodesForItem(this.listItems.id);
    }
    }
  }

  private findAllergyGroupCodesForItem(itemId: string): void {
    let pageNumber = 0;
    let size = 30;

    let filter = {
      status: 'ACTIVE',
      groupCode: '',
      drugIds: [itemId]
    }

    this.allergyGroupService.searchItem(filter, new Page(pageNumber, size))
      .subscribe((res) => {
        this.allergyGroupData = res.payload;
        this.setAllergyGroupCodes();
      }, (err) => {

      });

}

private setAllergyGroupCodes(): void {
  let allergyGroupsList = this.allergyGroupData.filter(allergy => !allergy.isFoodAllergy);
  let foodAllergyGroupsList = this.allergyGroupData.filter(allergy => allergy.isFoodAllergy);

  if (allergyGroupsList[0] != null) {
    this.drugFormGroup.get('allergyGroupCode').patchValue(allergyGroupsList[0].groupCode)
  }
  if (allergyGroupsList[1] != null) {
    this.drugFormGroup.get('allergyGroupCode1').patchValue(allergyGroupsList[1].groupCode)
  }
  if (allergyGroupsList[2] != null) {
    this.drugFormGroup.get('allergyGroupCode2').patchValue(allergyGroupsList[2].groupCode)
  }
  if (allergyGroupsList[3] != null) {
    this.drugFormGroup.get('allergyGroupCode3').patchValue(allergyGroupsList[3].groupCode)
  }
  if (allergyGroupsList[4] != null) {
    this.drugFormGroup.get('allergyGroupCode4').patchValue(allergyGroupsList[4].groupCode)
  }

  if (foodAllergyGroupsList[0] != null) {
    this.drugFormGroup.get('foodAllergyGroupCode1').patchValue(foodAllergyGroupsList[0].groupCode)
  }
  if (foodAllergyGroupsList[1] != null) {
    this.drugFormGroup.get('foodAllergyGroupCode2').patchValue(foodAllergyGroupsList[1].groupCode)
  }
  if (foodAllergyGroupsList[2] != null) {
    this.drugFormGroup.get('foodAllergyGroupCode3').patchValue(foodAllergyGroupsList[2].groupCode)
  }

}


  onSddCodeChanged(){
    try {
      this.codesTypeahead
        .pipe(
          distinctUntilChanged((a, b) => b.trim().length === 0),
          debounceTime(400),
          tap(() => (this.codeLoading = true)),
          switchMap((term: string) => {
            return this.onSearchSddCodes(term);
          })
        )
        .subscribe(
          (data) => {
            this.codeLoading = false;

            if (data) {
              this.sddCodesList = [...data.payload];
              // this.codes.push(data.payload);
            }
          },
          (err) => {
            this.codeLoading = false;
            if (err && err.error && err.error.message) {
              this.alertService.error(JSON.stringify(err.error.message));
            }
          }
        );
    }catch (err) {}
  }

  onGenericSddCodeChanged(){
    try {
      this.genericCodesTypeahead
        .pipe(
          distinctUntilChanged((a, b) => b.trim().length === 0),
          debounceTime(400),
          tap(() => (this.codeLoading = true)),
          switchMap((term: string) => {
            return this.onSearchSddCodes(term);
          })
        )
        .subscribe(
          (data) => {
            this.codeLoading = false;

            if (data) {
              this.genericSddCodesList = [...data.payload];
              // this.codes.push(data.payload);
            }
          },
          (err) => {
            this.codeLoading = false;
            if (err && err.error && err.error.message) {
              this.alertService.error(JSON.stringify(err.error.message));
            }
          }
        );
    }catch (err) {}
  }

  onSearchSddCodes(term){
    return this.apiCmsManagementService
      .searchSddCodes(encodeURI(term))
      .pipe(
        catchError(error => of(<HttpResponseBody>{ page: {}, payload: '' }))
      ); 
  }

  onInstructionChange(instructionOption) {
    const instruction = this.drugInstructionQuery.getAll().find((item) => item.code === instructionOption.value);

    if (instruction) {
      this.drugFormGroup.patchValue({ instruction }, { emitEvent: false });
    }
  }

  onDosageInstructionChange(instructionOption) {
    if(instructionOption) {
      const dosageInstruction = this.dosageInstructionQuery
        .getAll()
        .find((item) => item.code === instructionOption);

      if (dosageInstruction) {
        this.drugFormGroup.patchValue({ dosageInstruction : dosageInstruction.description}, { emitEvent: false });
      }
    }

  }

  addCustomNgSelectTag(value) {
    return { label: value, value: value };
  }

  getChangeValue($event: any) {
    if($event) {
      this.drugFormGroup.patchValue({
        frequency: $event.description
      })
    }else {
      this.drugFormGroup.patchValue({
        frequency: null
      });
    }
  }

  onChangeAllergy($event: any, formControl: string) {
    let drugFormClone = cloneDeep(this.drugFormGroup);
    drugFormClone.removeControl(formControl);
    if($event) {
      Object. keys(drugFormClone. controls). forEach(key => {
        if(key.includes('allergyGroupCode')) {
            if(drugFormClone.get(key).value == $event) {
              this.drugFormGroup.get(formControl).setErrors({duplicate: true});
            }
        }
      });
    }
  }

  listRouteOfAdministrations() {
    this.itemService
      .listRoutesOfAdministrations('DRUG_ROUTE_OF_ADMIN_MAP')
      .subscribe(
        res => {
          const routes = JSON.parse(JSON.stringify(res.payload));
          this.routeOfAdministrators = routes.values;
        }
      );
  }

  public listOfSMSTDoseFormMaster(): void {
    this.itemService
    .listRoutesOfAdministrations('SMST_DOSE_FORM_MASTER')
    .subscribe(
      res => {
        const routes = JSON.parse(JSON.stringify(res.payload));
        this.smstDoseFormMaster = routes.values;
      }
    );
  }

  listMimsClassifications() {
    this.apiCmsManagementService.listMims()
      .subscribe(
        res => {
          const mims = JSON.parse(JSON.stringify(res.payload));
          this.mimsClassificationList = mims.values.filter(item => item.status.toUpperCase() === 'ACTIVE')
            .map(item => ({ label: `${item.code} - ${item.description}`, value: item.code }));
        }
      );
  }
}
