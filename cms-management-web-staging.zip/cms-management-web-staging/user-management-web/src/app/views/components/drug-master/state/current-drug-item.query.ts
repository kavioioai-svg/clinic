import { Injectable } from '@angular/core';

import { Query } from '@datorama/akita';
import { StoreStatusService } from '../../../../state/store-status/store-status.service';
import {CurrentDrugItemState, CurrentDrugItemStore} from './current-drug-item.store';

@Injectable({ providedIn: 'root' })
export class CurrentDrugItemQuery extends Query<CurrentDrugItemState> {

  constructor(
    protected store: CurrentDrugItemStore,
  ) { super(store) }


  getCurrentDrugItemId() {
    return this.select(entity => entity.id)
  }

}
