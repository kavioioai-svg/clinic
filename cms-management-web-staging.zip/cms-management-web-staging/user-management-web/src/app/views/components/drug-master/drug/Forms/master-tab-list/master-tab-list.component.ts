import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { itemTab } from '../../../../../../model/enum/enums';
import { ItemService } from '../../../../../../services/item.service';
import { ChargeItemQuery } from '../../../../../../state/charge-item/charge-item.query';

@Component({
  selector: 'app-master-tab-list',
  templateUrl: './master-tab-list.component.html',
  styleUrls: ['./master-tab-list.component.scss']
})
export class MasterTabListComponent implements OnInit {
  backBtnText =  '< Back to Item';
  backUrl =  'pages/item/master';
  actionIndex: number;
  itemType: string;
  item: any;
  showCurrentItem: boolean = true;
  listItems: any[] =[];
  createItemFlag: boolean = false;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private itemService: ItemService,
    private chargeItemQuery: ChargeItemQuery
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.actionIndex = params['tabIndex'];
      this.itemType = params['type'];
      const itemId = params['id'];
      if (itemId){
        this.itemService.setCurrentDrugItemId(itemId);
      }
    });
    this.listItems = this.chargeItemQuery.getDrugItems();
    if(this.router.url.includes('/item/create/')) {
      this.createItemFlag = true;
    } else this.getItembyId();
  }

  getItembyId(){
    this.itemService.getItemById(this.itemService.getCurrentDrugItemId()).subscribe(res => {
      if(res.message === "Success") {
        this.item = res.payload;
        this.itemService.setSelectedItem(res.payload)
      }
    })
  }

  getAllListItems() {
    this.itemService.listAllItems('' , true).subscribe(items => {
      if (items && items.statusCode === 'S0000') {
        this.listItems =  items.payload.map((item) => item.item).filter((item) => item);
      }
    })
  }

  get itemTab() {
    return itemTab;
  }

  onTabSelected(tab: itemTab) {
    if(this.router.url.includes('edit')){
      this.router.navigate([`/pages/item/master/item/edit/${this.itemType}/${tab}`]);
    } else this.router.navigate([`/pages/item/master/item/view/${this.itemType}/${tab}`]);
  }

  ngOnDestroy(): void {
    if(!this.router.url.includes('/item/master/')) {
      this.itemService.setSelectedItem(null)
    }
  }

}
