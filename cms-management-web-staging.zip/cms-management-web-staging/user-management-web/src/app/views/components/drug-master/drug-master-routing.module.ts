import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { DrugComponent } from './drug/drug.component';
import { MasterTabListComponent } from './drug/Forms/master-tab-list/master-tab-list.component';
import { ItemFormComponent } from './../supplier/tab-list/item-tab-list/item-form/item-form.component'

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Drug'
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'master' },
      { path: 'master', component: DrugComponent },
      { path: 'master/item/:action/:type/:tabIndex', component: MasterTabListComponent},
      { path: "master/item/:action/:type/:tabIndex", component: ItemFormComponent},
      { path: "master/item/:action/:type/:tabIndex/:id", component: MasterTabListComponent},
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DrugMasterRoutingModule {}
