import { Injectable } from '@angular/core';

import { Store, StoreConfig } from '@datorama/akita';

export interface CurrentDrugItemState {


  id: string;

}

export function createInitialState(): CurrentDrugItemState {
  return {
   id: '',
  }
}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'drugItemsState' })
export class CurrentDrugItemStore extends Store<CurrentDrugItemState> {

  constructor() { super(createInitialState()); }

  clearDrugCurrentState(): void  {
    this.update(createInitialState());
  }

}
