import {AfterContentChecked, ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {ItemService} from '../../../../../../services/item.service';
import {valueTrimmedRequiredValidator} from '../../../../../../services/form.service';
import {ItemType, PRICE_ADJUSTMENT_TYPE, STATUS} from '../../../../../../constants/app.constants';
import {ActivatedRoute, Router} from '@angular/router';
import {Drug} from '../../../../../../objects/request/Drug';
import {AlertService} from '../../../../../../services/alert.service';
import {DrugInstructionQuery} from '../../../../../../state/drug/drug-instruction/drug-instruction.query';
import {DosageInstructionQuery} from '../../../../../../state/drug/dosage-instruction/dosage-instruction.query';
import {DrugUomQuery} from '../../../../../../state/drug/drug-uom/drug-uom.query';
import {BsModalService} from 'ngx-bootstrap';
import {Observable, Subscription} from 'rxjs';
import {distinctUntilChanged} from 'rxjs/operators';
import {CurrentDrugItemQuery} from '../../../state/current-drug-item.query';
import {Supplier} from '../../../../../../objects/Supplier';
import {UomMatrixService} from '../../../../../../services/master-data-service/uom-matrix.service';
import { StoreService } from '../../../../../../services/store.service';
import {itemTab} from '../../../../../../model/enum/enums'

@Component({
  selector: 'app-item-master-form',
  templateUrl: './item-master-form.component.html',
  styleUrls: ['./item-master-form.component.scss']
})
export class ItemMasterFormComponent implements OnInit , OnDestroy , AfterContentChecked{
  drugFormGroup: FormGroup;
  itemType:string
  routeAction :string
  isEdit: boolean;
  isReadOnly: boolean;
  isFullWidth: boolean;
  colWidth: string;

  UOM;
  Status = STATUS;
  priceAdjusmentType = PRICE_ADJUSTMENT_TYPE;

  category = [];

  instructions = [];
  dosageInstructions = [];
  uomMatrixList: any[] =[];
  filteredUomMatrixRatioList: any[] =[];

  //dropdown
  cautionary = [];
  priceAdjustmentType = [];
  status = [];
  packageType = [];
  booleanSelection = [];
  listItems: any;
  isResetForm: boolean;

  drugSearchFormControl: FormControl;
  searchDrugHttpRequest: Subscription = null;
  supplier: Supplier;
  backBtnText =  '< Back to Item';
  backUrl =  'pages/item/master';

  constructor( private itemService: ItemService,
                private route: ActivatedRoute,
                private alertService: AlertService,
                private drugInstructionQuery: DrugInstructionQuery,
                private currentDrugItemQuery: CurrentDrugItemQuery,
                private dosageInstructionQuery: DosageInstructionQuery,
                private drugUomQuery: DrugUomQuery,
                private router: Router,
                private modalService: BsModalService,
               private uomMatrixService: UomMatrixService,
               private storeService: StoreService,
               private cdref: ChangeDetectorRef ) {

  }

  ngOnInit() {

     this.route.params.subscribe(params => {
      this.itemType = params['type'];
      this.routeAction = params['action'];
    });
    this.initializeForm();

    if(this.routeAction === 'edit' || this.routeAction === 'view') {
      this.itemService.getItemById(this.itemService.getCurrentDrugItemId()).subscribe(item => {
        this.listItems = item.payload.item;
        this.onUomMatrixDataChange({uomCode:item.payload.item.baseUom});
        this.drugFormGroup =  this.itemService.populateDrugMasterForm(item.payload.item);
      });

      this.route.params.subscribe(params => {
        switch (params['action']) {
          case 'view':
            this.isReadOnly = true;
            this.drugFormGroup.disable();
            break;
          case 'edit':
            this.isReadOnly = false;
            this.drugFormGroup.enable();
            break;

        }
      });
    }
  }
  initializeForm() {

    this.drugFormGroup = this.itemService.getDrugMasterForm(this.itemType.toUpperCase());
    this.category = this.itemService.getCategoryOptions();
    this.itemService.categoryOptionStore.subscribe((options) => (this.category = [...options]));
    this.dropdownData();
    this.instructions = this.itemService.getInstructionsOptions();
    this.dosageInstructions = this.itemService.getDosageInstructionsOptions();
    this.getUomMatrixList();
    this.cautionary = this.itemService.getCautionaryOptions();

    this.itemService.instructionOptionsStore.subscribe((options) => (this.instructions = [...options]));
    this.itemService.dosageInstructionOptionsStore.subscribe((options) => (this.dosageInstructions = [...options]));

    this.itemService.cautionaryOptionStore.subscribe((options) => (this.cautionary = [...options]));

    this.subscribeChanges();
    this.isFullWidth =  !(this.itemType === 'Vaccination' || this.itemType === 'Drug' || this.itemType === 'Package');

    if(this.routeAction === 'view') {
      this.isReadOnly = true;
      this.drugFormGroup.disable();
    }

  }
  get getIemType(){
    return ItemType;
  }

  onSaveUpdateData() {
    if(this.itemType !== 'PACKAGE') {
      this.drugFormGroup.removeControl('subItems');
    }
      const data = <Drug>this.drugFormGroup.getRawValue();
      if (this.drugFormGroup.get('id').value) {
        // UPDATE
        this.itemService
          .editDrug(this.drugFormGroup.get('id').value, this.itemService.processDataBeforeSubmission(data))
          .subscribe(
            (res) => {
              this.alertService.success('Item Updated Successfully.');
              this.storeService.retrieveItems();

            },
            (err) => {
              this.alertService.error(JSON.stringify(err));
            }
          );
      } else {
        // NEW
        this.itemService.addDrug(this.itemService.processDataBeforeSubmission(data)).subscribe(
          (res) => {
            this.alertService.success(
              `Item has been added and registered under supplier ${this.supplier? this.supplier.name : ''}`);
            this.storeService.retrieveItems();
            this.resetFormGroup();
            const item = res.payload.item;
            setTimeout(() => {
              this.router.navigate([`/pages/item/master/item/edit/${item.itemType}/${itemTab.GENERAL}/${item.id}`]);
            }, 1000);
          },
          (err) => {
            this.alertService.error(JSON.stringify(err.error.message));
          }
        );
      }
    }

  resetFormGroup() {
    this.drugFormGroup.get('code').enable();
    this.isResetForm = true;
    this.cautionary = [...this.itemService.getCautionaryOptions()];
    this.category = [...this.itemService.getCategoryOptions()];
    this.drugFormGroup = this.itemService.getDrugMasterForm(this.itemType.toUpperCase());
    this.subscribeChanges();
  }

  subscribeChanges() {
    this.drugFormGroup.valueChanges.subscribe((res) => {
      const invalid = [];
      const controls = this.drugFormGroup.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
    });
  }

  goBack() {
  this.router.navigate(['pages/item/master'])
  }

  onSaveData() {

  }

  ngOnDestroy() {
    //this.itemService.clearItemStorage();
  }

   dropdownData() {
    this.priceAdjustmentType = [
      { value: 'PACKAGE', label: 'Package' },
      { value: 'SUB_ITEM', label: 'Sub Item' },
      { value: 'FIXED', label: 'Fixed' }
    ];

    this.status = [
      { value: 'ACTIVE', label: 'Active' },
      { value: 'INACTIVE', label: 'In Active' },
      { value: 'BLOCKED', label: 'Blocked' },
    ];
    this.packageType = [
      { value: 'PRE', label: 'Pre' },
      { value: 'PER_SESSION', label: 'Pre session' },
      { value: 'POST', label: 'Post' },
    ];
    this.booleanSelection = [
      { value: true, label: 'YES' },
      { value: false, label: 'NO' }
    ];

  }

  ngAfterContentChecked(): void {
    this.cdref.detectChanges();
  }

  isDisabled() {
    if (this.drugFormGroup.invalid) {
      return true;
    }
    return false
  }

  changeMultiCostItem($event: any) {
    let {item , index} = $event;
    console.log(item);
    console.log(index);
  }

  supplierOnChange($event: any) {
    if($event)
       this.supplier = $event;
  }

  onUomMatrixDataChange($event: any) {
    let code = $event.uomCode;
    if($event) {
      const Uom = this.uomMatrixList.find(r => r.uomCode == code);
      if(Uom){
        this.filteredExchangeRatioCodeList(Uom);
      }
    }
  }
  getUomMatrixList() {
    this.uomMatrixService.listAllUomMatrix({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).subscribe(res => {
      if(res) {
        this.uomMatrixList = res.payload.filter(e => e.status == 'ACTIVE');
      }
    })
  }

  filteredExchangeRatioCodeList(data: any) {
    this.filteredUomMatrixRatioList =[];
    this.drugFormGroup.patchValue({
      salesUom:'',
      purchaseUom:'',
    })
      // @ts-ignore
      Object.entries(data.exchangeRatio).forEach(([key, value], index) => {
        this.filteredUomMatrixRatioList.push({key:key, value:value});
      });
     if(this.filteredUomMatrixRatioList.length > 0){
      // @ts-ignore
      this.filteredUomMatrixRatioList = Object.values(this.filteredUomMatrixRatioList.reduce((acc,cur)=>Object.assign(acc,{[cur.key]:cur}),{}));
     }

  }

  goToEdit() {
    this.router.navigate([`/pages/item/master/item/edit/${this.itemType}/${itemTab.GENERAL}`]);
    this.itemService.setCurrentDrugItemId(this.drugFormGroup.get('id').value);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

}


