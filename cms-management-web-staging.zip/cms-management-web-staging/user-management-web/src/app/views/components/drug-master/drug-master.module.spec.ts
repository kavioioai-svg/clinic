import { DrugMasterModule } from './drug-master.module';

describe('DrugMasterModule', () => {
  let drugMasterModule: DrugMasterModule;

  beforeEach(() => {
    drugMasterModule = new DrugMasterModule();
  });

  it('should create an instance', () => {
    expect(drugMasterModule).toBeTruthy();
  });
});
