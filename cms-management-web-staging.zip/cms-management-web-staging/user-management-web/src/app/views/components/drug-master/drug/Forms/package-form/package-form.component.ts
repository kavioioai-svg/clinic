import {Component, Input, OnInit} from '@angular/core';
import {ControlContainer, FormArray, FormGroup} from '@angular/forms';
import {Drug} from '../../../../../../objects/request/Drug';
import {ItemService} from '../../../../../../services/item.service';
import {concat, Observable, of, Subject} from 'rxjs';
import {catchError, distinctUntilChanged, map, switchMap, tap} from 'rxjs/operators';
import {HttpResponseBody} from '../../../../../../objects/response/HttpResponseBody';

@Component({
  selector: 'app-package-form',
  templateUrl: './package-form.component.html',
  styleUrls: ['./package-form.component.scss']
})
export class PackageFormComponent implements OnInit {

  constructor(private controlContainer: ControlContainer,
              private itemService: ItemService) { }
  form: FormGroup;
  @Input () listItems: Drug;
  @Input () isResetForm: boolean;
  @Input () drugFormGroup: FormGroup;

  itemsList$: Observable<any>;
  itemTypeahead$ = new Subject<string | null>();
  spinner: boolean;
  listAllItems: any[] =[]
  ngOnInit() {
    this.searchItem();
  }

  // get subItems(): FormArray {
  //   console.log(111,this.drugFormGroup.get('subItems'));
  //   return this.drugFormGroup.get('subItems') as FormArray;
  // }

  get subItems(): FormArray {
    const subItemsFormArray = this.drugFormGroup.get('subItems') as FormArray;
    subItemsFormArray.controls.forEach(control => {
      const sellingPrice = control.get('sellingPrice.price');
      const formattedPrice = Number(sellingPrice.value).toFixed(2);
      sellingPrice.setValue(formattedPrice);
    });
    return subItemsFormArray;
  }

  deletePackageGroup(i: number) {
    const add = this.drugFormGroup.get('subItems') as FormArray;
    add.removeAt(i);
  }

  addPackage(): void {
    this.subItems.push(this.itemService.getPackageFormGroup());
  }

  searchItem() {
    // this.itemsList$ = concat(
    //   of([]),
    //   this.itemTypeahead$.pipe(
    //     distinctUntilChanged(),
    //     tap(() => (this.spinner = true)),
    //     switchMap((term) =>
    //       this.itemService.searchItem(term).pipe(
    //         catchError((errors) => of(<HttpResponseBody>{ page: {}, payload: '' })),
    //         tap(() => (this.spinner = false))
    //       )
    //     ),
    //     map((data) => data.payload.map((item) => item.item)),
    //     tap((data) => console.log(data))
    //   )
    // );
    this.itemService.listAllItems('' , true).subscribe(items => {
      if (items && items.statusCode === 'S0000') {
        this.listAllItems =  items.payload.map((item) => item.item).filter((item) => item);
      }
    })
  }
  getBooleanType() {
    return this.itemService.booleanSelection;
  }
}
