import { AlertService } from './../../../../services/alert.service';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import {ITEM_TYPE_DROPDOWN_LIST, ItemType, PRICE_ADJUSTMENT_TYPE} from './../../../../constants/app.constants';
import { Page } from './../../../../objects/datatable/Page';
import { ItemService } from '../../../../services/item.service';
import {AfterContentChecked, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import { STATUS } from '../../../../constants/app.constants';
import { Drug } from '../../../../objects/request/Drug';
import { markFormGroupTouched } from '../../../../services/form.service';
import {Observable, Subject, Subscription} from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { DrugInstructionQuery } from '../../../../state/drug/drug-instruction/drug-instruction.query';
import { DrugUomQuery } from '../../../../state/drug/drug-uom/drug-uom.query';
import { DosageInstructionQuery } from '../../../../state/drug/dosage-instruction/dosage-instruction.query';
import {BsModalService} from 'ngx-bootstrap';
import {CurrentDrugItemQuery} from '../state/current-drug-item.query';
import {Router} from '@angular/router';
import {ItemFilter} from '../../../../objects/ItemFilter';
import {StockListFilter} from '../../../../objects/StockListFilter';
import {CategoriesService} from '../../../../services/master-data-service/categories.service';
import {ChangeDetection} from '@angular/cli/lib/config/schema';
import {SupplierService} from '../../../../services/master-data-service/supplier.service';
import { Supplier } from '../../../../../app/objects/Supplier';
import { TemplateFucType, itemTab } from '../../../../../app/model/enum/enums';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-drug',
  templateUrl: './drug.component.html',
  styleUrls: ['./drug.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DrugComponent implements OnInit , AfterContentChecked{
  UOM;
  Status = STATUS;
  priceAdjusmentType = PRICE_ADJUSTMENT_TYPE;

  category = [];

  instructions = [];
  dosageInstructions = [];
  itemTypeOptions = [];
  itemStatusOptions = [];
  filterOptions: any[] =[];

  cautionary = [];
  ngSelectValue = [];

  drugFormGroup: FormGroup;
  searchFrm: FormGroup;
  drugSearchFormControl: FormControl;

  searchDrugHttpRequest: Subscription = null;
  isLoading: boolean;
  /** Datatable */
  drugList: Array<Drug>;
  /** Datatable */
  page: Page = new Page();
  isFilter: boolean;
  categoryList: Observable<any>;
  typeahead: Subject<string> = new Subject<string>();
  tableOffset = 0;
  supplierList: Supplier[] =[];
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;
  filter = new ItemFilter();
  sorts: any;
  actionButtonList = [
    {
      action:'Edit',
      label:'Edit'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'BLOCKED',
      label:'Set to Blocked'
    },
  ];

  constructor(
    private itemService: ItemService,
    private alertService: AlertService,
    private drugInstructionQuery: DrugInstructionQuery,
    private dosageInstructionQuery: DosageInstructionQuery,
    private drugUomQuery: DrugUomQuery,
    private modalService: BsModalService,
    private currentDrugItemQuery: CurrentDrugItemQuery,
    private router: Router,
    private fb: FormBuilder,
    private instructionService: CategoriesService,
    private cdr: ChangeDetectorRef,
    private supplierService: SupplierService,
    private masterDataService: MasterDataService,
  ) {

    this.drugFormGroup = this.itemService.getDrugMasterForm();
    this.category = this.itemService.getCategoryOptions();
    this.UOM = this.drugUomQuery.getAll().map((uom) => uom.uom);
    this.itemService.categoryOptionStore.subscribe((options) => (this.category = [...options]));

    this.instructions = itemService.getInstructionsOptions();
    this.dosageInstructions = itemService.getDosageInstructionsOptions();

    this.cautionary = itemService.getCautionaryOptions();

    itemService.instructionOptionsStore.subscribe((options) => (this.instructions = [...options]));
    itemService.dosageInstructionOptionsStore.subscribe((options) => (this.dosageInstructions = [...options]));

    itemService.cautionaryOptionStore.subscribe((options) => (this.cautionary = [...options]));

    this.subscribeChanges();

    this.drugSearchFormControl = this.itemService.getDrugSearchFormControl();
    this.subscribeDrugSearchValueChange();

    this.page.size = 50;
    this.page.pageNumber = 0;

    this.itemTypeOptions =    filterOptionsJson.itemTypeOptions.sort((a, b) => a.value.localeCompare(b.value));
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;
  }

  subscribeChanges() {
    this.drugFormGroup.valueChanges.subscribe((res) => {
      const invalid = [];
      const controls = this.drugFormGroup.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          invalid.push(name);
        }
      }
    });

    this.drugFormGroup
      .get('precautionaryInstructions')
      .valueChanges.pipe(distinctUntilChanged())
      .subscribe((value) => {
        this.drugFormGroup.get('indications').patchValue(value, { emitEvent: false });
      });
  }

  subscribeDrugSearchValueChange() {
    this.drugSearchFormControl.valueChanges.pipe(distinctUntilChanged(), debounceTime(50)).subscribe((value) => {
      const keyword = (value || '').toLowerCase();

      if (keyword) {
        if (this.searchDrugHttpRequest) {
          this.searchDrugHttpRequest.unsubscribe();
        }

        this.searchDrugHttpRequest = this.itemService.searchItem(keyword).subscribe((res) => {
          if (res.statusCode === 'S0000') {
            // this.page = res.;
            this.drugList = res.payload.map((item) => item.item).filter((item) => item.itemType === 'DRUG');
            this.isLoading = false;
          }
        });
      } else {
        this.reloadDrug();
      }
    });
  }

  ngOnInit() {
    this.populateSearchForm();
    this.reloadDrug();
    this.getSupplierList();
  }

  reloadDrug() {

    this.itemService.searchItemWithFilter(this.filter,this.page).subscribe(
      (res) => {
        if (res.statusCode === 'S0000') {
          this.page.pageNumber = res['pageNumber'];
          this.page.totalPages = res['totalPages'];
          this.page.totalElements = res['totalElements'];
          this.drugList = res.payload.map((item) => item.item).filter((item) => item);
          this.isLoading = false;
          this.cdr.detectChanges();
        }
      },
      (err) => {
        this.isLoading = false;
        this.alertService.error('Internal Server Error...!');
      }
    );
  }

  // onRowSelect(event: Drug , mode?: string) {
  //   let drugItem: Drug;
  //   if (event) {
  //     drugItem = event;
  //     this.cautionary = [
  //       ...this.itemService.getCautionaryOptions(),
  //       { value: drugItem.precautionaryInstructions, label: drugItem.precautionaryInstructions },
  //     ];
  //     let initialState = {
  //       drugItem: drugItem,
  //       mode: mode
  //     };
  //      this.modalService.show(DrugMasterFromComponent, {
  //       initialState,
  //       class: 'modal-lg stock-approval-reject-popup',
  //     });
  //
  //     this.modalService.onHide.subscribe((e) => {
  //       if(e && e.message) {
  //       }
  //     });
  //
  //     this.subscribeChanges();
  //
  //     markFormGroupTouched(this.drugFormGroup);
  //
  //
  //   }
  // }

  onSaveClicked($event) {
    const data = <Drug>this.drugFormGroup.getRawValue();
    if (this.drugFormGroup.get('id').value) {
      // UPDATE
      this.itemService
        .editDrug(this.drugFormGroup.get('id').value, this.itemService.processDataBeforeSubmission(data))
        .subscribe(
          (res) => {
            this.reloadDrug();
            this.alertService.success('Drug Updated Successfully.');
            this.resetFormGroup();
            this.drugSearchFormControl.reset();
          },
          (err) => {
            this.alertService.error(JSON.stringify(err));
          }
        );
    } else {
      // NEW
      this.itemService.addDrug(this.itemService.processDataBeforeSubmission(data)).subscribe(
        (res) => {
          this.reloadDrug();
          this.alertService.success('Drug Added Successfully.');
          this.resetFormGroup();
          this.drugSearchFormControl.reset();
        },
        (err) => {
          this.alertService.error(JSON.stringify(err));
        }
      );
    }
  }

  onDeleteClicked(event) {
    const confirmationResult = confirm(`Are you sure want to remove ${event.name}?`);
    if (confirmationResult === true) {
      this.itemService.removeDrug(event.id).subscribe(
        (res) => {
          this.reloadDrug();
          this.alertService.success('Drug Removed Successfully.');
        },
        (err) => {
          this.alertService.error(JSON.stringify(err));
        }
      );
    }
  }

  onInstructionChange(instructionOption) {
    const instruction = this.drugInstructionQuery.getAll().find((item) => item.code === instructionOption.value);

    if (instruction) {
      this.drugFormGroup.patchValue({ instruction }, { emitEvent: false });
    }
  }

  onDosageInstructionChange(instructionOption) {
    const dosageInstruction = this.dosageInstructionQuery
      .getAll()
      .find((item) => item.code === instructionOption.value);

    if (dosageInstruction) {
      this.drugFormGroup.patchValue({ dosageInstruction }, { emitEvent: false });
    }
  }

  addCustomNgSelectTag(value) {
    return { label: value, value: value };
  }

  onCancelClicked(event) {
    this.resetFormGroup();
  }

  resetFormGroup() {
    this.drugFormGroup.get('code').enable();
    this.drugFormGroup = this.itemService.getDrugMasterForm();

    this.cautionary = [...this.itemService.getCautionaryOptions()];
    this.category = [...this.itemService.getCategoryOptions()];
    this.subscribeChanges();
  }

  getInstruction(instructionCode) {
    return (
      (
        this.drugInstructionQuery.getAll().find((instruction) => instruction.code === instructionCode) || {
          instruct: '',
        }
      ).instruct || ''
    );
  }

  getDosageInstruction(dosageInstructionCode) {
    return (
      (
        this.dosageInstructionQuery.getAll().find((instruction) => instruction.code === dosageInstructionCode) || {
          instruct: '',
        }
      ).instruct || ''
    );
  }


  get ItemType(){
    return ItemType;
  }
  get ITEM_TYPE_DROPDOWN_LIST() {
    return ITEM_TYPE_DROPDOWN_LIST;
  }

  onActionChange($event: unknown, row: Drug) {

    switch ($event) {
      case 'view':
      case 'Edit':
        this.itemService.setCurrentDrugItemId(row.id);
        this.router.navigate(['/pages/item/master/item', $event.toLocaleLowerCase(), row.itemType ,itemTab.GENERAL]);
        break;
      case 'ACTIVE':
      case 'INACTIVE':
      case 'BLOCKED':
       this.changeStatus(row.id , $event)
        break;

    }

  }

   getItemType(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()
  }
  changeStatus(id ,status) {
    this.itemService.changeStatus(id , status).subscribe(res => {
      if(res.message === "Success") {
        this.ngSelectValue = [];
        let index = this.drugList.findIndex(x => x.id === res.payload.item.id);
        this.drugList[index] = res.payload.item;
        this.drugList =[...this.drugList];
      }
    })
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    if(this.isFilter) {
      this.onSearch();
    } else {
      this.reloadDrug();
    }

  }

  private populateSearchForm() {

    this.filterOptions =      filterOptionsJson.searchFilter.slice(0, 2);
    this.categoryList = this.getCategoryList();

    this.searchFrm = this.fb.group({
      itemType: ['ALL'],
      status: ['ALL'],
      category: [],
      searchText: '',
      filterOptionId: 0,
      withBrokenUomMatrix: [false],
      withBrokenIntegration: [false],
    });
  }

  onSearch() {
    this.isLoading = true;
    this.isFilter = true;

    const { itemType ,status,category ,searchText ,filterOptionId , withBrokenUomMatrix, withBrokenIntegration } = this.searchFrm.value;
    this.filter = new ItemFilter();

    switch (filterOptionId) {
      case 0: {
        this.filter.name = searchText;
        break;
      }
      case 1: {
        this.filter.code = searchText;
        break;
      }
    }

    this.filter.type = itemType;
    this.filter.status = status;
    this.filter.category = category;
    this.filter.withBrokenUomMatrix = withBrokenUomMatrix;
    this.filter.withBrokenIntegration = withBrokenIntegration;

    if(this.sorts){
      this.filter.sort = this.sorts[0];
    }

    if(itemType && itemType === 'ALL') {this.filter.type = '';}
    if(status && status === 'ALL')     {this.filter.status = '';}
    if(category && category === 'ALL') {this.filter.category = '';}


    this.itemService.searchItemWithFilter(this.filter,this.page).subscribe((res) => {
        if (res.message	=== "Success") {
          this.page.pageNumber = res['pageNumber'];
          this.page.totalPages = res['totalPages'];
          this.page.totalElements = res['totalElements'];
          this.drugList = res.payload.map((item) => item.item).filter((item) => item);
          this.isLoading = false;
        }
      },
      (err) => {
        this.isLoading = false;
        this.alertService.error('Internal Server Error...!');
      });

  }

  getCategoryList() {
    return this.typeahead.pipe(source =>
      this.instructionService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload));
  }

  getSupplierList() {
    this.supplierService.listAllSuppliers().subscribe(res => {
        if(res.message === "Success") {
          this.supplierList = [];
          if(res.payload.length > 0) {
            this.supplierList = res.payload;
          }
        }
      }
    )
  }

  getSupplierName(itemId: any) {
    if(this.supplierList.length > 0) {
      let item = this.supplierList.find(item => item.id === itemId);
      return item ? item.name : ''
    }
  }
  get TemplateFucType() {
    return TemplateFucType
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  returnTextAmount(price: any) {
    return price ? price/100 : '0';
  }
  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };
  sort($event: any) {

    this.page.size = 50;
    this.page.pageNumber = 0;

    this.isFilter = true;
    this.sorts = $event.sorts;
    this.searchFrm.patchValue({
      sort: $event.sorts[0]
    })
    this.onSearch();
  }
}
