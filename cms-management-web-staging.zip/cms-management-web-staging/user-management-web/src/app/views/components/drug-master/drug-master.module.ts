import { SharedModule } from './../../../shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DrugMasterRoutingModule } from './drug-master-routing.module';
import { DrugComponent } from './drug/drug.component';
import {ItemMasterFormComponent} from './drug/Forms/item-master-form/item-master-form.component';
import {VaccineFormComponent} from './drug/Forms/vaccine-form/vaccine-form.component';
import {MultiCostSubItemComponent} from './drug/Forms/multi-cost-sub-item/multi-cost-sub-item.component';
import {MasterDataModule} from "../master-data/master-data.module";
import {DrugFromComponent} from './drug/Forms/drug-from/drug-from.component';
import {PackageFormComponent} from './drug/Forms/package-form/package-form.component';
import {SupplierModule} from '../supplier/supplier.module';
import {MultiVaccineSubItemsComponent} from './drug/Forms/multi-vaccine-sub-items/multi-vaccine-sub-items.component';
import { MasterTabListComponent } from './drug/Forms/master-tab-list/master-tab-list.component';
@NgModule({
    imports: [
        CommonModule,
        DrugMasterRoutingModule,
        SharedModule,
        MasterDataModule,
        SupplierModule
    ],
  declarations: [DrugComponent,
    ItemMasterFormComponent,
    VaccineFormComponent ,
    DrugFromComponent,
    MultiCostSubItemComponent,
    MultiVaccineSubItemsComponent,
    PackageFormComponent,
    MasterTabListComponent]
})
export class DrugMasterModule { }
