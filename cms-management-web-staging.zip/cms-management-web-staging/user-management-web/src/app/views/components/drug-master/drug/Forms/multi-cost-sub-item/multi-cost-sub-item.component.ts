import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {ControlContainer, FormArray, FormBuilder, FormGroup} from '@angular/forms';
import { ItemService } from '../../../../../../services/item.service';
import {Drug} from '../../../../../../objects/request/Drug';
import { cloneDeep } from 'lodash';
import {ChargeItemQuery} from '../../../../../../state/charge-item/charge-item.query';

@Component({
  selector: 'app-multi-cost-sub-item',
  templateUrl: './multi-cost-sub-item.component.html',
  styleUrls: ['./multi-cost-sub-item.component.scss']
})
export class MultiCostSubItemComponent implements OnInit , OnChanges  {
  @Input () isResetForm: boolean;
  @Input() drugFormGroup: FormGroup;
  @Input () mode: string;
  @Input () listItemsEdit: Drug;

  @Output() onDataChange? = new EventEmitter<any>();

  isReadOnly: boolean;
  lisAllItemList: any[];
  form: FormGroup;

  constructor(private controlContainer: ControlContainer,
              private fb: FormBuilder,
              private chargeItemQuery: ChargeItemQuery,
              private  itemService: ItemService) {

  }

  ngOnInit() {
    this.lisAllItemList = this.chargeItemQuery.getAllItems();
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.listItemsEdit && this.listItemsEdit) {
      // this.drugFormGroup = this.itemService.populateDrugMasterForm(this.listItems);
      this.populateForm();
    }
    if (changes.isResetForm && this.isResetForm && this.drugFormGroup)  {
      this.drugFormGroup.reset();
    }
    if (changes.mode && this.mode) {
      this.isReadOnly = (this.mode === 'view');
    }
  }

  deleteSubItemGroup(i: number) {
    const add = this.drugFormGroup.get('multiCostSubItems') as FormArray;
    add.removeAt(i);
  }


  addSubItem(): void {
    this.subItems.push(this.itemService.getMultiCostSubItem());
  }

  get subItems(): FormArray {
    if(this.drugFormGroup)
     return this.drugFormGroup.get('multiCostSubItems') as FormArray;
  }

  populateForm() {
   this.subItems.clear();
    if(this.listItemsEdit.multiCostSubItems.length > 0) {
      this.listItemsEdit.multiCostSubItems.forEach(c => {
        const costForm = this.itemService.getMultiCostSubItem();
        costForm.patchValue(c);
        this.subItems.push(costForm);
      });
    }
    if(this.mode === 'view') {
      this.drugFormGroup.disable();
    }

  }

  itemChange(item: any, index: number , itemId: any) {
    if(this.subItems.controls.length > 1 && itemId) {
      let arr =  cloneDeep(this.subItems);
      arr.removeAt(index);
      let find = arr.controls.find(r => r.controls.itemRefId.value == itemId.id);
      this.subItems.controls[index].get('itemRefId').setErrors(null);
       if(find) {
         this.subItems.controls[index].get('itemRefId').setErrors({duplicate: true});
       }
    }
  }
}
