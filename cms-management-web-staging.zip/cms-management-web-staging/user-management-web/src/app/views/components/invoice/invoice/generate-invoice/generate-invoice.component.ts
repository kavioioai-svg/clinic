import { Component, OnInit } from '@angular/core';
import {BsModalService} from 'ngx-bootstrap';
import {PaymentInfoComponent} from '../payment-info/payment-info.component';
import {MasterDataTab, TemplateFucType} from '../../../../../model/enum/enums';
import {PayeeInfoComponent} from '../payee-info/payee-info.component';
import {ActivatedRoute} from '@angular/router';
import {InvoiceService} from '../../../../../services/eClaims/invoice.service';
import {GeneratedInvoice} from '../../../../../objects/eClaims/generated-invoice';
import {
  StockAdjustmentApprovalComponent
} from '../../../inventory/inventory/stock-adjustment/stock-adjustment-approval/stock-adjustment-approval.component';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { MasterDataService } from '../../../../../services/master-data-service/master-data.service';
import {PaymentRef} from "../../../../../objects/eClaims/payment-ref";
import {AlertService} from "../../../../../services/alert.service";
import moment = require("moment");
import {
  DISPLAY_DATE_FORMAT,
  DB_FULL_DATE_FORMAT,
} from '../../../../../constants/app.constants';
import { PrintInfoComponent } from '../print-template/print-template.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-generate-invoice',
  templateUrl: './generate-invoice.component.html',
  styleUrls: ['./generate-invoice.component.scss']
})
export class GenerateInvoiceComponent implements OnInit {

  payments: any[] =[];
  invoiceList: any[] =[];
  backBtnText =  '< Back to Invoice';
  backUrl =  `pages/invoice/main/1`;
  invoiceId: string;
  generatedInvoice: GeneratedInvoice;
  claimInfo: any;
  totalAmount: number;
  Gst: number = 0;
  grandTotal: number;
  totalRecievedAmount: number = 0;
  rowTotalAmount: number = 0;
  selectedClinic;
  clinicsList: any[];
  genForm: FormGroup;
  private operation: 'view' | 'edit';
  constructor(private modalService: BsModalService,
              private activatedRoute: ActivatedRoute,
              private masterDataService: MasterDataService,
              private clinicQuery: ClinicQuery,
              private fb: FormBuilder,
              private invoiceService: InvoiceService,
              private alert: AlertService,
  ) { }

  ngOnInit() {
    this.genForm = this.fb.group(
      {
        requestClinicId: [undefined, Validators.required],
        remarks: [undefined]

      });
    this.activatedRoute.params.subscribe(params => {
      this.invoiceId = params['id'];
      this.operation = params['operation'];
      if (params['id']) {
        this.getInvoiceById(params['id']);
      }
    });

  }

  getToInfo(invoice: any[]) {
    this.clinicsList = this.clinicQuery.getAll();
    if(invoice && invoice.length > 0 && this.clinicsList.length > 0)
      this.selectedClinic = this.clinicsList.find(c => c.clinicCode == invoice[0].clinicCode);
    if(this.selectedClinic) {
      this.genForm.patchValue({
        requestClinicId: this.selectedClinic.id,
      })
    }
  }

  addPayment() {
    let initialState = {
      generatedInvoice: this.generatedInvoice,

    };
    const stockModel = this.modalService.show(PaymentInfoComponent, {
      initialState,
      class: 'modal-lg add-clinic-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message == "Success") {
        this.getInvoiceById(e.payload.id);
      }
    });
  }

  onShowRow(itemRefId: any, i: number) {
    document.getElementById(itemRefId).classList.toggle('show');
  }

  addPayee() {
    let initialState = {
      generatedInvoice: this.generatedInvoice,

    };

    const stockModel = this.modalService.show(PayeeInfoComponent, {
      initialState,
      class: 'modal-lg add-clinic-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message == "Success") {

      }
    });
  }

  getInvoiceById(id: string){
    this.invoiceService.getGeneratedInvoicesById(id).subscribe(invoice => {
        if(invoice && invoice.message == "Success") {
          this.generatedInvoice = invoice.payload;
          this.claimInfo =  invoice.payload.invoicesData[0].claim;
          this.genForm.patchValue({
            remarks: invoice.payload.remarks
          })
          this.getToInfo(invoice.payload.invoicesData);
        }
      },
      error => console.log(error)
    )
  }

  getReceivedAmount() {
    this.totalRecievedAmount = 0;
    if(this.generatedInvoice && this.generatedInvoice.payments.length > 0) {
      this.generatedInvoice.payments.forEach(r => {
        this.totalRecievedAmount += r.amount ? r.amount : 0;
      });
    }
    return  this.totalRecievedAmount;
  }

  onDelete(payment: any) {
    this.invoiceService.deletePaymentRef(payment.id, this.generatedInvoice.id).subscribe(result => {
      this.alert.success('Record deleted successfully');
      this.getInvoiceById(this.invoiceId)
    }, error => {
      this.alert.error('Record deletion unsuccessful');
    });
  }

  getBalanceAmount() {
    return Math.max(this.generatedInvoice.amount -  this.totalRecievedAmount, 0);
  }
  get TemplateFucType() {
    return TemplateFucType;
  }

  clinicChange(e) {
    this.selectedClinic = e;
    this.genForm.patchValue({
      requestClinicId: this.selectedClinic.id,
    });
  }

  approve() {
    this.invoiceService.approveInvoice(this.genForm.value, this.invoiceId).subscribe(invoice => {
        if(invoice && invoice.message == "Success") {
          this.generatedInvoice = invoice.payload;
          this.claimInfo =  invoice.payload.invoicesData[0].claim;
          this.getToInfo(invoice.payload.invoicesData);

          this.alert.success("Invoice saved successfully")
          setTimeout(() =>{this.masterDataService.goBack('pages/invoice/main/1');},3000);


        }
      },
      error => this.alert.error(JSON.stringify(error.error.message))
    )
  }

  printInvoice() {
    // let initialState = {
    //   generatedInvoice: this.generatedInvoice,
    //
    // };
    const printModel = this.modalService.show(PrintInfoComponent, {
      class: 'modal-lg add-clinic-popup',
      initialState: {
        onClose: () => {
          printModel.hide();
        },
        onSubmit: () => {
          this.invoiceService.printInvoice(this.invoiceId).subscribe(invoice => {
              var decodedStringAtoB = atob(invoice.message);
              this.printPage(decodedStringAtoB);
            },
            error => console.log(error)
          )
          printModel.hide();
        }
      }

    });

    // this.modalService.onHide.subscribe((e) => {
    //
    //   this.invoiceService.printInvoice(this.invoiceId).subscribe(invoice => {
    //     var decodedStringAtoB = atob(invoice.message);
    //     this.printPage(decodedStringAtoB);
    //   },
    //     error => console.log(error)
    //   )
    //
    // });


  }

  printPage(decodedStringAtoB: string){
    const WinPrint = window.open();
    WinPrint.document.write('  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" >');
    WinPrint.document.write('<body >');
    WinPrint.document.write('<header >');
    WinPrint.document.write('</header >');
    WinPrint.document.write(decodedStringAtoB);
    WinPrint.document.write('</body></html>');
    WinPrint.document.close();

    // setTimeout(function() {
    //   WinPrint.print();
    //   WinPrint.close();
    // }, 5000);
    WinPrint.onload = ()=>{
      WinPrint.print();
    }
  }


  emailInvoice() {
    this.invoiceService.emailInvoice(this.invoiceId).subscribe(invoice => {
        this.masterDataService.goBack('pages/invoice/main/1');
      },
      error => console.log(error)
    )
  }

  generateReference(payment: PaymentRef) {
    switch (payment.paymentType) {
      case "CASH":
        return '';
      case "CHEQUE":
        return `${payment.chequeNo}(${payment.bankDetails})`;
      case "CREDIT_CARD":
        return `${payment.trxNumber}`
      case "BANK_TRANSFER":
        return `${payment.trxNumber}(${payment.bankDetails})`
      default:
        return '';
    }
  }

  getTax() {
    return this.generatedInvoice.tax;
  }

  formatDate(paymentDate: string) {
    return paymentDate ? moment(paymentDate).format(DISPLAY_DATE_FORMAT): '';
  }

  onToggleClicked(invoice: any) {
    document.getElementById(invoice.invoiceId).classList.toggle('show');
    let ele =$('#'+invoice.invoiceId+'-arrow')
    if(ele.hasClass('icon-up-open')) {
      $(ele).addClass('icon-down-open')
      $(ele).removeClass('icon-up-open')
    } else {
      $(ele).removeClass('icon-down-open')
      $(ele).addClass('icon-up-open')
    }
  }

}
