import {Component, OnInit} from '@angular/core';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import {TemplateFucType} from '../../../../../model/enum/enums';
import {ActivatedRoute, Router} from '@angular/router';
import {Page} from '../../../../../model/page';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AlertService} from '../../../../../services/alert.service';
import {Invoice} from '../../../../../objects/eClaims/invoice';
import {InvoiceFilter} from '../../../../../objects/eClaims/invoice-filter';
import {InvoiceService} from '../../../../../services/eClaims/invoice.service';
import {CurrentMedicalCoverageService} from '../../../medical-coverage/current-medical-coverage.service';
import {Clinic} from '../../../../../objects/response/Clinic';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {StoreStatusQuery} from "../../../../../state/store-status/store-status.query";
import {MedicalCoverageQuery} from "../../../../../state/medical-coverage/medical-coverage.query";
import moment = require("moment");
import {BsModalService} from "ngx-bootstrap";
import {GenerateInvoiceConfirmComponent} from "./generate-invoice-confirm/generate-invoice-confirm.component";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {validateOrder} from "../../../../../validators/claim-payment-validator";
import {merge} from "rxjs";

const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.scss']
})
export class InvoiceListComponent implements OnInit {
  isLoading:boolean;
  isDisableSelectAll: any;
  allItemsSelected: any;
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;
  invoiceList: Invoice[] = [];
  page: Page = new Page();
  tableOffset = 0;
  searchFrm: FormGroup;
  statusOptions = [];
  selectedItemSet: Invoice[] = [];
  invoiceGenerating: boolean;
  clinics: Array<Clinic>;
  constFilter: any
  actionButtonList: any = [
    {
      action: 'generate-invoice',
      label: 'Generate invoice'
    }
  ];
  private medicalCoverages: any;
  medicalCoveragesArray=[]
  selected = [];

  constructor( private router: Router,
               private fb: FormBuilder,
               private alertService: AlertService,
               private medicalCoverageService: CurrentMedicalCoverageService,
               private invoiceService: InvoiceService,
               private clinicQuery: ClinicQuery,
               private storeStatusQuery: StoreStatusQuery,
               private activatedRoute: ActivatedRoute,
               private medicalCoverageQuery: MedicalCoverageQuery,
               private modalService: BsModalService,
               private masterDataService: MasterDataService,
  ) {
    this.page.size = 50;
    this.page.pageNumber = 0;
  }

  ngOnInit() {
    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate() ,
      null ,
      'bottom', 'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
      moment().toDate() ,
      moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
      'bottom');

    this.populateData();
    this.onSubmitSearch();

    // this.masterDataService.onTabChange$.subscribe(result => {
    //   console.log(111,"tab change")
    //   if (result) {
    //     this.isLoading = true;
    //     setTimeout(() => {
    //       this.isLoading = false;
    //     }, 500)
    //   }
    // });
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    this.getFilterList();
  }

  isRowDisabled(row) {
    return !['INITIAL'].includes(row.invoiceState) || row.generatedInvoiceStatus === 'GENERATED';
  }

  onSelectAll($event: Event) {
    console.log(555,$event);
    if (!this.allItemsSelected) {
      console.log(666,this.invoiceList);
      this.invoiceList
        .filter(a => a.invoiceState == 'INITIAL' )
        .forEach(row => {
          if (!this.isRowDisabled(row)) {
            this.selectedItemSet.push(row);
          }
        });
      console.log(777,this.invoiceList);
      this.allItemsSelected = true;
    } else {
      this.selectedItemSet = [];
      this.allItemsSelected = false;
    }
  }

  onItemCheckBoxChange(row: any) {
    if (this.selectedItemSet.some(r => r.invoiceNumber == row.invoiceNumber)) {
      this.selectedItemSet = this.selectedItemSet.filter(r => r.invoiceNumber != row.invoiceNumber);
      this.allItemsSelected = false
    } else {
      this.selectedItemSet.push(row);
      this.allItemsSelected = this.invoiceList.filter(a => a.invoiceState === 'INITIAL').length == this.selectedItemSet.length;
    }
    this.selected = this.selectedItemSet
  }

  checkSelectedItem(row: any) {
    let selectedList: any[] = Array.from(this.selectedItemSet);
    return !!selectedList.some(r => r == row);
  }

  onSubmitSearch() {
    this.page.pageNumber = 0;
    this.getFilterList();
  }

  onActionChange($event: unknown, row: any) {

    switch ($event) {
      case 'view':
        this.router.navigate([`/pages/invoice/generate-invoice/${row.id}`]);
        break;
      case 'generate-invoice':
        this.doGenerateInvoice([row]);
        break;
    }

  }
  get TemplateFucType() {
    return TemplateFucType
  }

  getFilterList() {
    var filter : InvoiceFilter
    if(this.constFilter){
      filter = new InvoiceFilter(this.searchFrm.getRawValue(), this.constFilter);
    }
    else{
      filter = new InvoiceFilter(this.searchFrm.getRawValue());
    }


    this.invoiceService
      .listAllInvoices(filter, this.page)
      .subscribe(
        (list: any) => {
          if(list) {
            this.invoiceList = list.payload.content;
            this.page.pageNumber = list.payload['pageNumber'];
            this.page.totalPages = list.payload['totalPages'];
            this.page.totalElements = list.payload['totalElements'];
          }
        },
        err => {
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  populateData() {
    this.searchFrm = this.fb.group({
      startDate: [moment().subtract(12, 'months').toDate(), Validators.required],
      endDate: [moment().toDate(), Validators.required],
      clinicId: [null],
      status: ['ALL'],
      medicalCoverageType: [],
      invoiceNo: [],
      type: [],
      payerId:[],
      medicalCoveragesArray:[]
    });
    this.activatedRoute.queryParams.subscribe(params => {
      if (params['invoiceNos']) {
        this.searchFrm.patchValue({
          invoiceNo: params['invoiceNos']
        })
      }
      console.log(111,"tab change")
      // if (result) {
      this.isLoading = true;
      this.onSubmitSearch();
      setTimeout(() => {
        this.isLoading = false;
      }, 500)
      // }
    })

    this.searchFrm.get('endDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), false));
    this.searchFrm.get('startDate').setValidators(validateOrder( this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), true));

    merge(
      this.searchFrm.get('startDate').valueChanges,
      this.searchFrm.get('endDate').valueChanges
    ).subscribe(()=>{
      this.searchFrm.get('endDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), false));
      this.searchFrm.get('startDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), true));
    })

    this.storeStatusQuery.select().subscribe(loading => {
      this.medicalCoveragesArray = this.medicalCoverageQuery.getAll()
      this.clinics = this.clinicQuery.getAll();
      // @ts-ignore
      this.medicalCoverages = Object.fromEntries(this.medicalCoverageQuery.getAll().map(a => [a.id, a.name]))
    })
    this.statusOptions = filterOptionsJson.InvoiceStatusOptions;
    // this.statusOptions = filterOptionsJson.InvoiceStatusOptions.filter(r => r.id ==  0 ||  r.id ==  1  || r.id ==  2);

    this.searchFrm.get('startDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('',null , moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate() , null, 'right', 'right');
    });
  }

  generateInvoice() {
    let selectedList: any[] = Array.from(this.selectedItemSet);
    // this.doGenerateInvoice(selectedList);
    let modalRef = this.modalService.show(GenerateInvoiceConfirmComponent,{
      initialState: {
        invoices: Array.from(selectedList),
        onClose: () => {
          modalRef.hide();
        },
        onSubmit: (selectedList) => {
          this.doGenerateInvoice(selectedList);
          modalRef.hide();
        }
      }
    })
  }

  doGenerateInvoice(selectedList: any[]) {
    let invoices: any[] = [];
    this.invoiceGenerating = true;
    selectedList.forEach(res => {
      invoices.push({
        salesOrderId:res.salesOrderId,
        invoiceNo: res.invoiceNumber,
        caseId: res.caseId
      })
    });
    this.invoiceService.createGeneratedInvoice(invoices).subscribe(res => {
      if(res.message === "Success") {
        this.invoiceGenerating = false;
        this.alertService.success("Generated invoices created successfully")
        this.getFilterList();
        setTimeout(() =>{
          this.router.navigate(['../1'], {
            queryParams: {invoiceNos: res.payload},
            relativeTo: this.activatedRoute
          })

        },1000);
        //this.getFilterList();
        this.onSubmitSearch();

      }
    }, error => {
      this.alertService.error(JSON.stringify(error.error));
      this.invoiceGenerating = false;
      this.getFilterList();
    })
  }


  getMedicalCoverageTypeList() {
    return this.medicalCoverageService.medicalCoverageTypes;
  }

  onChangeItem(event:any){
    if(event != undefined && event.value != "All"){
      this.searchFrm.get('payerId').setValue(null)
      this.medicalCoveragesArray = this.medicalCoverageQuery.getAll().filter(e=> e.type == event.value)
    }
  }
  onSort($event: any) {
    this.page.pageNumber = 0;
    this.page.size = 50;

    const filter = new InvoiceFilter(this.searchFrm.getRawValue(), $event);
    this.constFilter = $event;
    this.getFilterList();
  }
  findMedicalCoverageName(medicalCoverageId: any) {
    return this.medicalCoverages[medicalCoverageId] || '';
  }
}
