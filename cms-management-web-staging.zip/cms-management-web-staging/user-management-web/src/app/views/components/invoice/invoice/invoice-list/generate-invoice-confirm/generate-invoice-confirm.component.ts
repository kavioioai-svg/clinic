import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {DatatableComponent} from "@swimlane/ngx-datatable";

@Component({
  selector: 'app-generate-invoice-confirm',
  templateUrl: './generate-invoice-confirm.component.html',
  styleUrls: ['./generate-invoice-confirm.component.scss']
})
export class GenerateInvoiceConfirmComponent implements OnInit {
  @Input() invoices: any[]
  formGroup: FormGroup
  @ViewChild(DatatableComponent,{ static: true }) table: DatatableComponent;
  @Input() onClose?: (resp: any | undefined) => void
  @Input() onSubmit: (invoices: any) => void

  constructor(
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.formGroup = this.fb.group({
      invoiceTime:[],
      invoiceNumber: [],
      invoiceState: [],
      invoiceType: [],
      patientName: [],
      clinicCode: [],
      payableAmount: [],
      taxAmount: [],
      clinicGroupLegalName: []
    });


  }

  closeModal() {
    this.formGroup.reset()
    if (this.onClose) this.onClose(undefined)
  }

  onCreate() {
    this.onSubmit( this.invoices);
  }

}
