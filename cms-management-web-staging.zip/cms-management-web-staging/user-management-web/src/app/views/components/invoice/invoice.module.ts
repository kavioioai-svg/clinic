import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceComponent } from './invoice/invoice.component';
import {BsDropdownModule, TabsModule} from 'ngx-bootstrap';
import {NgxPermissionsModule} from 'ngx-permissions';
import {InvoiceRoutingModule} from './invoice-routing.module';
import {InventoryModule} from '../inventory/inventory.module';
import { GenerateInvoiceComponent } from './invoice/generate-invoice/generate-invoice.component';
import {PaymentInfoComponent} from './invoice/payment-info/payment-info.component';
import {SharedModule} from '../../../shared.module';
import { PayeeInfoComponent } from './invoice/payee-info/payee-info.component';
import { PrintInfoComponent } from './invoice/print-template/print-template.component';
import { GenerateInvoiceConfirmComponent } from './invoice/invoice-list/generate-invoice-confirm/generate-invoice-confirm.component';



@NgModule({

  declarations: [InvoiceComponent, GenerateInvoiceComponent, PayeeInfoComponent, PrintInfoComponent, GenerateInvoiceConfirmComponent],
  imports: [
    CommonModule,
    InvoiceRoutingModule,
    TabsModule,
    NgxPermissionsModule,
    InventoryModule,
    BsDropdownModule,
    SharedModule,

  ],

  entryComponents: [PaymentInfoComponent , PayeeInfoComponent, PrintInfoComponent, GenerateInvoiceConfirmComponent]
})
export class InvoiceModule { }
