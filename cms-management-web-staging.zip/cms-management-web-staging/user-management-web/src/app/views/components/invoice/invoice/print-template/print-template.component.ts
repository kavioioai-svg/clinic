import {Component, Input, OnInit, Output} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap/modal';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import moment = require('moment');
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {BsModalService} from 'ngx-bootstrap';
import {GeneratedInvoice} from '../../../../../objects/eClaims/generated-invoice';
import {InvoiceService} from '../../../../../services/eClaims/invoice.service';
import {DB_FULL_DATE_FORMAT} from "../../../../../constants/app.constants";
const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-print-template',
  templateUrl: './print-template.component.html',
  styleUrls: ['./print-template.component.scss']
})
export class PrintInfoComponent implements OnInit {
  startDatePickerConfig: DatePickerConfig;
  date = new Date();
  printForm: FormGroup;
  generatedInvoice: GeneratedInvoice;
  printTypes: any = filterOptionsJson.printTypes;
  @Input() onSubmit: (numb:any) => void
  @Input() onClose?: (resp: any | undefined) => void
  @Output() selectedTemplate :any;
  constructor(  public bsModalRef: BsModalRef,
                private fb: FormBuilder,
                private modalService: BsModalService,
                private invoiceService: InvoiceService,
  ) { }

  ngOnInit() {
    this.populateData();
  }

  closeModel() {
    // this.bsModalRef.hide();
    this.printForm.reset()
    if (this.onClose) this.onClose(undefined)
  }

  populateData() {
    this.printForm = this.fb.group({
      printType: [,Validators.required],
    });
  }
  onSelect($event:any){
    this.selectedTemplate = $event.id
    // this.selectedTemplate.emit($event.id);
  }

  save() {
    // this.bsModalRef.hide();
    this.onSubmit(this.selectedTemplate)
  }
}
