import { Component, OnInit } from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-payee-info',
  templateUrl: './payee-info.component.html',
  styleUrls: ['./payee-info.component.scss']
})
export class PayeeInfoComponent implements OnInit {

  constructor(  public bsModalRef: BsModalRef,) { }

  ngOnInit() {
  }

  closeModel() {
    // this.modalService.setDismissReason();
    this.bsModalRef.hide();
  }
}
