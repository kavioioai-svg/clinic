import { Component, OnInit } from '@angular/core';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import moment = require('moment');
import {MasterDataTab, TemplateFucType} from '../../../../../model/enum/enums';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Page} from '../../../../../model/page';
import {AlertService} from '../../../../../services/alert.service';
import { InvoiceService } from '../../../../../services/eClaims/invoice.service';
import {InvoiceFilter} from '../../../../../objects/eClaims/invoice-filter';
import {CurrentMedicalCoverageService} from '../../../medical-coverage/current-medical-coverage.service';
import {BsModalService} from "ngx-bootstrap";
import {PrintInfoComponent} from "../print-template/print-template.component";
import {validateOrder} from "../../../../../validators/claim-payment-validator";
import {merge} from "rxjs";
const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-generated-invoice',
  templateUrl: './generated-invoice.component.html',
  styleUrls: ['./generated-invoice.component.scss']
})
export class GeneratedInvoiceComponent implements OnInit {

  isDisableSelectAll: any;
  allItemsSelected: any;
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;
  invoiceList: any[] = [];
  page: Page = new Page();
  tableOffset = 0;
  searchFrm: FormGroup;
  statusOptions = [];
  medicalCoverageType:any;
  invoiceNumber:any;


  constructor(private router: Router,
              private fb: FormBuilder,
              private invoiceService: InvoiceService,
              private medicalCoverageService: CurrentMedicalCoverageService,
              private activatedRoute: ActivatedRoute,
              private alertService: AlertService,
              private modalService: BsModalService,) {
    this.page.size = 50;
    this.page.pageNumber = 0;
  }


  ngOnInit() {
    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate() ,
      null ,
      'right', 'right');
    this.endDatePickerConfig = new DatePickerConfig('',
      moment().toDate() ,
      moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
      'right',
      'right');
    this.medicalCoverageType='All'
    this.populateData();
    this.onSubmitSearch();
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    this.getFilterList();
  }

  onSelectAll($event: Event) {

  }


  onSubmitSearch() {
    this.page.pageNumber = 0;
    this.getFilterList();
  }
  viewInvoice(row:any){
    this.onActionChange('view', row)
  }

  onActionChange($event: unknown, row: any) {
    switch ($event) {
      case 'view':
        this.router.navigate([`/pages/invoice/generate-invoice/view/${row.id}`]);
        break;
      case 'edit':
        this.router.navigate([`/pages/invoice/generate-invoice/edit/${row.id}`]);
        break;
      case 'delete':
        this.deleteInvoice(row.id);
        break;
      case 'approve':
        this.approveInvoice(row)
        break;
      case 'print':
        this.printInvoice(row.id);
        break;
    }
  }
  get TemplateFucType() {
    return TemplateFucType
  }
  getGeneratedInvoiceList() {
    this.invoiceService.listAllGeneratedInvoices().subscribe(invoice => {
        if(invoice) {

        }
      },
      error => console.log(error)
    )
  }

  getFilterList() {
    const filter = new InvoiceFilter(this.searchFrm.getRawValue(), null,'generated');
    if(this.medicalCoverageType && this.medicalCoverageType === 'All')     {filter.medicalCoverageType = null;}
    this.invoiceService
      .searchGeneratedInvoice(filter, this.page)
      .subscribe(
        list => {
          console.log(list)
          if(list.message === "Success") {
            this.invoiceList = list.payload.content;
            this.page.pageNumber = list.payload['pageNumber'];
            this.page.totalPages = list.payload['totalPages'];
            this.page.totalElements = list.payload['totalElements'];
          }

        },
        err => {
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  populateData() {
    this.searchFrm = this.fb.group({
      startDate: [moment().subtract(1, 'months').toDate(), Validators.required],
      endDate: [moment().toDate(), Validators.required],
      customerId: [null],
      status: ['ALL'],
      medicalCoverageType: ['All'],
      invoiceNos: [null],
      invoiceNumber: ['']
    });

    this.searchFrm.get('endDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), false));
    this.searchFrm.get('startDate').setValidators(validateOrder( this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), true));

    merge(
      this.searchFrm.get('startDate').valueChanges,
      this.searchFrm.get('endDate').valueChanges
    ).subscribe(()=>{
      this.searchFrm.get('endDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), false));
      this.searchFrm.get('startDate').setValidators(validateOrder(this.searchFrm.get('startDate'), this.searchFrm.get('endDate'), true));
    })

    this.activatedRoute.queryParams.subscribe(params => {
      if (params['invoiceNos']) {
        this.searchFrm.patchValue({
          invoiceNumber: params.invoiceNos.join(',')
        });
        this.onSubmitSearch()
        // this.router.navigate(['.'], {
        //   queryParams: {
        //     fromDate: this.searchFrm.value.fromDate ? moment(this.searchFrm.value.fromDate).format(DISPLAY_DATE_FORMAT) : null,
        //     endDate: this.searchFrm.value.endDate ? moment(this.searchFrm.value.endDate).format(DISPLAY_DATE_FORMAT) : null,
        //     invoiceNumber: this.searchFrm.value.invoiceNumber ? this.searchFrm.value.invoiceNumber.split(',') : null,
        //   },
        //   relativeTo: this.activatedRoute
        // })
      }
    })

    this.statusOptions = filterOptionsJson.InvoiceStatusOptions.filter(r => r.id !==  1 &&  r.id !=  2  );
    this.searchFrm.get('medicalCoverageType').valueChanges.subscribe(val=>{
      this.medicalCoverageType = val
    })
    this.searchFrm.get('startDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('',null , moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate() , null, 'right', 'right');
    });
  }
  getMedicalCoverageTypeList() {
    return this.medicalCoverageService.medicalCoverageTypes;
  }
  getClinicCode(invoice) {
    if(invoice ) {
      return invoice.clinicCode
    } else {
      return '';
    }

  }

  private deleteInvoice(id) {
    this.invoiceService.deleteInvoiceById(id).subscribe(invoice => {
      if(invoice) {
        this.alertService.success('Invoice deleted successfully');
        this.page.pageNumber = 0;
        this.getFilterList();
      }
    } ,err => {
      this.alertService.error(JSON.stringify(err.error));
    })
  }

  actionButtonList(row: any) {
    return [
      {action: 'view', label: 'View'},
      {action: 'edit', label: 'Add Payment', condition: row.status === 'INVOICED'},
      {action: 'edit', label: 'Edit ', condition: row.status !== 'INVOICED'},
      {action: 'approve', label: 'Invoice ', condition: row.status === 'INITIAL'},
      {action: 'print', label: 'Print ', condition: row.status !== 'INITIAL'},
      {action: 'email', label: 'Email ', condition: row.status !== 'INITIAL'},
      {action: 'delete', label: 'Delete', condition: row.status === 'INITIAL'},
    ].filter(r => r.condition !== false);
  }

  printInvoice(id:any) {
    const printModel = this.modalService.show(PrintInfoComponent,{
      class: 'modal-lg add-clinic-popup',
      initialState:{
        onClose: () => {
          printModel.hide();
        },
        onSubmit:()=>{
          this.invoiceService.printInvoice(id).subscribe(invoice => {
              var decodedStringAtoB = atob(invoice.message);
              this.printPage(decodedStringAtoB);
              this.alertService.success('Invoice printed successfully');
            },
            error => {
              console.log(error)
              this.alertService.error(error.error.message);
            }
          )
          printModel.hide();
        }
      }
    })

  }

  printPage(decodedStringAtoB: string){
    // const WinPrint = window.open('', '', 'letf=10,top=10,width="450",height="250",toolbar=1,scrollbars=1,status=1');
    const WinPrint = window.open();
    WinPrint.document.write('  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" >');
    WinPrint.document.write('<body >');
    WinPrint.document.write('<header >');
    WinPrint.document.write('</header >');
    WinPrint.document.write(decodedStringAtoB);
    WinPrint.document.write('</body></html>');
    WinPrint.document.close();

    // setTimeout(function() {
    //   WinPrint.print();
    //   WinPrint.close();
    // }, 5000);
    WinPrint.onload = ()=>{
      WinPrint.print();
    }
  }

  private approveInvoice(row) {
    this.invoiceService.approveInvoice(row, row.id).subscribe(invoice => {
      if(invoice) {
        this.alertService.success('Invoice approved successfully');
        this.page.pageNumber = 0;
        this.getFilterList();
      }
    } ,err => {
      this.alertService.error(JSON.stringify(err.error));
    })
  }

  onSort($event: any) {
    const filter = new InvoiceFilter(this.searchFrm.getRawValue(), $event,'generated');
    if(this.medicalCoverageType && this.medicalCoverageType === 'All')     {filter.medicalCoverageType = null;}

    this.page.pageNumber = 0;

    this.invoiceService
      .searchGeneratedInvoice(filter, this.page)
      .subscribe(
        list => {
          if(list.message === "Success") {
            this.invoiceList = list.payload.content;
            this.page.pageNumber = list.payload['pageNumber'];
            this.page.totalPages = list.payload['totalPages'];
            this.page.totalElements = list.payload['totalElements'];
          }

        },
        err => {
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }
}
