import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { InvoiceTab} from '../../../model/enum/enums';
import {InvoiceComponent} from './invoice/invoice.component';
import {GenerateInvoiceComponent} from './invoice/generate-invoice/generate-invoice.component';

const routes: Routes = [
  {
    path: '',
    //   canActivateChild: [NgxPermissionsGuard],
    data: {
      title: 'Invoice',
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: `main/${InvoiceTab.INVOICE}` },
      { path: 'main/:tabIndex', component: InvoiceComponent,
        pathMatch: 'prefix',
        data: {
          requiresLogin: true,
        },
      },
      { path: 'generate-invoice/:operation/:id', component: GenerateInvoiceComponent},
      { path: 'generate-invoice/:operation', component: GenerateInvoiceComponent},
      { path: 'generate-invoice/:id', component: GenerateInvoiceComponent},

    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvoiceRoutingModule { }
