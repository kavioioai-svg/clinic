import {Component, Input, OnInit} from '@angular/core';
import {BsModalRef} from 'ngx-bootstrap/modal';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import moment = require('moment');
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {BsModalService} from 'ngx-bootstrap';
import {GeneratedInvoice} from '../../../../../objects/eClaims/generated-invoice';
import {InvoiceService} from '../../../../../services/eClaims/invoice.service';
import {DB_FULL_DATE_FORMAT} from "../../../../../constants/app.constants";
import {AlertService} from "../../../../../services/alert.service";
const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-payment-info',
  templateUrl: './payment-info.component.html',
  styleUrls: ['./payment-info.component.scss']
})
export class PaymentInfoComponent implements OnInit {
  startDatePickerConfig: DatePickerConfig;
  date = new Date();
  paymentForm: FormGroup;
  generatedInvoice: GeneratedInvoice;
  paymentTypes: any = filterOptionsJson.paymentTypes;
  constructor(  public bsModalRef: BsModalRef,
                private fb: FormBuilder,
                private modalService: BsModalService,
                private invoiceService: InvoiceService,
                private alert: AlertService,
  ) { }

  ngOnInit() {
    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate() ,
      null ,
      'right', 'right');
    this.populateData();
  }

  closeModel() {
    this.bsModalRef.hide();
  }

  populateData() {
    this.paymentForm = this.fb.group({
      paymentDate: [moment().format('DD-MM-YYYY'), Validators.required],
      description: [],
      amount: [, Validators.required],
      adminFee: [],
      paymentType: [, Validators.required],
      bankDetails: [],
      chequeNo: [],
      trxNumber: [],
      remark: [],
    });

  }
  onPaymentTypeChange(event:any){
    if(event.value==='CREDIT_CARD'){
      this.paymentForm.get('chequeNo').clearValidators()
      this.paymentForm.get('bankDetails').clearValidators()
      this.paymentForm.get('trxNumber').setValidators(Validators.required)
    }else if(event.value === 'CHEQUE'){
      this.paymentForm.get('trxNumber').clearValidators()
      this.paymentForm.get('bankDetails').setValidators(Validators.required)
      this.paymentForm.get('chequeNo').setValidators(Validators.required)
    }else if(event.value === 'BANK_TRANSFER'){
      this.paymentForm.get('chequeNo').clearValidators()
      this.paymentForm.get('bankDetails').setValidators(Validators.required)
      this.paymentForm.get('trxNumber').setValidators(Validators.required)
    }else{
      this.paymentForm.get('bankDetails').clearValidators()
      this.paymentForm.get('trxNumber').clearValidators()
      this.paymentForm.get('chequeNo').clearValidators()
    }

    this.paymentForm.get('bankDetails').updateValueAndValidity()
    this.paymentForm.get('trxNumber').updateValueAndValidity()
    this.paymentForm.get('chequeNo').updateValueAndValidity()
  }

  save() {
    let value = this.paymentForm.getRawValue();
    let payments = this.generatedInvoice.receivedAmount + value.amount
    if(this.generatedInvoice.amount >= payments){
      this.invoiceService.createPaymentRef({
        ...value,
        paymentDate: moment(value.paymentDate, 'DD-MM-YYYY').add(1, 'days'),
      }, this.generatedInvoice.id).subscribe(res => {
          if(res.message === "Success") {
            this.modalService.setDismissReason(res);
            this.bsModalRef.hide();
          }
        },
        error => this.bsModalRef.hide());
    }else{
      this.alert.error(`Remaining payable amount is only : ${(this.generatedInvoice.amount-this.generatedInvoice.receivedAmount).toFixed(2)}`);
    }
  }
}
