import { Component, OnInit } from '@angular/core';
import { InvoiceTab } from '../../../../model/enum/enums';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiInventoryService} from '../../../../services/api-inventory.service';
import {MasterDataService} from "../../../../services/master-data-service/master-data.service";

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit {
  activeIndex: any;
  isEnableProceedBtn: boolean;
  tabChangeIndex: any;
  selectedItems: any;

  constructor( private router: Router,
               private activatedRoute: ActivatedRoute,
               private masterDataService: MasterDataService,
  ) { }

  ngOnInit() {

    this.activatedRoute.params.subscribe(params => {
      this.activeIndex = params['tabIndex'];
    });
  }

  get InvoiceTab() {
    return InvoiceTab;
  }

  onTabSelected(tab: InvoiceTab) {
    this.masterDataService.isOnTabChange(true);
    this.isEnableProceedBtn = this.selectedItems > 0 && tab == InvoiceTab.INVOICE;
    this.router.navigate([`pages/invoice/main/${tab}`]);
    this.tabChangeIndex = tab;
  };

}
