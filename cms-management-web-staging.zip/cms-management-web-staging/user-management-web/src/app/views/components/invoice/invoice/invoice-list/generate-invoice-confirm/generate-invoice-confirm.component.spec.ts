import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateInvoiceConfirmComponent } from './generate-invoice-confirm.component';

describe('GenerateInvoiceConfirmComponent', () => {
  let component: GenerateInvoiceConfirmComponent;
  let fixture: ComponentFixture<GenerateInvoiceConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateInvoiceConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateInvoiceConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
