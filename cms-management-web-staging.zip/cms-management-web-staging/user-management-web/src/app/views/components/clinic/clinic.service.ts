import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { AppConfigService } from "../../../services/app-config.service";
import { HttpResponseBody } from "../../../objects/response/HttpResponseBody";

@Injectable({
  providedIn: 'root'
})
export class ClinicService {

  private API_CMS_MANAGEMENT_URL: string;

  constructor(private http: HttpClient, appConfig: AppConfigService) {
    this.API_CMS_MANAGEMENT_URL = appConfig.getConfig().API_CMS_MANAGEMENT_URL
  }

  getOperatingHours(clinicId: string) {
    const url = `${this.API_CMS_MANAGEMENT_URL}/appointment/find/calendar/${clinicId}`;

    return this.http.post<HttpResponseBody>(url, {})
  }

  updateOperationHours(clinicId: string, body) {
    const url = `${this.API_CMS_MANAGEMENT_URL}/appointment/update/work-hour/${clinicId}`;

    return this.http.post<HttpResponseBody>(url, body)
  }

  updateClinicHolidays(clinicId: string, body) {
    const url = `${this.API_CMS_MANAGEMENT_URL}/appointment/update/holiday/${clinicId}`;

    return this.http.post<HttpResponseBody>(url, body)
  }
}
