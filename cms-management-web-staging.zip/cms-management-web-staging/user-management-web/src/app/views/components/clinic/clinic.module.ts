import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClinicRoutingModule } from './clinic-routing.module';
import { ClinicMasterComponent } from './clinic-master/clinic-master.component';
import { SharedModule } from '../../../shared.module';
import { SelectListModule } from '../../../components/select-list/select-list.module';
import { TimePickerComponent } from "./time-picker/time-picker.component";

@NgModule({
  imports: [
    CommonModule,
    ClinicRoutingModule,
    SharedModule,
    SelectListModule
  ],
  exports: [
    TimePickerComponent
  ],
    declarations: [ClinicMasterComponent, TimePickerComponent]
})
export class ClinicModule { }
