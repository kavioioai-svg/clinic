import { NgxPermissionsGuard } from 'ngx-permissions';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClinicMasterComponent } from './clinic-master/clinic-master.component';

const routes: Routes = [{
  path: '',
  canActivateChild: [NgxPermissionsGuard],
  data: {
    title: 'Clinic Module'
  },
  children: [
    { path: '', pathMatch: 'full', redirectTo: 'all' },
    {
      path: 'all',
      component: ClinicMasterComponent
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClinicRoutingModule { }
