import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ClinicMasterComponent } from "./clinic-master.component";
import { TestingModule } from "../../../../test/testing.module";

describe("ClinicMasterComponent", () => {
  let component: ClinicMasterComponent;
  let fixture: ComponentFixture<ClinicMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      declarations: [ClinicMasterComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
