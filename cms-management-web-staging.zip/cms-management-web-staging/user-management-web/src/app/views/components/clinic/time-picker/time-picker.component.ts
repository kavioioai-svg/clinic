import { Component, Input, OnInit } from '@angular/core';
import { Time } from "@angular/common";

@Component({
  selector: 'app-time-picker',
  templateUrl: './time-picker.component.html',
  styleUrls: ['./time-picker.component.scss']
})
export class TimePickerComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

  @Input() time: Time = {
    hours: 0,
    minutes: 0
  }

  @Input() label

  setHours(hour: number) {
    hour = Number(hour)
    if (hour >= 0 && hour <= 23) {
      this.time.hours = hour
    } else {
      this.time.hours = 0
    }
  }

  setMinutes(min: number) {
    min = Number(min)
    if (min >= 0 && min <= 59) {
      this.time.minutes = min
    } else {
      this.time.minutes = 0
    }
  }

}

enum TimeLiteral {
  HOUR, MINUTE
}
