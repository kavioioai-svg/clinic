import { FormGroup } from '@angular/forms';
import { Clinic } from '../../../objects/response/Clinic';
import { FormBuilder, Validators } from '@angular/forms';
import { Injectable } from '@angular/core';
import { validatePhoneNumber, validatewhatsAppNumber } from '../../../validators/PhoneNumberValidator';
import { DoctorQuery } from '../../../state/doctor/doctor.query';

@Injectable({
  providedIn: 'root',
})
export class ClinicFormService {
  constructor(private fb: FormBuilder, private doctorQuery: DoctorQuery) {}

  /** FORM **/
  getClinicMasterForm() {
    return this.fb.group({
      id: [],
      name: ['', Validators.required],
      groupName: [],
      emailAddress: [],
      address: this.getClinicAddressFormGroup(),
      faxNumber: ['', validatePhoneNumber],
      contactNumber: ['', validatePhoneNumber],
      status: ['ACTIVE'],
      heCode: [''],
      uen: [''],
      clinicCode: ['', Validators.required],
      anchorDoctors: [],
      stockAutoApprovalEnabled: [],
      stockAutoApprovalMaxAmount: [],
      attendingDoctorId: [],
      clinicStaffUsernames: [],
      clinicGroupLegalName: [],
      clinicFeatures: [],
      whatsAppNumber: ['', validatewhatsAppNumber]
    });
  }

  populateClinicMasterForm(data: Clinic) {
    const addrSplit = this.splitAddress(data);
    const newForm = this.fb.group({
      id: [data.id],
      name: [data.name, Validators.required],
      groupName: [data.groupName],
      emailAddress: [data.emailAddress],
      address: this.fb.group({
        attentionTo: [data.address.attentionTo],
        address: [addrSplit.address, Validators.required],
        postalCode: [data.address.postalCode, Validators.required],
        unit: [addrSplit.unitNo],
      }),
      faxNumber: [data.faxNumber, validatePhoneNumber],
      contactNumber: [data.contactNumber, validatePhoneNumber],
      status: ['ACTIVE'],
      heCode: [data.heCode],
      uen: [data.uen],
      clinicCode: [data.clinicCode, Validators.required],
      anchorDoctors: [data.anchorDoctors],
      attendingDoctorId: [data.attendingDoctorId],
      stockAutoApprovalEnabled: [data.stockAutoApprovalEnabled],
      stockAutoApprovalMaxAmount: [data.stockAutoApprovalMaxAmount],
      clinicStaffUsernames: [data.clinicStaffUsernames],
      clinicGroupLegalName: [data.clinicGroupLegalName],
      clinicFeatures: [data.clinicFeatures],
      whatsAppNumber: [data.whatsAppNumber, validatewhatsAppNumber]
    });
    this.triggerValidation(newForm);
    return newForm;
  }

  getClinicAddressFormGroup() {
    return this.fb.group({
      attentionTo: [],
      address: ['', Validators.required],
      postalCode: ['', Validators.required],
      unit: [],
    });
  }

  triggerValidation(formGroup: FormGroup) {
    if (formGroup) {
      Object.keys(formGroup.controls).forEach((key) => {
        if (formGroup.get(key) instanceof FormGroup) {
          this.triggerValidation(<FormGroup>formGroup.get(key));
        }
        formGroup.get(key).markAsTouched();
        formGroup.get(key).updateValueAndValidity();
      });
    }
  }
  /** FORM **/

  //   getCaOnly(clinicStaffUsernames: []) {

  //     clinicStaffUsernames.map(val => {

  //     });
  // }

  processDataBeforeSubmission(data: Clinic) {
    if (!data.id) {
      delete data.id;
    }

    this.processAddress(data);
    this.processClinicStaffUsernames(data);
    return data;
  }

  processAddress(data: Clinic) {
    data.address.address = data.address.address + '\n' + data.address.unit;

    return data;
  }

  processClinicStaffUsernames(data: Clinic) {
    const currentClinicStaffUsernames = data.clinicStaffUsernames;
    const currentAttendingDoctorId = data.attendingDoctorId;
    const newClinicStaffUsernames = new Array();

    currentClinicStaffUsernames.map((val) => {
      newClinicStaffUsernames.push(val);
    });

    currentAttendingDoctorId.map((val) => {
      const doctor = this.doctorQuery.getEntity(val);
      if (doctor && newClinicStaffUsernames.indexOf(doctor.username) < 0) {
        newClinicStaffUsernames.push(doctor.username);
      }
    });
    data.clinicStaffUsernames = newClinicStaffUsernames;
  }

  splitAddress(data: Clinic) {
    const tempData = data.address.address && data.address.address.split('\n');

    const address = (tempData && tempData[0]) || '';
    const unitNo = (tempData && tempData[1]) || '';
    return { address: address, unitNo: unitNo };
  }
}
