import * as moment from "moment";
import Helpers from "../../service/Helpers";
import { Time } from "@angular/common";

const dateFormat = 'DD-MM-YYYY'

class ClinicHoliday {
  date: string
  startTime: Time;
  endTime: Time;
  remarks: string

  constructor(date: string, startTime: Time, endTime: Time, remarks: string) {
    this.date = date;
    this.startTime = startTime;
    this.endTime = endTime;
    this.remarks = remarks;
  }

  static fromJSON(json: object): ClinicHoliday {
    const date = Helpers.getStr(json, 'calendarDayYear.date')
    const startTime = Helpers.getStr(json, 'start')
    const endTime = Helpers.getStr(json, 'end')
    const remarks = Helpers.getStr(json, 'remarks')

    return new ClinicHoliday(
      moment(date, dateFormat).format(dateFormat),
      Helpers.getTimeFromStr(startTime),
      Helpers.getTimeFromStr(endTime),
      remarks
    )
  }

  static fromJSONArray(jsonArr: Array<any>): Array<ClinicHoliday> {
    return jsonArr
      .map(json => {
        return {
          ...json,
          dateAndTime: moment(`${json.calendarDayYear.date} ${json.start}`, 'DD-MM-YYYY hh:mm')
        }
      })
      .sort((json1, json2) => json1.dateAndTime.valueOf() - json2.dateAndTime.valueOf())
      .map(json => ClinicHoliday.fromJSON(json))
  }

  static toRequestObj(clinicHolilday: ClinicHoliday): any {
    const {
      date,
      startTime: { hours: shr, minutes: smin },
      endTime: { hours: ehr, minutes: emin },
      remarks
    } = clinicHolilday

    return {
      calendarDayYear: {
        date: date
      },
      start: `${Helpers.padNumber(shr)}:${Helpers.padNumber(smin)}`,
      end: `${Helpers.padNumber(ehr)}:${Helpers.padNumber(emin)}`,
      remarks
    }
  }

  static toRequestObjs(clinicHolidays: Array<ClinicHoliday>): Array<any> {
    return clinicHolidays.map(holiday => ClinicHoliday.toRequestObj(holiday))
  }
}

export default ClinicHoliday
