import { Clinic } from './../../../../objects/response/Clinic';
import { ApiCmsManagementService } from './../../../../services/api-cms-management.service';
import { ClinicFormService } from '../clinic-form.service';
import { FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { AlertService } from '../../../../services/alert.service';
import { Doctor } from '../../../../objects/Doctor';
import { StoreService } from '../../../../services/store.service';
import { StoreStatus } from '../../../../objects/StoreStatus';
import { UserWithRole } from '../../../../objects/response/UserWithRole';
import { ClinicQuery } from '../../../../state/clinic/clinic.query';
import { DoctorQuery } from '../../../../state/doctor/doctor.query';
import { UserListQuery } from '../../../../state/user-list/user-list.query';
import { StoreStatusQuery } from '../../../../state/store-status/store-status.query';
import { ClinicService } from '../clinic.service';
import OperationHours from '../model/operation-hours';
import ClinicHoliday from '../model/clinic-holiday';
import Day from '../model/day';
import { Time } from '@angular/common';
import allClinicFeatures from '../model/clinic-features';
import { NgxPermissionsService } from 'ngx-permissions';
import { DISPLAY_DATE_FORMAT } from '../../../../constants/app.constants';
import * as moment from 'moment';

@Component({
  selector: 'app-clinic-master',
  templateUrl: './clinic-master.component.html',
  styleUrls: ['./clinic-master.component.scss'],
})
export class ClinicMasterComponent implements OnInit {
  clinicFormGroup: FormGroup;

  doctorList: Array<Doctor>;
  anchorDoctorList: Array<Doctor>;

  userList: Array<UserWithRole>;
  clinicList: Array<Clinic>;
  rows: Array<Clinic>;
  clinicFeatures = [];

  filteredDoctorList: Array<any>;
  filteredUserList: Array<any>;

  searchFieldInput = '';

  operationHours: Array<OperationHours> = [];
  clinicHolidays: Array<ClinicHoliday> = [];

  days = [
    { name: 'Monday', value: Day.MONDAY },
    { name: 'Tuesday', value: Day.TUESDAY },
    { name: 'Wednesday', value: Day.WEDNESDAY },
    { name: 'Thursday', value: Day.THURSDAY },
    { name: 'Friday', value: Day.FRIDAY },
    { name: 'Saturday', value: Day.SATURDAY },
    { name: 'Sunday', value: Day.SUNDAY },
  ];
  
  booleanSelection = [
    { value: true, label: 'YES' },
    { value: false, label: 'NO' }
  ];

  time = { hour: 13, minute: 30 };

  constructor(
    private clinicService: ClinicFormService,
    private apiCmsManagementService: ApiCmsManagementService,
    private alertService: AlertService,
    private store: StoreService,
    private clinicQuery: ClinicQuery,
    private doctorQuery: DoctorQuery,
    private userListQuery: UserListQuery,
    private storeStatusQuery: StoreStatusQuery,
    private service: ClinicService,
    private permissionService: NgxPermissionsService
  ) {
    this.clinicFormGroup = this.clinicService.getClinicMasterForm();
    this.clinicFormGroup.disable();
  }

  ngOnInit() {
    this.storeReadinessSubscription();
    this.storeSubscription();
    this.populateData(true);
    this.hasAdvancePermission();
  }

  private populateData(reload: Boolean = false) {
    this.doctorList = this.doctorQuery.getActiveDoctor();
    this.clinicList = this.clinicQuery.getAll();
    this.rows = this.clinicQuery.getAll();
    this.anchorDoctorList = this.doctorQuery.getActiveAnchorDoctor();
    this.userList = this.userListQuery.getAll().filter((each) => each.status === 'ACTIVE');
    this.getClinicFeatures();

    if (reload) {
      this.store.retrieveDoctors();
      this.store.retrieveClinics();
      this.store.retrieveUsers();
    }
    this.updateFilterResult();
  }

  private getClinicFeatures(): void {
    this.apiCmsManagementService.getAllClinicFeatures().subscribe(
      (result) => {
        if (result.statusCode === 'S0000') {
          const clinicFeatures = [];

          result.payload.map((data) => {
            clinicFeatures.push({
              label: data.replace(/_/g, ' '),
              value: data,
            });
          });

          this.clinicFeatures = clinicFeatures;
        }
      },
      (error) => {
        this.alertService.error(error.error.message);
      }
    );
  }

  storeReadinessSubscription() {
    this.storeStatusQuery.select().subscribe((val: StoreStatus) => {
      const isStoreReady = val.isLoaded && !val.isReseting;
      const hasError = val.hasError && val.isLoaded && !val.isReseting;

      if (isStoreReady && !hasError) {
        this.populateData();
      }
    });
  }

  storeSubscription() {
    this.doctorQuery.selectAll().subscribe((data) => {
      this.doctorList = (<Array<Doctor>>data).filter((each) => each.status === 'ACTIVE');
      this.anchorDoctorList = this.doctorList.filter((each) => each.doctorGroup === 'ANCHOR');
    });

    this.clinicQuery.selectAll().subscribe((data) => {
      this.clinicList = <Array<Clinic>>data;
      this.rows = <Array<Clinic>>data;
    });

    this.userListQuery.selectAll().subscribe((data) => {
      this.userList = (<Array<UserWithRole>>data).filter((each) => each.status === 'ACTIVE');
    });
  }

  handleClinicHolidayDate(ev, index) {
    this.clinicHolidays[index].date = moment(ev).format(DISPLAY_DATE_FORMAT);
  }

  removeClinicHoliday(index) {
    this.clinicHolidays.splice(index, 1);
  }

  removeOperationHour(index) {
    this.operationHours.splice(index, 1);
  }

  addClinicHoliday() {
    const startTime: Time = {
      hours: 0,
      minutes: 0,
    };

    const endTime: Time = {
      hours: 23,
      minutes: 59,
    };

    this.clinicHolidays.push(new ClinicHoliday(moment(new Date()).format(DISPLAY_DATE_FORMAT), startTime, endTime, ''));
  }

  addOperationHour() {
    const startTime: Time = {
      hours: 0,
      minutes: 0,
    };

    const endTime: Time = {
      hours: 23,
      minutes: 59,
    };

    this.operationHours.push(new OperationHours(Day.SUNDAY, startTime, endTime));
  }
  onDayChanged(event, index) {
    this.operationHours[index].day = event;

  }
  onSaveClicked(event) {
    let toProceed = false;

    const data = <Clinic>this.clinicFormGroup.value;

    const confirmationResult = confirm(`Are you sure want to edit ${data.name}?`);
    if (confirmationResult === true) {
      toProceed = true;
    }

    if (toProceed) {
      if (this.clinicFormGroup.get('id').value) {
        if (this.hasAdvancePermission()) {
          const operationHrReq = OperationHours.toRequestObjs(this.operationHours);
          
          const clinicHolidayReq = ClinicHoliday.toRequestObjs(this.clinicHolidays);
          const clinicId = this.clinicFormGroup.get('id').value;
          this.service.updateOperationHours(clinicId, operationHrReq).subscribe((res) => {
            console.info('updated operation hrs', res);
            this.operationHours = [];
          });
          this.service.updateClinicHolidays(clinicId, clinicHolidayReq).subscribe((res) => {
            console.info('updated clinic holidays', res);
            this.clinicHolidays = [];
          });
        }

        // UPDATE
        this.apiCmsManagementService
          .modifyClinic(this.clinicFormGroup.get('id').value, this.clinicService.processDataBeforeSubmission(data))
          .subscribe(
            (res) => {
              this.resetForm();
              this.store.retrieveClinics();
              this.alertService.success('Clinic Updated Successfully.');
            },
            (err) => {
              this.alertService.error(JSON.stringify(err));
            }
          );
      } else {
        // NEW
        this.apiCmsManagementService.addClinic(this.clinicService.processDataBeforeSubmission(data)).subscribe(
          (res) => {
            this.alertService.success('Clinic Added Successfully.');
            this.resetForm();
            this.store.retrieveClinics();
          },
          (err) => {
            this.alertService.error(JSON.stringify(err));
          }
        );
      }
    }
  }

  onEditClicked(event) {
    if (this.hasAdvancePermission()) {
      this.getOperatingHours(event.id);
    }

    this.clinicFormGroup.enable();
    // this.alertService.success(null);
    this.clinicFormGroup.get('clinicCode').disable();
    // this.clinicService.triggerValidation(this.clinicFormGroup);
    let clinicItem: Clinic;
    if (event) {
      clinicItem = event;
      this.clinicFormGroup = this.clinicService.populateClinicMasterForm(clinicItem);
      this.clinicFormGroup.markAsDirty();
      this.clinicFormGroup.updateValueAndValidity();

      this.filteredDoctorList = [];
      this.doctorQuery.getActiveDoctor().forEach((doc) => {
        this.filteredDoctorList.push({
          value: doc.id,
          label: doc.displayName,
          selected: this.clinicFormGroup.get('attendingDoctorId').value.includes(doc.id),
        });
      });

      this.filteredUserList = [];
      this.userList.forEach((user) => {
        this.filteredUserList.push({
          value: user.userName,
          label: user.userName,
          selected: this.clinicFormGroup.get('clinicStaffUsernames').value.includes(user.userName),
        });
      });

      window.scrollTo(0, 0);
    }
  }

  onCancelClicked(event) {
    this.operationHours = [];
    this.clinicHolidays = [];
    this.resetForm();
    this.populateData(true);
  }

  resetForm() {
    this.filteredDoctorList = undefined;
    this.filteredUserList = undefined;
    this.clinicFormGroup.reset();
    this.clinicFormGroup.disable();
  }

  getOperatingHours(clinicId: string) {
    this.service.getOperatingHours(clinicId).subscribe((res) => {
      const payload = res.payload;

      this.operationHours = OperationHours.fromJSONArray(payload.operationHours);
      this.clinicHolidays = ClinicHoliday.fromJSONArray(payload.clinicHolidays);
    });
  }

  getDoctors(rowData) {
    let doctorNames = [];
    doctorNames =
      rowData &&
      rowData.map((val) => {
        const doctor = this.doctorQuery.getEntity(val);
        const doctorName = doctor && doctor.displayName;
        return doctorName;
      });

    return doctorNames;
  }

  handleOperationHrsChange(ev, index) {
    this.operationHours[index].day = ev.target.value;
  }

  searchClinic(event) {
    this.searchFieldInput = event.target.value.toLowerCase();
    this.updateFilterResult();
  }

  updateFilterResult() {
    this.rows = [];
    this.rows = this.clinicList.filter((item) => {
      const searchKeyword = (item.name || '').toLowerCase().includes(this.searchFieldInput);

      const searchKeyword2 = (item.clinicCode || '').toLowerCase().includes(this.searchFieldInput);

      return searchKeyword || searchKeyword2;
    });
  }

  hasAdvancePermission() {
    return !!this.permissionService.getPermission('ROLE_CLINIC_ADVANCE_SETTINGS');
  }
}
