import Helpers from "../../service/Helpers";
import Day from "./day";
import { Time } from "@angular/common";

class OperationHours {
  day: Day
  startTime: Time;
  endTime: Time;

  constructor(day: Day, startTime: Time, endTime: Time) {
    this.day = day;
    this.startTime = startTime;
    this.endTime = endTime;
  }

  static fromJSON(json: object): OperationHours {
    const day: Day = Helpers.getStr(json, 'calendarDayWeek.dayOfWeek') as Day
    const startTime = Helpers.getStr(json, 'start')
    const endTime = Helpers.getStr(json, 'end')

    return new OperationHours(day, Helpers.getTimeFromStr(startTime), Helpers.getTimeFromStr(endTime))
  }

  static fromJSONArray(jsonArr: Array<any>): Array<OperationHours> {
    return jsonArr.map(json => OperationHours.fromJSON(json))
  }

  static toRequestObj(operationHours: OperationHours): any {
    const { day, startTime: { hours: shr, minutes: smin }, endTime: { hours: ehr, minutes: emin } } = operationHours

    return {
      calendarDayWeek: {
        dayOfWeek: day
      },
      start: `${Helpers.padNumber(shr)}:${Helpers.padNumber(smin)}`,
      end: `${Helpers.padNumber(ehr)}:${Helpers.padNumber(emin)}`
    }
  }

  static toRequestObjs(operationHoursArr: Array<OperationHours>): Array<any> {
    return operationHoursArr.map(operationHours => OperationHours.toRequestObj(operationHours))
  }
}

export default OperationHours
