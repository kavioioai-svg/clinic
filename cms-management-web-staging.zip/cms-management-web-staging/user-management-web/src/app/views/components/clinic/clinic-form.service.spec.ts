import { TestBed, inject } from "@angular/core/testing";

import { ClinicFormService } from "./clinic-form.service";
import { TestingModule } from "../../../test/testing.module";

describe("ClinicService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      providers: [ClinicFormService]
    });
  });

  it("should be created", inject([ClinicFormService], (service: ClinicFormService) => {
    expect(service).toBeTruthy();
  }));
});
