import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService} from 'ngx-bootstrap';
import { GST } from '../../../../constants/app.constants';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl } from '@angular/forms';
import { Subject,} from 'rxjs';
import { StoreService } from '../../../../services/store.service';
import { MedicalCoverageQuery } from '../../../../state/medical-coverage/medical-coverage.query';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../../services/auth.service';
import { CaseSummeryBillAdjDetailsComponent } from '../../../../components/claim/claim-bill-adjustment/case-summery-bill-adj-details/case-summery-bill-adj-details.component';
import { AlertService } from '../../../../services/alert.service';
import { ApiPatientVisitService } from '../../../../services/api-patient-visit.service';
import { BillAdjustmentReason } from '../../../../objects/BillAdjustment';
import { ApiDocumentService } from '../../../../services/api-document-service';
import moment = require('moment');
import { AdjustmentReasonQuery } from '../../../../state/adjustment-reason/adjustment-reason.query';

@Component({
  selector: 'bill-adjustment-summary',
  templateUrl: './bill-adjustment-summary.component.html',
  styleUrls: ['./bill-adjustment-summary.component.scss']
})
export class BillAdjustmentSummaryComponent implements OnInit {
  primaryDoc;
  secondaryDoc;

  paymentMethodSelections = [
    { value: 'CASH', label: 'CASH' },
    { value: 'NETS', label: 'NETS' },
    { value: 'VISA', label: 'VISA' },
    { value: 'MASTER_CARD', label: 'MASTER CARD' },
    { value: 'AMERICAN_EXPRESS', label: 'AMERICAN EXPRESS' },
    { value: 'JCB', label: 'JCB' },
    { value: 'OTHER_CREDIT_CARD', label: 'OTHER CREDIT CARD' },
    { value: 'CHEQUE', label: 'CHEQUE' },
    { value: 'GIRO', label: 'GIRO' },
    { value: 'FAVEPAY', label: 'FAVEPAY' },
    { value: 'GRABPAY', label: 'GRABPAY' },
    { value: 'STRIPE', label: 'STRIPE' },
    { value: 'SHOPBACK', label: 'SHOPBACK' },
    { value: 'PAYNOW', label: 'PAYNOW' },
  ];
  paymentMethodSelectionsAddNew;

  private componentDestroyed: Subject<void> = new Subject();
  public event: EventEmitter<any> = new EventEmitter();
  billAdjustmentFormGroup: FormGroup;
  isEdit: boolean;
  billAdjItem: any = {};
  discount = 0;
  charges = 0;
  payableWithGST = 0;
  bsModalRefs: BsModalRef;
  currentChargeItems$;
  currentChargeItems = [];
  codesTypeahead = new Subject<string>();
  loading = false;
  drugId: FormControl;
  INPUT_DELAY_ITEM = 500;
  itemDetailedInfo;
  billAdjustmentResons: BillAdjustmentReason[] = [];    
  exsistingfiles: any;
  billAdjReasonCode:any;
  discountedInvoice:any[];
  billAdjReasonCodeStr: string;  
  reasonsList= [];

  constructor(
    
    private activatedRoute: ActivatedRoute,
    private apiPatientVisitService: ApiPatientVisitService,    
    private alertService: AlertService,    
    private bsModalService: BsModalService,
    private akitaMedicalCoverageQuery: MedicalCoverageQuery,
    private fb: FormBuilder,
    private store: StoreService,
    private documentManagementService: ApiDocumentService,
    private adjustmentReasonQuery: AdjustmentReasonQuery
  ) { }

  ngOnInit() {
    setTimeout(() => this.loadData(), 3000);
  }

  loadData(){
    this.reasonsList = this.adjustmentReasonQuery.getAll();
    this.initBillAdjustmentForm();
    this.activatedRoute.params.pipe(
    ).subscribe(params => {
      let caseID = (params['caseID']);
      let adjustmentId = (params['adjustmentId']);      
      this.getBillAdjustment(caseID, adjustmentId);
    });
  }

  getBillAdjustment(caseID,adjustmentId) {
    this.apiPatientVisitService.getAllBillAdjustmentByID(caseID, adjustmentId, this.billAdjItem)
        .subscribe( res => {
          if(res.statusCode === 'S0000'){
            this.billAdjItem = res.payload[0];
            this.getDiscount();
            this.setSelectedValuesToForm();
            this.setDocs();
            this.loadSavedFiles(this.billAdjItem)
            this.billAdjustmentFormGroup.disable();
            this.paymentMethodSelectionsAddNew = this.paymentMethodSelections.filter(method=> method.value !== 'CASH');
          } else{
            this.alertService.error('Error occured while getting data');
          }
        },
        err => this.alertService.error(JSON.stringify(err.error.message)));
  }  

  getDiscount() {
    if(this.billAdjItem && this.billAdjItem.totalDiscount){
      this.discount = this.billAdjItem.totalDiscount;
      this.setChargesAndPayableAmt();
    }
  }

  setDocs() {
    if(this.billAdjItem && this.billAdjItem.primaryDoctorId){
      let pDoc = this.store.findDoctorById(this.billAdjItem.primaryDoctorId);
      if(pDoc){
        this.primaryDoc = pDoc.displayName;
      }
    }

    if(this.billAdjItem && this.billAdjItem.secondaryDoctorIds && this.billAdjItem.secondaryDoctorIds.legth > 0){
      this.billAdjItem.secondaryDoctorIds.forEach(element => {
        let secDoc = this.store.findDoctorById(element);
        if(secDoc){
          this.secondaryDoc = this.secondaryDoc + ", " + secDoc.displayName;
        }
      });
    }
  }

  initBillAdjustmentForm() {
    this.billAdjustmentFormGroup = this.fb.group({
      purchaseItemsAdj: this.fb.array([]),
      packageAdjEntities: this.fb.array([]),
      invoiceAdjEntities: this.fb.array([]),
      primaryDoctorId: this.fb.control('', Validators.required),
      secondaryDoctorIds: this.fb.control(''),
      remark: this.fb.control('', Validators.required)
    })
  }

  setChargesAndPayableAmt() {
    this.charges = 0;
    this.payableWithGST = 0;
    let tempCharges = 0;
    this.billAdjustmentFormGroup.get('purchaseItemsAdj').value.forEach(i=> {
      tempCharges += +Number(i.soldPrice);
    });
    this.charges = +(tempCharges).toFixed(2);
    this.payableWithGST = +((this.charges - this.discount) * GST).toFixed(2);
  }

  onChangeFinalAmt(){
    this.setChargesAndPayableAmt();
  }
  
  isShowingAdditionalPaymentMethod(){
    let isShowing = false;
    const formArray = this.billAdjustmentFormGroup.get('invoiceAdjEntities').value;
    if(formArray.length === 0){
      return false;
    }
    if(formArray.some(item=> item.invoiceType === 'DIRECT')){
      isShowing = false;
    } else{
      isShowing = true;
    }
    return false;
  }

  setReason() {
    if(this.billAdjItem && this.billAdjItem.billAdjReasonCode){
      let reasonObj = this.reasonsList.find(reason => reason.value === this.billAdjItem.billAdjReasonCode);
      if(reasonObj){
        this.billAdjReasonCodeStr = reasonObj.label;
      }
    }
  }

  setSelectedValuesToForm(){
    if(this.billAdjItem){
      this.billAdjustmentFormGroup.get('primaryDoctorId').patchValue(this.billAdjItem.primaryDoctorId || '');
      this.billAdjustmentFormGroup.get('secondaryDoctorIds').patchValue(this.billAdjItem.secondaryDoctorIds);
      this.billAdjustmentFormGroup.get('remark').patchValue(this.billAdjItem.billAdjRemarks);
      this.setReason();

      this.billAdjItem.purchaseItemsAdj.forEach(i=> {
        const purchaseItemsAdj = this.fb.group({
          itemRefId: i.itemRefId,
          soldPrice: Number(i.soldPrice / 100).toFixed(2),
          purchaseQty: i.purchaseQty,
          dispenseQty: i.dispenseQty,
          salesItemId: i.salesItemId,
          itemCode: i.itemCode,
          itemName: i.itemName,
          purchaseUom: i.salesUom,
        });
        const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
        formArray.push(purchaseItemsAdj);
      });

      this.billAdjItem.invoiceAdjEntities.forEach(i => {
        const paymentInfoArr = this.fb.array([]);
        i.paymentInfos.forEach(payInfo => {
          const paymentInfo = this.fb.group({
            billTransactionId: payInfo.billTransactionId,
            billMode: payInfo.billMode,
            amount: Number(payInfo.amount / 100).toFixed(2),
            invoiceNumber: payInfo.invoiceNumber,
          });
          paymentInfoArr.push(paymentInfo);
        });
      
        const invoiceAdjEntities = this.fb.group({
          visitId: i.visitId,
          invoiceId: i.invoiceId,
          invoiceType: paymentInfoArr.length > 0 ? "DIRECT" : "CREDIT",
          paymentInfos: paymentInfoArr,
          payableAmount: i.payableAmount,
          paidAmount: Number(i.paidAmount / 100).toFixed(2),
          planId: i.planId,
          coverageName: i.coverageName
        });
        const formArray = <FormArray>this.billAdjustmentFormGroup.get('invoiceAdjEntities');
        formArray.push(invoiceAdjEntities);
      });
    }

    this.setChargesAndPayableAmt()
  }

  trackById(index: number, item: any) {
    return item.itemRefId;
  }
  
  trackByInvoiceId(index: number, item: any) {
    return item.invoiceId;
  }

  trackByPaymentInfo(index: number, item: any) {
    return item.invoiceNumber;
  }

  ngOnDestroy() {
    this.componentDestroyed.next();
    this.componentDestroyed.unsubscribe();
  }

  getMedicalCoverage(planId) {
    const medicalCoverage = this.store.getMedicalCoverageByPlanId(planId);
    return medicalCoverage;
  }

  getMedicalCoveragePlan(planId) {
    return this.akitaMedicalCoverageQuery.getMedicalCoveragePlan(planId);
  }
  
  getReqPayload(): any {
    const purchaseItemsAdj = [];
    this.billAdjustmentFormGroup.get('purchaseItemsAdj').value.forEach(i=> {
      const pItem = {
        itemRefId: i.itemRefId,
        soldPrice: +Number(i.soldPrice *100),
        purchaseQty: i.purchaseQty,
        dispenseQty: i.dispenseQty,
        salesItemId: i.salesItemId,
      };
      purchaseItemsAdj.push(pItem);
    });

    const invoiceAdjEntities = [];
    this.billAdjustmentFormGroup.get('invoiceAdjEntities').value.forEach(i => {
      const paymentInfoArr = [];
      let newPaidAmt = 0;
      let newPayableAmt = 0;
      if(i.planId !== null){
        newPaidAmt = +Number(i.paidAmount * 100).toFixed(0);
        newPayableAmt = +Number(i.paidAmount * 100).toFixed(0);
      }
      i.paymentInfos.forEach(payInfo => {
        const paymentInfo = {
          billTransactionId: payInfo.billTransactionId,
          billMode: payInfo.billMode,
          amount: +Number(payInfo.amount * 100),
          invoiceNumber: payInfo.invoiceNumber,
        };
        newPaidAmt += +Number(payInfo.amount * 100).toFixed(0);
        newPayableAmt += +Number(payInfo.amount * 100).toFixed(0);
        paymentInfoArr.push(paymentInfo);
      });
    
      const invoiceItem = {
        visitId: i.visitId,
        invoiceId: i.invoiceId,
        claimExpectedAmt: i.claim && Number(i.claim.claimExpectedAmt).toFixed(2) ,
        paymentInfos: paymentInfoArr,
        payableAmount: newPayableAmt,
        paidAmount: newPaidAmt,
        planId: i.planId
      };
      invoiceAdjEntities.push(invoiceItem);
    });

    let reqObj = {
      purchaseItemsAdj: purchaseItemsAdj,
      invoiceAdjEntities: invoiceAdjEntities,
      packageAdjEntities: [],
      primaryDoctorId: this.billAdjustmentFormGroup.get('primaryDoctorId').value,
      secondaryDoctorIds: this.billAdjustmentFormGroup.get('secondaryDoctorIds').value,
      remark: this.billAdjustmentFormGroup.get('remark').value,
    }
    return reqObj;
  }

  addNewItem(){
    const purchaseItemsAdj = this.fb.group({
      itemRefId: ['', Validators.required],
      soldPrice: 0,
      purchaseQty: 0,
      dispenseQty: 0,
      salesItemId: '',
      itemCode: '',
      itemName: '',
      purchaseUom: '',
      isNew: true
    });
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
    formArray.push(purchaseItemsAdj);
  }

  onDiagnosisSelected(event, i){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');

    let item = formArray.controls[i];
    item.get('itemName').patchValue(event.name);
    item.get('purchaseQty').patchValue(event.dosageQty || 1);
    item.get('purchaseUom').patchValue(event.salesUom);
  }

  isValidItemForm(){
    return this.billAdjustmentFormGroup.get('purchaseItemsAdj').status === 'VALID';
  }

  onbtnDeleteClicked(item){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('purchaseItemsAdj');
    formArray.removeAt(formArray.value.findIndex(i=> i.itemRefId === item.itemRefId));
    this.setChargesAndPayableAmt();
  }

  onbtnNewItemDeleteClicked(index){
    const formArray = <FormArray>this.billAdjustmentFormGroup.get('invoiceAdjEntities');
    const directMethods = formArray.controls.find(item => item.get('invoiceType').value === 'DIRECT');
    if(directMethods){
      let paymentInfoArr = <FormArray>directMethods.get('paymentInfos');
      paymentInfoArr.removeAt(index);
    }
  }

  public onDocumentClicked(file): void {
    this.documentManagementService.downloadDocumentToLocal(file, this.billAdjItem.patientId, this.store.getClinicList()[0].id);
  }
  
  loadSavedFiles(billAdjItem?: any){
    if (billAdjItem) {
    let patientID = billAdjItem.patientId;
    this.exsistingfiles = [];
    this.documentManagementService
    .getAllFilesInBillMangement(patientID, billAdjItem.billAdjId , this.store.getClinicList()[0]? this.store.getClinicList()[0].id : '')
      .subscribe(documents => {
        this.exsistingfiles = documents.filter(document => document.description.includes(billAdjItem.billAdjId));
      },
      err => {
      });
    }
  }

}
