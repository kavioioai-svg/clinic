import { ClaimChasComponent } from './../../../components/claim/claim-chas/claim-chas.component';
import { SharedModule } from './../../../shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClaimRoutingModule } from './claim-routing.module';
import { ClaimListComponent } from './claim-list/claim-list.component';
import { ClaimMedisaveComponent } from '../../../components/claim/claim-medisave/claim-medisave.component';
import { ClaimDentalComponent } from '../../../components/claim/claim-dental/claim-dental.component';
import { ClaimManualComponent } from '../../../components/claim/claim-manual/claim-manual.component';
import { ClaimRefundComponent } from '../../../components/claim/claim-refund/claim-refund.component';
import { ClaimBillAdjustmentComponent } from '../../../components/claim/claim-bill-adjustment/claim-bill-adjustment.component';
import { RefundComponent } from '../../../components/claim/claim-refund/refund/refund.component';
import { RefundBreakdownComponent } from '../../../components/claim/claim-refund/refund/refund-breakdown/refund-breakdown.component';
import { RefundBreakdownItemComponent } from '../../../components/claim/claim-refund/refund/refund-breakdown/refund-breakdown-item/refund-breakdown-item.component';
import { RefundPaymentItemComponent } from '../../../components/claim/claim-refund/refund/refund-breakdown/refund-breakdown-item/refund-payment-item/refund-payment-item.component';
import { RefundItemComponent } from '../../../components/claim/claim-refund/refund/refund-item/refund-item.component';
import { CaseRefundService } from '../../../components/claim/claim-refund/refund/case-refund.service';
import { BillAdjustmentSummaryComponent } from './bill-adjustment-summary/bill-adjustment-summary.component';
import { CaseSummeryBillAdjDetailsComponent } from '../../../components/claim/claim-bill-adjustment/case-summery-bill-adj-details/case-summery-bill-adj-details.component';
import { RefundBillAdjListComponent } from './refund-bill-adjstment-list/refund-bill-adjstment-list.component';
import { ClaimSFLComponent } from '../../../components/claim/sfl/claim-sfl.component';
import { SflHistoyPopupComponent } from '../../../components/claim/sfl/sfl-histoy-popup/sfl-histoy-popup.component';

@NgModule({
  imports: [CommonModule, ClaimRoutingModule, SharedModule],
  declarations: [
    ClaimListComponent,
    ClaimChasComponent,
    ClaimMedisaveComponent,
    ClaimDentalComponent,
    ClaimManualComponent,
    ClaimRefundComponent,
    ClaimBillAdjustmentComponent,
    RefundComponent,
    RefundBreakdownComponent,
    RefundBreakdownItemComponent,
    RefundPaymentItemComponent,
    RefundItemComponent,
    BillAdjustmentSummaryComponent,
    RefundBillAdjListComponent,
    ClaimSFLComponent,
    SflHistoyPopupComponent
    
  ],
  providers: [
    CaseRefundService
  ],
  entryComponents: [
    SflHistoyPopupComponent
  ]
})
export class ClaimModule {}
