import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RefundBillAdjListComponent } from './refund-bill-adjstment-list.component';

describe('ClaimListComponent', () => {
  let component: RefundBillAdjListComponent;
  let fixture: ComponentFixture<RefundBillAdjListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RefundBillAdjListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RefundBillAdjListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
