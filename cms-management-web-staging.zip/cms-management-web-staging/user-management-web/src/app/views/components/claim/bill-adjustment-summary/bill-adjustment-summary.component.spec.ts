import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillAdjustmentSummaryComponent } from './bill-adjustment-summary.component';

describe('BillAdjustmentSummaryComponent', () => {
  let component: BillAdjustmentSummaryComponent;
  let fixture: ComponentFixture<BillAdjustmentSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillAdjustmentSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillAdjustmentSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
