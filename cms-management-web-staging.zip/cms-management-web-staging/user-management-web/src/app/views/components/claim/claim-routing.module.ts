import { ClaimListComponent } from './claim-list/claim-list.component';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RefundComponent } from '../../../components/claim/claim-refund/refund/refund.component';
import { BillAdjustmentSummaryComponent } from './bill-adjustment-summary/bill-adjustment-summary.component';
import { RefundBillAdjListComponent } from './refund-bill-adjstment-list/refund-bill-adjstment-list.component';

const routes: Routes = [
  {
    path: '',
    canActivate: [NgxPermissionsGuard],
    data: {
      title: 'Claim'
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'chas' },
      {
        path: 'chas',
        component: ClaimListComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          requiresLogin: true,
          permissions: {
            only: ['ROLE_MHCP_LIST', 'ROLE_MHCP_LIST_HQ']
          }
        }
      },
      {
        path: 'refund-bill',
        component: RefundBillAdjListComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          title: 'Bill Management',
          requiresLogin: true,
          permissions: {
            only: ['ROLE_SO_CORRECTION', 'ROLE_REFUND']
          }
        }
      },
      {
        path: 'bill-adjustment/:caseID/:adjustmentId',
        component: BillAdjustmentSummaryComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          requiresLogin: true
        }
      },
      {
        path: 'refund-breakdown',
        component: RefundComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          requiresLogin: true,
        }
      },
      {
        path: 'refund-breakdown/:caseID/:refundID',
        component: RefundComponent,
        canActivate: [NgxPermissionsGuard],
        data: {
          requiresLogin: true
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClaimRoutingModule {}
