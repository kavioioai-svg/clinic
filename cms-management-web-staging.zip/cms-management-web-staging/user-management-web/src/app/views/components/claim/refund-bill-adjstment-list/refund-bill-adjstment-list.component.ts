import { Component, OnInit } from '@angular/core';
import { NgxPermissionsService } from 'ngx-permissions';

@Component({
  selector: 'app-refund-bill-adjstment-list',
  templateUrl: './refund-bill-adjstment-list.component.html',
  styleUrls: ['./refund-bill-adjstment-list.component.scss']
})
export class RefundBillAdjListComponent implements OnInit {

  showRefundTab: boolean = false;
  showBillAdjTab: boolean = false;

  constructor(private permissionService: NgxPermissionsService) { }

  ngOnInit() {
    this.showRefundTab =  !!this.permissionService.getPermission('ROLE_REFUND');
    this.showBillAdjTab =  !!this.permissionService.getPermission('ROLE_SO_CORRECTION');
  }

}
