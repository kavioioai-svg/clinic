import { Injectable } from '@angular/core';

import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { CurrentChargeItemStore } from './current-charge-item.store';
import { FormBuilder } from '@angular/forms';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class CurrentChargeItemService {

  constructor(
    private apiCmsManagementService: ApiCmsManagementService,
    private currentChargeItemStore: CurrentChargeItemStore,
    private formBuilder: FormBuilder
  ) { }

  createItemListingFilterFormGroup() {
    return this.formBuilder.group({
      searchChargeItemStatus: undefined,
      searchChargeItemType: undefined,
      searchClinicGroups: undefined,
      searchClinics: undefined,
      searchItemCodeName: undefined
    })
  }

  createItemFilterFormGroup() {
    return this.formBuilder.group({
      addedItemList: [],
      keywordSearch: undefined,
      keywordSearchAdded: undefined,
      searchAddedItem: undefined,
      type: undefined
    })
  }

  generateItemFormArray(items) {
    const itemsFormArray = [];
    items.forEach(item => itemsFormArray.push(this.createItemFormGroup(item)));
    return this.formBuilder.array(itemsFormArray);
  }

  createItemFormGroup(item) {
    const { itemRefId = '', price = -1 } = item;
    const updatedPrice = (price === -1 || price === '' || isNaN(price)) ? '' : ((Number.isInteger(price) ? (price * 0.01).toFixed(2) : Number(price).toFixed(2))).toString();
    return this.formBuilder.group({
      itemRefId: itemRefId,
      price: updatedPrice
    });
  }

  updateChargeItemCodeName(chargeItemCodeName) { this.currentChargeItemStore.update({ chargeItemCodeName: chargeItemCodeName }); }
  updateChargeItemClinicGroup(chargeItemClinicGroup) { this.currentChargeItemStore.update({ chargeItemClinicGroup: chargeItemClinicGroup }); }
  updateChargeItemClinic(chargeItemClinic) { this.currentChargeItemStore.update({ chargeItemClinic: chargeItemClinic }); }
  updateChargeItemType(chargeItemType) { this.currentChargeItemStore.update({ chargeItemType: chargeItemType }); }
  updateChargeItemStatus(chargeItemStatus) { this.currentChargeItemStore.update({ chargeItemStatus: chargeItemStatus }); }

  updateLoadingState(loadingState) { this.currentChargeItemStore.update({ loadingState: loadingState }); }
  updateSelectedEditType(selectedEditType) { this.currentChargeItemStore.update({ selectedEditType: selectedEditType }); }
  updateSelectedEditValue(selectedEditValue) { this.currentChargeItemStore.update({ selectedEditValue: selectedEditValue }); }

  updateAddedCodeName(addedCodeName) { this.currentChargeItemStore.update({ addedCodeName: addedCodeName }); }
  updateAddedList(addedList) { this.currentChargeItemStore.update({ addedList: addedList }); }
  updateCodeName(codeName) { this.currentChargeItemStore.update({ codeName: codeName }); }
  updateItemType(itemType) { this.currentChargeItemStore.update({ itemType: itemType }); }

  updateTableFilter(tableFilter) { this.currentChargeItemStore.update({ tableFilter: tableFilter }); }

  modifyChargeItemListByGroup(groupName, chargeItemList) {
    return this.apiCmsManagementService.modifyChargeItemByGroup(groupName, chargeItemList).pipe(tap(data => console.log(data)));
  }

  modifyChargeItemListByClinic(clinicId, chargeItemList) {
    return this.apiCmsManagementService.modifyChargeItemByClinicId(clinicId, chargeItemList);
  }
}
