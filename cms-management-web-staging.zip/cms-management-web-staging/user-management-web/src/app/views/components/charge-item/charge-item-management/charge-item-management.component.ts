import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { map, tap } from 'rxjs/operators';

import { AlertService } from '../../../../services/alert.service';
import { adjustDownPrice, adjustUpPrice, UtilsService } from '../../../../services/utils.service';
import { ChargeItemQuery } from '../../../../state/charge-item/charge-item.query';
import { CurrentChargeItemQuery } from '../state/current-charge-item.query';
import { CurrentChargeItemService } from '../state/current-charge-item.service';

@Component({
  selector: 'app-charge-item-management',
  templateUrl: './charge-item-management.component.html',
  styleUrls: ['./charge-item-management.component.scss'],
})
export class ChargeItemManagementComponent implements OnInit {
  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  backendData;

  filterForm = this.currentChargeItemService.createItemFilterFormGroup();
  itemFormArray;
  addedItemList$;
  itemList$;
  itemTypeList$ = this.chargeItemQuery.selectItemType().pipe(
    map((data) =>
      data
        .filter((item) => item !== undefined && item !== null && item.trim().length > 0)
        .map((item) => item.toLowerCase())
        .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
        .map((item) => ({ label: this.utilsService.convertToTitleCase(item), value: item.toUpperCase() }))
    ),
    tap((data) => {
      if (data && data.length > 0) this.filterForm.get('type').setValue(data[0].value);
    })
  );

  addedItemTable$;

  constructor(
    private alertService: AlertService,
    private chargeItemQuery: ChargeItemQuery,
    private currentChargeItemQuery: CurrentChargeItemQuery,
    private currentChargeItemService: CurrentChargeItemService,
    private router: Router,
    private utilsService: UtilsService
  ) {}

  ngOnInit() {
    this.currentChargeItemQuery.selectRemoteItemList().subscribe((data) => {
      if (data && data.payload) {
        this.backendData = data.payload;
        const rawData = data.payload.hasOwnProperty('itemsForClinic')
          ? data.payload.itemsForClinic
          : data.payload.clinicGroupItemPrices;
        this.currentChargeItemService.updateAddedList(rawData.map((item) => item.itemRefId));

        this.itemFormArray = this.currentChargeItemService.generateItemFormArray(rawData);
      }
    });

    this.itemList$ = this.currentChargeItemQuery.selectItemListing();
    this.addedItemList$ = this.currentChargeItemQuery.selectAddedItemListing();
    this.addedItemTable$ = this.currentChargeItemQuery.selectAddedItemTable();

    this.dataSubscription();
  }

  dataSubscription() {
    this.filterForm.get('keywordSearchAdded').valueChanges.subscribe((keyword) => {
      this.currentChargeItemService.updateAddedCodeName(keyword);
    });

    this.filterForm.get('keywordSearch').valueChanges.subscribe((keyword) => {
      this.currentChargeItemService.updateCodeName(keyword);
    });

    this.filterForm.get('searchAddedItem').valueChanges.subscribe((keyword) => {
      this.currentChargeItemService.updateTableFilter(keyword);
    });

    this.filterForm.get('type').valueChanges.subscribe((itemType) => {
      this.currentChargeItemService.updateItemType(itemType);
    });
  }

  getLoadingState() {
    return this.currentChargeItemQuery.select((entity) => entity.loadingState);
  }

  updateList(items) {
    const itemList = items.map((item) => item.itemRefId);
    this.currentChargeItemService.updateAddedList(itemList);
    this.itemFormArray = this.currentChargeItemService.generateItemFormArray(items);
  }

  adjustDownPrice(value) {
    if (value && value.price && value.price !== -1) return adjustDownPrice(value.price);
    return '0.00';
  }

  getItemFormGroup(id) {
    return <FormGroup>this.itemFormArray.controls.find((control) => control.value.itemRefId === id);
  }

  redirectToItemManagementListing() {
    this.router.navigate(['/pages/clinic-item/all']);
    return false;
  }

  onSaveGroupItem() {
    this.currentChargeItemService.updateLoadingState(true);

    let finalValue = [];
    finalValue = this.itemFormArray.getRawValue();

    finalValue.forEach((item) => {
      if (item.price === undefined || item.price === null || item.price.length === 0) item.price = -1;
      else item.price = adjustUpPrice(parseFloat(item.price));
    });

    this.backendData = { ...this.backendData };
    if (this.currentChargeItemQuery.getValue().selectedEditType === 'CLINIC') {
      this.backendData = { ...this.backendData, itemsForClinic: finalValue };
      this.currentChargeItemService
        .modifyChargeItemListByClinic(this.currentChargeItemQuery.getValue().selectedEditValue, {
          clinicGroupItem: this.backendData,
        })
        .subscribe(
          (data) => {
            this.currentChargeItemService.updateLoadingState(false);
            this.alertService.success('Successfully updated Clinic Charge Item List');
          },
          (err) => {
            this.currentChargeItemService.updateLoadingState(false);
            this.alertService.error('Error updating Clinic Charge Item List');
          }
        );
    } else {
      this.backendData = { ...this.backendData, clinicGroupItemPrices: finalValue };
      this.currentChargeItemService
        .modifyChargeItemListByGroup(this.currentChargeItemQuery.getValue().selectedEditValue, {
          clinicGroupItem: this.backendData,
        })
        .subscribe(
          (data) => {
            this.currentChargeItemService.updateLoadingState(false);
            this.alertService.success('Successfully updated Clinic Group Charge Item List');
          },
          (err) => {
            this.currentChargeItemService.updateLoadingState(false);
            this.alertService.error('Error updating Clinic Group Charge Item List');
          }
        );
    }
  }
}
