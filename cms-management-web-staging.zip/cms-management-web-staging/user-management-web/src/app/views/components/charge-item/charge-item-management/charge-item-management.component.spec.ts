import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargeItemManagementComponent } from './charge-item-management.component';

describe('ChargeItemManagementComponent', () => {
  let component: ChargeItemManagementComponent;
  let fixture: ComponentFixture<ChargeItemManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChargeItemManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChargeItemManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
