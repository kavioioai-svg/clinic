import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargeItemListingComponent } from './charge-item-listing.component';

describe('ChargeItemListingComponent', () => {
  let component: ChargeItemListingComponent;
  let fixture: ComponentFixture<ChargeItemListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChargeItemListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChargeItemListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
