import { Injectable } from '@angular/core';

import { combineLatest, Observable } from 'rxjs';
import { map, mergeMap, withLatestFrom } from 'rxjs/operators';
import { Query } from '@datorama/akita';

import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { ChargeItem } from '../../../../objects/ChargeItem';
import { ChargeItemQuery } from '../../../../state/charge-item/charge-item.query';
import { Clinic } from '../../../../objects/response/Clinic';
import { ClinicQuery } from '../../../../state/clinic/clinic.query';
import { CurrentChargeItemState, CurrentChargeItemStore } from './current-charge-item.store';
import { HttpResponseBody } from '../../../../objects/response/HttpResponseBody';

@Injectable({ providedIn: 'root' })
export class CurrentChargeItemQuery extends Query<CurrentChargeItemState> {
  constructor(
    private apiCmsManagementService: ApiCmsManagementService,
    private chargeItemQuery: ChargeItemQuery,
    private clinicQuery: ClinicQuery,
    protected store: CurrentChargeItemStore
  ) {
    super(store);
  }

  selectClinicGroupList() {
    return this.clinicQuery.selectAll().pipe(
      map((clinicList: Array<Clinic>) => {
        return clinicList
          .map((clinic) => clinic.groupName)
          .reduce((unique, item) => (unique.includes(item) ? unique : [...unique, item]), [])
          .map((data) => ({ value: data, label: data }));
      })
    );
  }

  selectClinicList() {
    return this.select((entity) => entity.chargeItemClinicGroup).pipe(
      withLatestFrom(this.clinicQuery.selectAll()),
      map((data) => {
        return data[1]
          .filter((clinic) => clinic.groupName === data[0])
          .map((clinic) => ({ value: clinic.id, label: clinic.clinicCode }));
      })
    );
  }

  selectItemList() {
    return combineLatest(
      this.select((entity) => entity.chargeItemCodeName),
      this.select((entity) => entity.chargeItemType),
      this.select((entity) => entity.chargeItemStatus),
      this.select((entity) => entity.chargeItemClinicGroup),
      this.select((entity) => entity.chargeItemClinic)
    ).pipe(
      mergeMap((data) => {
        const searchCodeName = data[0] && data[0].length > 0 ? data[0].toLowerCase() : '';
        const searchItemType = data[1] && data[1].length > 0 ? data[1].toLowerCase() : '';
        const searchItemStatus = data[2] && data[2].length > 0 ? data[2].toLowerCase() : '';

        let tableData: Observable<HttpResponseBody>;
        if (data[4] && data[4].length > 0) tableData = this.apiCmsManagementService.listChargeItemByClinicId(data[4]);
        else tableData = this.apiCmsManagementService.listChargeItemsByGroup(data[3]);

        return combineLatest(
          this.chargeItemQuery.selectAll({
            filterBy: (entity) =>
              (entity.name.toLowerCase().includes(searchCodeName) ||
                entity.code.toLowerCase().includes(searchCodeName)) &&
              searchItemType &&
              searchItemType.length > 0
                ? entity.itemType.toLowerCase() === searchItemType
                : true && searchItemStatus && searchItemStatus.length > 0
                ? entity.status.toLowerCase() === searchItemStatus
                : true,
          }),
          tableData
        );
      }),
      map((data) => {
        const chargeItemList = data[0];
        const res = data[1];
        const mappedData = [];
        if (res.payload) {
          if (res.payload.itemsForClinic) {
            res.payload.itemsForClinic.forEach((item) => {
              const matchingChargeItem = chargeItemList.find((chargeItem) => chargeItem.id === item.itemRefId);
              if (matchingChargeItem) mappedData.push({ chargeItem: matchingChargeItem, modifier: item });
            });
          }

          if (res.payload.clinicGroupItemPrices) {
            res.payload.clinicGroupItemPrices.forEach((item) => {
              const matchingChargeItem = chargeItemList.find((chargeItem) => chargeItem.id === item.itemRefId);
              if (matchingChargeItem) mappedData.push({ chargeItem: matchingChargeItem, modifier: item });
            });
          }
        }

        return mappedData;
      })
    );
  }

  selectRemoteItemList() {
    return combineLatest(
      this.select((entity) => entity.selectedEditType),
      this.select((entity) => entity.selectedEditValue)
    ).pipe(
      mergeMap((data) => {
        if (data[0] === 'CLINIC') return this.apiCmsManagementService.listChargeItemByClinicId(data[1]);
        return this.apiCmsManagementService.listChargeItemsByGroup(data[1]);
      })
    );
  }

  selectItemListing() {
    return combineLatest(
      this.select((entity) => entity.addedList),
      this.select((entity) => entity.codeName),
      this.select((entity) => entity.itemType)
    ).pipe(
      map((data) => {
        const chargeItemAddedList = data[0];
        const searchCodeName = data[1] && data[1].length > 0 ? data[1].toLowerCase() : '';
        const searchItemType = data[2] && data[2].length > 0 ? data[2].toLowerCase() : '';

        return [chargeItemAddedList, searchCodeName, searchItemType];
      }),
      mergeMap((data) => {
        const value = this.chargeItemQuery
          .selectAll({
            filterBy: (entity: ChargeItem) => {
              const chargeItemAddedList = new Set(data[0]);
              const searchCodeName = <string>data[1];
              const searchItemType = <string>data[2];

              return (
                entity.name.toLowerCase().includes(searchCodeName) &&
                (searchItemType ? entity.itemType.toLowerCase() === searchItemType : true) &&
                !chargeItemAddedList.has(entity.id)
              );
            },
          })
          .pipe(map((data) => data.map((item) => ({ id: item.id, name: item.name }))));

        return value;
      })
    );
  }

  selectAddedItemListing() {
    return combineLatest(
      this.select((entity) => entity.addedCodeName),
      this.select((entity) => entity.addedList)
    ).pipe(
      map((data) => {
        const chargeItemAddedList = data[1];
        const searchCodeName = data[0] && data[0].length > 0 ? data[0].toLowerCase() : '';

        return [chargeItemAddedList, searchCodeName];
      }),
      mergeMap((data) => {
        const value = this.chargeItemQuery.selectAll({
          filterBy: (entity: ChargeItem) => {
            const chargeItemAddedList = data[0];
            const searchCodeName = <string>data[1];

            return entity.name.toLowerCase().includes(searchCodeName) && chargeItemAddedList.includes(entity.id);
          },
        });

        return value;
      })
    );
  }

  selectAddedItemTable() {
    return combineLatest(
      this.select((entity) => entity.tableFilter).pipe(
        map((data) => (data && data.length > 0 ? data.toLowerCase() : ''))
      ),
      this.select((entity) => entity.addedList).pipe(map((data) => new Set(data)))
    ).pipe(
      mergeMap((data) =>
        this.chargeItemQuery.selectAll({
          filterBy: (entity) =>
            data[1].has(entity.id) &&
            (entity.name.toLowerCase().includes(data[0]) || entity.code.toLowerCase().includes(data[0])),
        })
      )
    );
  }
}
