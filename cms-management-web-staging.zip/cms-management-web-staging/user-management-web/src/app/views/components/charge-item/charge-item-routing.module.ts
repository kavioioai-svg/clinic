import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NgxPermissionsGuard } from 'ngx-permissions';

import { ChargeItemListingComponent } from './charge-item-listing/charge-item-listing.component';
import { ChargeItemManagementComponent } from './charge-item-management/charge-item-management.component';

const routes: Routes = [{
  path: '',
 // canActivateChild: [NgxPermissionsGuard],
  data: {
    title: 'Clinic Item Management'
  },
  children: [
    { path: '', pathMatch: 'full', redirectTo: 'all' },
    { path: 'all', component: ChargeItemListingComponent },
    { path: 'detail', component: ChargeItemManagementComponent }
  ]
}];;

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChargeItemRoutingModule { }
