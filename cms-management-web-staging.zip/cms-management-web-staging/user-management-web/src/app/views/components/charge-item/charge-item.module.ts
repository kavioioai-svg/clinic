import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContentLoaderModule } from '@ngneat/content-loader';

import { ChargeItemListingComponent } from './charge-item-listing/charge-item-listing.component';
import { ChargeItemRoutingModule } from './charge-item-routing.module';
import { CurrentChargeItemService } from './state/current-charge-item.service';
import { SharedModule } from '../../../shared.module';
import { ChargeItemManagementComponent } from './charge-item-management/charge-item-management.component';
import { SelectListModule } from '../../../components/select-list/select-list.module';


@NgModule({
  declarations: [
    ChargeItemListingComponent,
    ChargeItemManagementComponent],
  imports: [ ContentLoaderModule, CommonModule, ChargeItemRoutingModule, SelectListModule, SharedModule ],
  providers: [ CurrentChargeItemService ]
})
export class ChargeItemModule { }
