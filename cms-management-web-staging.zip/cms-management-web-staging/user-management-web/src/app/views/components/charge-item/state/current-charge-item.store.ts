import { Injectable } from '@angular/core';

import { StoreConfig, Store } from '@datorama/akita';

export interface CurrentChargeItemState {

  chargeItemClinic: string;
  chargeItemClinicGroup: string;
  chargeItemCodeName: string;
  chargeItemStatus: string;
  chargeItemType: string;

  loadingState: boolean;
  selectedEditType: string;
  selectedEditValue: string;

  addedCodeName: string;
  addedList: Array<string>;
  codeName: string;
  itemType: string;
  tableFilter: string;

}

export function createInitialState(): CurrentChargeItemState {

  return {
    chargeItemClinic: '',
    chargeItemClinicGroup: '',
    chargeItemCodeName: '',
    chargeItemStatus: '',
    chargeItemType: '',

    loadingState: false,
    selectedEditType: '',
    selectedEditValue: '',

    addedCodeName: '',
    addedList: [],
    codeName: '',
    itemType: '',
    tableFilter: ''
  };

}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'chargeItemState' })
export class CurrentChargeItemStore extends Store<CurrentChargeItemState> {

  constructor() {
    super(createInitialState());
  }

}


