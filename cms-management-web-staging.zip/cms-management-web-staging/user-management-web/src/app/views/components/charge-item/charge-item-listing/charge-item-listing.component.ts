import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { adjustDownPrice, UtilsService } from '../../../../services/utils.service';
import { ChargeItemQuery } from '../../../../state/charge-item/charge-item.query';
import { CurrentChargeItemService } from '../state/current-charge-item.service';
import { CurrentChargeItemQuery } from '../state/current-charge-item.query';

@Component({
  selector: 'app-charge-item-listing',
  templateUrl: './charge-item-listing.component.html',
  styleUrls: ['./charge-item-listing.component.scss']
})
export class ChargeItemListingComponent implements OnInit {

  listFilterFormGroup: FormGroup;

  chargeItemList$: Observable<Array<any>>;

  clinicGroupList$: Observable<Array<any>>;
  clinicList$: Observable<Array<any>>;
  itemType$: Observable<Array<any>>;
  itemStatus$ = of([{ label: 'Active', value: 'ACTIVE' }, { label: 'Inactive', value: 'INACTIVE' }]);

  constructor(
    private chargeItemQuery: ChargeItemQuery,
    private currentChargeItemQuery: CurrentChargeItemQuery,
    private currentChargeItemService: CurrentChargeItemService,
    private router: Router,
    private utilsService: UtilsService
  ) { }

  ngOnInit() {
    this.listFilterFormGroup = this.currentChargeItemService.createItemListingFilterFormGroup();

    this.clinicGroupList$ = this.currentChargeItemQuery.selectClinicGroupList().pipe(
      tap(data => data ? this.listFilterFormGroup.get('searchClinicGroups').setValue(data[0].value) : '')
    );
    this.clinicList$ = this.currentChargeItemQuery.selectClinicList();
    this.itemType$ = this.chargeItemQuery.selectItemType().pipe(
      map(data => {
        const updatedData = data.filter(item => item !== undefined && item !== null && item.trim().length > 0).map(item =>
          item.toLowerCase()).sort((a, b) => a < b ? -1 : (a > b ? 1 : 0)).map(item => ({ label: this.utilsService.convertToTitleCase(item), value: item.toUpperCase() }));
        return updatedData;
      })
    );;

    this.chargeItemList$ = this.currentChargeItemQuery.selectItemList();

    this.listFilterFormGroup.get('searchItemCodeName').valueChanges.subscribe(codeName =>
      this.currentChargeItemService.updateChargeItemCodeName(codeName));

    this.listFilterFormGroup.get('searchClinicGroups').valueChanges.subscribe(clinicGroups => {
      this.currentChargeItemService.updateChargeItemClinicGroup(clinicGroups);
      this.currentChargeItemService.updateChargeItemClinic('');
      this.listFilterFormGroup.get('searchClinics').setValue(undefined);
    });

    this.listFilterFormGroup.get('searchClinics').valueChanges.subscribe(clinics =>
      this.currentChargeItemService.updateChargeItemClinic(clinics));

    this.listFilterFormGroup.get('searchChargeItemType').valueChanges.subscribe(itemType =>
      this.currentChargeItemService.updateChargeItemType(itemType));

    this.listFilterFormGroup.get('searchChargeItemStatus').valueChanges.subscribe(status =>
      this.currentChargeItemService.updateChargeItemStatus(status));

  }

  adjustDownPrice(value) {
    return adjustDownPrice(value);
  }

  editChargeItemListing() {
    const listFilterRawValues = this.listFilterFormGroup.getRawValue();

    this.currentChargeItemService.updateSelectedEditType(listFilterRawValues.searchClinics && listFilterRawValues.searchClinics.length > 0 ? 'CLINIC' : 'GROUP');
    this.currentChargeItemService.updateSelectedEditValue(listFilterRawValues.searchClinics && listFilterRawValues.searchClinics.length > 0 ?
      listFilterRawValues.searchClinics : listFilterRawValues.searchClinicGroups);

    this.router.navigate(['/pages/clinic-item/detail']);
    return false;
  }

  selectClinicValue() {
    return this.currentChargeItemQuery.select(entity => entity.chargeItemClinic);
  }

}


