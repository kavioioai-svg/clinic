import { ReportSearchComponent } from './report-search/report-search.component';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [{
  path: '',
  canActivate: [NgxPermissionsGuard],
  data: {
    title: 'Report'
  },
  children: [
    { path: '', pathMatch: 'full', redirectTo: 'search' },
    // {
    //   path: 'list',
    //   component: ReportListComponent,
    //   data: {
    //     requiresLogin: true
    //   }
    // },
    {
      path: 'search',
      component: ReportSearchComponent,
      data: {
        requiresLogin: true
      }
    },
    // {
    //   path: 'result',
    //   component: ReportSearchResultComponent,
    //   data: {
    //     requiresLogin: true
    //   }
    // }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
