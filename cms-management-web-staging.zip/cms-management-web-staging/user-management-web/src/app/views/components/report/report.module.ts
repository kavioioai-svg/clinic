import { ReportSearchComponent } from './report-search/report-search.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportRoutingModule } from './report-routing.module';
import { SharedModule } from '../../../shared.module';

@NgModule({
  imports: [
    CommonModule,
    ReportRoutingModule,
    SharedModule,
  ],
  declarations: [ReportSearchComponent]
})
export class ReportModule { }
