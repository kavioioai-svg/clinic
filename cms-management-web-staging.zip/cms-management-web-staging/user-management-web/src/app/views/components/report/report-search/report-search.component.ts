import { DB_FULL_DATE_FORMAT_NO_SECOND, PRIVATE_PATIENT_REPORTS, REPORT_TYPES } from './../../../../constants/app.constants';
import { MedicalCoverage } from './../../../../objects/MedicalCoverage';
import { AppConfigService } from './../../../../services/app-config.service';
import { ItemService } from '../../../../services/item.service';
import { AlertService } from './../../../../services/alert.service';
import { filter, distinctUntilChanged, debounceTime, switchMap, tap, catchError, share, map } from 'rxjs/operators';
import { Subject, of, throwError, concat, Observable } from 'rxjs';
import { ReportCategory, Report, ReportCategories } from './../../../../objects/ReportCategories';
import { NgxPermissionsService } from 'ngx-permissions';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ReportCategorization } from '../../../../objects/model/ReportCategorization';
import { ApiPatientInfoService } from '../../../../services/api-patient-info.service';
import { StoreStatus } from '../../../../objects/StoreStatus';
import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { saveAs } from 'file-saver';
import { ClinicQuery } from '../../../../state/clinic/clinic.query';
import { DoctorQuery } from '../../../../state/doctor/doctor.query';
import { MedicalCoverageQuery } from '../../../../state/medical-coverage/medical-coverage.query';
import { ChargeItemQuery } from '../../../../state/charge-item/charge-item.query';
import { StoreStatusQuery } from '../../../../state/store-status/store-status.query';
import { PurchaseStatus } from '../../../../objects/PurchaseStatus';
import { TransactionTypes } from '../../../../objects/TransactionTypes';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { ServiceService } from '../../service/service.service';
import DatePickerConfig from '../../../../objects/DatePickerConfig';

@Component({
  selector: 'app-report-search',
  templateUrl: './report-search.component.html',
  styleUrls: ['./report-search.component.scss'],
})
export class ReportSearchComponent implements OnInit {
  objectKeys = Object.keys;
  // reportUrl = 'http://10.10.20.5:8080/reporting-ui/';
  reportUrl: string;
  reportUrlNew: string;

  // Form Submission
  authToken: string;
  payload: any;
  reportSubmitAction: string;
  tenantId: String;
  // End of Form Submission

  reportCategories: ReportCategories;
  selectedCategory: ReportCategory;
  tempData: ReportCategory;

  commonReports: any[];
  reportTypes: any[];
  selectedReport: Report;

  // Input Filter
  patientTypeahead = new Subject<string>();
  patients: any;

  public visitPurposeList: string[] = [];
  // doctorTypeahead = new Subject<string>();
  doctors: any;

  drugTypeahead = new Subject<string>();
  drugs: any;

  codesTypeahead = new Subject<string>();
  codeLoading = false;

  clinics: any;
  clinicGroups: any;
  groupedClinics: any;
  chargeItems: any;
  inventoriedChargeItems: any;
  drugOrVaccineItems: any;
  public packageItems: any;
  allChargeItems: any;
  allChargeInventoryItems: any;
  chargeItemCategories: any;

  medicalCoverages: MedicalCoverage[];
  filteredMedicalCoverages: MedicalCoverage[];
  filteredMedicalCoverages$: Observable<MedicalCoverage[]>;
  filteredMedicalCoveragesSubject = new Subject<MedicalCoverage[]>();
  selectedMedicalCoverageType = [];

  endMinDate: Date;
  startDate: Date;
  endDate: Date;
  maxDate: Date;
  public createdStartDatePickerConfig: DatePickerConfig = new DatePickerConfig('Create Start Date',
    moment().toDate(), null, 'bottom');
  public createdEndDatePickerConfig: DatePickerConfig = new DatePickerConfig('Create End Date',
      null,  moment().toDate(), 'bottom');

  isLoading: boolean;

  // End of Input Filter

  coverageTypes = [
    { value: 'CORPORATE', label: 'CORPORATE' },
    { value: 'INSURANCE', label: 'INSURANCE' },
    { value: 'MEDISAVE', label: 'MEDISAVE' },
    { value: 'CHAS', label: 'CHAS' },
    { value: 'Direct/Private', label: 'DIRECT/PRIVATE' },
  ];

  dateFilterTypes = [
    { value: 'ENROLLMENT_DATE', label: 'Enrollment Date' },
    { value: 'PLAN_DATE', label: 'Plan creation date'},
  ];

  nphsReportTypes = [
    { value: 'CONSENT', label: 'Consent' },
    { value: 'DATASET', label: 'Dataset' },
    { value: 'CONSENT_YOUTH', label: 'Consent Youth' },
    { value: 'DATASET_YOUTH', label: 'Dataset Youth' },
  ];

  nphsHe3ReportTypes = [
    { value: 'NORMAL', label: 'Normal' },
    { value: 'YOUTH', label: 'Youth' },
  ];
  // paymentStatus = [
  //   { value: 'INITIAL', label: 'INITIAL' },
  //   { value: 'PAID', label: 'PAID' },
  //   { value: 'DELETED', label: 'DELETED' }
  // ];

  // paymentStatus = ['SUBMITTED', 'PENDING', 'REJECTED_PERMANENT', 'REJECTED', 'FAILED', 'PAID', 'UNKNOWN'];
  paymentStatus = ['PAID', 'OUTSTANDING'];
  caseStatus = ['OPEN', 'CLOSED'];
  purchaseStatus = PurchaseStatus;
  transactionTypes = TransactionTypes;
  reportVariations = [];
  // excludeFinancialClass = ['CORPORATE_PLAN', 'TPA', 'CHAS', 'MEDISAVE', 'INSURANCE', 'SFL', 'MBS_GOV', 'IA'];
  excludeFinancialClass = ['IA'];

  mainFormGroup: FormGroup;
  actionButtonName = 'Submit';
  reportSubmitStatus = 'return false';
  private marked: false;
  startDateBsConfig: Partial<BsDatepickerConfig>;
  dateArray: Date[] = [];
  hsgStatusCodes = [
    { label: 'NEW', value: 'NEW' },
    { label: 'APPOINTMENT MADE', value: 'CONTACTED' },
    { label: 'FIRST VISIT COMPLETED', value: 'FIRST_VISIT_COMPLETED' }
  ]
  constructor(
    private apiCmsManagementService: ApiCmsManagementService,
    private apiPatientInfoService: ApiPatientInfoService,
    private _service: ServiceService,
    private drugService: ItemService,
    private alertService: AlertService,
    private fb: FormBuilder,
    private appConfig: AppConfigService,
    public readonly permissionsService: NgxPermissionsService,
    private clinicQuery: ClinicQuery,
    private doctorQuery: DoctorQuery,
    private medicalCoverageQuery: MedicalCoverageQuery,
    private chargeItemQuery: ChargeItemQuery,
    private storeStatusQuery: StoreStatusQuery
  ) {
    this.reportUrl = appConfig.getConfig().REPORT_URL;
    this.reportUrlNew = appConfig.getConfig().REPORT_URL_NEW;
    this.reportCategories = <ReportCategories>ReportCategorization;
    this.selectedCategory = new ReportCategory();
    this.selectedReport = new Report();

    this.startDateBsConfig = {
      dateInputFormat:'DD-MM-YYYY',
      containerClass: 'theme-blue',
      adaptivePosition: true,
      datesDisabled: this.dateArray,
    }

    this.onPatientInputChanged();
    this.onDrugInputChanged();
    this.onCoverageCodeChanged();
    this.generateForm();

    this.authToken = `Bearer ${localStorage.getItem('access_token')}`;
    this.tenantId = localStorage.getItem('tenantId');
    // this.payload = JSON.stringify({ clinicIds: '', startDate: '2018-06-01', endDate: '2018-06-30' });
    this.payload = '';
    this.reportSubmitAction = '';

    this.endMinDate = new Date();

    this.startDate = new Date();
    this.startDate.setHours(0, 0, 0);

    this.endDate = new Date();
    this.endDate.setHours(23, 59, 59);

    this.isLoading = false;
    this.reportTypes = REPORT_TYPES;
    // this.filteredMedicalCoveragesSubject = new Subject();
  }

  ngOnInit() {
    this.populateData();
    this.storeReadinessSubscription();
    this.subscribeChange();
    this.dateValues();
  }

  dateValues(){
    let currDate = moment().startOf('year').subtract(5, 'years');
    let lastDate = moment().endOf('year').add(5, 'years');
    while (currDate.diff(lastDate) < 0) {
      let currDateUpdate = new Date(currDate.toDate());
      let getDay = new Date(currDateUpdate).getDay();
      let getDate = new Date(currDateUpdate).getDate();
      if (getDate !== 1 && getDay !== 0){
        this.dateArray.push(currDateUpdate);
      }
      currDate = currDate.add(1, 'days')
    }
  }

  private populateData() {
    this.clinics = this.clinicQuery.getAll();
    this.doctors = this.doctorQuery.getActiveDoctor();
    this.medicalCoverages = this.medicalCoverageQuery.getAll();
    this.filteredMedicalCoverages = this.medicalCoverageQuery.getAll();
    this.chargeItems = this.chargeItemQuery.getDrugOrVaccineItem().filter(item => item.status === 'ACTIVE');
    this.inventoriedChargeItems = this.chargeItemQuery.getInventoriedActiveChargeItems();
    this.drugOrVaccineItems = this.chargeItemQuery.getDrugOrVaccineItem().filter(item => item.status === 'ACTIVE');
    this.packageItems = this.chargeItemQuery.getPackageItem().filter(item => item.status === 'ACTIVE');
    this.drugOrVaccineItems = this.chargeItemQuery.getDrugOrVaccineItem();
    this.packageItems = this.chargeItemQuery.getPackageItem();

    this.chargeItemCategories = Object.keys(this.groupBy(this.chargeItemQuery.getAll(), 'itemType'));
    this.allChargeItems = this.chargeItemQuery.getAll().filter(itemObj => itemObj.status === 'ACTIVE');
    this.allChargeInventoryItems = this.chargeItemQuery.getAllInventoriedChargeItems();

    this.groupClinics();
    this.fetchAllAppointmentPurpose();
  }

  public fetchAllAppointmentPurpose(): void {
    this.showLoading();
    this._service.fetchAllAppointmentPurpose().subscribe({
      next: (res) => {
        this.dismissLoading();
        if(res.statusCode === "S0000") {
          this.visitPurposeList = res.payload;
        }else {
          this.alertService.error(res.message);
        }
      },
      error: (err) => {
        this.dismissLoading();
        this.alertService.error(err.message);
      }
    });
  }

  storeReadinessSubscription() {
    this.storeStatusQuery.select().subscribe((val: StoreStatus) => {
      const isStoreReady = val.isLoaded && !val.isReseting;

      // if (!val) {
      const hasError = val.hasError && val.isLoaded && !val.isReseting;
      // }

      if (isStoreReady && !hasError) {
        this.populateData();
      }
    });
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }

  onCategoryClick(data: ReportCategory) {
    this.commonReports = [];
    this.selectedCategory = data;
    this.selectedReport = new Report();
    this.resetMainGroupForm();
  }

  onReportClick(report: Report) {
    if (report.reportName === 'inventory_valuation_report') {
      const date = new Date();
      this.startDate = new Date(date.getFullYear(), date.getMonth(),1);
      this.startDate.setHours(0, 0, 0);
    } else {
      this.startDate = new Date();
      this.startDate.setHours(0, 0, 0);
    }

    if (report.reportName === 'primary_care_network') {
      this.actionButtonName = 'Export';
      this.maxDate = new Date();
      this.maxDate.setDate(this.maxDate.getDate() + 365);
    } else {
      this.actionButtonName = 'Submit';
      this.maxDate = null;
    }

    this.selectedReport = report;
    if (report.newUrl) {
      this.reportSubmitAction = this.reportUrlNew + report.reportName;
    } else {
      this.reportSubmitAction = this.reportUrl + report.reportName;
    }

    if (report.reportName === 'drug_dispensing_enquiry' || report.reportName === 'item_usage_report') {
      this.chargeItems = this.allChargeItems;
    } else if (report.reportName === 'inventory_movement_report' || report.reportName === 'inventory_grn_report') {
      this.chargeItems = this.allChargeItems;
    } else if (report.reportName === 'inventory_valuation_report'  || report.reportName === 'item_usage_advance_report') {
      this.chargeItems = this.allChargeInventoryItems;
    }
     else {
      this.chargeItems = this.selectedReport.reportName === 'package_dispensed_report' ?  this.packageItems : this.drugOrVaccineItems;
    }

    this.onMedicalCoverageTypeSelect(null);

    this.resetMainGroupForm();

    this.setMandatoryFields(report);

    this.prePopulateData();

    this.mainFormGroup.markAsTouched();
    if (
      report.reportName == "private_corporate_patient_listing") {
      this.commonReports = PRIVATE_PATIENT_REPORTS;
      this.mainFormGroup.get('reportFilter').patchValue(PRIVATE_PATIENT_REPORTS[0].reportName);
    } else {
      this.commonReports = [];
    }
    if (report.reportName == "dataset_he2") {
      this.mainFormGroup.get('nphsReportType').patchValue(this.nphsReportTypes[0].value);
    }
    if (report.reportName == "dataset_he3") {
      this.mainFormGroup.get('nphsReportTypeHe3').patchValue(this.nphsHe3ReportTypes[0].value);
    }
  }

  onSubmitClicked() {
    const reqBody: any = {
      startDate: moment(this.mainFormGroup.get('startDate').value).format('DD-MM-YYYY'),
      endDate: moment(this.mainFormGroup.get('endDate').value).format('DD-MM-YYYY'),
      clinicIds: this.mainFormGroup.get('clinicIds').value,
      itemCodes: (this.mainFormGroup.get('itemCodes').value || []).join(','),
      purchaseStatus: (this.mainFormGroup.get('purchaseStatus').value || []).join(','),
      reportType: this.mainFormGroup.get('nphsReportType').value,
      reportTypeHe3: this.mainFormGroup.get('nphsReportTypeHe3').value,
    };

    if (this.selectedReport.reportName === 'primary_care_network') {
      this.showLoading();
      this.apiCmsManagementService.downloadPCNReport(reqBody).subscribe(
        (res) => {
          this.dismissLoading();
          saveAs(res, 'Primary_care_network.xlsx');
        },
        (err) => {
          this.dismissLoading();
        }
      );
    } else if (this.selectedReport.reportName === 'dataset_he2') {
      this.showLoading();
      this.apiCmsManagementService.downloadNPHSHE2Report(reqBody).subscribe(
        (res) => {
          this.dismissLoading();
          let reportName = reqBody.reportType === 'CONSENT' || reqBody.reportType === 'CONSENT_YOUTH' ? 
                            'NPHS_consent_' : 'NPHS_dataset_';
          if (reqBody.reportType === 'CONSENT_YOUTH' || reqBody.reportType === 'DATASET_YOUTH') {
            reportName = reportName + 'youth_';
          }
          reportName = reportName + 'HE2.xlsx';
          saveAs(res, reportName);
        },
        (err) => {
          this.dismissLoading();
        }
      );
    } else if (this.selectedReport.reportName === 'dataset_he3') {
      this.showLoading();
      this.apiCmsManagementService.downloadNPHSHE3Report(reqBody).subscribe(
        (res) => {
          this.dismissLoading();
          saveAs(res, reqBody.reportTypeHe3 === 'NORMAL' ? 'NPHS_Normal_HE3.xlsx' : 'NPHS_Youth_HE3.xlsx');
        },
        (err) => {
          this.dismissLoading();
        }
      );
    } else if (this.selectedReport.reportName === 'health_screen') {
      (reqBody.clinicId = this.mainFormGroup.get('clinicId').value),
        (reqBody.patientIdentifier = this.mainFormGroup.get('patientId').value);
      reqBody.templateName = 'NPHS_HS_DATA_PRINT';

      this.apiCmsManagementService.downloadHealthScreenReport(reqBody).subscribe(
        (res) => {
          if (res.statusCode === 'S0000') {
            let formattedContent = res.payload.template.replace(/\\n/g, '\n');
            formattedContent = formattedContent.replace(/\\"/g, '"');
            this.apiCmsManagementService.printTemplate(formattedContent, false);
          } else {
            alert('No data to print');
          }
        },
        (err) => alert(JSON.stringify(err.error.message))
      );
    }

    // if (
    //   this.selectedReport.reportName === 'private_corporate_patient_listing_paginated' &&
    //   this.mainFormGroup.get('isExport').value
    // ) {
    //   this.showLoading();
    //   this.onPrivateCorporateExcelExport();
    // }
  }

  onPrivateCorporateExcelExport() {
    let request = this.payload;

    request = JSON.parse(request);
    delete request.isExport;
    request['reportType'] = 'paginated';

    if (request['coverageType'] && request['coverageType'].length) {
      request['coverageType'] = request['coverageType'].split(',');
    }

    const { startDate, endDate } = request;
    request.startDate = moment(startDate, 'YYYY-MM-DD').format(DB_FULL_DATE_FORMAT_NO_SECOND);
    request.endDate = moment(endDate, 'YYYY-MM-DD').add(1, 'days').startOf('day').format(DB_FULL_DATE_FORMAT_NO_SECOND);
    this.apiCmsManagementService.downloadPrivateCorpReport(JSON.stringify(request)).subscribe(
      (res) => {
        this.dismissLoading();
        saveAs(res, 'private_corporate_paginated.xlsx');
      },
      (err) => {
        this.dismissLoading();
      }
    );
  }

  disableReason(evnt) {
    this.marked = evnt.target.checked;
    if (this.marked) {
      this.mainFormGroup.get('incentiveFormat').disable();
      this.mainFormGroup.get('showReason').enable();
    } else {
      this.mainFormGroup.get('incentiveFormat').enable();
      this.mainFormGroup.get('showReason').enable();
    }
  }

  disableIncentive(evnts) {
    this.marked = evnts.target.checked;
    if (this.marked) {
      this.mainFormGroup.get('showReason').disable();
      this.mainFormGroup.get('incentiveFormat').enable();
    } else {
      this.mainFormGroup.get('incentiveFormat').enable();
      this.mainFormGroup.get('showReason').enable();
    }
  }

  showLoading() {
    this.isLoading = true;
    this.mainFormGroup.disable();
  }

  dismissLoading() {
    this.isLoading = false;
    this.mainFormGroup.enable();
  }

  onFormSubmit() {
    if (
      this.selectedReport.reportName === 'primary_care_network' ||
      (this.selectedReport.reportName === 'private_corporate_patient_listing_paginated' &&
        this.mainFormGroup.get('isExport').value) ||
      this.selectedReport.reportName === 'health_screen'
    ) {
      return false;
    }
    return true;
  }

  resetMainGroupForm() {
    // Manual reset Validators, somehow clearValidators doesn't reset them
    this.mainFormGroup.get('statuses').setValidators(null);
    this.mainFormGroup.get('coverageType').setValidators(null);
    this.mainFormGroup.get('clinicId').setValidators(null);
    this.mainFormGroup.get('clinicIds').setValidators(null);
    this.mainFormGroup.get('clinicGroups').setValidators(null);
    this.mainFormGroup.get('doctorIds').setValidators(null);
    this.mainFormGroup.get('drugCode').setValidators(null);
    this.mainFormGroup.get('startDate').setValidators(null);
    this.mainFormGroup.get('endDate').setValidators(null);
    this.mainFormGroup.get('startTime').setValidators(null);
    this.mainFormGroup.get('endTime').setValidators(null);
    this.mainFormGroup.get('itemCodes').setValidators(null);
    this.mainFormGroup.get('itemCategoryCodes').setValidators(null);
    this.mainFormGroup.get('itemIds').setValidators(null);
    this.mainFormGroup.get('itemTypes').setValidators(null);
    this.mainFormGroup.get('financialPlanId').setValidators(null);
    this.mainFormGroup.get('patientId').setValidators(null);
    this.mainFormGroup.get('monthlyReport').setValidators(null);
    this.mainFormGroup.get('patientNric').setValidators(null);
    this.mainFormGroup.get('showReason').setValidators(null);
    this.mainFormGroup.get('incentiveFormat').setValidators(null);
    this.mainFormGroup.get('coverageCode').setValidators(null);
    this.mainFormGroup.get('coverageCodes').setValidators(null);
    this.mainFormGroup.get('reportFilter').setValidators(null);
    this.mainFormGroup.get('nphsReportType').setValidators(null);
    this.mainFormGroup.get('nphsReportTypeHe3').setValidators(null);
    this.mainFormGroup.get('hsgStatuses').setValidators(null);
    this.mainFormGroup.get('isExport').setValidators(null);
    this.mainFormGroup.get('caseStatus').setValidators(null);
    this.mainFormGroup.get('purchaseStatus').setValidators(null);
    this.mainFormGroup.get('transactionTypes').setValidators(null);
    this.mainFormGroup.get('patientIdentifier').setValidators(null);
    this.mainFormGroup.get('createdStartDate').setValidators(null);
    this.mainFormGroup.get('createdEndDate').setValidators(null);

    this.mainFormGroup.updateValueAndValidity();
    // Reset Form
    this.mainFormGroup.reset();
    // Reset Validation
    this.mainFormGroup.clearValidators();
  }

  /** Form Change Subscription */
  subscribeChange() {
    this.mainFormGroup.valueChanges.subscribe((value) => {
      // set Min End Date
      if (value.startDate) {
        this.endMinDate = value.startDate;
      }

      if(value.createdStartDate){
        this.createdEndDatePickerConfig =  new DatePickerConfig('Create End Date',
          null,  moment(value.createdStartDate).toDate(), 'bottom');
      }
      if (this.selectedReport.reportName === 'primary_care_network') {
        // set Max End Date for PCN
        if (value.startDate) {
          this.maxDate = new Date();
          this.maxDate.setDate(value.startDate.getDate() + 365);
        }
      }
      const data = {};
      this.selectedReport.params.forEach((param) => {
        if (param === 'startDate') {
          if (this.selectedReport.params.indexOf('startTime') > 0) {
            data[param] = moment(value[param]).format('YYYY-MM-DD') + 'T' + moment(value['startTime']).format('HH:mm');
          } else {
            data[param] = moment(value[param]).format('YYYY-MM-DD');
          }
        } else if (param === 'endDate') {
          if (this.selectedReport.params.indexOf('endTime') > 0) {
            data[param] = moment(value[param]).format('YYYY-MM-DD') + 'T' + moment(value['endTime']).format('HH:mm');
          } else {
            data[param] = moment(value[param]).format('YYYY-MM-DD');
          }
        } else if(param === 'createdStartDate' || param === 'createdEndDate') {
          data[param] = moment(value[param]).format('YYYY-MM-DD');
        } else if (
          value[param] &&
          (param === 'clinicIds' ||
            param === 'doctorIds' ||
            param === 'financialPlanId' ||
            param === 'coverageType' ||
            param === 'status' ||
            param === 'paymentStatuses' ||
            param === 'itemCodes' ||
            param === 'patientIdentifier' ||
            param === 'itemIds' ||
            param === 'itemTypes' ||
            param === 'itemCategoryCodes' ||
            param === 'purchaseStatus' ||
            param === 'transactionTypes' ||
            param === 'excludeFinancialClass' ||
            param === 'coverageCodes' || 
            param === 'hsgStatuses' ||
            param === 'visitPurpose'
          )
        ) {
          data[param] = value[param].toString();
        } else {
          data[param] = value[param];
        }
      });
      delete data['clinicGroups'];
      this.payload = JSON.stringify(data);
    });
  }

  /** End of Form Change Subscription */

  /** Input Filters **/
  onPatientInputChanged() {
    try {
      this.patientTypeahead
        .pipe(
          filter((input) => {
            if (input.match(/[^a-zA-Z0-9 ]/g)) {
              const str = input.replace(/[^a-zA-Z0-9 ]/g, '');
              if (str.length < 1) {
                input = str;
                return false;
              }
            }
            if (input.trim().length === 0) {
              return false;
            } else {
              return true;
            }
          }),
          distinctUntilChanged((a, b) => {
            return a === b;
          }),
          debounceTime(200),
          switchMap((term: string) => {
            return this.apiPatientInfoService.search(term);
          })
        )
        .subscribe(
          (data) => {
            if (data) {
              this.patients = data.payload;
            }
          },
          (err) => {
            this.alertService.error(JSON.stringify(err));
            this.onPatientInputChanged();
          }
        );
    } catch (err) { }
  }

  onDrugInputChanged() {
    try {
      this.drugTypeahead
        .pipe(
          filter((input) => {
            if (input.match(/[^a-zA-Z0-9 ]/g)) {
              const str = input.replace(/[^a-zA-Z0-9 ]/g, '');
              if (str.length < 1) {
                input = str;
                return false;
              }
            }
            if (input.trim().length === 0) {
              return false;
            } else {
              return true;
            }
          }),
          distinctUntilChanged((a, b) => {
            return a === b;
          }),
          debounceTime(200),
          switchMap((term: string) => {
            return this.drugService.searchItem(term);
          })
        )
        .subscribe(
          (data) => {
            if (data) {
              this.drugs = data.payload.filter(({ item: item }) => {
                return item.itemType === 'DRUG';
              });
            }
          },
          (err) => {
            this.alertService.error(JSON.stringify(err));
            this.onDrugInputChanged();
          }
        );
    } catch (err) { }
  }

  onCoverageCodeChanged() {
    this.filteredMedicalCoverages$ = concat(
      of(this.medicalCoverageQuery.getAll()),
      this.filteredMedicalCoveragesSubject.asObservable(),
      this.codesTypeahead.pipe(
        distinctUntilChanged(),
        filter((input) => input !== undefined && input !== null && input.trim().length !== 0),
        tap(() => (this.codeLoading = true)),
        switchMap((term: string) =>
          this.apiCmsManagementService.searchCoverageAsObject(term).pipe(
            map((payload) => {
              const filteredPayload = payload.filter((data) => {
                return data['status'] === 'ACTIVE' && data['coveragePlans'].length > 0;
              });
              return filteredPayload;
            }),
            map((unfilteredData) => {
              if (this.selectedMedicalCoverageType.length > 0) {
                let tempfilteredMedicalCoverages = [];
                this.selectedMedicalCoverageType.map((value) => {
                  if (value) {
                    if (value === 'SFL') {
                      const _filteredMedicalCoverages = unfilteredData.filter((item) => item.type === value || item.name.includes(value));
                      tempfilteredMedicalCoverages = [...tempfilteredMedicalCoverages, ..._filteredMedicalCoverages];
                    } else {
                      const _filteredMedicalCoverages = unfilteredData.filter((item) => item.type === value);
                      tempfilteredMedicalCoverages = [...tempfilteredMedicalCoverages, ..._filteredMedicalCoverages];
                    }
                    
                  }
                });
                return tempfilteredMedicalCoverages;
              } else {
                return unfilteredData;
              }
            }),
            catchError(() => of(this.medicalCoverageQuery.getAll())),
            tap(() => (this.codeLoading = false))
          )
        )
      )
    );
  }

  private filterMedicalCoverage(filteredMedicalCoverages: any) {
    if (this.selectedMedicalCoverageType.length > 0) {
      this.filteredMedicalCoverages = [];
      this.selectedMedicalCoverageType.map((value) => {
        if (value) {
          const _filteredMedicalCoverages = filteredMedicalCoverages.filter((item) => item.type === value);
          this.filteredMedicalCoverages = [...this.filteredMedicalCoverages, ..._filteredMedicalCoverages];
        }
      });
    } else {
      this.filteredMedicalCoverages = filteredMedicalCoverages;
    }
  }

  /** End of Input Filters **/

  /** Event Listeners **/
  onPatientSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      this.onPatientInputChanged();
    }
  }

  onDoctorSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      // this.onPatientInputChanged();
    }
  }

  onDrugSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      this.onDrugInputChanged();
    }
  }

  onItemChargeSelect(event) { }

  onpurchaseStatusChargeSelect(event) { }
  onTransactionTypesSelect(event) { }

  onClinicGroupSelect(event) {
    if (event) {
      // reset all clinics
      this.mainFormGroup.get('clinicIds').patchValue([]);
      // select all clinics
      const clinics = [];
      event.forEach((element) => {
        this.groupedClinics[element].forEach((clinic) => {
          clinics.push(clinic.id);
        });
      });
      this.mainFormGroup.get('clinicIds').patchValue(clinics);
    }
  }

  onClinicSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      // this.onDrugInputChanged();
    }
  }

  onMedicalCoverageSelect(event) {
    if (!event) {
      // re-register the typeahead when ng-select is being cleared
      // this.onDrugInputChanged();
    }
  }

  onMedicalCoverageTypeSelect(event) {
    if (event && event.length > 0) {
      // event = array of {value, label}
      // filter medical coverages based on type
      this.filteredMedicalCoverages = [];
      this.selectedMedicalCoverageType = [];
      event.map((value) => {
        const medicalCoverageType = value['value'];
        this.selectedMedicalCoverageType.push(medicalCoverageType);
        if (medicalCoverageType) {
          const _filteredMedicalCoverages = this.medicalCoverageQuery
            .getAll()
            .filter((item) => item.type === medicalCoverageType);
          this.filteredMedicalCoverages = [...this.filteredMedicalCoverages, ..._filteredMedicalCoverages];
        }
      });
      this.filteredMedicalCoveragesSubject.next(this.filteredMedicalCoverages);
    } else {
      // put back original medical coverages
      this.selectedMedicalCoverageType = [];
      this.filteredMedicalCoverages = this.medicalCoverageQuery.getAll();
      this.filteredMedicalCoveragesSubject.next(this.filteredMedicalCoverages);
    }
  }

  onReportTypeSelect(event) {
    if (event) {
      if (
        event.reportName === 'private_corporate_patient_listing_paginated' &&
        this.mainFormGroup.get('isExport').value
      ) {
        this.showLoading();
        this.onPrivateCorporateExcelExport();
      }
      if (this.selectedReport.newUrl) {
        this.reportSubmitAction = this.reportUrlNew + event.reportName;
      } else {
        this.reportSubmitAction = this.reportUrl + event.reportName;
      }
    }
  }

  /** End of Event Listeners **/

  /** UTILS */
  getEndDatePickerPlacement(report: Report) {
    switch (report.reportName) {
      case 'pos_collection_summary':
      case 'corporate_revenue_summary':
      case 'laboratory_service_report':
      case 'report_on_weekly_revenue_summary':
      case 'report_on_sms_utilization':
        return 'bottom';

      default:
        return 'left';
    }
  }

  setMandatoryFields(report: Report) {
    report.params.forEach((value) => {
      if (
        value === 'clinicGroups' ||
        (value === 'clinicIds' &&
          this.selectedReport.reportName !== 'vaccine' &&
          this.selectedReport.reportName !== 'primary_care_network') ||
        value === 'coverageCodes' ||
        (value === 'doctorIds' &&
          this.selectedReport.reportName !== 'doctor_revenue_report' &&
          this.selectedReport.reportName !== 'doctor_revenue_report_cost') ||
        value === 'itemCategoryCodes' ||
        value === 'statuses' ||
        value === 'status' ||
        value === 'paymentStatuses' ||
        value === 'isMonthly' ||
        value === 'isDetail' ||
        value === 'isExport' ||
        value === 'showReason' ||
        value === 'incentiveFormat' ||
        value === 'patientNric' ||
        value === 'coverageType' ||
        value === 'excludeFinancialClass' ||
        (value === 'coverageCode' && this.selectedReport.reportName === 'medical_chit') ||
        (value === 'patientId' && this.selectedReport.reportName === 'medical_chit') ||
        this.selectedReport.reportName === 'daily_patient_register_report' ||
        (value === 'clinicId' && this.selectedReport.reportName === 'medical_chit') ||
        (value === 'itemCodes' &&
          (this.selectedReport.reportName === 'drug_dispensing_enquiry' ||
            this.selectedReport.reportName === 'drug_usage_report' ||
            this.selectedReport.reportName === 'item_usage_report' ||
            this.selectedReport.reportName === 'item_usage_advance_report' ||
            this.selectedReport.reportName === 'patient_treatment_records')) ||
        (value === 'itemCategoryCodes' && this.selectedReport.reportName === 'patient_treatment_records') ||
        (value === 'itemTypes' && this.selectedReport.reportName === 'patient_treatment_records') ||
        (value === 'itemIds' && this.selectedReport.reportName === 'inventory_grn_report' || this.selectedReport.reportName === 'purchase_flow_report' || this.selectedReport.reportName === 'inventory_movement_report') ||
        (value === 'purchaseStatus' && this.selectedReport.reportName === 'purchase_flow_report' ) ||
        (value === 'transactionTypes' && this.selectedReport.reportName === 'purchase_flow_report' ) ||
        value === 'caseStatus' || (value === 'itemIds' && this.selectedReport.reportName === 'inventory_valuation_report') ||
        (value === 'hsgStatuses' && this.selectedReport.reportName === 'hsg_report') ||
        (value === 'visitPurpose' && this.selectedReport.reportName === 'appointment_extraction_report')
      ) {
        // value === 'patientId' ||
        // (value === 'patientId' && this.selectedReport.reportName === 'medical_chit') ||
        return;
      }

      if (
        value === 'doctorIds' &&
        (this.selectedReport.reportName === 'doctor_revenue_report' || this.selectedReport.reportName === 'doctor_revenue_report_cost') &&
        !!this.permissionsService.getPermission('ROLE_ALL_DOCTOR_REPORTS')
      ) {
        return false;
      }

      this.mainFormGroup.get(value).setValidators(Validators.required);
      this.mainFormGroup.get(value).updateValueAndValidity();
      this.mainFormGroup.get(value).markAsTouched();
    });
  }

  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  /** End of UTILS */

  generateForm() {
    this.mainFormGroup = this.fb.group({
      clinicIds: '',
      clinicId: '',
      clinicGroups: '',
      doctorIds: '',
      dateRange: '',
      startDate: this.startDate,
      endDate: this.endDate,
      startTime: this.startDate,
      endTime: this.endDate,
      drugCode: '',
      itemCodes: '',
      itemCategoryCodes: '',
      itemIds: '',
      itemTypes: '',
      financialPlanId: '',
      coverageType: '',
      statuses: '',
      status: '',
      patientId: '',
      monthlyReport: '',
      isMonthly: [false],
      coverageCode: '',
      coverageCodes: '',
      reportFilter: '',
      patientNric: '',
      showReason: [false],
      incentiveFormat: [false],
      isDetail: [false],
      isExport: [false],
      caseStatus: '',
      purchaseStatus: '',
      transactionTypes: '',
      paymentStatuses: '',
      excludeFinancialClass: '',
      patientIdentifier: '',
      nphsReportType: '',
      nphsReportTypeHe3: '',
      hsgStatuses: '',
      dateFilterType: '',
      visitPurpose: '',
      createdStartDate: this.startDate,
      createdEndDate: this.endDate,
    });
  }

  prePopulateData() {
    if (this.findByParam('clinicId')) {
      this.mainFormGroup.get('clinicId').patchValue(localStorage.getItem('clinicId'));
      this.mainFormGroup.updateValueAndValidity();
    }

    if (this.findByParam('itemCodes')) {
      this.mainFormGroup.get('itemCodes').patchValue('');
    }

    if (this.findByParam('itemIds')) {
      this.mainFormGroup.get('itemIds').patchValue('');
    }

    if (this.findByParam('itemCategoryCodes')) {
      this.mainFormGroup.get('itemCategoryCodes').patchValue('');
    }

    if (this.findByParam('purchaseStatus')) {
      this.mainFormGroup.get('purchaseStatus').patchValue('');
    }

    if (this.findByParam('transactionTypes')) {
      this.mainFormGroup.get('transactionTypes').patchValue('');
    }

    /** Start Date */
    this.mainFormGroup.get('startDate').patchValue(this.startDate);
    this.mainFormGroup.get('startTime').patchValue(this.startDate);
    if (this.selectedReport.reportName === 'inventory_movement_report') {
      this.mainFormGroup.get('startDate').patchValue(moment().subtract(1, 'month').startOf('day').toDate());
    }

    /** End Date */
    this.mainFormGroup.get('endDate').patchValue(this.endDate);
    this.mainFormGroup.get('endTime').patchValue(this.endDate);

    this.mainFormGroup.get('createdStartDate').patchValue(this.startDate);
    this.mainFormGroup.get('createdEndDate').patchValue(this.endDate);

    if (this.selectedReport.reportName === 'mobile_consult_doctor_incentive_report') {
      let lastmonth = moment().subtract(1, 'months').startOf('day').toDate();
      let lestMonthStart = moment(lastmonth).startOf('month').toDate();
      let lestMonthEnd = moment(lastmonth).endOf('month').toDate();
      lestMonthStart.setHours(0, 0, 0);
      lestMonthEnd.setHours(23, 59, 59);

      this.mainFormGroup.get('startDate').patchValue(lestMonthStart);
      this.mainFormGroup.get('startDate').patchValue(lestMonthStart);
      this.mainFormGroup.get('endDate').patchValue(lestMonthEnd);
      this.mainFormGroup.get('endTime').patchValue(lestMonthEnd);
    }

    /** isDetail */
    this.mainFormGroup.get('isDetail').patchValue(false);

    /** dateFilterType */
    this.mainFormGroup.get('dateFilterType').patchValue(this.dateFilterTypes[0].value);
  }

  findByParam(param) {
    if (this.selectedReport && this.selectedReport.params) {
      const result = this.selectedReport.params.find((value) => {
        return value === param;
      });
      return result;
    } else {
      return false;
    }
  }
}
