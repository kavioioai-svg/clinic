import { Component, OnInit, ViewChild } from '@angular/core';
import { keyBy, omit, isEmpty, keys, get } from 'lodash';
import helper from '../Helpers';
import { UserListService } from '../../../../state/user-list/user-list.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ServiceService } from '../service.service';
import { AlertService } from '../../../../services/alert.service';
import { StoreService } from '../../../../services/store.service';
import { UserListQuery } from '../../../../state/user-list/user-list.query';

@Component({
  selector: 'app-company-grouping',
  templateUrl: './company-grouping.component.html',
  styleUrls: ['./company-grouping.component.scss'],
})
export class CompanyGroupingComponent implements OnInit {
  @ViewChild('companyFilter', { static: false }) companyFilterRef;
  @ViewChild('userFilter', { static: false }) userFilterRef;
  @ViewChild('companyGroupForm', { static: false }) companyGroupForm;

  _id: string;
  myGroup: FormGroup;
  companyFormGroup: FormGroup;
  userFormGroup: FormGroup;
  companiesList: any = [];
  companiesListMaster: any = [];

  usersList: any = [];
  usersListMaster: any = [];

  users: any = {};
  userFetchState = 0;

  selectedUsers: any = {};
  selectedCompanies: any = {};

  filteredCompanyList: Array<any>;
  companies: any = {};

  filteredUserList: Array<any>;

  companyGroups: CompanyGroup[] = [];
  companyGroupsAll: CompanyGroup[] = [];

  pageIndex = 0;
  countPerPage = 5;
  searchText = '';
  constructor(
    private service: ServiceService,
    private fb: FormBuilder,
    private alert: AlertService,
    private userListQuery: UserListQuery
  ) {
    this.myGroup = new FormGroup({
      filterUser: new FormControl(),
    });

    this.companyFormGroup = this.getCompanyForm();
    this.userFormGroup = this.getUserForm();
    this.getCompanyList();
    this.onSearchUsers();
  }
  getCompanyForm() {
    return this.fb.group({
      id: [],
      name: [],
      selectedCompanyIds: [],
    });
  }

  getUserForm() {
    return this.fb.group({
      id: [],
      name: [],
      selectedUserIds: [],
    });
  }
  populateCompanyMasterForm() {
    this.companyFormGroup.get('selectedCompanyIds').patchValue([]);
  }
  populateUserMasterForm() {
    this.userFormGroup.get('selectedUserIds').patchValue([]);
  }
  ngOnInit() {
    this.userFetchState = 1;
    const users = this.userListQuery
      .getAll()
      .filter((each) => each.status === 'ACTIVE')
      .map((d, index) => ({ name: d.userName, index }));
    this.users = keyBy(users, 'index');

    this.userFetchState = 2;
    this.service.fetchCompanyGroup().subscribe((res) => {
      this.companyGroups = res.payload.content.map((json) => CompanyGroup.fromListJSON(json));
      this.companyGroupsAll = this.companyGroups;
      this.getCompanyGroups();
    });
    this.populateCompanyMasterForm();
    this.populateUserMasterForm();
  }
  searchKey(data: string) {
    this.companyGroups = this.companyGroupsAll;
    this.searchText = data;
    this.search();
  }
  search() {
    this.companyGroups =
      this.searchText === ''
        ? this.companyGroupsAll
        : this.companyGroups.filter((element) => {
            return (
              element.groupId.toLowerCase().includes(this.searchText.toLowerCase()) ||
              element.groupName.toLowerCase().includes(this.searchText.toLowerCase()) ||
              element.description.toLowerCase().includes(this.searchText.toLowerCase())
            );
          });
  }

  getCompanyList() {
    this.service.searchCompanies().subscribe((res) => {
      const payload = res.payload.content;
      
      this.filteredCompanyList = payload.map(doc => {
        return {'value': doc.id, 'label': doc.name, 'selected': false} 
      });
      const companies = keyBy(this.filteredCompanyList, 'value');
      this.companies = omit(companies, keys(this.selectedCompanies));
    });
  }

  onSearch() {
    let tempFilteredList = this.filteredCompanyList;
    this.filteredCompanyList = [];
    tempFilteredList.forEach((com) => {
      com.selected = Object.keys(this.selectedCompanies).includes(com.value);
    });
    this.filteredCompanyList = [...tempFilteredList];
  }

  onSearchUsers() {
    const users = this.userListQuery
      .getAll()
      .filter((each) => each.status === 'ACTIVE')
      .map((d, index) => ({ name: d.userName, index }));
    this.filteredUserList = [];
    users.forEach((doc) => {
      this.filteredUserList.push({
        value: doc.index,
        label: doc.name,
        selected: false,
      });
    });
  }

  onSearchUsersEdit() {
    const users = this.userListQuery
      .getAll()
      .filter((each) => each.status === 'ACTIVE')
      .map((d, index) => ({ name: d.userName, index }));
    this.filteredUserList = [];
    users.forEach((doc) => {
      this.filteredUserList.push({
        value: doc.index,
        label: doc.name,
        selected: this.checkSelectedUser(doc.name, this.selectedUsers), //Object.keys(this.selectedUsers).includes(doc.name),
      });
    });
  }
  checkSelectedUser(name: any, selectedUsersArray: any) {
    let userSelected = false;
    selectedUsersArray.forEach((doc) => {
      if (doc.name === name) {
        userSelected = true;
      }
    });
    return userSelected;
  }
  getUsernamesByIds() {
    let userSelected = [];
    this.filteredUserList.forEach((doc) => {
      if (doc.selected) {
        userSelected.push(doc.label);
      }
    });
    return userSelected;
  }

  getCompaniesByIds() {
    let companySelected = [];
    this.filteredCompanyList.forEach((doc) => {
      if (doc.selected) {
        companySelected.push(doc.value);
      }
    });
    return companySelected;
  }
  submit() {
    const createReq = {
      ...this.companyGroupForm.form.value,
      medicalCoverageList: this.getCompaniesByIds(),
      usernameList: this.getUsernamesByIds(),
    };
    if (this._id) {
      this.updateCompanyGroup(createReq);
    } else {
      this.createCompanyGroup(createReq);
    }
  }

  createCompanyGroup(createReq) {
    this.service.createCompanyGroup(createReq).subscribe(
      (res) => {
        this.alert.success('Created company group successfully');
        this.companyGroups.push(CompanyGroup.fromCreateJSON(res.payload, this.selectedCompanies, this.selectedUsers));

        this.clear();
        this.selectedCompanies = {};
        this.ngOnInit();
        this.onSearch();
      },
      (error) => {
        const msg =
          helper.getStr(error, 'error.message') || helper.getStr(error, 'message') || 'Create company group failed';
        this.alert.error(msg);
      }
    );
  }

  updateCompanyGroup(createReq) {
    this.service.updateCompanyGroup(createReq, this._id).subscribe(
      (res) => {
        this.alert.success('Company group successfully updated');

        const companyGroup = CompanyGroup.fromCreateJSON(res.payload, this.selectedCompanies, this.selectedUsers);

        const index = this.companyGroups.findIndex((cg) => cg.id === companyGroup.id);
        if (index >= 0) this.companyGroups[index] = companyGroup;

        this.clear();
        this.selectedCompanies = {};
        this.ngOnInit();
        this.onSearch();
      },
      (error) => {
        const msg =
          helper.getStr(error, 'error.message') || helper.getStr(error, 'message') || 'Create company group failed';
        this.alert.error(msg);
      }
    );
  }

  clear() {
    this._id = null;

    this.companyGroupForm.reset();
    this.selectedUsers = {};
    this.selectedCompanies = {};
    this.onSearch();
    this.onSearchUsers();
  }

  edit(item) {
    this.companyGroupForm.setValue(omit(item, ['id', 'medicalCoverages', 'users']));
    this.selectedCompanies = keyBy(item['medicalCoverages'], 'id');
    this.selectedUsers = item['users'];

    this._id = item.id;
    this.onSearch();
    this.onSearchUsersEdit();
  }
  isDirty() {
    return get(this.companyGroupForm, 'touched') || !isEmpty(this.selectedCompanies) || !isEmpty(this.selectedUsers);
  }

  getName(item) {
    return helper.getStr(item, 'name');
  }

  handlePageChange(index) {
    this.pageIndex = index;
    this.getCompanyGroups();
  }

  getCompanyGroups() {
    const startIndex = this.pageIndex * this.countPerPage;
    const endIndex = (this.pageIndex + 1) * this.countPerPage;

    this.companyGroups = this.companyGroups.sort((a, b) => a.status.localeCompare(b.status));
    this.companiesList = this.companyGroups.slice(startIndex, endIndex);
    this.companiesListMaster = this.companiesList;
  }

  searchTable() {
    this.getCompanyGroups();
  }

  getPages() {
    return this.companyGroups.length / this.countPerPage;
  }
}

class CompanyGroup {
  id: string;
  groupId: string;
  groupName: string;
  description: string;
  status: string;
  medicalCoverages: any[];
  users: any[];

  constructor(
    id: string,
    groupId: string,
    groupName: string,
    description: string,
    status: string,
    medicalCoverages: string[],
    users: string[]
  ) {
    this.id = id;
    this.groupId = groupId;
    this.groupName = groupName;
    this.description = description;
    this.status = status;
    this.medicalCoverages = medicalCoverages;
    this.users = users;
  }

  static fromListJSON(json) {
    const medicalCoverageNameList = json['medicalCoverageNameList'];
    const medicalCoverages = Object.keys(medicalCoverageNameList).map<any>((id) => ({
      id,
      name: medicalCoverageNameList[id],
    }));

    const users = json['usernameList'].map((name) => ({ name }));

    return new CompanyGroup(
      json['groupingId'],
      json['groupId'],
      json['groupName'],
      json['description'],
      json['status'],
      medicalCoverages,
      users
    );
  }

  static fromCreateJSON(json, selectedCompanies, selectedUsers) {
    return new CompanyGroup(
      json['id'],
      json['groupId'],
      json['groupName'],
      json['description'],
      json['status'],
      Object['values'](selectedCompanies),
      Object['values'](selectedUsers)
    );
  }
}
