import { get, range } from 'lodash'
import { Time } from "@angular/common";

export const UTC_FORMAT = 'DD-MM-YYYYTHH:mm:ss';

class Helpers {
  static getStr = (obj, ltr) => get(obj, ltr) || ''

  static range = (limit) => range(0, limit)

  static getTimeFromStr = (time: string): Time => {
    const arr = time.split(':')

    return {
      hours: parseInt(arr[0]),
      minutes: parseInt(arr[1])
    }
  }

  static padNumber = (number: number) => number < 10 ? `0${number}` : `${number}`

  static getErrors = (err) => get(err, 'error.message') || get(err, 'message') || ''
}

export default Helpers
