import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { GroupManagementComponent } from "./group-management.component";
import { TestingModule } from "../../../../test/testing.module";

describe("GroupManagementComponent", () => {
  let component: GroupManagementComponent;
  let fixture: ComponentFixture<GroupManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TestingModule],
      declarations: [GroupManagementComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
