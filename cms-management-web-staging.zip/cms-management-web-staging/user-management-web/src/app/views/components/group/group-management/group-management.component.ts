import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from '../../../../services/alert.service';
import { ApiAAService } from '../../../../services/api-aa';
// import { Angular5Csv } from 'angular5-csv/Angular5-csv';
@Component({
  selector: 'app-group-management',
  templateUrl: './group-management.component.html',
  styleUrls: ['./group-management.component.scss'],
})
export class GroupManagementComponent implements OnInit {
  formGroup: FormGroup;
  moduleList;
  selectedModule = '';

  avaliableRoleList;
  originialAvaliableRoleList; // The very first list of avaliavble role
  userSelectedRoleList; // The array of roles user have
  highlishtedUserRoleList; // The highlighted elements on RHS
  highlishtedAvaliableRoleList; // The highlighted elements on LHS

  isFormGroupEditUser = false;

  rows; // Items will be shown
  tempRows; // Cache the list

  constructor(
    private fb: FormBuilder,
    private alertService: AlertService,
    private router: Router,
    private apiAAService: ApiAAService
  ) {}

  ngOnInit() {
    this.getAllRoleList();
    this.getAllModulesList();
    this.getAllGroupList();
    this.createForm();

    this.moduleList = [];
    this.originialAvaliableRoleList = []; // Avaliable Role List

    this.userSelectedRoleList = []; // Left Column
    this.avaliableRoleList = Object.assign([], this.originialAvaliableRoleList); // Right Column
  }

  /* Form Group Related */
  createForm() {
    this.formGroup = this.fb.group({
      module: this.selectedModule, // Default CMS
      name: ['', Validators.required],
      description: ['', Validators.required],
      avaliableRole: [], // Keep empty, just for detect valueChange in <select> element
      selectedRole: [], // Keep empty, patch selectedRoleList only until user submit
    });
  }

  updateForm(userObj) {
    this.isFormGroupEditUser = true;
    this.userSelectedRoleList = Object.assign([], userObj.selectedRole);

    const roleNotSelected = this.originialAvaliableRoleList.filter((role) => userObj.selectedRole.indexOf(role) === -1);
    this.avaliableRoleList = Object.assign([], roleNotSelected); // And filter those item in userSelectedRoleList
    this.formGroup.patchValue({
      module: userObj.module,
      name: userObj.name,
      description: userObj.description,
      avaliableRole: [], // Keep empty, just for detect valueChange in <select> element
      selectedRole: [], // Keep empty, patch selectedRoleList only until user submit. (We submit all shown in <select> but not just Selected)
    });
    this.formGroup.get('module').disable();
  }

  resetForm() {
    this.isFormGroupEditUser = false;
    this.userSelectedRoleList = [];
    this.avaliableRoleList = Object.assign([], this.originialAvaliableRoleList);

    this.formGroup.reset();
    this.formGroup.enable();
    this.createForm();
  }

  addRole() {
    const highlishtedAvaliableRoleList = this.formGroup.get('avaliableRole').value;

    highlishtedAvaliableRoleList.forEach((element) => {
      const index = this.avaliableRoleList.indexOf(element);
      if (index >= 0) {
        this.avaliableRoleList.splice(index, 1);
        this.userSelectedRoleList.push(element);
      }
    });

    this.userSelectedRoleList.sort();
  }

  removeRole() {
    const highlishtedUserRoleList = this.formGroup.get('selectedRole').value;

    highlishtedUserRoleList.forEach((element) => {
      const index = this.userSelectedRoleList.indexOf(element);
      if (index >= 0) {
        this.userSelectedRoleList.splice(index, 1);
        this.avaliableRoleList.push(element);
      }
    });

    this.avaliableRoleList.sort();
  }
  /* END OF Form Group Related */

  /* API Connection */
  getAllModulesList() {
    this.apiAAService.listModulesWithPagination().subscribe((res) => {
      this.moduleList = [...res.payload.map((val) => val.name)];
      this.selectedModule = this.moduleList[0];
      this.formGroup.get('module').setValue(this.moduleList[0]);
    });
  }

  getAllGroupList() {
    this.apiAAService.listGroupsWithPagination().subscribe(
      (res) => {
        const newArr = res.payload.map((val, index, arr) => {
          return {
            module: '------',
            name: val.name,
            description: val.description,
            selectedRole: (val.roles.map((value) => value.role) as Array<string>).sort(),
            expanded: false,
          };
        });

        this.rows = newArr;
        this.tempRows = newArr;
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }

  getAllRoleList() {
    this.apiAAService.listRoles().subscribe((res) => {
      this.originialAvaliableRoleList = (res.payload.map((val) => val.role) as Array<string>).sort();
      this.resetForm();
    });
  }

  addNewGroup(group: AddGroupReq) {
    this.apiAAService.addGroup(JSON.stringify(group)).subscribe(
      (res) => {
        // Group is added
        this.resetForm();
        this.getAllGroupList();
        alert('New Group "' + group.groupName + '" is added');
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }

  editGroup(group: EditGroupReq) {
    this.apiAAService.editGroup(JSON.stringify(group)).subscribe(
      (res) => {
        // Group is added
        this.resetForm();
        this.getAllGroupList();
        alert('New Group "' + group.groupName + '" is updated');
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      }
    );
  }
  /* END of API Connection */

  onEditUserClicked(row) {
    this.updateForm(row);
    window.scrollTo(0, 0);
  }

  updateInputFilter(event) {
    const val = event.target.value.toLowerCase();
    // filter our data
    const temp = this.tempRows.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || d.description.toLowerCase().indexOf(val) !== -1 || !val;
    });

    // update the rows
    this.rows = temp;
  }

  onModuleChange(val) {
    this.selectedModule = val;
  }

  onAddGroupClicked() {
    if (this.formGroup.valid) {
      const groupAdd: AddGroupReq = this.mapFormGroupToAddGroupReq(this.formGroup);
      this.addNewGroup(groupAdd);
    } else {
    }
  }

  onEditGroupClicked() {
    if (this.formGroup.valid) {
      const groupEdit: EditGroupReq = this.mapFormGroupToEditGroupReq(this.formGroup);
      this.editGroup(groupEdit);
    } else {
    }
  }

  /* Data Mapper */
  mapFormGroupToAddGroupReq(formGroup: FormGroup): AddGroupReq {
    const group = new AddGroupReq(
      formGroup.get('module').value,
      formGroup.get('name').value,
      formGroup.get('description').value,
      this.userSelectedRoleList
    );
    return group;
  }

  mapFormGroupToEditGroupReq(formGroup: FormGroup): EditGroupReq {
    const group = new EditGroupReq(
      formGroup.get('name').value,
      formGroup.get('description').value,
      this.userSelectedRoleList
    );
    return group;
  }

  exportCSV() {
    //     const options = {
    //       headers: ['Name', 'Description', 'Selected Role', 'Status']
    //     };
    //     const csvArr = this.tempRows.map(val => {
    //       return {
    //         name: val.name,
    //         description: val.description,
    //         selectedRole: val.selectedRole.toString(),
    //         status: 'N/A'
    //       };
    //     });
    //     new Angular5Csv(csvArr, 'Groups', options);
  }
}

class AddGroupReq {
  module: string;
  groupName: string;
  description: string;
  roles: string[];

  constructor(module?: string, groupName?: string, description?: string, roles?: string[]) {
    this.module = module;
    this.groupName = groupName;
    this.description = description;
    this.roles = roles;
  }
}

class EditGroupReq {
  groupName: string;
  description: string;
  roles: string[];

  constructor(groupName?: string, description?: string, roles?: string[]) {
    this.groupName = groupName;
    this.description = description;
    this.roles = roles;
  }
}
