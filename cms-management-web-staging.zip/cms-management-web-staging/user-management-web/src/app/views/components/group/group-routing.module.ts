import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgxPermissionsGuard } from 'ngx-permissions';

import { GroupManagementComponent } from './group-management/group-management.component';

const routes: Routes = [
  {
    path: '',
    canActivateChild: [NgxPermissionsGuard],
    data: {
      title: 'Group',
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'all' },
      { path: 'all',
        component: GroupManagementComponent
      },
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GroupRoutingModule { }
