import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../../../shared.module';
import { GroupRoutingModule } from './group-routing.module';
import { GroupManagementComponent } from './group-management/group-management.component';

@NgModule({
  imports: [CommonModule, SharedModule, GroupRoutingModule],
  declarations: [GroupManagementComponent],
})
export class GroupModule { }
