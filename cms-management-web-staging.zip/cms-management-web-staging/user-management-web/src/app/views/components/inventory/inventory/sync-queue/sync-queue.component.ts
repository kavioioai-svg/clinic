import { Component, OnInit, ViewChild } from '@angular/core';
import { InventoryService } from '../../../../../services/inventory.service';
import { Page } from '../../../../../model/page';
import { SyncQueue, SyncQueueFilter, SyncQueueStatus, SyncQueueServiceKey } from '../../../../../objects/SyncQueue';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
const filterOptionsJson = require('../../../../../settings/filter-options.json');
import { MasterDataService } from '../../../../../services/master-data-service/master-data.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { TemplateFucType } from '../../../../../model/enum/enums';

@Component({
  selector: 'app-sync-queue',
  templateUrl: './sync-queue.component.html',
  styleUrls: ['./sync-queue.component.scss'],
})
export class SyncQueueComponent implements OnInit {
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;

  page: Page = new Page();
  listQueue: SyncQueue[] = [];
  isLoading: boolean = false;
  searchFrm: FormGroup;
  statusOptions: any[] = [];
  serviceKeyOptions: any[] = [];
  @ViewChild('myTable', { static: false }) table: DatatableComponent;
  private isActiveTab: boolean;

  constructor(
    private inventoryService: InventoryService,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private masterDataService: MasterDataService,
  ) {

    this.defaultPageOption();
    this.startDatePickerConfig = new DatePickerConfig('start date', null, null, 'bottom', 'right');
    this.endDatePickerConfig = new DatePickerConfig('end date', null, null, 'bottom', 'right');
  }

  async ngOnInit() {
    // this.activatedRoute.params.subscribe((res) => {
    //   //if (res.tabIndex === '3') this.getSyncQueueList();
    // });
    await this.populateFormData();

    this.masterDataService.onTabChange$.subscribe(result => {
      if (result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '2'
      if (this.isActiveTab) {
        this.onSubmitSearch()
      }
    })
  }

  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.filterSyncQueue();
  }

  get SyncQueueStatus() {
    return SyncQueueStatus;
  }

  refreshSyncStatus(item: SyncQueue) {
    this.inventoryService.refreshSyncQueue(item.id).subscribe(
      (res: any) => {
        item.isLoading = false;
        let index = this.listQueue.findIndex((x) => x.id === res.payload.id);
        this.listQueue[index] = new SyncQueue(res.payload);
        this.listQueue = [...this.listQueue];
      },
      (error) => {
        item.isLoading = false;
      }
    );
  }

  onSubmitSearch() {
    if (this.isActiveTab) {
      this.defaultPageOption();
      this.filterSyncQueue();
    }
  }

  filterSyncQueue() {
    let filter = new SyncQueueFilter(this.searchFrm.controls);
    this.inventoryService.filterSyncQueue(filter, this.page).subscribe(
      (res) => {
        if (res.message === 'Success') {
          this.page.pageNumber = res['pageNumber'];
          this.page.totalPages = res['totalPages'];
          this.page.totalElements = res['totalElements'];
          this.listQueue = [];
          if (res.payload.content.length > 0) {
            res.payload.content.forEach((r) => {
              this.listQueue.push(new SyncQueue(r));
            });
          }
          this.isLoading = false;
        }
      },
      (err) => {
        (error) => (this.isLoading = false);
      }
    );
  }

  async populateFormData() {
    this.searchFrm = this.fb.group({
      referenceNo: [''],
      sentOnStart: [new Date(), Validators.required],
      sentOnEnd: [new Date(), Validators.required],
      status: ['ALL'],
      serviceName: [''],
    });

    this.statusOptions = filterOptionsJson.syncQStatus;
    this.serviceKeyOptions = filterOptionsJson.serviceKey.sort((a, b) => a.name.localeCompare(b.name));
    // this.inventoryService
    //   .filterSyncQueue(<SyncQueueFilter>this.searchFrm.getRawValue(), this.page)
    //   .subscribe((res) => {});
  }
  get TemplateFucType() {
    return TemplateFucType;
  }

  private defaultPageOption() {
    this.page.size = 50;
    this.page.pageNumber = 0;
  }
  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table, pageInfo);
  };

  copyDescription(event) {
    const abc = event;
    navigator.clipboard.writeText(event.navResponse);
  }
}
