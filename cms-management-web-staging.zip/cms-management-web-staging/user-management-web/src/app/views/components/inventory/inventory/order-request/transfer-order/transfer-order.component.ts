import {Component, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {StoreStatusQuery} from '../../../../../../state/store-status/store-status.query';
import {ClinicQuery} from '../../../../../../state/clinic/clinic.query';
import {ActivatedRoute, Router} from '@angular/router';
import {InventoryService} from '../../../../../../services/inventory.service';
import {AlertService} from '../../../../../../services/alert.service';
import {BehaviorSubject, combineLatest} from 'rxjs';
import {InventoryTab, TemplateFucType} from '../../../../../../model/enum/enums';
import {Order} from '../../../../../../objects/Supplier';
import {Clinic} from '../../../../../../objects/response/Clinic';
import {ApiInventoryService} from "../../../../../../services/api-inventory.service";
import {ChargeItemQuery} from "../../../../../../state/charge-item/charge-item.query";
import * as $ from 'jquery';
import moment = require("moment");

@Component({
  selector: 'app-transfer-order',
  templateUrl: './transfer-order.component.html',
  styleUrls: ['./transfer-order.component.scss']
})
export class TransferOrderComponent implements OnInit {

  orderForm: FormGroup;
  initForm: FormGroup;
  currentOrderStatus: string;
  order: BehaviorSubject<Order> = new BehaviorSubject<Order>(null);
  allClinics: BehaviorSubject<Clinic[]> = new BehaviorSubject<Clinic[]>([]);
  items: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);
  itemsWithInventory: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);
  itemMap: {[k: string]: any} = {};

  requestedClinic: Clinic;
  senderClinic: Clinic;
  clinics: Clinic[];
  itemAvailableClinics: Clinic[];
  selectedItems: Set<string> = new Set<string>();
  _allItemsSelected: boolean = false
  operation: 'view' | 'edit' | 'create' = 'view';
  private inventoryItemsMap: BehaviorSubject<any> = new BehaviorSubject<any>({});
  private lineIdCounter: number = 1;

  constructor(  private storeStatusQuery: StoreStatusQuery,
                private clinicQuery: ClinicQuery,
                private router: Router,
                private fb: FormBuilder,
                private inventoryService: InventoryService,
                // private itemService: ItemService,
                private alertService: AlertService,
                private activatedRoute: ActivatedRoute,
                private chargeItemQuery: ChargeItemQuery,
                private apiInventoryService: ApiInventoryService) { }

  ngOnInit() {
    this.orderForm = this.fb.group({
      requestClinicId: [undefined, Validators.required],
      senderClinicId: [undefined, Validators.required],
      transferRequestItems: this.fb.array([], Validators.required),
      remark: [],
    })
    this.initForm = this.orderForm.getRawValue();
    this.items.subscribe(items => {
      this.itemMap = items.reduce((acc, val) => {
        acc[val.id] = val;
        return acc;
      }, {})
    })

    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        let all = this.clinicQuery.getAll();
        this.allClinics.next(all);
        this.clinics = all;
        this.itemAvailableClinics = all;
        let allItems = this.chargeItemQuery.getAllItems();
        this.items.next(allItems.filter(a => (a.category === 'DRUGS' || 'RAD' || 'RADIOLOGY' || 'CONSUMABLE' || 'VACCINATION' || 'LABORATORY' || 'OTHER' || 'IMPLANTS')));
      });

    this.activatedRoute.params.subscribe(params => {
      let id = params['id'];
      this.operation = params['operation'];
      if (!!id) {
        this.inventoryService.getPurchaseOrderById(id).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.order.next(res.payload.order);
            this.initialiseTransferOrdreDependencies();
          }
        })
      } else {
        this.order.next({
          orderStatus: 'DRAFT',
          goodPurchasedItems: [],
          goodReceivedNotes: [],
          orderType: 'TRANSFER',
          transferRequestItems: [],
          returnItems: [],
          deliveryNotes: []
        })

        this.initialiseTransferOrdreDependencies();
      }
    })

    // this.orderForm.get("senderClinicId").valueChanges.subscribe(val => {
    //   if (!!val) {
    //     this.apiInventoryService.findItemsByClinicId(val).subscribe(res => {
    //       if (res && res.statusCode === "S0000") {
    //         let inventoryItemsMap = {}
    //         res.payload
    //           .filter(({expiryDate}) => moment(expiryDate, "DD-MM-YYYY").isAfter(moment()))
    //           .filter(({availableCount}) => availableCount > 0)
    //           .forEach(inventoryItem => {
    //             inventoryItem["availableQuantity (expiryDate)"] = `${inventoryItem.availableCount} ( ${inventoryItem.expiryDate} )`
    //             inventoryItemsMap[inventoryItem.itemRefId] = inventoryItemsMap[inventoryItem.itemRefId] || [];
    //             inventoryItemsMap[inventoryItem.itemRefId].push(inventoryItem);
    //           })
    //         this.inventoryItemsMap.next({inventoryItemsMap});
    //       }
    //     })
    //   }
    // })

    combineLatest([this.allClinics, this.order])
      .subscribe(([allClinics, order]) => {
        this.itemAvailableClinics = allClinics;
      })

    combineLatest([this.allClinics, this.orderForm.valueChanges, this.order]).subscribe(([clinics, orderForm, order]) => {
      let filteredClinics = order.transferRequestItems.map(item => clinics.find(clinic => clinic.id === order.requestClinicId))
        .filter(a => !!a);
      if (filteredClinics.length > 0) {
        this.clinics = filteredClinics;
      } else {
        this.clinics = clinics;
      }

      this.requestedClinic = clinics.find(clinic => clinic.id === orderForm.requestClinicId)
      this.senderClinic = clinics.find(clinic => clinic.id === orderForm.senderClinicId)
    })

    combineLatest([this.items, this.inventoryItemsMap]).subscribe(([items, inventoryItemsMap]) => {
      let itemsWithInventory = items.map(item => {
        return {
          ...item,
          batches: inventoryItemsMap[item.id],
          inventoryAvailable: inventoryItemsMap[item.id] && inventoryItemsMap[item.id].length ? 'AVAILABLE' : 'NOT_AVAILABLE'
        }
      }).sort((a, b) => {
        if (a.inventoryAvailable === b.inventoryAvailable) {
          return a.code > b.code ? 1 : -1;
        } else {
          return a.inventoryAvailable === 'AVAILABLE' ? -1 : 1;
        }
      })
      this.itemsWithInventory.next(itemsWithInventory);

    })

    combineLatest([this.items, this.orderForm.get("senderClinicId").valueChanges]).subscribe(([items, value]) => {
      if (value) {
        this.apiInventoryService.findItemsByClinicId(value).subscribe(res => {

          
          if (res && res.statusCode === "S0000") {
            let inventoryItemsMap = {}
            res.payload
              .filter(({expiryDate}) => moment(expiryDate, "DD-MM-YYYY").isAfter(moment()))
              .filter(({availableCount}) => availableCount > 0)
              .forEach(inventoryItem => {
                inventoryItem["availableQuantity (expiryDate)"] = `${inventoryItem.availableCount} ( ${inventoryItem.expiryDate} )`
                inventoryItemsMap[inventoryItem.itemRefId] = inventoryItemsMap[inventoryItem.itemRefId] || [];
                inventoryItemsMap[inventoryItem.itemRefId].push(inventoryItem);
              })

            Object.keys(inventoryItemsMap).forEach(key => {
              inventoryItemsMap[key].sort(this.sortBatches.bind(this))
            })

            this.inventoryItemsMap.next(inventoryItemsMap)

            let requestItems = this.orderForm.get("transferRequestItems") as FormArray;
            requestItems.controls.forEach((control, index) => {
              control.patchValue({
                batches: inventoryItemsMap[control.value.itemRefId]
              })
            })
          } else {
          }
        })
      } else {
        this.orderForm.get('senderClinicId').setErrors({ invalid: 'To Clinic should not be empty' });
      }
    })
  }

  private initialiseTransferOrdreDependencies() {
    this.orderForm.patchValue({
      requestClinicId: this.order.value.requestClinicId,
      senderClinicId: this.order.value.senderClinicId,
      remark: this.order.value.remark,
    });
    this.currentOrderStatus = this.order.value.orderStatus;
    if(!this.orderForm.controls.senderClinicId.value) {
      this.orderForm.get('senderClinicId').setValidators([Validators.required])
      this.orderForm.get('senderClinicId').setErrors({ invalid: 'To Clinic should not be empty' });
    }

    let receivedQuantities: { [k: string]: number } = {}
    this.order.value.transferRequestItems.forEach(item => {
      for (const note of this.order.value.goodReceivedNotes) {
        if (note.status == 'CONFIRM') {
          for (const receivedItem of note.receivedItems) {
            if (receivedItem.lineNo == item.lineNo) {
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] || 0;
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] + receivedItem.quantity;
            }
          }
        }
      }
    })

    this.order.value.transferRequestItems
      .map(this.createListItemGroup.bind(this, receivedQuantities))
      .forEach(item => (this.orderForm.get("transferRequestItems") as FormArray).push(item as any));

    this.initForm = this.orderForm.getRawValue();
  }

  goBack() {
    let isModified:boolean = JSON.stringify(this.initForm) !== JSON.stringify(this.orderForm.getRawValue());
    if(isModified && this.operation != 'view'){
      let text = "Changes are not saved";
      if (confirm(text) == true) {
        this.router.navigate([`pages/inventory/main/4`])
      }
      document.getElementById("demo").innerHTML = text;
    }else{
      this.router.navigate([`pages/inventory/main/4`])
    }
  }

  goBackDefault() {
    this.router.navigate([`pages/inventory/main/4`])
  }

  getStatus(requestStatus: any) {
    if(requestStatus)
      return requestStatus.replace(/_/g, ' ')
  }
  get TemplateFucType() {
    return TemplateFucType;
  }

  onShowRow(itemRefId: any , i: any ){
    document.getElementById(itemRefId).classList.toggle('show');
    let ele =$('#'+itemRefId+'-arrow')
    if(ele.hasClass('icon-up-open')) {
      $(ele).addClass('icon-down-open')
      $(ele).removeClass('icon-up-open')
    } else {
      $(ele).removeClass('icon-down-open')
      $(ele).addClass('icon-up-open')

    }
  }

  createListItemGroup(receivedQuantities?: any, listItem?: any) {
    let control = this.fb.group({
      itemRefId: [, Validators.required],
      lineNo: [++this.lineIdCounter],
      batchNumber: [, Validators.required],
      quantity: [, Validators.required],
      purchasePrice: [, Validators.required],
      receivedQuantity: [],
      receiverClinicId: [],
      inventoryQuantity: [],
      supplierId: [],
      uom: [],
      remarks: [],
      cpRemarks: [],
      batches: [],
    });

    combineLatest([this.inventoryItemsMap, this.items, control.get('itemRefId').valueChanges])
      .subscribe(([inventoryItemsMap, items, itemRefId]) => {
        if (!itemRefId) {
          return;
        }
        // control.get('batchNumber').setValue('')

        let batches = inventoryItemsMap[itemRefId] || [];
        batches.sort(this.sortBatches.bind(this));
        //console.log(111,batches);

        let item = items.find(item => item.id === itemRefId)

        if(!item.inventoried){
          control.get('batchNumber').clearValidators();
        } else {
          control.get('batchNumber').setValidators(Validators.required);
        }

        if (item) {
          control.patchValue({
            uom: item.baseUom,
            batches: batches,
          })
        }
      })
    combineLatest([this.inventoryItemsMap, control.get("batchNumber").valueChanges, control.get("itemRefId").valueChanges])
      .subscribe(([inventoryItemsMap, batchNumber, itemRefId]) => {
        let batch = inventoryItemsMap[itemRefId] && inventoryItemsMap[itemRefId].find(batch => batch.batchNumber === batchNumber);
        let inventoryQuantity = batch ? batch.availableCount : 0;
        let bathcPrice = batch && batch.batchPrice ? batch.batchPrice : 0;

        if(batch){
          control.get('quantity').clearValidators();
          control.get('quantity').setValidators([Validators.required, Validators.min(1), Validators.max(inventoryQuantity)]);
        }

        control.patchValue({
          inventoryQuantity: inventoryQuantity,
          quantity: control.get('quantity').value
        });
        control.patchValue({
          purchasePrice: (bathcPrice * (control.get('quantity').value ? control.get('quantity').value : 0)).toFixed(4)
        });
      })


    control.get("itemRefId").valueChanges.subscribe(()=>{
        control.get('batchNumber').setValue('');
        control.get('purchasePrice').setValue('');
    })

    combineLatest([this.inventoryItemsMap, control.get("quantity").valueChanges, control.get("itemRefId").valueChanges, control.get("batchNumber").valueChanges])
      .subscribe(([inventoryItemsMap, quantity, itemRefId, batchNumber]) => {
        let batch = inventoryItemsMap[itemRefId] && inventoryItemsMap[itemRefId].find(batch => batch.batchNumber === batchNumber);
        let bathcPrice = batch && batch.batchPrice ? batch.batchPrice : 0;

        if(quantity) {
          control.patchValue({
            purchasePrice: (bathcPrice * (control.get('quantity').value ? control.get('quantity').value : 0)).toFixed(4)
          });
        } else {
          control.patchValue({
            purchasePrice: bathcPrice.toFixed(4)
          });
        }

      });

    let receivedQuantity = receivedQuantities && receivedQuantities[listItem.lineNo];

    control.patchValue({
      ...listItem ? listItem : {},
      receivedQuantity: receivedQuantity ? receivedQuantity : 0,
      inventoryQuantity: 0
    })
    return control;
  }

  sortBatches(a, b) {
    if (!a.expiryDate) {
      return 1; // "a" has no expiry date, so it should come last
    } else if (!b.expiryDate) {
      return -1; // "b" has no expiry date, so it should come last
    } else {
      const dateA = new Date(a.expiryDate.split("-").reverse().join("-"));
      const dateB = new Date(b.expiryDate.split("-").reverse().join("-"));
      const dateCompare = dateA.getTime() - dateB.getTime();
      if (dateCompare === 0) {
        return a.batchNumber.localeCompare(b.batchNumber);
      }
      return dateCompare;
    }
  }

  get transferRequestItems(): FormArray {
    return this.orderForm.get('transferRequestItems') as FormArray;
  }

  addListItem() {
    this.transferRequestItems.push(this.createListItemGroup());
  }

  deleteItems() {
    let transferRequestItems: FormArray = this.orderForm.get('transferRequestItems') as FormArray;
    let items = transferRequestItems.controls.filter((control, index) => this.selectedItems.has(control.value.lineNo))
    for (const item of items) {
      transferRequestItems.removeAt(transferRequestItems.controls.indexOf(item))
    }
    this.selectedItems.clear()
    let isAllSelected = this.transferRequestItems.value.every(item => this.selectedItems.has(item.lineNo))
    if(isAllSelected){
      this._allItemsSelected = false
    }
  }

  groupBy(item) {
    return item.inventoryAvailable
  }

  allItemsSelected() {
    return this._allItemsSelected;
  }

  onSelectAll($event: Event) {
    if (this._allItemsSelected) {
      this._allItemsSelected = false
      this.selectedItems.clear()
    } else {
      this.transferRequestItems.value.forEach(item => {
        this.selectedItems.add(item.lineNo)
      })
      this._allItemsSelected = true
    }
  }

  onSelect(lineNo: any) {

    if (this.selectedItems.has(lineNo)) {
      this._allItemsSelected = false
      this.selectedItems.delete(lineNo)
    } else {
      this.selectedItems.add(lineNo)
      let isAllSelected = this.transferRequestItems.value.every(item => this.selectedItems.has(item.lineNo))
      if(isAllSelected){
        this._allItemsSelected = true
      }else{
        this._allItemsSelected = false
      }
    }
  }

  getCodeAndName(value: any) {
    if (this.items) {
      let item = this.items.value.find(item => item.id === value)
      if (item) {
        return item.code + ' - ' + item.name
      }
    }
    return ''
  }

  save() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder = {
      ...this.order.value,
      ...this.orderForm.value
    };
    if (purchaseOrder.orderStatus === 'DRAFT') {
      purchaseOrder.orderStatus = 'INITIAL'
    }
    this.apiInventoryService.savePurchaseOrder({
      ...purchaseOrder,
      transferRequestItems: purchaseOrder.transferRequestItems.map(item => {
        return {
          ...item,
          itemRefId: item.itemRefId,
          batchNumber: item.batchNumber,
          purchasePrice: item.purchasePrice,
        }
      })
    }, false).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.initForm = this.orderForm.getRawValue();
        this.alertService.success('Transfer Order Save successfully')
        setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},3000);
      } else {
        this.alertService.error(res.message)
      }
    },err =>  this.alertService.error(JSON.stringify(err.error.message)))
  }

  issueOrder() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder = {
      ...this.order.value,
      ...this.orderForm.value
    };
    if (purchaseOrder.orderStatus === 'DRAFT') {
      purchaseOrder.orderStatus = 'INITIAL'
    }
    this.apiInventoryService.issuePurchaseOrder({
      ...purchaseOrder,
      transferRequestItems: purchaseOrder.transferRequestItems.map(item => {
        return {
          ...item,
          itemRefId: item.itemRefId,
          batchNumber: item.batchNumber,          
          purchasePrice: item.purchasePrice,
        }
      })
    }).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.initForm = this.orderForm.getRawValue();
        this.alertService.success('Transfer Order Issued successfully')
        setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},3000);
      } else {
        this.alertService.error(res.message)
      }
    },err =>  this.alertService.error(JSON.stringify(err.error.message)))
  }

  saveDraft() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder = {
      ...this.order.value,
      ...this.orderForm.value
    };
    this.apiInventoryService.savePurchaseOrderDraft({
      ...purchaseOrder,
      transferRequestItems: purchaseOrder.transferRequestItems.map(item => {
        return {
          ...item,
          itemRefId: item.itemRefId,
          batchNumber: item.batchNumber,
          purchasePrice: item.purchasePrice
        }
      })
    }).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.initForm = this.orderForm.getRawValue();
        this.alertService.success('Transfer Order Save successfully')
        setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},3000);
      } else {
        this.alertService.error(res.message)
      }
    })
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else if (control instanceof FormArray) {
        for (let i = 0; i < control.length; i++) {
          this.validateAllFormFields(control.at(i) as FormGroup)
        }
      }
    });
  }

  isFormValid() {
    this.validateAllFormFields(this.orderForm);
    if (!this.orderForm.valid || !this.validateLineItemList()) {
      this.alertService.error("Incomplete, Please fill all the necessary fields.")
      return false
    }
    return true
  }

  validateLineItemList() {
    let isValidate = true;
    if( this.getTransferRequestItemsControl().length > 0)
      this.getTransferRequestItemsControl().forEach((ctr: any) => {
        if(!ctr.controls.itemRefId.value) {
          isValidate = !!ctr.controls.itemRefId.value;
        }
      });
    return isValidate;
  }

  getTransferRequestItemsControl() {
    return (this.orderForm.get('transferRequestItems') as FormArray).controls;
  }
  showQuantityError(value: any, i: number): string {
    if (!value) return '';
    if (value.required) {
      return 'Quantity is required'
    }
    if (value.min) {
      return 'Quantity should be greater than 0'
    }
    if (value.max) {
      return 'Quantity should be less than or equal to ' + value.max.max
    }
    return ''
  }

  showBatchError(errors, i: number) {
    if (errors && errors.required) return 'Batch Number is required'
    return ""
  }

  showItemError(errors, i: number) {
    if (errors && errors.required) return 'Item is required'
    return ""
  }
  goToEdit() {
    let requestItems = this.orderForm.get("transferRequestItems") as FormArray;
    requestItems.clear()
    this.router.navigate([`/pages/inventory/transfer-order/edit/${this.order.value.id}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
}
