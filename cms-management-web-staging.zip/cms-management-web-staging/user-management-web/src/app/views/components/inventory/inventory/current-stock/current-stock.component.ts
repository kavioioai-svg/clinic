import {AfterContentChecked, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Page} from '../../../../../model/page';
import {StockItem} from '../../../../../objects/StockItem';
import {StockListFilter} from '../../../../../objects/StockListFilter';
import {InventoryService} from '../../../../../services/inventory.service';
import {map, tap} from 'rxjs/operators';
import {ActivatedRoute} from '@angular/router';
import {InventoryTab} from '../../../../../model/enum/enums';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
import * as moment from 'moment';
import {DISPLAY_DATE_FORMAT} from '../../../../../constants/app.constants';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {AlertService} from '../../../../../services/alert.service';
import {SearchParams} from '../../../../../objects/searchParams';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {StoreStatusQuery} from '../../../../../state/store-status/store-status.query';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
const filterOptionsJson = require('../../../../../settings/filter-options.json');
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-current-stock',
  templateUrl: './current-stock.component.html',
  styleUrls: ['./current-stock.component.scss']
})
export class CurrentStockComponent implements OnInit ,AfterContentChecked {

  @Input() selectedItemSet: Set<string> = new Set();
  isLoading:boolean = false;

  stockLevelOptions: any[] = []
  itemGroupOptions: any[] = []
  tableExpandedArray: any[];
  stockList: Array<StockItem> = [];
  clinics: any[] = [];
  filterOptions: any[] =[];

  itemLevelMap = new Map<string, PurchasableItemLevel>();

  searchFrm: FormGroup;
  page: Page = new Page();

  stockListDataLoaded: boolean = false;
  selectedAllItem: boolean = false;

  @ViewChild('table', { static: false }) table: DatatableComponent;

  constructor(private fb: FormBuilder,
              private inventory: InventoryService,
              private activatedRoute:ActivatedRoute,
              private chargeItemQuery:ChargeItemQuery,
              private clinicQuery: ClinicQuery,
              private alertService: AlertService,
              private storeStatusQuery: StoreStatusQuery,
              private masterDataService: MasterDataService,
              private cdr: ChangeDetectorRef) {
    this.page.size = 50;
    this.page.pageNumber = 0;
  }

  async ngOnInit() {
    await  this.populateData();
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll();
      });

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });
  }

  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.getStockList();
  }

  getStockList(exportData: boolean = false) {
    const { itemGroup ,stockLevel,clinicId ,searchText ,filterOptionId} = this.searchFrm.value;
    this.tableExpandedArray = [];
    this.isLoading = true;
    let filter = new StockListFilter();
    let params = new SearchParams();

    switch (filterOptionId) {
      case 0: {
        filter.ITEM_NAME_REGEX = searchText;
        break;
      }
      case 1: {
        filter.ITEM_CODE_REGEX = searchText;
        break;
      }
      case 2: {
        filter.SUPPLIER_NAME_REGEX = searchText;
        break;
      }
    }
    if(stockLevel && stockLevel !== 'ALL'){filter.STOCK_ALERT = stockLevel;}
    params.clinicId = clinicId;
    params.itemGroup = itemGroup;

    this.inventory
      .getCurrentStockList(params, filter, this.page)
      .pipe(
        tap(res => {
          this.page.pageNumber = res.payload['pageNumber'];
          this.page.totalPages = res.payload['totalPages'];
          this.page.totalElements = res.payload['totalElements'];
        }),
        map(res => {
          const content = res.payload.content.reduce(
            (items: Array<StockItem>, drugItem) =>
              items.concat(drugItem.inventories || []),
            []
          );

          return { content: content, payload: res.payload.content };
        })
      )
      .subscribe(
        list => {
          if (!this.itemLevelMap)
            this.itemLevelMap = new Map<string, PurchasableItemLevel>();
          list.payload.forEach(item =>
            this.itemLevelMap.set(item.itemId, createPurchasableItemLevel(item))
          );
          this.stockList = list.content.map(stockListItem => {
            let currentItem = stockListItem;
            const itemInfo = this.chargeItemQuery.getItemById(stockListItem.itemRefId);
            if (itemInfo && itemInfo.baseUom && itemInfo.baseUom.length > 0) {
              currentItem = { ...stockListItem, baseUom: itemInfo.baseUom };
            }
            return currentItem;
          });
          this.isLoading = false;
          this.selectedAllItem = false;
          this.stockListDataLoaded = true;

          if (this.table) {
            this.table.groupHeader.collapseAllGroups();
            this.tableExpandedArray = [];
          }
          //
          // if (this.isHandleLowStock) {
          //   this.onSelectAllCheckBoxChange();
          //   this.reOrderStock();
          // }

          if (exportData === true) {
            this.downloadExcel(params, filter);
          }

        },
        err => {
         this.isLoading = false;
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  downloadExcel(params, filter) {
    this.isLoading = true;
    filter['EXPORT_EXCEL'] = true;
    this.page.size = this.page.totalElements;
    this.inventory
    .downloadCurrentStockList(params, filter, this.page).subscribe(
        (res) => {
          this.isLoading = false;
          let clinicCode = this.clinics.find(clinic => clinic.id === params.clinicId).clinicCode;
          let fileName = 'CURRENT_STOCK_OF_'+clinicCode+ '.xlsx';
          saveAs(res, fileName);
        },
        (err) => {
          this.isLoading = false;
        }
      );
      this.page.size = 50;
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  onSubmitSearch(exportData) {
    this.stockListDataLoaded = false;
    this.page.pageNumber = 0;
    this.getStockList(exportData);
  }
  onItemCheckBoxChange(itemId: string) {
    if (this.selectedItemSet.has(itemId)) {
      this.selectedItemSet.delete(itemId);
    } else {
      this.selectedItemSet.add(itemId);
    }
  }

  onSelectAllCheckBoxChange() {

  }

  isDrugOrVaccine(i: any) {
     return 0;
  }

  addStock(i:any) {

  }

  toggleExpandGroup(group: any) {
    if (this.tableExpandedArray.includes(group['key'])) {
      this.tableExpandedArray = this.tableExpandedArray.filter(key => key !== group['key']);
    } else {
      this.tableExpandedArray.push(group['key']);
    }

    this.table.groupHeader.toggleExpandGroup(group);
  }

  isItemExpired(expiryDateStr) {
    if (!expiryDateStr || expiryDateStr === '31-12-0001') return false;
    const expiryDate = moment(expiryDateStr, DISPLAY_DATE_FORMAT);
    return expiryDate.isBefore(moment()) && expiryDate.format(DISPLAY_DATE_FORMAT) !== moment().format(DISPLAY_DATE_FORMAT);
  }

  editable(item: StockItem) {
    const isDrugOrVaccine = this.isDrugOrVaccine(item.itemRefId);
    if (isDrugOrVaccine) {
      return (item.batchNumber && item.batchNumber.length > 0) && (item.expiryDate && item.expiryDate.length > 0) && item.baseUomQuantity > 0;
    }

    return true;
  }

  onEditStockClicked(item: StockItem) {
    let initialState = {
      stockItem: item,
      stockList: this.stockList.filter(
        listItem =>
          listItem.itemRefId === item.itemRefId &&
          listItem.batchNumber !== item.batchNumber
      ),
    };
  }

  checkAllGroupedRowExpanded() {
    if (this.table && this.table.groupedRows) {
      const allTableKeys = this.table.groupedRows.map(row => row['key']).sort();
      const expandedTableKeys = this.tableExpandedArray.sort();
      return allTableKeys.length === expandedTableKeys.length && allTableKeys.every((val, index) => val === this.tableExpandedArray[index]);
    }

    return false;
  }

  toggleExpandAllGroups() {
    const filteredRows = this.table.groupedRows.filter(row => !this.tableExpandedArray.includes(row['key']));
    filteredRows.forEach(row => {
      this.table.groupHeader.toggleExpandGroup(row);
      this.tableExpandedArray.push(row['key']);
    });
  }

  toggleCollapseAllGroups() {
    if (this.checkAllGroupedRowExpanded()) {
      this.table.groupedRows.forEach(row => {
        this.table.groupHeader.toggleExpandGroup(row);
        this.tableExpandedArray = [];
      });
    }
  }


  populateData() {
    this.searchFrm = this.fb.group({
      itemGroup:  ['ALL', Validators.required],
      stockLevel: ['ALL', Validators.required],
      clinicId:   [null, Validators.required],
      searchText: '',
      filterOptionId: 0,
    });

    this.stockLevelOptions = filterOptionsJson.stockLevelOptions;
    this.itemGroupOptions  = filterOptionsJson.itemGroupOptions;
    this.filterOptions     = filterOptionsJson.searchFilter;
  }
  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

}

export interface PurchasableItemLevel {
  reorderPoint: number;
  lowStockLevel: boolean;
}



export function createPurchasableItemLevel(
  {
        reorderPoint = 0,
        lowStockLevel = false,
           } = {}) {
  return {
    reorderPoint,
    lowStockLevel
  } as PurchasableItemLevel;
}
