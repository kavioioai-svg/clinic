import { Component, OnInit } from '@angular/core';
import { StockItem } from '../../../../../../objects/StockItem';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { StockAdjustmentReason } from '../../../../../../objects/StockAdjustment';
import { InventoryService } from '../../../../../../services/inventory.service';
import { AlertService } from '../../../../../../services/alert.service';
import { StoreService } from '../../../../../../services/store.service';

import { ChargeItemQuery } from '../../../../../../state/charge-item/charge-item.query';

import { DISPLAY_DATE_FORMAT } from '../../../../../../constants/app.constants';

import DatePickerConfig from '../../../../../../objects/DatePickerConfig';
import { StockTakeApproveStatus } from '../../../../../../objects/StockTakeApproveStatus';
import { stockAdjustmentApproveRejection } from '../../../../../../objects/stockAdjustmentApproveRejection';

import { Page } from '../../../../../../model/page';
import { TemplateFucType } from '../../../../../../model/enum/enums';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap';
import * as moment from 'moment';

@Component({
  selector: 'app-stock-take-approval',
  templateUrl: './stock-take-approval.component.html',
  styleUrls: ['./stock-take-approval.component.scss']
})
export class StockTakeApprovalComponent implements OnInit {

  stockItem: any;
  chargeItems: any;
  stockList: Array<StockItem> = [];
  action: boolean;
  initialState: any;
  formGroup: FormGroup;
  isSubmitting: boolean;
  isBtnLoading: boolean;
  isThreadHoldExceeded: boolean;
  purposeOptions: Array<StockAdjustmentReason> = [];

  expiryDateDatePickerConfig: DatePickerConfig = new DatePickerConfig(
    '',
    null,
    moment().toDate(),
    'bottom',
    'right'
  );

  pendingStockTakeList: any[] = [];
  page: Page = new Page();

  constructor(
    private akitaChargeItemQuery: ChargeItemQuery,
    public bsModalRef: BsModalRef,
    private inventory: InventoryService,
    private store: StoreService,
    private fb: FormBuilder,
    private alert: AlertService,
    private modalService: BsModalService,
    private inventoryService: InventoryService,
  ) {
    this.purposeOptions = this.store.getStockAdjustmentReasonList().filter(reason => !(reason.billAdjustmentIdentifier));
    this.page.pageNumber = 0;
    this.page.size = 6;
    this.isSubmitting = false;
  }

  async ngOnInit() {
    this.initForm();
    this.pendingStockTakeList = [this.stockItem];

    // call the checkFormValidity function whenever the cpRemarks field value changes
    // this.formGroup.controls['cpRemarks'].valueChanges.subscribe(() => {
    //   this.checkFormValidity();
    // });
  }

  setPage(pageInfo) {
    if (this.page.pageNumber !== pageInfo.offset && pageInfo.offset > this.page.pageNumber) {
      this.page.pageNumber = pageInfo.offset;
    }
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  onScroll(event: any) {
    if (event.srcElement.type === 'number') {
      event.preventDefault();
    }
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  approveRejectRequest(isApprove: boolean) {
    this.isBtnLoading = true;
    let obj = [{stockTakeId: this.stockItem.stockTakeId, lineId: this.stockItem.lineId, ...this.formGroup.value}];
    const msg = isApprove ? 'Request has been approved' : 'Request has been rejected';
    if(isApprove){
      //Approve
      this.inventory.stockTakeApproval(
        obj).subscribe(res => {
          this.isBtnLoading = false;
          // res.stockTakeId = this.stockItem.stockTakeId;
          this.modalService.setDismissReason(res);
          this.bsModalRef.hide();
        }, error => {
          this.isBtnLoading = false;
          if (error.error && error.error.message) {
            this.alert.error(error.error.message);
          } else {
            this.alert.error(JSON.stringify(error) || "Request failed");
          }
      })
    }else{
      //Reject
      this.inventory.stockTakeReject(
        obj).subscribe(res => {
          this.isBtnLoading = false;
          // res.stockTakeId = this.stockItem.stockTakeId;
          this.modalService.setDismissReason(res);
          this.bsModalRef.hide();
        }, error => {
          this.isBtnLoading = false;
          if (error.error && error.error.message) {
            this.alert.error(error.error.message);
          } else {
            this.alert.error(JSON.stringify(error) || "Request failed");
          }
      })
    }
  }



  closeModal() {
    this.bsModalRef.hide();
  }

  initForm() {
    this.formGroup = this.fb.group({
      cpRemarks: [null],
    });

    this.formGroup.patchValue(this.stockItem);

    // disable the approve button initially
    this.isBtnLoading = false;
    this.isSubmitting = true;

  }

  // add a function to check the validity of the form and enable/disable the approve button
  checkFormValidity() {
    if (this.formGroup.valid) {
      this.isSubmitting = false;
      this.isBtnLoading = false;
    } else {
      this.isSubmitting = true;
     // this.isBtnLoading = true;
    }
  }

  getBtnLabel() {
    return this.action ? 'Approve' : 'Reject';
  }

  get TemplateFucType() {
    return TemplateFucType;
  }
}
