import {
  Component,
  OnInit,
  ComponentFactory,
  ComponentFactoryResolver,
  ElementRef,
  ViewChild,
  AfterViewChecked,
  ChangeDetectorRef,
  Input
} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {StoreStatusQuery} from '../../../../../../state/store-status/store-status.query';
import {ClinicQuery} from '../../../../../../state/clinic/clinic.query';
import {ActivatedRoute, Router} from '@angular/router';
import {InventoryService} from '../../../../../../services/inventory.service';
import {TemplateFucType} from '../../../../../../model/enum/enums';
import {BehaviorSubject, combineLatest} from 'rxjs';
import {GoodPurchasedItem, Order, Supplier} from "../../../../../../objects/Supplier";
import {Clinic} from "../../../../../../objects/response/Clinic";
import {ItemService} from "../../../../../../services/item.service";
import {ApiInventoryService} from "../../../../../../services/api-inventory.service";
import {SupplierService} from "../../../../../../services/master-data-service/supplier.service";
import {AlertService} from "../../../../../../services/alert.service";
import {debounceTime} from "rxjs/operators";
import {Price} from '../../../../../../objects/request/Drug';
import {InventorySummaryItem} from '../../../../../../objects/InventorySummaryItem';
import * as $ from 'jquery';
import {BsModalService} from "ngx-bootstrap";
import {
  MinPurchaseConfirmPopupComponent
} from "./min-purchase-confirm-popup/min-purchase-confirm-popup.component";
import { SupplierContactPopupComponent } from './supplier-contact-popup/supplier-contact-popup.component';

@Component({
  selector: 'app-purchase-order',
  templateUrl: './purchase-order.component.html',
  styleUrls: ['./purchase-order.component.scss']
})
export class PurchaseOrderComponent implements OnInit {

  order: BehaviorSubject<Order> = new BehaviorSubject<Order>(null);
  suppliers: BehaviorSubject<Supplier[]> = new BehaviorSubject<Supplier[]>([]);
  allClinics: BehaviorSubject<Clinic[]> = new BehaviorSubject<Clinic[]>([]);
  items: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

  orderForm: FormGroup;
  initForm: FormGroup;

  requestedClinic: Clinic;
  supplier: Supplier;
  clinics: Clinic[];
  currentOrderStatus: string;
  isReadOnly: boolean;

  selectedItems: Set<string> = new Set<string>();
  _allItemsSelected: boolean = false
  supplierProvidedItems: any[] = [];
  operation: 'view' | 'edit' | 'create' = 'view';
  isEditModeFromButton: boolean = false;
  printTemplateData: any;
  gstPercent: number = 0
  gstAmount: number = 0 ;
  validSupplierItems: any[];
  minimumPurchase: any;
  inventorySummaryItem: InventorySummaryItem;
  isRecivedQty: boolean = false;
  invalidPurchaseItems: boolean = false;
  private lineIdCounter: number = 1;
  receivedBonusQuantity;

  constructor(private router: Router,
              private activatedRouter: ActivatedRoute,
              private inventoryService: InventoryService,
              private fb: FormBuilder,
              private storeStatusQuery: StoreStatusQuery,
              private apiInventoryService: ApiInventoryService,
              private clinicQuery: ClinicQuery,
              private supplierService: SupplierService,
              private alertService: AlertService,
              private resolver: ComponentFactoryResolver,
              private itemService: ItemService,
              private modalService: BsModalService) {
  }

  get TemplateFucType() {
    return TemplateFucType;
  }

  get goodPurchasedItems(): FormArray {
    return this.orderForm.get('goodPurchasedItems') as FormArray;
  }

  get goodPurchasedBonusItems(): FormArray {
    return this.orderForm.get('goodPurchasedBonusItems') as FormArray;
  }

  get total() {
    let total = 0
    for (let item of this.orderForm.value.goodPurchasedItems) {
      if (!!item && !!item.unitPrice && !!item.unitPrice.price) {
        total += item.unitPrice.price * item.quantity
      }
    }
    return total
  }

  ngOnInit(): void {
    this.orderForm = this.fb.group({
      requestClinicId: [undefined, Validators.required],
      supplierId: [undefined, Validators.required],
      goodPurchasedItems: this.fb.array([], Validators.required),
      goodPurchasedBonusItems: this.fb.array([]),
      remark: [""],
    });
    this.initForm = this.orderForm.getRawValue();
    this.orderForm.valueChanges.subscribe(e => {
      this.apiInventoryService.calculateGst(e).subscribe((res: any) => {
        this.gstPercent = res.payload.first;
        this.gstAmount = res.payload.second * 100;
        this.getMinimumPurchaseAmount();
      });
      if (this.supplier) {
        let minPurchaseAmounts = this.supplier.clinicMinPurchaseAmounts || this.supplier.minPurchaseAmounts;
        let minPurchaseAmount = minPurchaseAmounts.find(a => a.clinicId && a.clinicId === e.requestedClinicId);
        if (!minPurchaseAmount) {
          minPurchaseAmount = minPurchaseAmounts.find(a => a.global)
        }
        if (minPurchaseAmount) {
          this.inventorySummaryItem = new InventorySummaryItem(this.supplier, this.getGrandTotal(), minPurchaseAmount)
          return
        }
      }
      this.inventorySummaryItem = null
    })

    this.getActivatedRoutes();

    combineLatest([this.allClinics, this.orderForm.valueChanges, this.order]).subscribe(([clinics, orderForm, order]) => {
      let filteredClinics = order.goodPurchasedItems.map(item => clinics.find(clinic => clinic.id === item.receiverClinicId))
        .filter(a => !!a);
      if (filteredClinics.length > 0) {
        this.clinics = filteredClinics;
      } else {
        this.clinics = clinics;
      }

      this.requestedClinic = clinics.find(clinic => clinic.id === orderForm.requestClinicId)
    })

    combineLatest([this.suppliers, this.items, this.orderForm.get('supplierId').valueChanges]).subscribe(([suppliers, items, value]) => {
      this.supplier = suppliers.find(supplier => supplier.id === value);
      if (this.supplier) {
        this.supplierService.listAllSupplierItems(this.supplier.id).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.validSupplierItems = res.payload;
            this.supplierProvidedItems = items.filter(item => this.validSupplierItems.some(vi => vi.itemId === item.id))
          } else {
            let validItemIds = this.supplier.items.map(item => item.itemId);
            this.supplierProvidedItems = items.filter(item => validItemIds.includes(item.id))
          }
        })
        let validItemIds = this.supplier.items.map(item => item.itemId);
        this.supplierProvidedItems = items.filter(item => validItemIds.includes(item.id));
      } else {
        this.supplierProvidedItems = items
      }
    })

    let goodPurchasedItemsControl: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    combineLatest([
      this.orderForm.get('supplierId').valueChanges,
      this.orderForm.get('requestClinicId').valueChanges,
      goodPurchasedItemsControl.valueChanges,
    ])
      .subscribe(([supplierId, requestClinicId, goodPurchasedItems]) => {

        let goodPurchasedBonusItems: FormArray = this.orderForm.get('goodPurchasedBonusItems') as FormArray;
        goodPurchasedBonusItems.clear();

        let sums: {[k: string]: number} = {}
        for (const item of goodPurchasedItems) {
          sums[item.itemRefId] = sums[item.itemRefId] || 0;
          sums[item.itemRefId] = sums[item.itemRefId] + item.quantity;
        }
        if (this.supplier && this.supplier.purchaseBonuses) {

          // @ts-ignore
          for (const [key, value] of Object.entries(sums)) {
            let item = this.supplierProvidedItems.find(item => item.id === key);
            let supplierItem = this.validSupplierItems && this.validSupplierItems.find(supplierItem => supplierItem.itemId === key);

            let purchaseBonus = this.supplier.purchaseBonuses.find(bonus => bonus.itemId === key);
            if (purchaseBonus) {
              let validBonuses = purchaseBonus.bonusDetails
                .filter(bonus => bonus.purchaseQuantity <= value) as any[]

              let uomBasedBonus: {[k: string]: number} = {}
              for (let validBonus of validBonuses) {
                uomBasedBonus[validBonus.uom] = uomBasedBonus[validBonus.uom] || 0;
                uomBasedBonus[validBonus.uom] = uomBasedBonus[validBonus.uom] + validBonus.bonusQuantity;
              }

              // @ts-ignore
              for (let entry of Object.entries(uomBasedBonus)) {
                let bonusItem: GoodPurchasedItem;
                if(supplierItem){
                bonusItem = {
                  uom: entry[0],
                  quantity: entry[1],
                  itemRefId: purchaseBonus.itemId,
                  receiverClinicId: this.orderForm.getRawValue().requestClinicId ? this.orderForm.getRawValue().requestClinicId : undefined,
                  supplierId: supplierId,
                  isBonusItem: true,
                  unitPrice: {
                    ...supplierItem.unitPrice,
                    price: 0
                  },
                };

                // @ts-ignore
                let controls = Object.fromEntries(Object.entries({
                  ...bonusItem,
                  unitPriceValue: 0,
                  receivedQuantity: this.receivedBonusQuantity,
                  remark: '',
                  cpRemarks: ''
                }).map(([key, value]) => {
                  return [key, [value]]
                }));
                controls.quantity = [bonusItem.quantity, [Validators.required, Validators.min(1)]]
                controls.bonusItem = [true]
                let control = this.fb.group(controls);
                goodPurchasedBonusItems.push(control)
              }
              }
              if(this.isEditModeFromButton){
                goodPurchasedBonusItems.clear();
              }
            }
          }
        }
      })

    this.itemService.listAllItems('',true).subscribe(res => {
      if (res && res.statusCode === "S0000") {
        this.items.next(res.payload.map(item => item.item))
      }
    })

    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.allClinics.next(this.clinicQuery.getAll());
      });

    this.orderForm.get('requestClinicId').valueChanges.subscribe(res => {
      if(res) {
        if(this.getGoodPurchasedItemsControl().length > 0) {
             this.getGoodPurchasedItemsControl().forEach(ctr => {
                ctr.patchValue({
                    ...ctr,
                    receiverClinicId: res
                  });
               });
         }

        if(this.getGoodPurchasedBonusControl().length > 0) {
          this.getGoodPurchasedBonusControl().forEach(ctr => {
            ctr.patchValue({
              ...ctr,
              receiverClinicId: res
            });
          });
        }
      }
    });


  }

  goBack() {
    let isModified:boolean = JSON.stringify(this.initForm) !== JSON.stringify(this.orderForm.getRawValue());

    if(isModified){
      let text = "Changes are not saved";
      if (confirm(text) == true) {
        this.router.navigate([`pages/inventory/main/4`])
      }
      document.getElementById("demo").innerHTML = text;
    }else{
      this.router.navigate([`pages/inventory/main/4`])
    }
  }

  getStatus(requestStatus: any) {
    let status = '';
    if(requestStatus) {
      status = requestStatus.replace(/_/g, ' ');
    }
   return  status === 'PARTIAL RECEIVED' ? 'PARTIALLY RECEIVED' : status;
  }

  onClinicChange($event: any) {
    this.requestedClinic = this.allClinics.value.find(clinic => clinic.id === $event.value)
  }

  allItemsSelected() {
    return this._allItemsSelected
  }

  onSelectAll($event: Event) {
    if (this._allItemsSelected) {
      this._allItemsSelected = false
      this.selectedItems.clear()
    } else {
      this.goodPurchasedItems.value.forEach(item => {
        this.selectedItems.add(item.lineNo)
      })
      this._allItemsSelected = true
    }
  }

  onSelect(lineNo: any) {
    if (this.selectedItems.has(lineNo)) {
      this._allItemsSelected = false
      this.selectedItems.delete(lineNo)
    } else {
      this.selectedItems.add(lineNo)
      let isAllSelected = this.goodPurchasedItems.value.every(item => this.selectedItems.has(item.lineNo))
      if(isAllSelected){
        this._allItemsSelected = true
      }else{
        this._allItemsSelected = false
      }
    }
  }

  onShowRow(itemRefId: any, i: number) {
    document.getElementById(itemRefId).classList.toggle('show');
     let ele =$('#'+itemRefId+'-arrow')
    if(ele.hasClass('icon-up-open')) {
      $(ele).addClass('icon-down-open')
      $(ele).removeClass('icon-up-open')
    } else {
      $(ele).removeClass('icon-down-open')
      $(ele).addClass('icon-up-open')
    }
  }

  addListItem() {
    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    let control = this.fb.group({
      itemRefId: ['', Validators.required],
      quantity: [],
      uom: [],
      unitPrice: this.itemService.getPriceFormGorup(),
      unitPriceValue: [],
      supplierName: [],
      clinicCode: [],
      cpRemarks: [],
      remark: [],
      receivedQuantity: [],
      lineNo: [++this.lineIdCounter],
      receiverClinicId: [this.orderForm.getRawValue().requestClinicId]
    });
    control.get('receiverClinicId').disable()
    control.get("unitPriceValue").valueChanges.subscribe(value => {
      control.patchValue({
        unitPrice: {
          price: parseInt((value * 100).toFixed(2))
        }
      })
    })
    control.get('itemRefId').valueChanges.subscribe(val => {
      let item = this.supplierProvidedItems.find(item => item.id === val)
      let supplierItem = this.validSupplierItems.find(supplierItem => supplierItem.itemId === val);

      if (item) {
        control.patchValue({
          uom: item.purchaseUom ? item.purchaseUom : '',
          unitPrice: {
            price: supplierItem ? supplierItem.unitPrice.price : 0,
            taxIncluded: supplierItem ? supplierItem.unitPrice.taxIncluded : false,
          },
          unitPriceValue: supplierItem ? (supplierItem.unitPrice.price / 100) : 0
        });
        this.getMinimumPurchaseAmount();
      }
    })
    goodPurchasedItems.push(control)
  }

  deleteItems() {
    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    let items = goodPurchasedItems.controls.filter((control, index) => this.selectedItems.has(control.value.lineNo))
    for (const item of items) {
      if(item.value.receivedQuantity > 0) {
        alert("Detected item(s) which have recieved amount of quantity. Those item(s) will not be deleted")
        return;
      }
      goodPurchasedItems.removeAt(goodPurchasedItems.controls.indexOf(item))
    }
    this.selectedItems.clear();

    let isAllSelected = this.goodPurchasedItems.value.every(item => this.selectedItems.has(item.lineNo))
    if(isAllSelected){
      this._allItemsSelected = false
    }
  }

  getGrandTotal() {
    return this.total + this.gstAmount
  }

  save() {
      let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());
    let savePO = (() => {
      if (purchaseOrder.orderStatus === 'DRAFT') {
        purchaseOrder.orderStatus = 'INITIAL'
      }
      this.apiInventoryService.savePurchaseOrder(purchaseOrder, false).subscribe(res => {
        if (res.statusCode === "S0000") {
          this.initForm = this.orderForm.getRawValue();
          this.alertService.success('Purchase Order saved successfully');
          setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
        } else {
          this.alertService.error(res.message)
        }
      },err =>  this.alertService.error(JSON.stringify(err.error.message)))
    }).bind(this)

    if (!this.isFormValid()) {
      return
    }

    if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
      savePO()
    } else {
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            savePO()
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message:`The PO ${purchaseOrder.orderNo  || ''} has not fulfilled the Minimum Purchase Amount $${(this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)} , do you still want to issue?`
        }
      })
    }
  }

  issueOrder() {
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());
  let savePO = (() => {
    if (purchaseOrder.orderStatus === 'DRAFT') {
      purchaseOrder.orderStatus = 'INITIAL'
    }
    this.apiInventoryService.issuePurchaseOrder(purchaseOrder).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.initForm = this.orderForm.getRawValue();
        this.alertService.success('Purchase Order issued successfully');
        setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
      } else {
        this.alertService.error(res.message)
      }
    },err =>  this.alertService.error(JSON.stringify(err.error.message)))
  }).bind(this)

  if (!this.isFormValid()) {
    return
  }
  if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
    savePO()
  } else {
    let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
      initialState: {
        onConfirm() {
          savePO()
          ref.hide()
        },
        onClose() {
          ref.hide()
        },
        message:`The PO ${purchaseOrder.orderNo  || ''} has not fulfilled the Minimum Purchase Amount $${(this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)} , do you still want to issue?`
      }
    })
  }
}

  sendDraft() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());
    this.apiInventoryService.savePurchaseOrderDraft(purchaseOrder).subscribe(res => {
        if (res.statusCode === "S0000") {
          this.initForm = this.orderForm.getRawValue();
          setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
          this.alertService.success('Purchase Order Save successfully')
        } else {
          this.alertService.error(res.message)
        }
    },err =>  this.alertService.error(JSON.stringify(err.error.message)))
  }

  deletePO() {
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());
    // let result = [purchaseOrder.id];
      this.apiInventoryService.deleteOrder(purchaseOrder.id).subscribe(res => {
        if (res.statusCode === "S0000") {
          this.initForm = this.orderForm.getRawValue();
          setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
          this.alertService.success('Purchase Order Deleted successfully')
        } else {
          this.alertService.error(res.message)
        }
    },err =>  this.alertService.error(JSON.stringify(err.error.message)))
  }

  checkQtyValid(index){
    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    let item = goodPurchasedItems.controls[index].value;
    if(item.receivedQuantity <= 0 && this.order.value.orderStatus === 'PARTIAL_RECEIVED' && item.receivedQuantity !== null){
      return true;
    }
  }

  checkQtyValidWithRecieved(index){
    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    let item = goodPurchasedItems.controls[index].value;
    if(item.quantity < item.receivedQuantity && this.order.value.orderStatus === 'PARTIAL_RECEIVED'){
      goodPurchasedItems.controls[index].get('quantity').setErrors({cannotReduceThanRecieved: true});
    }
  }

  showQuantityError(value: any, i: number): string {
    if (!value) return '';
    if (value["cannotReduceThanRecieved"]) {
      return 'Cannot reduce than recieved quantity'
    }
    return ''
  }

  saveAndSendMail() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());

    let showModalOnConfirmation = (()=>{
      let supModal = this.modalService.show(SupplierContactPopupComponent, {
        initialState: {
          onConfirm(singleSupplerContact) {
            const emails = [];
            singleSupplerContact.forEach(element => {
              emails.push(element.email);
            });
            emailPO(emails)
            supModal.hide()
          },
          onClose() {
            supModal.hide()
          },
          supplierId: purchaseOrder.supplierId,
          message: ``
        }
      })

    })

    let emailPO = ((supplierEmail?:Array<any>)=>{
        if (purchaseOrder.orderStatus === 'DRAFT') {
          purchaseOrder.orderStatus = 'INITIAL'
        }
        this.apiInventoryService.savePurchaseOrderWithEmail(purchaseOrder, supplierEmail).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.alertService.success("Purchase order issued successfully")
            setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},3000);
          } else {
            this.alertService.error(res.message)
          }
        },err =>  this.alertService.error(JSON.stringify(err.error.message)))
          }).bind(this)

    if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
      showModalOnConfirmation();
    } else {
      let minPurchaseAmount = (this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            showModalOnConfirmation();
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message: `The PO ${purchaseOrder.orderNo || ''} has not fulfilled the Minimum Purchase Amount $${minPurchaseAmount} , do you still want to save and email?`
        }
      })
    }
  }

  saveAndPrint() {
    if (!this.isFormValid()) {
      return
    }
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(this.orderForm.getRawValue());

    let saveAndPrintPO = (()=>{
        if (purchaseOrder.orderStatus === 'DRAFT') {
          purchaseOrder.orderStatus = 'INITIAL'
        }
        this.apiInventoryService.issuePurchaseOrder(purchaseOrder).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.alertService.success("Purchase order issued successfully")
            this.printContent(res.payload.id);
            setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
          } else {
            this.alertService.error(res.message)
          }
        },err =>  this.alertService.error(JSON.stringify(err.error.message)))
      }).bind(this)


    if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
      saveAndPrintPO()
    } else {
      let minPurchaseAmount = (this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            saveAndPrintPO()
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message: `The PO ${purchaseOrder.orderNo || ''} has not fulfilled the Minimum Purchase Amount $${minPurchaseAmount} , do you still want to save and print?`
        }
      })
    }
  }

  printContent(id: string) {
    this.inventoryService.getPoEPrintTemplate(id).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.printTemplateData = res.payload
     //   this.print(res.payload);

      }
    //  this.router.navigate([`pages/inventory/main/4`])
    });
    }

  getCodeAndName(value: any) {
    let item = this.supplierProvidedItems.find(item => item.id === value)
    if (item) {
      return `${item.code} - ${item.name}`
    }
    return ''
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else if (control instanceof FormArray) {
        for (let i = 0; i < control.length; i++) {
          this.validateAllFormFields(control.at(i) as FormGroup)
        }
      }
    });
  }

  isFormValid() {
    this.validateAllFormFields(this.orderForm);
    if (!this.orderForm.valid || !this.validateLineItemList()) {
      this.alertService.error("Incomplete, Please fill all the necessary fields.")
      return false
    }
    return true
  }

  validateLineItemList() {
    let isValidate = true;
    if( this.getGoodPurchasedItemsControl().length > 0)
      this.getGoodPurchasedItemsControl().forEach((ctr: FormControl) => {
        // @ts-ignore
        isValidate = !!ctr.controls.itemRefId.value;
      })
    return isValidate;
  }

  getGoodPurchasedItemsControl() {
    return (this.orderForm.get('goodPurchasedItems') as FormArray).controls;
  }

  getGoodPurchasedBonusControl() {
    return (this.orderForm.get('goodPurchasedBonusItems') as FormArray).controls;
  }

  lineItemOnChange($event: any, i: number) {
    let item = this.supplierProvidedItems.find(item => item.id === $event.id);
    let supplierItem = this.supplier.items.find(supplierItem => supplierItem.itemId === $event.id);
    if (item) {
      // @ts-ignore
      let price: Price = {
        price: supplierItem ? supplierItem.unitPrice : item.cost ? item.cost.price : 0,
      }
      this.getGoodPurchasedItemsControl()[i].patchValue({
        uom: item.purchaseUom ? item.purchaseUom : '',
        unitPrice: this.itemService.populatePriceFormGorup(price)
      })

    }
  }

   getActivatedRoutes() {
    this.activatedRouter.params.subscribe(params => {
      let id = params['id'];
      this.operation = params['operation'];
      if (!!id) {
        this.inventoryService.getPurchaseOrderById(id).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.order.next(res.payload.order);
            this.suppliers.next(res.payload.suppliers)
            this.initializaPurchaseOrderDependencies();
          }
        });
        this.inventoryService.getPoEPrintTemplate(id).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.printTemplateData = res.message
          }
        });
      } else {
        this.order.next({
          orderStatus: 'DRAFT',
          goodPurchasedItems: [],
          goodReceivedNotes: [],
          orderType: 'PURCHASE',
          transferRequestItems: [],
          returnItems: [],
          deliveryNotes: []
        })
        this.supplierService.listAllSuppliers().subscribe(res => {
          if (res.statusCode === "S0000") {
            if(res.payload.length > 0) {
              this.suppliers.next(res.payload.filter(item => this.operation == 'create' ? item.status != 'BLOCKED' : true))
            }
            this.initializaPurchaseOrderDependencies();
          }
        })
      }
    });
  }

  getMinimumPurchaseAmount() {
    if(this.operation == 'edit' || this.operation == 'view') {
      if(this.supplier && this.supplier.minPurchaseAmounts && this.supplier.minPurchaseAmounts.length > 0) {
        let global = this.supplier.minPurchaseAmounts.find(item => item.global );
        if(global)
          this.inventorySummaryItem = new InventorySummaryItem(this.supplier , (this.getGrandTotal()) , global);
      }
    } else {
      if(this.supplier && this.supplier.clinicMinPurchaseAmounts && this.supplier.clinicMinPurchaseAmounts.length > 0) {
        let global = this.supplier.clinicMinPurchaseAmounts.find(item => item.global );
        if(global) {
          this.inventorySummaryItem = new InventorySummaryItem(this.supplier , (this.getGrandTotal()) , global);
        } else {
          let minPur = this.supplier.clinicMinPurchaseAmounts.find(item => item.clinicId == this.orderForm.controls.requestClinicId.value);
          if(minPur) {
            this.inventorySummaryItem = new InventorySummaryItem(this.supplier , (this.getGrandTotal()) , minPur);
          } else {
            this.inventorySummaryItem = null;

          }
        }

      }
    }

  }

  printPage(){
    const WinPrint = window.open('', '', 'letf=10,top=10,width="450",height="250",toolbar=1,scrollbars=1,status=1');
    WinPrint.document.write('  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" >');
    WinPrint.document.write('<body >');
    WinPrint.document.write('<header >');
    WinPrint.document.write('</header >');
    WinPrint.document.write(document.getElementById('print').innerHTML);
    WinPrint.document.write('</body></html>');
    WinPrint.document.close()

    WinPrint.onload = ()=>{
      WinPrint.window.print()
    }

    if('matchMedia' in WinPrint.window){
      WinPrint.matchMedia('print').addEventListener("change", (media)=>{
        if(!media.matches){
          WinPrint.close();
        }
      });
    }else{
      WinPrint.onafterprint = function () {
        WinPrint.close()
      }
    }
  }
  private initializaPurchaseOrderDependencies() {
    this.orderForm.patchValue({
      requestClinicId: this.order.value.requestClinicId,
      supplierId: this.order.value.supplierId,
      remark: this.order.value.remark
    })
    this.currentOrderStatus = this.order.value.orderStatus;

    let lineNos = []

    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    let goodPurchasedBonusItems: FormArray = this.orderForm.get('goodPurchasedBonusItems') as FormArray;
    goodPurchasedBonusItems.clear()

    this.order.value.goodPurchasedItems.forEach(item => {
      let _lineNo = parseFloat(item.lineNo);
      if (!isNaN(_lineNo)) {
        lineNos.push(_lineNo)
      }

      item.isBonusItem = item.bonusItem && (!item.unitPrice || !item.unitPrice.price)

      let receivedQuantities: { [k: string]: number } = {}
      for (const note of this.order.value.goodReceivedNotes) {
        if (note.status == 'CONFIRM') {
          for (const receivedItem of note.receivedItems) {
            if (receivedItem.lineNo == item.lineNo) {
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] || 0;
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] + receivedItem.quantity;
              this.receivedBonusQuantity = receivedQuantities[receivedItem.lineNo] || 0;
            }
          }
        }
      }

      var recievedQty = receivedQuantities[item.lineNo] || 0;
      if(recievedQty > 0) {
        this.isRecivedQty = true;
      }

      // @ts-ignore
      let controls = Object.fromEntries(Object.entries({
        ...item,
        receivedQuantity: receivedQuantities[item.lineNo] || 0,
        remark: (item as any).remark,
        cpRemarks: (item as any).cpRemarks,
        unitPriceValue: []
      }).map(([key, value]) => {
        return [key, [value]]
      }));
      controls.quantity = [item.quantity, [Validators.required, Validators.min(1)]]
      controls.unitPriceValue = [item.unitPrice && item.unitPrice.price ? item.unitPrice.price / 100 : 0, [Validators.required, Validators.min(0)]]

      if (item.isBonusItem) {
        controls.bonusItem = [true]
      } else {
        controls.bonusItem = [false]
      }

      let control = this.fb.group(controls);
      control.get("unitPriceValue").valueChanges.subscribe(value => {
        control.patchValue({
          unitPrice: {
            ...item.unitPrice,
            price: value * 100
          }
        })
      })
      if (!item.isBonusItem) {
        goodPurchasedItems.push(control)
      } else {
        goodPurchasedBonusItems.push(control)
      }
    });

    this.lineIdCounter = Math.max.call(null, 0, ...lineNos)

    this.initForm = this.orderForm.getRawValue();
  }

  private composePurchaseOrder(purchaseOrder: Order & { goodPurchasedBonusItems: GoodPurchasedItem[] }) {
    return {
      ...this.order.value,
      ...purchaseOrder,
      goodPurchasedItems: [...purchaseOrder.goodPurchasedItems, ...purchaseOrder.goodPurchasedBonusItems],
    };
  }
  goToEdit() {
    let goodPurchasedItems: FormArray = this.orderForm.get('goodPurchasedItems') as FormArray;
    goodPurchasedItems.clear();
    this.isEditModeFromButton = true;
    this.router.navigate([`/pages/inventory/purchase-order/edit/${this.order.value.id}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
}
