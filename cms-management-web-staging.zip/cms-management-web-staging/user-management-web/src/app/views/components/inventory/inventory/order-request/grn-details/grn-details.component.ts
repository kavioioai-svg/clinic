import {Component, Input, OnInit} from '@angular/core';
import {GoodReceivedNote} from "../../../../../../objects/GoodReceivedNote";
import {Order} from "../../../../../../objects/Supplier";

@Component({
  selector: 'app-grn-details',
  templateUrl: './grn-details.component.html',
  styleUrls: ['./grn-details.component.scss']
})
export class GrnDetailsComponent implements OnInit {

  @Input() grn: GoodReceivedNote;
  @Input() order: Order;
  @Input() items: any[]

  constructor() { }

  ngOnInit() {
  }

  getItemName(grn: any) {
    if(this.items.length > 0) {
      let item = this.items.find(i => i.id === grn.itemRefId);
      return item ? item.name : ''
    }
  }
}
