import {Component, Input, OnInit} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { SupplierService } from '../../../../../../../services/master-data-service/supplier.service';
import { ChargeItemQuery } from '../../../../../../../state/charge-item/charge-item.query';

@Component({
  selector: 'app-supplier-contact-popup',
  templateUrl: './supplier-contact-popup.component.html',
  styleUrls: ['./supplier-contact-popup.component.scss']
})
export class SupplierContactPopupComponent implements OnInit {

  @Input() onConfirm: () => void
  @Input() onClose: () => void
  @Input() message: string
  @Input() supplierId: string

  supplierContactFormGroup: FormGroup;

  constructor(private chargeItemQuery: ChargeItemQuery,
    private supplierService: SupplierService,
    private fb: FormBuilder) { }

  lisAllItemList: any[];
  supplierList: any[];
  singleSupplierContact: {};
  supplierControl: any;
  isReadOnly: boolean = true;

  ngOnInit() {
    this.supplierContactFormGroup = this.fb.group({
      contactId: null,
    })
    this.lisAllItemList = this.chargeItemQuery.getDrugItems();
    this.getSupplierList(this.supplierId);
    //this.supplierContactFormGroup.get('contactId').patchValue("5ea92143dbea1b38b670c517");
  }

  getSupplierList(supplierId) {
    this.supplierService.listAllSuppliers().subscribe(res => {
        if(res.message === "Success") {
          this.supplierList = [];
          if(res.payload.length > 0) {
            if(res.payload.length > 0) {
              let isPrimaryFound = false;
              let singleSupplier = res.payload.find(supplier => supplier.id === supplierId);
              for (let index = 0; index < singleSupplier.contacts.length; index++) {
                this.supplierList.push({...singleSupplier.contacts[index], name: singleSupplier.contacts[index].name ? singleSupplier.contacts[index].name : "N/A", id: singleSupplier.id});
                if(singleSupplier.contacts[index].hasOwnProperty('primary')){
                  if(singleSupplier.contacts[index].primary){
                    isPrimaryFound = true;
                    this.supplierContactFormGroup.get('contactId').patchValue(singleSupplier.contacts[index].email);
                    this.singleSupplierContact = singleSupplier.contacts[index];
                    this.isReadOnly = false;
                  }

                }

              }

              if(!isPrimaryFound && singleSupplier.contacts.length > 0){
                this.supplierContactFormGroup.get('contactId').patchValue(singleSupplier.contacts[0].email);
                this.singleSupplierContact = singleSupplier.contacts[0];
                this.isReadOnly = false;

              }
            }
          }
        }
      }
    )
  }

  onChangeItem($event: any) {
    this.singleSupplierContact = $event;
    if($event != undefined) {
      this.isReadOnly = false;
    }else{
      this.isReadOnly = true;
    }
  }

}
