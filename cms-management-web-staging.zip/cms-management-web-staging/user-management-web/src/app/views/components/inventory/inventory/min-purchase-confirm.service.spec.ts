import { TestBed } from '@angular/core/testing';

import { MinPurchaseConfirmService } from '././min-purchase-confirm.service';

describe('BelowMinimumPurchaseConfirmService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MinPurchaseConfirmService = TestBed.get(MinPurchaseConfirmService);
    expect(service).toBeTruthy();
  });
});
