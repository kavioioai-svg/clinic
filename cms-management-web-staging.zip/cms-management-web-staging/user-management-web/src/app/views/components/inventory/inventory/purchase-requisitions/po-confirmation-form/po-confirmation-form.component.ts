import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from "@angular/forms";
import { PurchaseRequestItemView } from "../../../../../../objects/PurchaseRequestItemView";
import { StoreStatusQuery } from "../../../../../../state/store-status/store-status.query";
import { ClinicQuery } from "../../../../../../state/clinic/clinic.query";
import { ChargeItemQuery } from "../../../../../../state/charge-item/charge-item.query";
import { ApiInventoryService } from "../../../../../../services/api-inventory.service";
import { AlertService } from '../../../../../../services/alert.service';
import { Subscription } from "rxjs";
import { wholeNumberValidator } from '../../../../../../validators/whole-number.validator';
import { ERR_SELECT_DELIVERY_LOCATION } from './PoConfirmationFormConstants';

@Component({
  selector: 'app-po-confirmation-form',
  templateUrl: './po-confirmation-form.component.html',
  styleUrls: ['./po-confirmation-form.component.scss']
})
export class PoConfirmationFormComponent implements OnInit, OnDestroy {

  @Input() purchaseRequests: PurchaseRequestItemView[]

  @Input() onClose?: (resp: any | undefined) => void

  @Input() onSubmit: (purchaseRequests: PurchaseRequestItemView[]) => void

  formGroup: FormGroup
  warehouses: any
  warehouseDisabled: boolean = true;
  private subscriptions: Subscription = new Subscription();

  get items(): FormArray {
    return this.formGroup.get('items') as FormArray;
  }

  constructor(
    private fb: FormBuilder,
    private storeStatusQuery: StoreStatusQuery,
    private clinicQuery: ClinicQuery,
    private alertService: AlertService,
    private itemQuery: ChargeItemQuery,
    private apiInventoryService: ApiInventoryService
  ) { }

  ngOnInit(): void {
    this.formGroup = this.fb.group({
      isDeliveredToSingleLocation: [false],
      centralWarehouseId: [],
      items: this.fb.array([])
    });


    this.purchaseRequests.forEach(pr => {
      const group = this.fb.group({
        uom: [pr.uom],
        quantity: [pr.quantity, wholeNumberValidator],
        unitPrice: [pr.supplierItem.unitPrice.price],
        totalPrice: [{ value: pr.quantity * pr.supplierItem.unitPrice.price, disabled: true }]
      });
      this.items.push(group);
    });

    const itemsSub = this.items.valueChanges.subscribe(rows => {
      rows.forEach((row, i) => {
        const total = (row.quantity || 0) * (row.unitPrice || 0);
        const formGroup = this.items.at(i);
        if (formGroup.get('totalPrice').value !== total) {
          formGroup.get('totalPrice').setValue(total, { emitEvent: false });
        }
      });
    });

    this.subscriptions.add(itemsSub);

    const isDeliveredToSingleLocationSub = this.formGroup.get('isDeliveredToSingleLocation').valueChanges.subscribe(val => {
      this.warehouseDisabled = !val;
      if (!val) {
        this.formGroup.patchValue({ centralWarehouseId: null });
      }
    });

    this.subscriptions.add(isDeliveredToSingleLocationSub);

    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.warehouses = this.clinicQuery.getAll()
          .filter((clinic) => clinic.clinicFeatures.includes('CP'))
        let chargeItems = this.itemQuery.getAllItems()
          .filter(a => this.purchaseRequests.some(b => b.itemRefId === a.id));

        let request = this.purchaseRequests.map((purchaseRequest) => {
          let chargeItem = chargeItems.find(a => a.id === purchaseRequest.itemRefId);
          return {
            id: purchaseRequest.uId,
            itemRefId: purchaseRequest.itemRefId,
            sourceUom: purchaseRequest.uom,
            destinationUom: chargeItem.purchaseUom,
            quantity: purchaseRequest.quantity,
          }
        });

        this.apiInventoryService.convertUom(request).subscribe({
          next: (resp) => {
            if (resp.statusCode === 'S0000') {
              Object.keys(resp.payload).forEach((key, i) => {
                let purchaseRequestItemView = this.purchaseRequests.find(({ uId }) => uId === key);
                let chargeItem = chargeItems.find(({ id }) => id === purchaseRequestItemView.itemRefId);

                this.items.at(i).patchValue({
                  uom: chargeItem.purchaseUom,
                  quantity: resp.payload[key],
                  unitPrice: purchaseRequestItemView.supplierItem.unitPrice.price,
                  totalPrice: resp.payload[key] * purchaseRequestItemView.supplierItem.unitPrice.price
                }, { emitEvent: false });
              });
            }
          },
          error: (err) => {
            this.alertService.error(err.message);
          }
        });
      })
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public closeModal(): void {
    this.formGroup.reset();
    if (this.onClose) this.onClose(undefined);
  }

  public onCreate(): void {
    let { isDeliveredToSingleLocation, centralWarehouseId, items } = this.formGroup.value;

    if (isDeliveredToSingleLocation && !centralWarehouseId || centralWarehouseId == '') {
      this.alertService.error(ERR_SELECT_DELIVERY_LOCATION);
      return
    }

    let requests = this.purchaseRequests.map((purchaseRequest, i) => ({
      ...purchaseRequest,
      requestClinicId: isDeliveredToSingleLocation ? centralWarehouseId : purchaseRequest.requestClinicId,
      quantity: items[i].quantity,
      uom: items[i].uom,
      unitPrice: {
        price: items[i].unitPrice,
        taxIncluded: purchaseRequest.taxIncluded
      }
    }));

    this.onSubmit(requests);
  }
}
