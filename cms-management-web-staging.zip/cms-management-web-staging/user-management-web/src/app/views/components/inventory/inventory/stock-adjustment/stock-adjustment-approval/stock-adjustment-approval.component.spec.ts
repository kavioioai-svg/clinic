import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockAdjustmentApprovalComponent } from './stock-adjustment-approval.component';

describe('StockAdjustmentApprovalComponent', () => {
  let component: StockAdjustmentApprovalComponent;
  let fixture: ComponentFixture<StockAdjustmentApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockAdjustmentApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockAdjustmentApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
