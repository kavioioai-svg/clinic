import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import * as moment from 'moment';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InventoryService} from '../../../../../services/inventory.service';
import {ActivatedRoute} from '@angular/router';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {AlertService} from '../../../../../services/alert.service';
import { DISPLAY_DATE_FORMAT} from '../../../../../constants/app.constants';
import {StockAdjustmentListFilter} from '../../../../../objects/StockAdjustmentListFilter';
import {SearchParams} from '../../../../../objects/searchParams';
import {StockTakeApproveStatus} from '../../../../../objects/StockTakeApproveStatus';
import {Page} from '../../../../../model/page';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {AkitaStoreService} from '../../../../../services/akita-store.service';
import {BsModalService} from 'ngx-bootstrap';
import {StockAdjustmentApprovalComponent} from './stock-adjustment-approval/stock-adjustment-approval.component';
import { TemplateFucType } from '../../../../../model/enum/enums';
import { StoreStatusQuery} from '../../../../../state/store-status/store-status.query';
import {SyncQueue} from '../../../../../objects/SyncQueue';
import {ItemService} from '../../../../../services/item.service';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import { ApiInventoryService } from '../../../../../services/api-inventory.service';
import { finalize } from 'rxjs/operators';
const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-stock-adjustment',
  templateUrl: './stock-adjustment.component.html',
  styleUrls: ['./stock-adjustment.component.scss']
})
export class StockAdjustmentComponent implements OnInit ,AfterContentChecked{
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;

  searchFrm: FormGroup;
  clinics: any[] = [];
  statusOptions: any[] = [];
  filterOptions: any[] = [];
  clinicGroups: any[] = [];
  page: Page = new Page();
  itemList = [];

  @ViewChild('table', { static: false }) datatable: DatatableComponent;

  stockListDataLoaded: boolean = false;
  loading: boolean = false;
  groupedClinics: any[] = [];
  tableOffset = 0;
  isBtnDisabled: boolean;
   allChargeItems: any;
  private isActiveTab: boolean;
  constructor(private fb: FormBuilder,
              private inventoryService: InventoryService,
              private activatedRoute:ActivatedRoute,
              private chargeItemQuery:ChargeItemQuery,
              private clinicQuery: ClinicQuery,
              private alertService: AlertService,
              private akitaServiceService: AkitaStoreService,
              private modalService: BsModalService,
              private cdr: ChangeDetectorRef,
              private storeStatusQuery: StoreStatusQuery,
              private alert: AlertService,
              private masterDataService: MasterDataService,
              private apiInventoryService: ApiInventoryService,
              ) {

    this.page.size = 50;
    this.page.pageNumber = 0;

    this.startDatePickerConfig = new DatePickerConfig('',
                                 moment().toDate() ,
                        null ,
             'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
                      null,
                               moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
            'bottom'
                );
  }

   ngOnInit() {
    this.populateData();
    this.searchFrm.get('startDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('',null , moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate() , null, 'right', 'right');
    });

    //if
    this.searchFrm.get('clinicGroupId').valueChanges.subscribe(val => {
      if(!val || val ==='') {
        this.clinics = this.clinicQuery.getAll();
      }
    });
    this.akitaServiceService.getStockAdjustment();

     this.storeStatusQuery
       .select()
       .subscribe((val) => {
         this.clinics = this.clinicQuery.getAll();
         this.groupClinics();
         this.allChargeItems = this.chargeItemQuery.getAll();
       });

     this.masterDataService.onTabChange$.subscribe(result => {
       if(result) {
         this.loading = true;
         setTimeout(() => {
           this.loading = false;
         }, 500)
       }
     });

     this.activatedRoute.params.subscribe(a => {
       this.isActiveTab = a.tabIndex === '1'
       if (this.isActiveTab) {
         this.onSubmitSearch()
       }
     })

  }

    populateData() {
     this.clinics = this.clinicQuery.getAll();
     this.searchFrm = this.fb.group({
       startDate:      [moment().subtract(1, 'months').toDate(), Validators.required],
       endDate:        [moment().toDate(), Validators.required],
       clinicId:       [null],
       clinicGroupId:  [null],
       statusId:       ['NOT_APPROVED', Validators.required],
       searchText: '',
       filterOptionId: 0,
     });

     this.statusOptions = filterOptionsJson.statusOptions;
     this.filterOptions = filterOptionsJson.searchFilter.slice(0, 2);
  }



  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }


  getStockAdjustmentList() {
    this.loading = true;
    const filter = new StockAdjustmentListFilter();
    const { startDate ,endDate,clinicId ,clinicGroupId ,statusId ,searchText,filterOptionId} = this.searchFrm.value;
    let params = new SearchParams();

    switch (filterOptionId) {
      case 0: {
        filter.itemName = searchText;
        break;
      }
      case 1: {
        filter.itemCode = searchText;
        break;
      }
    }
    if (statusId && statusId !== 'ALL') {
      filter.approveStatus =
        StockTakeApproveStatus[statusId]
      ;
    }if(clinicId){
      filter.clinicIds = clinicId;
    }
    // if(clinicGroupId){
    //   filter.CLINIC_GROUP = clinicGroupId
    // }
    filter.startDateFrom = String(moment(startDate).format('DD-MM-YYYY'));
    filter.startDateTo =  String(moment(endDate).format('DD-MM-YYYY')) ;

    this.inventoryService
      .getStockAdjustmentList(filter, this.page)
      .subscribe(
        list => {
          this.itemList = list;
          this.stockListDataLoaded = true;
          this.loading = false;
        },
        err => {
          this.loading = false;
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  onSubmitSearch() {
    if (this.isActiveTab) {
    this.stockListDataLoaded = false;
    this.page.pageNumber = 0;
    this.getStockAdjustmentList();
  }
  }
  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    this.getStockAdjustmentList();
  }
  onSortClicked() {
    this.datatable.offset = this.page.pageNumber;
  }
  toggleExpandRow(row) {
    this.datatable.rowDetail.toggleExpandRow(row);
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  openApproveRejectModal(item: any, status: StockTakeApproveStatus) {

    let initialState = {
      stockItem: item,
      action: status === StockTakeApproveStatus.APPROVED,
      chargeItems: this.allChargeItems
    };
    const stockModel = this.modalService.show(StockAdjustmentApprovalComponent, {
      initialState,
      class: 'modal-lg stock-approval-reject-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message) {
        this.getStockAdjustmentById(e.stockTakeId);
      }
    });
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onClinicGroupSelect(event) {
    this.searchFrm.get('clinicId').setValue('');
    if (event) {
      this.clinics = [];
        this.groupedClinics[event].forEach((clinic) => {
          this.clinics.push(clinic);
        });

        if(this.searchFrm.controls.clinicId.value === '' ||
          !this.searchFrm.controls.clinicId.value) {
          this.isBtnDisabled = true;
        }
    } else {
      this.isBtnDisabled = !!event;
    }
  }

  get TemplateFucType() {
    return TemplateFucType;
  }

  onClinicSelect($event: any) {
    if($event && $event.length === 0) {
           this.isBtnDisabled = (!(!this.searchFrm.controls.clinicGroupId.value ||
             this.searchFrm.controls.clinicGroupId.value !== ''));
    } else {
      this.isBtnDisabled = false;
    }
  }

  onRetryStock(item: any) {
    this.inventoryService.retryStockAdjustment(item.stockTakeId).subscribe(
      (res: any) => {
        item.isLoading = false;
        if (res.payload.recordStatus === 'SUCCESS') {
          this.alert.success('Item retry succeeded');
          this.itemList = this.itemList.filter((x) => x.stockTakeId !== res.payload.param1);
        }
      },
      (error) => {
        item.isLoading = false;
        this.alert.error(JSON.stringify(error) || "Request failed");
      }
    );
  }

  onDeleteStock(id) {
    this.apiInventoryService.deleteIncompleteStockTake(id).pipe(
      finalize(() => {
        this.onSubmitSearch();
      })
    ).subscribe(res => {}, err => this.alertService.error(JSON.stringify(err.error)));
  }


  getStockAdjustmentById(id: string ) {
    this.inventoryService.getStockAdjustmentById(id).subscribe(res => {
      let stockItem = this.inventoryService.changeObjectModel({payload: [res.payload]});
      let index = this.itemList.findIndex(x => x.stockTakeId === stockItem[0].stockTakeId);
      this.itemList[index] = stockItem[0];
      this.itemList =[...this.itemList];
    })
  }
  onSort(pageInfo) {
    this.datatable = this.masterDataService.setCurrentPageIndex(this.datatable,pageInfo);
  };
}
