import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import * as moment from 'moment';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InventoryService} from '../../../../../services/inventory.service';
import {ActivatedRoute} from '@angular/router';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {AlertService} from '../../../../../services/alert.service';
import { DISPLAY_DATE_FORMAT} from '../../../../../constants/app.constants';
import {StockDisposalListFilter} from '../../../../../objects/StockDisposalListFilter';
import {SearchParams} from '../../../../../objects/searchParams';
import {StockTakeApproveStatus} from '../../../../../objects/StockTakeApproveStatus';
import {Page} from '../../../../../model/page';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {AkitaStoreService} from '../../../../../services/akita-store.service';
import {BsModalService} from 'ngx-bootstrap';
import {StockDisposalDialogComponent} from './stock-disposal-dialog/stock-disposal-dialog.component';
import { StoreStatusQuery} from '../../../../../state/store-status/store-status.query';
import {SyncQueue} from '../../../../../objects/SyncQueue';
import {ItemService} from '../../../../../services/item.service';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import { TemplateFucType } from '../../../../../model/enum/enums';
import { StockDisposalApproveStatus } from '../../../../../objects/StockDisposalApproveStatus';
const filterOptionsJson = require('../../../../../settings/filter-options.json');

@Component({
  selector: 'app-stock-disposal',
  templateUrl: './stock-disposal.component.html',
  styleUrls: ['./stock-disposal.component.scss']
})
export class StockDisposalComponent implements OnInit ,AfterContentChecked{
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;

  searchFrm: FormGroup;
  clinics: any[] = [];
  statusOptions: any[] = [];
  filterOptions: any[] = [];
  clinicGroups: any[] = [];
  page: Page = new Page();
  itemList = [];

  @ViewChild('table', { static: false }) datatable: DatatableComponent;

  stockListDataLoaded: boolean = false;
  loading: boolean = false;
  groupedClinics: any[] = [];
  tableOffset = 0;
  isBtnDisabled: boolean;
  private isActiveTab: boolean;
  constructor(private fb: FormBuilder,
              private inventoryService: InventoryService,
              private activatedRoute:ActivatedRoute,
              private clinicQuery: ClinicQuery,
              private alertService: AlertService,
              private akitaServiceService: AkitaStoreService,
              private modalService: BsModalService,
              private cdr: ChangeDetectorRef,
              private storeStatusQuery: StoreStatusQuery,
              private alert: AlertService,
              private masterDataService: MasterDataService,

              ) {

    this.page.size = 50;
    this.page.pageNumber = 0;

    this.startDatePickerConfig = new DatePickerConfig('',
                                 moment().toDate() ,
                        null ,
             'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
                      null,
                               moment('').add(1, 'days').subtract(1, 'months').toDate(),
            'bottom'
                );
    // this.endDatePickerConfig = new DatePickerConfig('',
    //                   null,
    //                            moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
    //         'bottom'
    //             );
  }

   ngOnInit() {
    this.populateData();
    this.searchFrm.get('startDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('',null , moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate() , null, 'right', 'right');
    });

    this.searchFrm.get('clinicGroupId').valueChanges.subscribe(val => {
      if(!val || val ==='') {
        this.clinics = this.clinicQuery.getAll();
      }
    });
    this.akitaServiceService.getStockAdjustment();

     this.storeStatusQuery
       .select()
       .subscribe((val) => {
         this.clinics = this.clinicQuery.getAll();
         this.groupClinics();
       });

     this.masterDataService.onTabChange$.subscribe(result => {
       if(result) {
         this.loading = true;
         setTimeout(() => {
           this.loading = false;
         }, 500)
       }
     });

     this.activatedRoute.params.subscribe(a => {
       this.isActiveTab = a.tabIndex === '6'
       if (this.isActiveTab) {
        //  this.onSubmitSearch()
       }
     })

  }

    populateData() {
     this.clinics = this.clinicQuery.getAll();
     this.searchFrm = this.fb.group({
       startDate:      [moment().toDate(), Validators.required],
       endDate:        [moment().subtract(1, 'months').toDate(), Validators.required],
       clinicId:       [null, Validators.required],
       clinicGroupId:  [null],
       statusId:       ['REQUESTED', Validators.required],
       searchText: '',
       filterOptionId: 0,
     });

     this.statusOptions = filterOptionsJson.disposalStatusOptions;
     this.filterOptions = filterOptionsJson.searchFilter.slice(0, 2);
  }



  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }


  getStockDisposalList() {
    this.loading = true;
    const filter = new StockDisposalListFilter();
    const { startDate ,endDate,clinicId ,clinicGroupId ,statusId ,searchText,filterOptionId} = this.searchFrm.value;
    let params = new SearchParams();

    if (statusId && statusId !== 'ALL') {
      filter.disposeStatuses = [
        StockDisposalApproveStatus[statusId]
      ]
      ;
    }else{
      filter.disposeStatuses = []
    }
    
    if(clinicId){
      filter.clinicId = clinicId;
    }

    // if(clinicGroupId){
    //   filter.CLINIC_GROUP = clinicGroupId
    // }
    
    filter.startDate = String(moment(startDate).format('DD-MM-YYYY'));
    filter.endDate =  String(moment(endDate).format('DD-MM-YYYY')) ;

    this.inventoryService
      .getStockDisposalList(filter, this.page)
      .subscribe(
        list => {
          this.itemList = list; // Commented since no api is available
          // this.itemList = [];
          this.stockListDataLoaded = true;
          this.loading = false;
        },
        err => {
          this.loading = false;
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  onSubmitSearch() {
    if (this.isActiveTab) {
    this.stockListDataLoaded = false;
    this.page.pageNumber = 0;
    this.getStockDisposalList();
  }
  }
  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    this.getStockDisposalList();
  }
  onSortClicked() {
    this.datatable.offset = this.page.pageNumber;
  }
  toggleExpandRow(row) {
    this.datatable.rowDetail.toggleExpandRow(row);
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  openEditModal(item: any) {

    let initialState = {
      stockDisposalItem: item,
      action: 'edit',
    };
    const stockModel = this.modalService.show(StockDisposalDialogComponent, {
      initialState,
      class: 'modal-lg stock-dialog-reject-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message) {
        this.alertService.success("Data Updated Successfully");
        this.onSubmitSearch();
        // this.getStockDisposalById(e.stockTakeId);
      }
    });
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onClinicGroupSelect(event) {
    this.searchFrm.get('clinicId').setValue('');
    if (event) {
      this.clinics = [];
        this.groupedClinics[event].forEach((clinic) => {
          this.clinics.push(clinic);
        });

        if(this.searchFrm.controls.clinicId.value === '' ||
          !this.searchFrm.controls.clinicId.value) {
          this.isBtnDisabled = true;
        }
    } else {
      this.isBtnDisabled = !!event;
    }
  }

  get TemplateFucType() {
    return TemplateFucType;
  }

  onClinicSelect($event: any) {
    if($event && $event.length === 0) {
           this.isBtnDisabled = (!(!this.searchFrm.controls.clinicGroupId.value ||
             this.searchFrm.controls.clinicGroupId.value !== ''));
    } else {
      this.isBtnDisabled = false;
    }
  }
  
  onSort(pageInfo) {
    this.datatable = this.masterDataService.setCurrentPageIndex(this.datatable,pageInfo);
  };
}
