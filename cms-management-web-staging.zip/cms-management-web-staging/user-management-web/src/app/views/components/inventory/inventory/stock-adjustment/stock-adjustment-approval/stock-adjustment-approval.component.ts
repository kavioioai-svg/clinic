import { Component, OnInit } from '@angular/core';
import { StockItem } from '../../../../../../objects/StockItem';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { StockAdjustmentReason } from '../../../../../../objects/StockAdjustment';
import { InventoryService } from '../../../../../../services/inventory.service';
import { AlertService } from '../../../../../../services/alert.service';
import { StoreService } from '../../../../../../services/store.service';

import { ChargeItemQuery } from '../../../../../../state/charge-item/charge-item.query';

import { DISPLAY_DATE_FORMAT } from '../../../../../../constants/app.constants';

import DatePickerConfig from '../../../../../../objects/DatePickerConfig';
import { StockTakeApproveStatus } from '../../../../../../objects/StockTakeApproveStatus';
import { stockAdjustmentApproveRejection } from '../../../../../../objects/stockAdjustmentApproveRejection';

import { Page } from '../../../../../../model/page';
import { TemplateFucType } from '../../../../../../model/enum/enums';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap';
import * as moment from 'moment';

@Component({
  selector: 'app-stock-adjustment-approval',
  templateUrl: './stock-adjustment-approval.component.html',
  styleUrls: ['./stock-adjustment-approval.component.scss']
})
export class StockAdjustmentApprovalComponent implements OnInit {

  stockItem: any;
  chargeItems: any;
  stockList: Array<StockItem> = [];
  action: boolean;
  initialState: any;
  formGroup: FormGroup;
  isSubmitting: boolean;
  isBtnLoading: boolean;
  isThreadHoldExceeded: boolean;
  purposeOptions: Array<StockAdjustmentReason> = [];

  expiryDateDatePickerConfig: DatePickerConfig = new DatePickerConfig(
    '',
    null,
    moment().toDate(),
    'bottom',
    'right'
  );

  pendingAdjustmentList: any[] = [];
  page: Page = new Page();

  constructor(
    private akitaChargeItemQuery: ChargeItemQuery,
    public bsModalRef: BsModalRef,
    private inventory: InventoryService,
    private store: StoreService,
    private fb: FormBuilder,
    private alert: AlertService,
    private modalService: BsModalService,
    private inventoryService: InventoryService,
  ) {
    this.purposeOptions = this.store.getStockAdjustmentReasonList().filter(reason => !(reason.billAdjustmentIdentifier));
    this.page.pageNumber = 0;
    this.page.size = 6;
    this.isSubmitting = false;
  }

  async ngOnInit() {
    await this.getThreadHoldsStatus();
    this.pendingAdjustmentList = [this.stockItem];
    
    this.subscribeToExpiryDate();
  }

  private subscribeToExpiryDate(): void {
    this.formGroup.get('expiryDate').valueChanges.subscribe({
      next: result => {
        const today = moment();
        const expiriyDate = moment(result);

        if(expiriyDate.diff(today, 'days') < 0) {
          this.formGroup.get('expiryDate').setErrors({ invalidExpDate: true });
        }
      }
    });
  }

  setPage(pageInfo) {
    if (this.page.pageNumber !== pageInfo.offset && pageInfo.offset > this.page.pageNumber) {
      this.page.pageNumber = pageInfo.offset;
    }
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  isDrugOrVaccine(itemCode) {
    let isDrugOrVaccine = false;
    const correspondingItem = this.akitaChargeItemQuery.getChargeItemByCode(itemCode);
    if (correspondingItem) {
      isDrugOrVaccine = correspondingItem.itemType === 'DRUG' || correspondingItem.itemType === 'VACCINATION' ||
        (correspondingItem.itemType === 'CONSUMABLE' && correspondingItem.trackingCode);
    }

    return isDrugOrVaccine;
  }

  onScroll(event: any) {
    if (event.srcElement.type === 'number') {
      event.preventDefault();
    }
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  approveRejectRequest(isApprove: boolean) {
    this.isBtnLoading = true;
    let obj = new stockAdjustmentApproveRejection(this.formGroup.value, this.stockItem);
    const msg = isApprove ? 'Request has been approved' : 'Request has been rejected';
    this.inventory.stockAdjustmentApproveRejection(
      isApprove,
      obj,
      this.stockItem.stockTakeId).subscribe(res => {
        this.isBtnLoading = false;
        res.stockTakeId = this.stockItem.stockTakeId;
        this.modalService.setDismissReason(res);
        this.bsModalRef.hide();
      }, error => {
        this.isBtnLoading = false;
        if (error.error && error.error.message) {
          this.alert.error(error.error.message);
        } else {
          this.alert.error(JSON.stringify(error) || "Request failed");
        }
      })
  }

  getThreadHoldsStatus() {

    this.initForm()
    let obj = {
      stockTakeId: this.stockItem.stockTakeId,
      itemRefId: this.stockItem.itemRefId
    }
    this.inventoryService.getThreadHoldsStatus(obj).subscribe(res => {
      if (res && res.message === "Success") {
        this.isThreadHoldExceeded = (res.payload.isExceeds && this.action);
        if (res.payload.isExceeds && this.action) { this.formGroup.disable() }
      }
    })
  }

  closeModal() {
    this.bsModalRef.hide();
  }

  initForm() {
    this.formGroup = this.fb.group({
      itemCode: [null],
      itemName: [null],
      availableCount: [null],
      adjustedQuantity: [null],
      batchNumber: ['', Validators.required],
      expiryDate: [moment().format(DISPLAY_DATE_FORMAT)],
      baseUom: [null],
      _purposeOfAdjustmentCode: [null],
      cpRemark: [null],
      isDrugOrVaccine: [false]
    });

    this.formGroup.patchValue(this.stockItem);
     if(this.isDrugOrVaccine(this.stockItem.itemCode)) {
       this.formGroup.controls['expiryDate'].setValidators([Validators.required]);
       this.formGroup.patchValue({
         isDrugOrVaccine: this.isDrugOrVaccine(this.stockItem.itemCode)
       });
     }

     if(this.chargeItems && this.chargeItems.length > 0) {
       let item =  this.chargeItems.find(i => i.id == this.stockItem.itemRefId);
       if(item && !item.trackingCode){
         this.formGroup.get('expiryDate').disable();
       }
     }
  }

  getBtnLabel() {
    return this.action ? 'Approve' : 'Reject';
  }

  get TemplateFucType() {
    return TemplateFucType;
  }
}