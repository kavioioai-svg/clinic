import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import * as moment from 'moment';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InventoryService} from '../../../../../services/inventory.service';
import {ActivatedRoute} from '@angular/router';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {AlertService} from '../../../../../services/alert.service';
import { DISPLAY_DATE_FORMAT} from '../../../../../constants/app.constants';
import {StockAdjustmentListFilter} from '../../../../../objects/StockAdjustmentListFilter';
import {SearchParams} from '../../../../../objects/searchParams';
import {StockTakeLineStatus} from '../../../../../objects/StockTakeLineStatus';
import {Page} from '../../../../../model/page';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {AkitaStoreService} from '../../../../../services/akita-store.service';
import {BsModalService} from 'ngx-bootstrap';
import { StoreStatusQuery} from '../../../../../state/store-status/store-status.query';
import {SyncQueue} from '../../../../../objects/SyncQueue';
import {ItemService} from '../../../../../services/item.service';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import { TemplateFucType } from '../../../../../model/enum/enums';
import { StockTakeApprovalComponent } from './stock-take-approval/stock-take-approval.component';
import { BehaviorSubject } from 'rxjs';
import { StockTakeListFilter } from '../../../../../objects/StockTakeListFilter';
import { StockTakeApproveStatus } from '../../../../../objects/StockTakeApproveStatus';
import { StockTakeAllStatus } from '../../../../../objects/StockTakeAllStatus';
const filterOptionsJson = require('../../../../../settings/filter-options.json');
import * as $ from 'jquery';
import { StockTakeBulkApprovalComponent } from './stock-take-bulk-approval/stock-take-bulk-approval.component';

@Component({
  selector: 'app-stock-take',
  templateUrl: './stock-take.component.html',
  styleUrls: ['./stock-take.component.scss']
})
export class StockTakeComponent implements OnInit ,AfterContentChecked{
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;

  searchFrm: FormGroup;
  clinics: any[] = [];
  statusOptions: any[] = [];
  lineStatusOptions: any[] = [];
  filterOptions: any[] = [];
  clinicGroups: any[] = [];
  page: Page = new Page();
  stockTakeData = [];
  itemList: any = [];

  @ViewChild('table', { static: false }) datatable: DatatableComponent;

  stockTakeListDataLoaded: boolean = false;
  loading: boolean = false;
  groupedClinics: any[] = [];
  tableOffset = 0;
  isBtnDisabled: boolean;
  allChargeItems: any;
  allItemsSelected: boolean;
  selectedItemSet: BehaviorSubject<Set<string>> = new BehaviorSubject<Set<string>>(new Set<string>());

  private isActiveTab: boolean;
  constructor(private fb: FormBuilder,
              private inventoryService: InventoryService,
              private activatedRoute:ActivatedRoute,
              private chargeItemQuery:ChargeItemQuery,
              private clinicQuery: ClinicQuery,
              private alertService: AlertService,
              private akitaServiceService: AkitaStoreService,
              private modalService: BsModalService,
              private cdr: ChangeDetectorRef,
              private storeStatusQuery: StoreStatusQuery,
              private alert: AlertService,
              private masterDataService: MasterDataService,
              private itemService: ItemService,

              ) {

    this.page.size = 50;
    this.page.pageNumber = 0;

    this.startDatePickerConfig = new DatePickerConfig('',
                                 moment().toDate() ,
                        null ,
             'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
                      null,
                               moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
            'bottom'
                );
  }

   ngOnInit() {
    this.populateData();
    this.searchFrm.get('startDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('',null , moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate() , null, 'right', 'right');
    });

    //if
    this.searchFrm.get('clinicGroupId').valueChanges.subscribe(val => {
      if(!val || val ==='') {
        this.clinics = this.clinicQuery.getAll();
      }
    });
    // this.akitaServiceService.getStockAdjustment();

     this.storeStatusQuery
       .select()
       .subscribe((val) => {
         this.clinics = this.clinicQuery.getAll();
         this.groupClinics();
         this.allChargeItems = this.chargeItemQuery.getAll();
       });

     this.masterDataService.onTabChange$.subscribe(result => {
       if(result) {
         this.loading = true;
         setTimeout(() => {
           this.loading = false;
         }, 500)
       }
     });

     this.activatedRoute.params.subscribe(a => {
       this.isActiveTab = a.tabIndex === '7'
       if (this.isActiveTab) {
        //  this.onSubmitSearch()
       }
     })

  }

  getAllItem() {
    this.itemService.listAllItems('',true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.itemList = res.payload.map((item) => item.item);
        }
      }
    );
  }

    populateData() {
     this.clinics = this.clinicQuery.getAll();
     this.searchFrm = this.fb.group({
       startDate:      [moment().subtract(1, 'months').toDate(), Validators.required],
       endDate:        [moment().toDate(), Validators.required],
       clinicId:       [null, Validators.required],
       clinicGroupId:  [null],
       itemRefId:       [null],
       approveStatus:['ALL', Validators.required],
       stockTakeStatus:['ALL', Validators.required],
       stockTakeKeyword: '',
       filterOptionId: 0,
     });

     this.lineStatusOptions = filterOptionsJson.lineStatusOptions;
     this.statusOptions = filterOptionsJson.stockeTakeStatusOptions;
     this.filterOptions = filterOptionsJson.searchFilter.slice(0, 2);

     this.getAllItem();
  }



  groupClinics() {
    this.groupedClinics = this.groupBy(this.clinics, 'groupName');
    this.clinicGroups = Object.keys(this.groupedClinics);
  }

  groupBy(objectArray, property) {
    const clinicGroupKeys = new Set();
    const clinics = objectArray.reduce((acc, obj) => {
      const key = obj[property];
      clinicGroupKeys.add(key);
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
    return clinics;
  }


  getStockTakeList() {
    this.loading = true;
    const filter = new StockTakeListFilter();
    const { startDate ,endDate,clinicId,itemRefId,approveStatus ,stockTakeStatus ,stockTakeKeyword,filterOptionId} = this.searchFrm.value;
    let params = new SearchParams();

    if (stockTakeStatus && stockTakeStatus !== 'ALL') {
      filter.approveStatus =
        StockTakeAllStatus[stockTakeStatus]
      ;
    }

    if (approveStatus && approveStatus !== 'ALL') {
      filter.status =
        StockTakeLineStatus[approveStatus]
      ;
    }
    // filter.approveStatus = "ALL";
    if(clinicId){
      filter.clinicIds = clinicId;
    }

    if(stockTakeKeyword && stockTakeKeyword !== ''){
      filter.stockTakeKeyword = stockTakeKeyword;
    }
    
    if(itemRefId){
      filter.itemRefId = itemRefId;
    }
    // if(clinicGroupId){
    //   filter.CLINIC_GROUP = clinicGroupId
    // }
    filter.startDateFrom = String(moment(startDate).format('DD-MM-YYYY'));
    filter.startDateTo =  String(moment(endDate).format('DD-MM-YYYY')) ;

    this.inventoryService
      .getStockTakeList(filter, this.page)
      .subscribe(
        list => {
          this.stockTakeData = list;
          this.stockTakeListDataLoaded = true;
          this.loading = false;
          this.allItemsSelected = false;
        },
        err => {
          this.loading = false;
          this.alertService.error(JSON.stringify(err.error));
        }
      );
  }

  onSelectAll($event) {
    if ($event.target.checked) {
      this.allItemsSelected = true;
      this.selectedItemSet.next(
        new Set<string>(this.stockTakeData.filter(r=> !this.isCheckboxDisabled(r)).map((item) => item)));
    } else {
      this.allItemsSelected = false;
      this.selectedItemSet.next(new Set<string>())
    }
  }

  
  isCheckboxDisabled(row: any) {
    if (!row) {
      return true;
    }

    return row.status != 'REQUESTED';
  }

  checkSelectedItem(item: any) {
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    return !!selectedList.find(r => r.lineId == item.lineId);
  }

  onItemCheckBoxChange(row: any) {
    this.allItemsSelected = false;
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    if (!!selectedList.find(r => r.lineId == row.lineId)) {
      this.selectedItemSet.next(
        new Set<any>(
          selectedList.filter(r => r.lineId != row.lineId)
        ));
      $("#" + row.lineId).attr('disabled', 'disabled');
    } else {
      this.selectedItemSet.value.add(row);
      setTimeout(() => {
        $("#" + row.lineId).removeAttr('disabled');
      });
    }
    this.selectedItemSet.next(this.selectedItemSet.value);
  }

  approveRejectBulkModal(status: StockTakeLineStatus) {
    let modalRef = this.modalService.show(StockTakeBulkApprovalComponent, {
      initialState: {
        stockItem: Array.from(this.selectedItemSet.value.values()),
        action: status === StockTakeLineStatus.APPROVED,
        onClose: () => {
          modalRef.hide();
        },
        onSubmit: (stockItem: any[]) => {

        }
      },
      class: 'modal-xl'
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message) {
        if(status === StockTakeLineStatus.APPROVED){
          this.alertService.success("Stock Take Approved");
        }else{
          this.alertService.success("Stock Take Rejected");
        }
        this.allItemsSelected = false;
        this.selectedItemSet.next(new Set<string>())
        this.onSubmitSearch();
      }
    });
  }

  onSubmitSearch() {
    if (this.isActiveTab) {
    this.stockTakeListDataLoaded = false;
    this.page.pageNumber = 0;
    this.getStockTakeList();
  }
  }
  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    this.getStockTakeList();
  }
  onSortClicked() {
    this.datatable.offset = this.page.pageNumber;
  }
  toggleExpandRow(row) {
    this.datatable.rowDetail.toggleExpandRow(row);
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  get StockTakeLineStatus() {
    return StockTakeLineStatus;
  }

  openApproveRejectModal(item: any, status: StockTakeLineStatus) {
    let initialState = {
      stockItem: item,
      action: status === StockTakeLineStatus.APPROVED,
      chargeItems: this.allChargeItems
    };
    const stockModel = this.modalService.show(StockTakeApprovalComponent, {
      initialState,
      class: 'modal-lg stock-approval-reject-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message) {
        if(status === StockTakeLineStatus.APPROVED){
          this.alertService.success("Stock Take Approved");
        }else{
          this.alertService.success("Stock Take Rejected");
        }
        this.allItemsSelected = false;
        this.selectedItemSet.next(new Set<string>())
        this.onSubmitSearch();
      }
    });
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onClinicGroupSelect(event) {
    this.searchFrm.get('clinicId').setValue('');
    if (event) {
      this.clinics = [];
        this.groupedClinics[event].forEach((clinic) => {
          this.clinics.push(clinic);
        });

        if(this.searchFrm.controls.clinicId.value === '' ||
          !this.searchFrm.controls.clinicId.value) {
          this.isBtnDisabled = true;
        }
    } else {
      this.isBtnDisabled = !!event;
    }
  }

  get TemplateFucType() {
    return TemplateFucType;
  }

  onClinicSelect($event: any) {
    if($event && $event.length === 0) {
           this.isBtnDisabled = (!(!this.searchFrm.controls.clinicGroupId.value ||
             this.searchFrm.controls.clinicGroupId.value !== ''));
    } else {
      this.isBtnDisabled = false;
    }
  }

  onRetryStock(item: any) {
    this.inventoryService.retryStockAdjustment(item.stockTakeId).subscribe(
      (res: any) => {
        item.isLoading = false;
        if (res.payload.recordStatus === 'SUCCESS') {
          this.alert.success('Item retry succeeded');
          this.stockTakeData = this.stockTakeData.filter((x) => x.stockTakeId !== res.payload.param1);
        }
      },
      (error) => {
        item.isLoading = false;
        this.alert.error(JSON.stringify(error) || "Request failed");
      }
    );
  }


  getStockAdjustmentById(id: string ) {
    this.inventoryService.getStockAdjustmentById(id).subscribe(res => {
      let stockItem = this.inventoryService.changeObjectModel({payload: [res.payload]});
      let index = this.stockTakeData.findIndex(x => x.stockTakeId === stockItem[0].stockTakeId);
      this.stockTakeData[index] = stockItem[0];
      this.stockTakeData =[...this.stockTakeData];
    })
  }
  onSort(pageInfo) {
    this.datatable = this.masterDataService.setCurrentPageIndex(this.datatable,pageInfo);
  };
}
