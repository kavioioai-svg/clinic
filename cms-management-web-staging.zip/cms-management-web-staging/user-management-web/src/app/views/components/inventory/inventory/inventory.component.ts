import {Component, OnInit, ViewChild, ElementRef, EventEmitter, Output} from '@angular/core';
import {InventoryTab} from '../../../../model/enum/enums';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiInventoryService} from '../../../../services/api-inventory.service';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import { NgxPermissionsService } from 'ngx-permissions';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.scss']
})
export class InventoryComponent implements OnInit {
  isEnableProceedBtn: boolean;
  activeIndex: any;
  selectedItems: any;
  tabChangeIndex: any;
  @ViewChild('dropdownAction',{static: false}) dropdownAction: ElementRef;

  constructor( private router: Router,
               private activatedRoute: ActivatedRoute,
               private apiInventoryService: ApiInventoryService,
               private masterDataService: MasterDataService,
               private permissionsService: NgxPermissionsService,
               ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.activeIndex = params['tabIndex'];
      this.onInitialLoad();
    });
  }


  get InventoryTab() {
    return InventoryTab;
  }

  onInitialLoad() {
    if(this.activeIndex !== "-"){
      return
    }
    let permissions = [
      ['ROLE_CURRENT_STOCK_OVERVIEW'],
      ['ROLE_STOCK_ADJUSTMENT_APPROVAL'],
      ['ROLE_VIEW_SYNC_INFO'],
      ['ROLE_VIEW_ORDER_REQUEST'],
      ['ROLE_VIEW_ORDER_REQUEST']
    ]

    for (let i = 0; i < permissions.length; i++) {
      let a = permissions[i]
      for(let b in a){
        if(this.permissionsService.getPermission(a[b])){
          this.router.navigate([`pages/inventory/main/${i}`]);
          return true;

        }
      }
    }
  }

  onTabSelected(tab: InventoryTab) {
    this.masterDataService.isOnTabChange(true);
    this.isEnableProceedBtn = this.selectedItems > 0 && tab == InventoryTab.PURCHASE_REQUEST;
    this.router.navigate([`pages/inventory/main/${tab}`]);
    this.tabChangeIndex = tab;
  };

  onSelectItem(selectedItems: any) {
    this.selectedItems = selectedItems;
    this.isEnableProceedBtn = selectedItems.size && selectedItems.size > 0;
  }
}
