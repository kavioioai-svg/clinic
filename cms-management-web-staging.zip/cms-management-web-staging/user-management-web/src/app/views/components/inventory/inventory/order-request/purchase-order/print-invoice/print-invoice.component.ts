import {Component, OnInit, Input, SimpleChanges, OnChanges, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-print-invoice',
  templateUrl: './print-invoice.component.html',
  styleUrls: ['./print-invoice.component.scss']
})
export class PrintInvoiceComponent implements OnInit , OnChanges{
  @Input() printTemplateData: any;
  @Input() items: any;
  @Input() gstPercent: number = 0;
  @Input() gstAmount: number = 0;
  @Output() printPage = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  ngOnChanges(Changes: SimpleChanges) {
    if(Changes['printTemplateData'] && Changes['printTemplateData'].currentValue && Changes['printTemplateData'].currentValue.order) {
      setTimeout(() => this.printPage.emit(true) , 500)
    }
  }
  getItemCodeName(code: string, itemRefId: any) {
    if(this.items.value.length > 0) {
      let item = this.items.value.find(item => item.id === itemRefId);
      return item ? item.code : ''
    }
  }
}
