import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryComponent } from './inventory/inventory.component';
import {InventoryRoutingModule} from './inventory-routing.module';
import {SharedModule} from '../../../shared.module';
import { StockAdjustmentComponent } from './inventory/stock-adjustment/stock-adjustment.component';
import { CurrentStockComponent } from './inventory/current-stock/current-stock.component';
import {InventoryDisplayItemsSumQuantityPipe} from '../../../pipes/inventory-display-items-sum-quantity.pipe';
import { StockAdjustmentApprovalComponent } from './inventory/stock-adjustment/stock-adjustment-approval/stock-adjustment-approval.component';
import { SyncQueueComponent } from './inventory/sync-queue/sync-queue.component';
import {SupplierModule} from "../supplier/supplier.module";
import {SelectListModule} from "../../../components/select-list/select-list.module";
import { PurchaseOrderComponent } from './inventory/order-request/purchase-order/purchase-order.component';
import { OrderRequestComponent } from './inventory/order-request/order-request.component';
import { PurchaseRequisitionsComponent } from './inventory/purchase-requisitions/purchase-requisitions.component';
import { GrnDetailsComponent } from './inventory/order-request/grn-details/grn-details.component';
import { TransferOrderComponent } from './inventory/order-request/transfer-order/transfer-order.component';
import {PrintInvoiceComponent} from './inventory/order-request/purchase-order/print-invoice/print-invoice.component';
import { PoConfirmationFormComponent } from './inventory/purchase-requisitions/po-confirmation-form/po-confirmation-form.component';
import { MinPurchaseConfirmPopupComponent } from './inventory/order-request/purchase-order/min-purchase-confirm-popup/min-purchase-confirm-popup.component';
import { SupplierContactPopupComponent } from './inventory/order-request/purchase-order/supplier-contact-popup/supplier-contact-popup.component';
import { StockDisposalComponent } from './inventory/stock-disposal/stock-disposal.component';
import { StockDisposalDialogComponent } from './inventory/stock-disposal/stock-disposal-dialog/stock-disposal-dialog.component';
import { PurchaseReturnApprovalsComponent } from './inventory/purchase-return-approvals/purchase-return-approvals.component';
import { StockTakeComponent } from './inventory/stock-take/stock-take.component';
import { StockTakeApprovalComponent } from './inventory/stock-take/stock-take-approval/stock-take-approval.component';
import { StockTakeBulkApprovalComponent } from './inventory/stock-take/stock-take-bulk-approval/stock-take-bulk-approval.component';
import { ReturnOrderComponent } from './inventory/purchase-return-approvals/return-order/return-order.component';

@NgModule({
    declarations: [
      InventoryComponent,
      StockAdjustmentComponent,
      CurrentStockComponent,
      InventoryDisplayItemsSumQuantityPipe,
      StockAdjustmentApprovalComponent,
      SyncQueueComponent,
      PurchaseOrderComponent,
      OrderRequestComponent,
      PurchaseRequisitionsComponent,
      GrnDetailsComponent,
      TransferOrderComponent,
      ReturnOrderComponent,
      PrintInvoiceComponent,
      PoConfirmationFormComponent,
      MinPurchaseConfirmPopupComponent,
      SupplierContactPopupComponent,
      StockDisposalComponent,
      StockDisposalDialogComponent,
      PurchaseReturnApprovalsComponent,
      StockTakeComponent,
      StockTakeApprovalComponent,
      StockTakeBulkApprovalComponent
      ],
  imports: [
    CommonModule,
    InventoryRoutingModule,
    SharedModule,
    SupplierModule,
    SelectListModule,
  ],
  entryComponents:[StockAdjustmentApprovalComponent, PoConfirmationFormComponent, MinPurchaseConfirmPopupComponent, SupplierContactPopupComponent, StockDisposalDialogComponent, StockTakeApprovalComponent, StockTakeBulkApprovalComponent]
})
export class InventoryModule { }
