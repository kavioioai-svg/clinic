import {Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import {Page} from '../../../../../model/page';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiInventoryService} from '../../../../../services/api-inventory.service';
import {AlertService} from '../../../../../services/alert.service';
import {StoreStatusQuery} from '../../../../../state/store-status/store-status.query';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {ItemService} from '../../../../../services/item.service';
import {SupplierService} from '../../../../../services/master-data-service/supplier.service';
import {InventoryService} from '../../../../../services/inventory.service';
import {PurchaseOrderFilter} from '../../../../../objects/purchaseOrder-filter';
import * as moment from 'moment';
import {InventoryTab, TemplateFucType} from '../../../../../model/enum/enums';
import {DISPLAY_DATE_FORMAT} from '../../../../../constants/app.constants';
import {BehaviorSubject} from "rxjs";
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
import {SharedDataService} from "../../../../../services/master-data-service/shared-data-service.service";
import {
  MinPurchaseConfirmPopupComponent
} from "./purchase-order/min-purchase-confirm-popup/min-purchase-confirm-popup.component";
import {BsModalService} from "ngx-bootstrap";
import {MinPurchaseConfirmService} from ".././min-purchase-confirm.service";
import {NgxPermissionsService} from "ngx-permissions";
import {GoodPurchasedItem, Order} from '../../../../../objects/Supplier';
import {SupplierContactPopupComponent} from './purchase-order/supplier-contact-popup/supplier-contact-popup.component';

const filterOptionsJson = require('../../../../../settings/filter-options.json');


@Component({
  selector: 'app-order-request',
  templateUrl: './order-request.component.html',
  styleUrls: ['./order-request.component.scss']
})
export class OrderRequestComponent implements OnInit, OnChanges {
  [x: string]: any;
  order: BehaviorSubject<Order> = new BehaviorSubject<Order>(null);
  searchFrm: FormGroup;
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;
  page: Page = new Page();
  transferOrderList: any;
  clinics = [];
  itemList: any = [];
  supplierList: any[];
  statusOptions: any;
  orderTypeOptions: any;
  isFilter: boolean;
  isLoading: boolean;
  tableOffset = 0;
  allItemsSelected: boolean;
  selectedItemSet: BehaviorSubject<Set<string>> = new BehaviorSubject<Set<string>>(new Set<string>());
  @Input() tabChangeIndex: any;
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;
  public data: any;
  printTemplateData: any;
  itemLists: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);


  private isActiveTab: boolean;

  constructor(private activatedRoute: ActivatedRoute,
              private apiInventoryService: ApiInventoryService,
              private alertService: AlertService,
              private storeStatusQuery: StoreStatusQuery,
              private clinicQuery: ClinicQuery,
              private itemService: ItemService,
              private supplierService: SupplierService,
              private inventoryService: InventoryService,
              private fb: FormBuilder,
              private masterDataService: MasterDataService,
              private alert: AlertService,
              private router: Router,
              private chargeItemQuery: ChargeItemQuery,
              private sharedDataService: SharedDataService,
              private modalService: BsModalService,
              private belowMinimumPurchaseConfirmService:MinPurchaseConfirmService,
              private permissionService: NgxPermissionsService
  ) {
    this.page.size = 50;
    this.page.pageNumber = 0;

    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate(),
      null,
      'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
      null,
      moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
      'bottom');
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.tabChangeIndex && changes.tabChangeIndex.currentValue == InventoryTab.ORDER_REQUEST) {
      this.getFilterState();
    }
  }


  ngOnInit() {
    this.initData();
    this.sharedDataService.data$.subscribe(data => {
      this.data = data;
      if(this.data !== null && this.data !== undefined){
        this.onSubmitSearch();
      }
    });
    this.inventoryService.getPageFilterState().subscribe(res => {
      if (res && res.length > 0) {
        let find = res.find(frm => frm.pageIndex == InventoryTab.ORDER_REQUEST);
        if (find) {
          this.searchFrm.patchValue(find.searchForm);
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '4'
      if (this.isActiveTab) {
        this.onSubmitSearch()

        this.activatedRoute.queryParams.subscribe(params => {
          let value = {
            ...params,
          };
          if (params.fromDate) {
            value.fromDate = moment(params.fromDate, DISPLAY_DATE_FORMAT).toDate();
          }
          if (params.endDate) {
            value.endDate = moment(params.endDate, DISPLAY_DATE_FORMAT).toDate();
          }
          if (params.prNos) {
            value.prNos = params.prNos.join(',');
          }
          this.searchFrm.patchValue(value);
          this.executeSearch(params.isPaginated)
        })
      }
    })

  

    this.masterDataService.onTabChange$.subscribe(result => {
      if (result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.searchFrm.get('fromDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('', null, moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate(), null, 'right', 'right');
    });


  }

  isActionsAvailable(row:any){
    if (row && row.data && row.data.orderType === "TRANSFER") return true
    return this.permissionService.getPermission('ROLE_PURCHASE_ORDER_CREATE')
  }
  disableCheckbox(row:any){
    if(row.dataType == 'TO' && !row.data.senderClinicId) return true
    if (row.dataType == 'PO' && this.permissionService.getPermission('ROLE_PURCHASE_ORDER_CREATE') == undefined) return true
  }

  onSubmitSearch(isPaginated = false, timestamp: number = undefined) {
    if (this.isActiveTab) {
      this.router.navigate(['.'], {queryParams: {
          ...this.searchFrm.value,
          isPaginated,
          fromDate: this.searchFrm.value.fromDate ? moment(this.searchFrm.value.fromDate).format(DISPLAY_DATE_FORMAT) : null,
          endDate: this.searchFrm.value.endDate ? moment(this.searchFrm.value.endDate).format(DISPLAY_DATE_FORMAT) : null,
          prNos: this.searchFrm.value.prNos ? this.searchFrm.value.prNos.split(',') : null,
          timestamp
        }, relativeTo: this.activatedRoute});
    }
  }

  executeSearch(isPaginated = false) {
    this.isFilter = true;
    this.isLoading = true;
    let filter = new PurchaseOrderFilter();
    if (this.searchFrm.controls.clinicId.value) {
      filter.CLINIC_ID = this.searchFrm.controls.clinicId.value;
    }
    if (this.searchFrm.controls.fromDate.value) {
      filter.CREATED_DATE_MORE = moment(this.searchFrm.controls.fromDate.value).format(DISPLAY_DATE_FORMAT);

    }
    if (this.searchFrm.controls.endDate.value) {
      filter.CREATED_DATE_LESS = moment(this.searchFrm.controls.endDate.value).add(1, 'days').format(DISPLAY_DATE_FORMAT);
    }
    if (this.searchFrm.controls.orderStatus.value && this.searchFrm.controls.orderStatus.value != "ALL") {
      filter.STATUS = this.searchFrm.controls.orderStatus.value;
    }
    if (this.data != null) {
      filter.ORDER_IDS = this.data
    }
    if(this.searchFrm.controls.orderNo.value){
      filter.ORDER_REQUEST_NO = this.searchFrm.controls.orderNo.value;
    }
    if(this.searchFrm.controls.vendor.value){
      filter.VENDOR_ID = this.searchFrm.controls.vendor.value;
    }
    if(this.searchFrm.controls.itemRefId.value){
      filter.ITEMREF_ID = this.searchFrm.controls.itemRefId.value;
    }

    if (this.searchFrm.controls.orderType.value && this.searchFrm.controls.orderType.value != "ALL" && this.searchFrm.controls.orderType.value != "PO_TO") {
      filter.TRANSFER_PURCHASE_TYPE = this.searchFrm.controls.orderType.value;
    }

    if (this.searchFrm.controls.prNos.value) {
      filter.PR_NOS = this.searchFrm.controls.prNos.value.split(',');
    }

    this.setSearchFilterState();
    this.inventoryService.getPurchaseOrderList(filter, this.page).subscribe(res => {
      if (res.statusCode === 'S0000') {
        this.isLoading = false;
        this.page.pageNumber = res.payload['pageNumber'];
        this.page.totalPages = res.payload['totalPages'];
        this.page.totalElements = res.payload['totalElements'];
        this.transferOrderList = res.payload.content;
        if (!isPaginated) {
          this.selectedItemSet.next(new Set<string>());
          this.allItemsSelected = false;
        }

      }
    }, error => {
      this.isLoading = false;
    })
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    window.scrollTo(0, 0);
    this.onSubmitSearch(true);
  }
  get TemplateFucType() {
    return TemplateFucType;
  }

  getStatus(requestStatus: any) {
    let status = requestStatus.replace(/_/g, ' ');
    return status === 'PARTIAL RECEIVED' ? 'PARTIALLY RECEIVED' : status;
  }
  getClinics() {
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll();
      });
  }
  getAllItem() {
    this.itemService.listAllItems('',true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.itemList = res.payload.map((item) => item.item);
        }
      }
    );
  }
  getSupplierList() {
    this.supplierService.listAllSuppliers().subscribe((res => {
      if (res && res.statusCode == "S0000") {
        this.supplierList = res.payload;
      }
    }))
  }

  private initData() {
    this.getClinics();
    this.getAllItem();
    this.getSupplierList();
    this.initForm(this.previousFilter);
    this.getFilterState();


    this.statusOptions = filterOptionsJson.OrderRequestStatus.sort((a, b) => a.name.localeCompare(b.name));
    this.orderTypeOptions = filterOptionsJson.OrderType.sort((a, b) => a.name.localeCompare(b.name));

    this.getOrderList();

    this.itemService.listAllItems('',true).subscribe(res => {
      if (res && res.statusCode === "S0000") {
        this.itemLists.next(res.payload.map(item => item.item))
      }
    })

  }

  viewOrder(order: any) {
    let type = order.orderType == "TRANSFER" ? 'transfer-order' : 'purchase-order';
    this.router.navigate([`pages/inventory/${type}/view/${order.id}`])
  }

  getOrderList() {
    this.onSubmitSearch();
  }

  edit(row: any) {
    let type = row.orderType == "TRANSFER" ? 'transfer-order' : 'purchase-order';
    this.router.navigate([`pages/inventory/${type}/edit/${row.id}`])
  }

  onActionChange($event: unknown, row: any) {
    if ($event === 'Edit') {
      this.edit(row.data);
    }

    if ($event === 'View') {
      this.viewOrder(row.data);
    }

    if ($event === 'Email') {
      this.saveAndSendMail(row.data);
    }

    if ($event === 'Print') {
      this.saveAndPrint(row.data);
    }
  }

  saveAndSendMail(data) {
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(data);
    let getModifiedData = this.initializaPurchaseOrderDependencies(data);
    let showModalOnConfirmation = (()=>{
      let supModal = this.modalService.show(SupplierContactPopupComponent, {
        initialState: {
          onConfirm(singleSupplerContact) {
            const emails = [];
            singleSupplerContact.forEach(element => {
              emails.push(element.email);
            });
            emailPO(emails)
            supModal.hide()
          },
          onClose() {
            supModal.hide()
          },
          supplierId: getModifiedData.supplierId,
          message: ``
        }
      })

    })

    let emailPO = ((supplierEmail?:Array<any>)=>{
      if (getModifiedData.orderStatus === 'DRAFT') {
        getModifiedData.orderStatus = 'INITIAL'
      }
      let isValidForm = this.checkFormValidation(getModifiedData);
      if(isValidForm){
        this.apiInventoryService.savePurchaseOrderWithEmail(getModifiedData, supplierEmail).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.alertService.success("Purchase order issued successfully")
            setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},3000);
          } else {
            this.alertService.error(res.message)
          }
        },err =>  this.alertService.error(JSON.stringify(err.error.message)))
      }
    }).bind(this)

    if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
      showModalOnConfirmation();
    } else {
      let minPurchaseAmount = (this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            showModalOnConfirmation();
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message: `The PO ${purchaseOrder.orderNo || ''} has not fulfilled the Minimum Purchase Amount $${minPurchaseAmount} , do you still want to save and email?`
        }
      })
    }
  }

  saveAndPrint(data) {
    let purchaseOrder: Order & {goodPurchasedBonusItems: GoodPurchasedItem[]} = this.composePurchaseOrder(data);
    let getModifiedData = this.initializaPurchaseOrderDependencies(data);

    let saveAndPrintPO = (()=>{
      if (getModifiedData.orderStatus === 'DRAFT') {
        getModifiedData.orderStatus = 'INITIAL'
      }
      let isValidForm = this.checkFormValidation(getModifiedData);
      if(isValidForm){
        this.apiInventoryService.issuePurchaseOrder(getModifiedData).subscribe(res => {
          if (res.statusCode === "S0000") {
            this.alertService.success("Purchase order issued successfully")
            this.printContent(res.payload.id);
            setTimeout(() =>{this.router.navigate([`pages/inventory/main/4`])},4000);
          } else {
            this.alertService.error(res.message)
          }
        },err =>  this.alertService.error(JSON.stringify(err.error.message)))
      }

    }).bind(this)


    if (!this.inventorySummaryItem || this.inventorySummaryItem.reachMinimum) {
      saveAndPrintPO()
    } else {
      let minPurchaseAmount = (this.inventorySummaryItem.minimumPurchaseAmount / 100).toFixed(2)
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            saveAndPrintPO()
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message: `The PO ${purchaseOrder.orderNo || ''} has not fulfilled the Minimum Purchase Amount $${minPurchaseAmount} , do you still want to save and print?`
        }
      })
    }
  }

  checkFormValidation(data){
    if(!data.requestClinicId || !data.requestId || !data.supplierId){
      this.alertService.error("Basic data invalid. Please fill all the required fields")
      return false;
    }else{
      if(data.goodPurchasedItems && data.goodPurchasedItems.length > 0){
        let isItemValid = data.goodPurchasedItems.every(item => {
          if(!item.quantity || !item.receiverClinicId || !item.purchaseRequestId || !item.itemRefId || !item.uom){
            this.alertService.error("Good purchase items invalid. Please fill all the required fields")
            return false;
          }else{
            return true;
          }
        })
        if(!isItemValid){
          return false;
        }
      }
      return true;
    }
  }

  printContent(id: string) {
    this.inventoryService.getPoEPrintTemplate(id).subscribe(res => {
      if (res.statusCode === "S0000") {
        this.printTemplateData = res.payload
      }
    });
  }

  printPage(){
    const WinPrint = window.open('', '', 'letf=10,top=10,width="450",height="250",toolbar=1,scrollbars=1,status=1');
    WinPrint.document.write('  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" >');
    WinPrint.document.write('<body >');
    WinPrint.document.write('<header >');
    WinPrint.document.write('</header >');
    WinPrint.document.write(document.getElementById('print').innerHTML);
    WinPrint.document.write('</body></html>');
    WinPrint.document.close()

    WinPrint.onload = ()=>{
      WinPrint.window.print()
    }

    if('matchMedia' in WinPrint.window){
      WinPrint.matchMedia('print').addEventListener("change", (media)=>{
        if(!media.matches){
          WinPrint.close();
        }
      });
    }else{
      WinPrint.onafterprint = function () {
        WinPrint.close()
      }
    }
  }

  private initializaPurchaseOrderDependencies(data) {

    this.inventoryService.getPurchaseOrderById(data.id).subscribe(res => {
      if (res.statusCode === "S0000") {
        data.requestNo = res.payload.order.requestNo;
      }
    });

    let lineNos = []

    data.cPTransfer = data.cptransfer || false;
    data.goodPurchasedBonusItems = data.goodPurchasedBonusItems ? data.goodPurchasedBonusItems : [];

    data.goodPurchasedItems.forEach(item => {
      let _lineNo = parseFloat(item.lineNo);
      if (!isNaN(_lineNo)) {
        lineNos.push(_lineNo)
      }

      item.isBonusItem = !item.unitPrice || !item.unitPrice.price

      let receivedQuantities: { [k: string]: number } = {}
      for (const note of data.goodReceivedNotes) {
        if (note.status == 'CONFIRM') {
          for (const receivedItem of note.receivedItems) {
            if (receivedItem.lineNo == item.lineNo) {
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] || 0;
              receivedQuantities[receivedItem.lineNo] = receivedQuantities[receivedItem.lineNo] + receivedItem.quantity;
            }
          }
        }
      }

      item.receivedQuantity = receivedQuantities[item.lineNo] || 0;
      item.unitPriceValue = item.unitPrice && item.unitPrice.price ? item.unitPrice.price / 100 : 0;
      item.quantity = item.quantity;
      item.cpRemarks = item.cpRemarks ?  item.cpRemarks : null;
      item.remark = item.remark;

    });


    return data;
  }

  private composePurchaseOrder(purchaseOrder: Order & { goodPurchasedBonusItems: GoodPurchasedItem[] }) {
    return {
      ...this.order.value,
      ...purchaseOrder,
      goodPurchasedItems: [...purchaseOrder.goodPurchasedItems, ...purchaseOrder.goodPurchasedBonusItems],
    };
  }

  onSelectAll($event) {
    if ($event.target.checked) {
      this.allItemsSelected = true;
      this.selectedItemSet.next(
        new Set<string>(this.transferOrderList.filter(r=> !this.isCheckboxDisabled(r)).map((item) => item.data.id)));
    } else {
      this.allItemsSelected = false;
      this.selectedItemSet.next(new Set<string>())
    }
  }

  onItemCheckBoxChange(row: any) {
    this.allItemsSelected = false;
    if (this.selectedItemSet.value.has(row.data.id)) {
      this.selectedItemSet.value.delete(row.data.id);
    } else {
      this.selectedItemSet.value.add(row.data.id);
    }
    this.selectedItemSet.next(this.selectedItemSet.value);
  }

  rejectSelected() {
    this.isLoading = true;
    let selectedItem = Array.from(this.selectedItemSet.value.values());
    let result = selectedItem.filter(o1 => !this.transferOrderList.some(o2 => o1 === o2.data.id && o2.status !== "FULL_RECEIVED"));
    this.apiInventoryService.rejectOrders(result).subscribe((res: any) => {
        if (res.statusCode == "S0000") {
          this.alert.success('Orders has been rejected successfully');
          this.selectedItemSet.next(new Set<string>());
          this.allItemsSelected = false;
          this.onSubmitSearch();
          this.isLoading = false;
        }
      },
      error => {
        this.alert.error(JSON.stringify(error));
        this.isLoading = false;
      })
  }

  saveSelected() {
    let items = [];
    this.selectedItemSet.value.forEach(res => {
      items.push(this.transferOrderList.find(r => r.data.id == res))
    });

    let underPricedOrders = this.belowMinimumPurchaseConfirmService.getMinimum(items);

    let saveSelectedPo=(()=>{
      if (items.length > 0) {
        items = items.map(item => item.data).map(r =>
          r.orderStatus == 'DRAFT' ? { ...r, orderStatus: 'INITIAL' } : r
        )
      }
      this.apiInventoryService.saveOrder(items).subscribe((res: any) => {
          if (res.statusCode == "S0000") {
            this.onSubmitSearch(false, Date.now());
            this.alert.success('Orders has been saved successfully')
            this.selectedItemSet.next(new Set<string>());
            this.allItemsSelected = false;
          }
        },
        error => {
          this.alert.error(JSON.stringify(error));
        })
    }).bind(this)

    if (underPricedOrders.length) {
      let ref = this.modalService.show(MinPurchaseConfirmPopupComponent, {
        initialState: {
          onConfirm() {
            saveSelectedPo()
            ref.hide()
          },
          onClose() {
            ref.hide()
          },
          message:`The PO ${underPricedOrders.map(a => a.orderId).join(', ')} ${underPricedOrders.length > 1 ? 'have' : 'has'} not fulfilled the Minimum Purchase Amount do you still want to issue?`
        }
      })
    } else {
      saveSelectedPo()
    }
  }

  createPo() {
    this.router.navigate(['pages/inventory/purchase-order/create/']);
  }

  createTo() {
    this.router.navigate(['pages/inventory/transfer-order/create/']);
  }

  setSearchFilterState() {
    this.inventoryService.setPageFilterState({ pageIndex: InventoryTab.ORDER_REQUEST, searchForm: this.searchFrm.getRawValue() });
  }

  initForm(previousFilter: any) {
    this.searchFrm = this.fb.group({
      fromDate: [moment().subtract(7, 'days').toDate()],
      endDate: [moment().toDate()],
      orderStatus: ['ALL'],
      orderType: ['PO_TO'],
      clinicId: [],
      vendor: [],
      itemRefId: [],
      orderNo: [],
      prNos: []
    });
    if (previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
    this.itemList = this.chargeItemQuery.getDrugItems();
  }

  getFilterState() {
    this.inventoryService.getPageFilterState().subscribe(res => {
      if (res && res.length > 0) {
        let find = res.find(frm => frm.pageIndex == InventoryTab.ORDER_REQUEST);
        if (find) {
          this.previousFilter = find.searchFrm;
          this.initForm(find.searchForm);

        }
      }
    })
  }

  clinicCode(requestClinicId?: string) {
    if (!requestClinicId) {
      return '';
    }
    const clinic = this.clinics.find((clinic) => clinic.id === requestClinicId);
    return clinic ? clinic.clinicCode : '';
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  getSupplierName(itemId: any) {
    if(this.supplierList && this.supplierList.length > 0) {
      let item = this.supplierList.find(item => item.id === itemId);
      return item ? item.name : ''
    }
  }

  isCheckboxDisabled(row: any) {
    if (!row || !row.data) {
      return true;
    }
    switch (row.dataType) {
      case "PO":
        return !this.permissionService.getPermission('ROLE_PURCHASE_ORDER_CREATE');
      case "TO":
        return !row.data.senderClinicId
    }

    return row.dataType == 'TO' && !row.data.senderClinicId;
  }


  getGrandTotal(row:any) {
    let totalPrices = row.data.totalPrice/100
    return totalPrices.toFixed(2) || '0';
  }

  getActions(row: any) {
    let status = this.getStatus(row.status);
    if (status === 'DRAFT' && row.filterType === 'PURCHASE_ORDER') {
      return [
        {
          action: 'Edit',
          label: 'Edit'
        },
        {
          action: 'View',
          label: 'View'
        },
        {
          action: 'Email',
          label: 'Issue and Email'
        },
        {
          action: 'Print',
          label: 'Issue and Print'
        },
      ];
    } else if (status === "FULL RECEIVED") {
      return [
        {
          action: 'View',
          label: 'View'
        },
      ]
    } else if (status !== 'DELETED') {
      return [
        {
          action: 'Edit',
          label: 'Edit'
        },
        {
          action: 'View',
          label: 'View'
        },
        // {
        //   action:'Delete',
        //   label:'Delete'
        // },
      ];
    } else {
      return [
        {
          action: 'View',
          label: 'View'
        },
      ];
    }
  }

  isIssueEnabled() {
    let map = Array.from(this.selectedItemSet.value).map(res => {
      return this.transferOrderList.find(a => a.data.id === res);
    });
    let isFullReceivedAvailable = map.some(res => res.status === 'FULL_RECEIVED');

    if (isFullReceivedAvailable) return false;
    return this.selectedItemSet.value.size > 0
  }
}
