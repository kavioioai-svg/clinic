export const ERR_SELECT_DELIVERY_LOCATION = 'Please select a delivery location or uncheck the Deliver to single location option';
