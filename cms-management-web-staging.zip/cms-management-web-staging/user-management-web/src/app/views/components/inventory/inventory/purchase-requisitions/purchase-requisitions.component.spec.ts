import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseRequisitionsComponent } from './purchase-requisitions.component';

describe('PurchaseRequisitionsComponent', () => {
  let component: PurchaseRequisitionsComponent;
  let fixture: ComponentFixture<PurchaseRequisitionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchaseRequisitionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchaseRequisitionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
