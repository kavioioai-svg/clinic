import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoConfirmationFormComponent } from './po-confirmation-form.component';

describe('PoConfirmationFormComponent', () => {
  let component: PoConfirmationFormComponent;
  let fixture: ComponentFixture<PoConfirmationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoConfirmationFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoConfirmationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
