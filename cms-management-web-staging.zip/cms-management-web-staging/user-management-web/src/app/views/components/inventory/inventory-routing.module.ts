import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InventoryComponent } from './inventory/inventory.component';
import {InventoryTab} from '../../../model/enum/enums';
import {PurchaseOrderComponent} from './inventory/order-request/purchase-order/purchase-order.component';
import {TransferOrderComponent} from './inventory/order-request/transfer-order/transfer-order.component';
import { ReturnOrderComponent } from './inventory/purchase-return-approvals/return-order/return-order.component';


const routes: Routes = [
  {
    path: '',
 //   canActivateChild: [NgxPermissionsGuard],
    data: {
      title: 'Inventory',
    },
    children: [
      { path: '', pathMatch: 'full', redirectTo: `main/-` },
      { path: 'main/:tabIndex', component: InventoryComponent,
        pathMatch: 'prefix',
        data: {
          requiresLogin: true,
        },
      },
      { path: 'purchase-order/:operation', component: PurchaseOrderComponent},
      { path: 'purchase-order/:operation/:id', component: PurchaseOrderComponent},
      { path: 'transfer-order/:operation', component: TransferOrderComponent},
      { path: 'transfer-order/:operation/:id', component: TransferOrderComponent},
      { path: 'return-order/:operation', component: ReturnOrderComponent},
      { path: 'return-order/:operation/:id', component: ReturnOrderComponent}
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InventoryRoutingModule { }
