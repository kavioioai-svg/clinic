import { Component, OnInit } from '@angular/core';
import { StockItem } from '../../../../../../objects/StockItem';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { StockAdjustmentReason } from '../../../../../../objects/StockAdjustment';
import { InventoryService } from '../../../../../../services/inventory.service';
import { AlertService } from '../../../../../../services/alert.service';
import { StoreService } from '../../../../../../services/store.service';

import { ChargeItemQuery } from '../../../../../../state/charge-item/charge-item.query';

import { DISPLAY_DATE_FORMAT } from '../../../../../../constants/app.constants';

import DatePickerConfig from '../../../../../../objects/DatePickerConfig';
import { StockTakeApproveStatus } from '../../../../../../objects/StockTakeApproveStatus';
import { stockAdjustmentApproveRejection } from '../../../../../../objects/stockAdjustmentApproveRejection';

import { Page } from '../../../../../../model/page';
import { TemplateFucType } from '../../../../../../model/enum/enums';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap';
import * as moment from 'moment';

@Component({
  selector: 'app-stock-take-bulk-approval',
  templateUrl: './stock-take-bulk-approval.component.html',
  styleUrls: ['./stock-take-bulk-approval.component.scss']
})
export class StockTakeBulkApprovalComponent implements OnInit {

  stockItem: any;
  chargeItems: any;
  stockList: Array<StockItem> = [];
  action: boolean;
  initialState: any;
  formGroup: FormGroup;
  isSubmitting: boolean;
  isBtnLoading: boolean;
  isThreadHoldExceeded: boolean;
  purposeOptions: Array<StockAdjustmentReason> = [];

  expiryDateDatePickerConfig: DatePickerConfig = new DatePickerConfig(
    '',
    null,
    moment().toDate(),
    'bottom',
    'right'
  );

  pendingStockTakeList: any[] = [];
  page: Page = new Page();

  constructor(
    private akitaChargeItemQuery: ChargeItemQuery,
    public bsModalRef: BsModalRef,
    private inventory: InventoryService,
    private store: StoreService,
    private fb: FormBuilder,
    private alert: AlertService,
    private modalService: BsModalService,
    private inventoryService: InventoryService,
  ) {
    this.purposeOptions = this.store.getStockAdjustmentReasonList().filter(reason => !(reason.billAdjustmentIdentifier));
    this.page.pageNumber = 0;
    this.page.size = 6;
    this.isSubmitting = false;
  }

  async ngOnInit() {
    this.initForm();
    this.pendingStockTakeList = this.stockItem;
  }

  setPage(pageInfo) {
    if (this.page.pageNumber !== pageInfo.offset && pageInfo.offset > this.page.pageNumber) {
      this.page.pageNumber = pageInfo.offset;
    }
  }

  dateComparator(valueA, valueB): number {
    const momentA = moment(valueA, DISPLAY_DATE_FORMAT);
    const momentB = moment(valueB, DISPLAY_DATE_FORMAT);

    return momentA.valueOf() - momentB.valueOf();
  }

  onScroll(event: any) {
    if (event.srcElement.type === 'number') {
      event.preventDefault();
    }
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  approveRejectRequest(isApprove: boolean) {
    this.isBtnLoading = true;
    
    let obj = [];
    for (let index = 0; index < this.stockItem.length; index++) {
      const element = {stockTakeId: this.stockItem[index].stockTakeId, lineId: this.stockItem[index].lineId, ...this.formGroup.value};
      obj.push(element);
    }
    const msg = isApprove ? 'Request has been approved' : 'Request has been rejected';
    if(isApprove){
      //Approve
      this.inventory.stockTakeApproval(
        obj).subscribe(res => {
          this.isBtnLoading = false;
          // res.stockTakeId = this.stockItem.stockTakeId;
          this.modalService.setDismissReason(res);
          this.bsModalRef.hide();
        }, error => {
          this.isBtnLoading = false;
          if (error.error && error.error.message) {
            this.alert.error(error.error.message);
          } else {
            this.alert.error(JSON.stringify(error) || "Request failed");
          }
      })
    }else{
      //Reject
      this.inventory.stockTakeReject(
        obj).subscribe(res => {
          this.isBtnLoading = false;
          // res.stockTakeId = this.stockItem.stockTakeId;
          this.modalService.setDismissReason(res);
          this.bsModalRef.hide();
        }, error => {
          this.isBtnLoading = false;
          if (error.error && error.error.message) {
            this.alert.error(error.error.message);
          } else {
            this.alert.error(JSON.stringify(error) || "Request failed");
          }
      })
    }
  }

  removeStockTakeFromBulk(row){
    //remove from list
    this.pendingStockTakeList = this.pendingStockTakeList.filter(item => item.lineId !== row.lineId);
    if(this.pendingStockTakeList.length <= 0){
      this.bsModalRef.hide();
    }
  }

  closeModal() {
    this.bsModalRef.hide();
  }

  initForm() {
    this.formGroup = this.fb.group({
      cpRemarks: [null],
    });

    this.formGroup.patchValue(this.stockItem);
 
 
  }

  getBtnLabel() {
    return this.action ? 'Approve' : 'Reject';
  }

  get TemplateFucType() {
    return TemplateFucType;
  }
}