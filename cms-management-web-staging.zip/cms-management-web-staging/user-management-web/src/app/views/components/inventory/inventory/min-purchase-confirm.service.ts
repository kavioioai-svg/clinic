import { Injectable } from '@angular/core';
import { InventorySummaryItem } from "../../../../objects/InventorySummaryItem";
import { SupplierService } from "../../../../services/master-data-service/supplier.service";

@Injectable({
  providedIn: 'root'
})
export class MinPurchaseConfirmService {
  private supplierList: any[] = [];

  constructor(private supplierService: SupplierService) {
    this.getSupplierList();
  }

  private getSupplierList(): void {
    this.supplierService.listAllSuppliers().subscribe((res) => {
      if (res && res.statusCode === "S0000") {
        this.supplierList = res.payload || [];
      }
    });
  }


  private getMinPurchaseAmount(reqSupplierId: any, requestedClinicId: any): number {
    const supplier = this.supplierList.find((supplier) => supplier.id === reqSupplierId);
    if (supplier) {
      const minPurchaseAmounts = supplier.clinicMinPurchaseAmounts || supplier.minPurchaseAmounts;
      const minPurchaseAmount = minPurchaseAmounts.find((a) => a.clinicId && a.clinicId === requestedClinicId);
      if (!minPurchaseAmount) {
        return minPurchaseAmounts.find((a) => a.global);
      }
      return minPurchaseAmount;
    }
    return null;
  }

  public getMinimum(orders: any[]): { orderId: string, summary: InventorySummaryItem }[] {
    return orders.map(order => {
      if (order.data.goodPurchasedItems) {
        let goodPurchasedItems: any[] = order.data.goodPurchasedItems;
        let totalPrice = goodPurchasedItems.reduce((acc, item) => {
          let unitPrice = item.unitPrice ? item.unitPrice.price : 0;
          let quantity = item.quantity ? item.quantity : 0;
          return acc + (unitPrice * quantity)
        }, 0);
        let minPurchaseAmount = this.getMinPurchaseAmount(order.data.supplierId, order.data.requestClinicId)
        let supplier = this.supplierList.find(a => a.id === order.data.supplierId);
        let inventorySummaryItem = new InventorySummaryItem(supplier, totalPrice, minPurchaseAmount);
        if (!inventorySummaryItem.reachMinimum) {
          return {
            orderId: order.orderRequestNo,
            summary: inventorySummaryItem
          }
        }
      }
      return null
    }).filter(a => !!a);
    return [];
  }
}
