import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MinPurchaseConfirmPopupComponent } from './min-purchase-confirm-popup.component';

describe('BelowMinimumPurchaseAmountComfirmationPopupComponent', () => {
  let component: MinPurchaseConfirmPopupComponent;
  let fixture: ComponentFixture<MinPurchaseConfirmPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MinPurchaseConfirmPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MinPurchaseConfirmPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
