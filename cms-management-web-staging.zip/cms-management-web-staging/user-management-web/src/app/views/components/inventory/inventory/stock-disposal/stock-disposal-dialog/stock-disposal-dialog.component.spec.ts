import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockDisposalDialogComponent } from './stock-disposal-dialog.component';

describe('StockDisposalDialogComponent', () => {
  let component: StockDisposalDialogComponent;
  let fixture: ComponentFixture<StockDisposalDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockDisposalDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockDisposalDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
