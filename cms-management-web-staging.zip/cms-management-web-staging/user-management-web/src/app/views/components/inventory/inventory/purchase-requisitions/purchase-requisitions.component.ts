import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
  ChangeDetectorRef,
  AfterViewChecked,
  AfterViewInit
} from '@angular/core';
import { FormBuilder, FormGroup } from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import moment = require("moment");
import DatePickerConfig from "../../../../../objects/DatePickerConfig";
import { BehaviorSubject, combineLatest } from "rxjs";
import { Page } from "../../../../../model/page";
import { ItemService } from "../../../../../services/item.service";
import { StoreStatusQuery } from "../../../../../state/store-status/store-status.query";
import { ClinicQuery } from "../../../../../state/clinic/clinic.query";
import { ApiInventoryService } from "../../../../../services/api-inventory.service";
import { PurchaseRequestItemView } from "../../../../../objects/PurchaseRequestItemView";
import { AlertService } from '../../../../../services/alert.service';
import { DISPLAY_DATE_FORMAT } from '../../../../../constants/app.constants';
import { DatatableComponent } from '@swimlane/ngx-datatable';
const filterOptionsJson = require('../../../../../settings/filter-options.json');
import * as $ from 'jquery';
import { MasterDataService } from '../../../../../services/master-data-service/master-data.service';
import { TemplateFucType } from 'app/model/enum/enums';
import {BsModalService} from "ngx-bootstrap";
import {PoConfirmationFormComponent} from "./po-confirmation-form/po-confirmation-form.component";

import { SharedDataService } from '../../../../../services/master-data-service/shared-data-service.service';
import {SupplierService} from "../../../../../services/master-data-service/supplier.service";

interface RequestItemWithData extends PurchaseRequestItemView {
  item?: any;
  supplier?: any;
  supplierItem?: any;
  clinic?: any;
}

@Component({
  selector: 'app-purchase-requisitions',
  templateUrl: './purchase-requisitions.component.html',
  styleUrls: ['./purchase-requisitions.component.scss']
})
export class PurchaseRequisitionsComponent implements OnInit {

  searchFrm: FormGroup;
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;
  page: BehaviorSubject<Page> = new BehaviorSubject<Page>(new Page(0, 50));
  statusOptions: any;
  itemList: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);
  itemMap: BehaviorSubject<{ [k: string]: any }> = new BehaviorSubject<{ [k: string]: any }>({});
  clinics: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);
  clinicsMap: BehaviorSubject<{ [k: string]: any }> = new BehaviorSubject<{ [k: string]: any }>({});
  supplierList: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);
  supplierMap: BehaviorSubject<{ [k: string]: any }> = new BehaviorSubject<{ [k: string]: any }>({});
  requestItems: BehaviorSubject<PurchaseRequestItemView[]> = new BehaviorSubject<PurchaseRequestItemView[]>([]);
  requestItemsWithData: BehaviorSubject<RequestItemWithData[]> = new BehaviorSubject<RequestItemWithData[]>([]);
  isLoading: boolean;
  offset = 0;
  allItemsSelected: any;
  selectedItemSet: BehaviorSubject<Set<PurchaseRequestItemView>> = new BehaviorSubject<Set<PurchaseRequestItemView>>(new Set<PurchaseRequestItemView>());
  @ViewChild('table', {static: false}) datatable: DatatableComponent;

  @ViewChild('dropdownAction', {static: false}) dropdownAction: ElementRef;
  isDisableSelectAll: boolean;
  private isActiveTab: boolean;
  isCpEmpty = false;
  txtHeight: number

  constructor(private fb: FormBuilder,
              private router: Router,
              private apiInventoryService: ApiInventoryService,
              private itemService: ItemService,
              private alert: AlertService,
              private storeStatusQuery: StoreStatusQuery,
              private cdRef: ChangeDetectorRef,
              private masterDataService: MasterDataService,
              private clinicQuery: ClinicQuery,
              private sharedDataService: SharedDataService,
              private modalService: BsModalService,
              private activatedRoute: ActivatedRoute,
              private supplierService: SupplierService) {
  }


  ngOnInit(page?) {
    this.searchFrm = this.fb.group({
      requestDateStart: [moment().subtract(7, 'days').toDate()],
      requestDateEnd: [moment().toDate()],
      requestItemStatus: ['PENDING'],
      requestNo: [],
      itemRefId: [],
      requestClinicId: [],
      supplierId: [],
    });

    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate(),
      null,
      'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
      null,
      moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
      'bottom'); // can use two arguments

    this.masterDataService.onTabChange$.subscribe(result => {
      if (result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '3'
      if (this.isActiveTab) {
        this.onSubmitSearch()
      }
    })

    this.statusOptions = filterOptionsJson.PrItemStatusOptions.sort((a, b) => a.name.localeCompare(b.name));
    this.itemService.listAllItems('', true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.itemList.next(res.payload.map((item) => item.item));
          this.itemMap.next(res.payload.reduce((acc, item) => {
            acc[item.item.id] = item.item;
            return acc;
          }, {}));
        }
      }
    );
    // this.supplierService.listAllSuppliers('').subscribe(
    //   (res)=>{
    //     this.supplierList.next(res.payload.map((supplier)=>{supplier.supplierNo}));
    //     this.supplierMap.next(res.payload.reduce((acc, supplier) => {
    //       acc[supplier.supplier.id] = supplier.supplier;
    //       return acc;
    //     }, {}));
    //   }
    // );
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics.next(this.clinicQuery.getAll());
        this.clinicsMap.next(this.clinicQuery.getAll().reduce((acc, clinic) => {
          acc[clinic.id] = clinic;
          return acc;
        }, {}));
      });
    this.itemService.listAllSuppliers().subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          if (res.payload.length > 0) {
            this.supplierList.next(res.payload);
            this.supplierMap.next(res.payload.reduce((acc, supplier) => {
              acc[supplier.id] = supplier;
              return acc;
            }, {}));
          }
        }
      }
    );
    combineLatest([this.requestItems, this.clinicsMap, this.supplierMap, this.itemMap]).subscribe(
      ([requestItems, clinics, supplierList, itemList]) => {
        let value = requestItems.map((item) => {
          let supplier = supplierList[item.supplierId];
          return ({
            ...item,
            clinic: clinics[item.requestClinicId],
            supplier: supplier,
            supplierItem: supplier ? supplier.items.find((supplierItem) => supplierItem.itemId === item.itemRefId) : undefined,
            item: itemList[item.itemRefId],
          });
        });
        this.requestItemsWithData.next(value)
      });
    this.onSubmitSearch();
  }

  onSubmitSearch() {
    if (this.isActiveTab) {
      this.page.next(new Page(0, 50));
      this.isDisableSelectAll = this.searchFrm.get('requestItemStatus').value == 'REJECTED';
      this.search();
    }
  }

  search(isPaginated = false) {
    if (this.isActiveTab) {
      this.isLoading = true;
      if (this.searchFrm.controls.requestDateStart.value) {
        this.searchFrm.value['requestDateStart'] = moment(this.searchFrm.get('requestDateStart').value).format(DISPLAY_DATE_FORMAT);
      }
      if (this.searchFrm.controls.requestDateEnd.value) {
        this.searchFrm.value['requestDateEnd'] = moment(this.searchFrm.get('requestDateEnd').value).format(DISPLAY_DATE_FORMAT);

      }
      this.apiInventoryService.searchPurchaseOrderItems({
        ...this.searchFrm.value,
        ...this.page.value
      }).subscribe(res => {
          this.requestItems.next(res.payload.content);
          this.isLoading = false;
          this.page.next({
            ...this.page.value,
            totalElements: res.payload.totalElements,
          });

          if (!isPaginated) {
            this.selectedItemSet.next(new Set<PurchaseRequestItemView>());
            this.allItemsSelected = false;
          } else {
            this.checkSelectedAllItems();
          }
          this.expendRows();
        },
        error => {
          this.isLoading = false;
          this.alert.error(JSON.stringify(error));
        })
    }
  }

  setPage($event: any) {

    this.page.next({
      ...this.page.value,
      pageNumber: $event.offset,
    });
    this.search(true);
  }

  onSelectAll($event) {
    if ($event.target.checked) {
      this.allItemsSelected = true;
      this.selectedItemSet.next(
        new Set<PurchaseRequestItemView>(
          this.requestItemsWithData.value.filter(value => value.requestItemStatus == 'SUBMITTED' || value.requestItemStatus == 'PENDING')
        ));
    } else {
      this.allItemsSelected = false;
      this.selectedItemSet.next(new Set<PurchaseRequestItemView>())
    }
  }

  displayCheck() {
    let itemSet = this.selectedItemSet;
    return (row) => {
      return itemSet.value.has(row);
    }
  }

  onItemCheckBoxChange(row: any) {
    this.allItemsSelected = false;
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    if (!!selectedList.find(r => r.uId == row.uId)) {
      this.selectedItemSet.next(
        new Set<PurchaseRequestItemView>(
          selectedList.filter(r => r.uId != row.uId)
        ));
      $("#" + row.uId).attr('disabled', 'disabled');
    } else {
      this.selectedItemSet.value.add(row);
      setTimeout(() => {
        $("#" + row.uId).removeAttr('disabled');
      });
    }
    this.selectedItemSet.next(this.selectedItemSet.value);
  }

  createPo() {
    // this.isLoading = true;
    let modalRef = this.modalService.show(PoConfirmationFormComponent, {
      initialState: {
        purchaseRequests: Array.from(this.selectedItemSet.value.values()),
        onClose: () => {
          modalRef.hide();
        },
        onSubmit: (purchaseRequests: PurchaseRequestItemView[]) => {
          this.apiInventoryService.createOrders('PO', 'combined', Array.from(purchaseRequests)).subscribe((res: any) => {
              if (res.statusCode == "S0000") {
                this.dropdownAction.nativeElement.click();
                this.alert.success('PO has been created successfully');
                this.selectedItemSet.next(new Set<PurchaseRequestItemView>());
                this.allItemsSelected = false;
                this.search();
                this.isLoading = false;
                this.router.navigate(['../4'], {
                  queryParams: {prNos: purchaseRequests.map(a => a.requestNo)},
                  relativeTo: this.activatedRoute
                })
                modalRef.hide()
              } else {
                this.alert.error(JSON.stringify(res));
                this.isLoading = false;
                modalRef.hide();
              }
            },
            error => {
              this.alert.error(JSON.stringify(error));
              this.isLoading = false;
              modalRef.hide();
            })
        }
      },
      class: 'modal-xl'
    });
  }

  createTo() {
    this.isLoading = true;
    this.apiInventoryService.createOrders('TO', 'single', Array.from(this.selectedItemSet.value.values())).subscribe((res: any) => {
        if (res.statusCode == "S0000") {
          this.dropdownAction.nativeElement.click();
          this.alert.success('To has been created successfully');
          this.selectedItemSet.next(new Set<PurchaseRequestItemView>());
          this.search();
          this.sharedDataService.setData(res.payload)
          this.allItemsSelected = false;
          this.isLoading = false;
          this.router.navigate(['../4'], {
            queryParams: {prNos: Array.from(this.selectedItemSet.value.values()).map(a => a.requestNo)},
            relativeTo: this.activatedRoute
          })
        } else {
          this.alert.error(JSON.stringify(res));
          this.isLoading = false;
        }

      },
      error => {
        this.alert.error(JSON.stringify(error));
        this.isLoading = false;
      })
  }

  rejectPr() {
    let selectedItem = Array.from(this.selectedItemSet.value.values());
    let isRemarkEnable = !!selectedItem.find((e: any) => !e.cpRemarks || e.cpRemarks == '')
    if (!isRemarkEnable) {
      this.apiInventoryService.rejectRequests(Array.from(this.selectedItemSet.value.values())).subscribe((res: any) => {
          if (res.statusCode == "S0000") {
            this.dropdownAction.nativeElement.click();
            this.alert.success('Requests has been rejected successfully');
            this.search();
          } else {
            this.alert.error(JSON.stringify(res));
          }
        },
        error => {
          this.alert.error(JSON.stringify(error));
        })
    } else {
      selectedItem.forEach(item => {
        this.isCpEmpty = true
        this.toggleExpandRow(item)
      })
      this.alert.error('CP Remark is mandatory');
    }

  }

  toArray(value: Set<PurchaseRequestItemView>) {
    return Array.from(value.values());
  }

  checkSelectedItem(item: any) {
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    return !!selectedList.find(r => r.uId == item.uId);
  }

  checkSelectedAllItems() {
    let itemsList: any[] = Array.from(this.requestItems.value);
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    itemsList.forEach(r => {
      this.allItemsSelected = !!selectedList.find(e => e.uId == r.uId);
    });
  }

  toggleExpandRow(row) {
    this.datatable.rowDetail.toggleExpandRow(row);
    this.enableDisableCpRemark(row);
  }

  expendRows(): void {
    setTimeout(() => {
      if (this.datatable && this.datatable.rowDetail)
        this.requestItemsWithData.value.forEach(item => {
          if (item.remark)
            this.datatable.rowDetail.toggleExpandRow(item)
        });
      this.cdRef.detectChanges();
    }, 1000);
  }

  getItemName(itemId: any) {
    if (this.itemList.value.length > 0) {
      let item = this.itemList.value.find(item => item.id === itemId);
      return item ? item.code + ' - ' + item.name : ''
    }
  }
  // getSupplierName(supplierId: any) {
  //   if (this.supplierList.value.length > 0) {
  //     let supplier = this.supplierList.value.find(supplier => supplier.id === supplierId);
  //     return supplier ? supplier.No + ' - ' + supplier.name : ''
  //   }
  // }

  enableDisableCpRemark(row) {
    let selectedList: any[] = Array.from(this.selectedItemSet.value);
    if (!!selectedList.find(r => r.uId == row.uId)) {
      setTimeout(() => {
        $("#" + row.uId).removeAttr('disabled');
      });
    } else {


    }
  }

  get TemplateFucType() {
    return TemplateFucType;
  }

  getStatus(requestStatus: any) {
    let status = requestStatus.replace(/_/g, ' ');
    return status === 'PARTIAL RECEIVED' ? 'PARTIALLY RECEIVED' : status;
  }

  onSort(pageInfo) {
    this.datatable = this.masterDataService.setCurrentPageIndex(this.datatable, pageInfo);
  };

}
