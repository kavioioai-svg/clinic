import { Component, Input, OnInit, OnChanges, SimpleChanges , ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import DatePickerConfig from '../../../../../objects/DatePickerConfig';
import { Page } from '../../../../../model/page';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiInventoryService } from '../../../../../services/api-inventory.service';
import { AlertService } from '../../../../../services/alert.service';
import { StoreStatusQuery } from '../../../../../state/store-status/store-status.query';
import { ClinicQuery } from '../../../../../state/clinic/clinic.query';
import { ItemService } from '../../../../../services/item.service';
import { SupplierService } from '../../../../../services/master-data-service/supplier.service';
import { InventoryService } from '../../../../../services/inventory.service';
import { OrderType, PurchaseOrderFilter } from '../../../../../objects/purchaseOrder-filter';
import * as moment from 'moment';
import { InventoryTab, TemplateFucType } from '../../../../../model/enum/enums';
import { DISPLAY_DATE_FORMAT } from '../../../../../constants/app.constants';
import { BehaviorSubject } from "rxjs";
import { MasterDataService } from '../../../../../services/master-data-service/master-data.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {ChargeItemQuery} from '../../../../../state/charge-item/charge-item.query';
const filterOptionsJson = require('../../../../../settings/filter-options.json');
import { SharedDataService } from "../../../../../services/master-data-service/shared-data-service.service";
import {BsModalService} from "ngx-bootstrap";
import {MinPurchaseConfirmService} from ".././min-purchase-confirm.service";
import {NgxPermissionsService} from "ngx-permissions";
import { GoodPurchasedItem, Order } from '../../../../../objects/Supplier';
import { SupplierContactPopupComponent } from '../order-request/purchase-order/supplier-contact-popup/supplier-contact-popup.component';
import { MinPurchaseConfirmPopupComponent } from '../order-request/purchase-order/min-purchase-confirm-popup/min-purchase-confirm-popup.component';
import { PurchaseReturnOrderFilter } from '../../../../../objects/purchaseReturnOrder-filter';


@Component({
  selector: 'app-purchase-return-approvals',
  templateUrl: './purchase-return-approvals.component.html',
  styleUrls: ['./purchase-return-approvals.component.scss']
})
export class PurchaseReturnApprovalsComponent implements OnInit, OnChanges {
  [x: string]: any;
  order: BehaviorSubject<Order> = new BehaviorSubject<Order>(null);
  searchFrm: FormGroup;
  startDatePickerConfig: DatePickerConfig;
  endDatePickerConfig: DatePickerConfig;
  page: Page = new Page();
  purchaseReturnOrderList: any;
  clinics = [];
  itemList: any = [];
  supplierList: any[];
  statusOptions: any;
  orderTypeOptions: any;
  isFilter: boolean;
  isLoading: boolean;
  tableOffset = 0;
  allItemsSelected: boolean;
  selectedItemSet: BehaviorSubject<Set<string>> = new BehaviorSubject<Set<string>>(new Set<string>());
  @Input() tabChangeIndex: any;
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;
  public data: any;
  printTemplateData: any;
  itemLists: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);


  actionButtonList = [
    {
      action:'View',
      label:'View'
    },
  ];

  actionButtonListAll = [
    {
      action:'Edit',
      label:'Edit'
    },
    {
      action:'View',
      label:'View'
    },
  ];


  private isActiveTab: boolean;

  constructor(private activatedRoute: ActivatedRoute,
              private apiInventoryService: ApiInventoryService,
              private alertService: AlertService,
              private storeStatusQuery: StoreStatusQuery,
              private clinicQuery: ClinicQuery,
              private itemService: ItemService,
              private supplierService: SupplierService,
              private inventoryService: InventoryService,
              private fb: FormBuilder,
              private masterDataService: MasterDataService,
              private alert: AlertService,
              private router: Router,
              private chargeItemQuery: ChargeItemQuery,
              private sharedDataService: SharedDataService,
              private modalService: BsModalService,
              private belowMinimumPurchaseConfirmService:MinPurchaseConfirmService,
              private permissionService: NgxPermissionsService
  ) {
    this.page.size = 50;
    this.page.pageNumber = 0;

    this.startDatePickerConfig = new DatePickerConfig('',
      moment().toDate(),
      null,
      'bottom');
    this.endDatePickerConfig = new DatePickerConfig('',
      null,
      moment(this.startDatePickerConfig.maxDate).add(1, 'days').subtract(1, 'months').toDate(),
      'bottom');
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.tabChangeIndex && changes.tabChangeIndex.currentValue == InventoryTab.PURCHASE_RETURN_APPROVAL) {
      this.getFilterState();
    }
  }


  ngOnInit() {
    this.initData();
    this.sharedDataService.data$.subscribe(data => {
      this.data = data;
      if(this.data !== null && this.data !== undefined){
        this.onSubmitSearch();
      }
    });
    this.inventoryService.getPageFilterState().subscribe(res => {
      if (res && res.length > 0) {
        let find = res.find(frm => frm.pageIndex == InventoryTab.PURCHASE_RETURN_APPROVAL);
        if (find) {
          this.searchFrm.patchValue(find.searchForm);
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '5'
      if (this.isActiveTab) {
        this.onSubmitSearch()

        this.activatedRoute.queryParams.subscribe(params => {
          let value = {
            ...params,
          };
          if (params.fromDate) {
            value.fromDate = moment(params.fromDate, DISPLAY_DATE_FORMAT).toDate();
          }
          if (params.endDate) {
            value.endDate = moment(params.endDate, DISPLAY_DATE_FORMAT).toDate();
          }
          if (params.prNos) {
            value.prNos = params.prNos.join(',');
          }
          this.searchFrm.patchValue(value);
          this.executeSearch(params.isPaginated)
        })
      }
    })

   

    this.masterDataService.onTabChange$.subscribe(result => {
      if (result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.searchFrm.get('fromDate').valueChanges.subscribe(val => {
      this.endDatePickerConfig = new DatePickerConfig('', null, moment(val).toDate(), 'right', 'right');
    });
    this.searchFrm.get('endDate').valueChanges.subscribe(val => {
      this.startDatePickerConfig = new DatePickerConfig('', moment(val).toDate(), null, 'right', 'right');
    });


  }

  isActionsAvailable(row:any){
    if (row && row.data && row.data.orderType === "TRANSFER") return true
    return this.permissionService.getPermission('ROLE_PURCHASE_ORDER_CREATE')
  }
  disableCheckbox(row:any){
    if(row.dataType == 'TO' && !row.data.senderClinicId) return true
    if (row.dataType == 'PO' && this.permissionService.getPermission('ROLE_PURCHASE_ORDER_CREATE') == undefined) return true
  }

  onSubmitSearch(isPaginated = false, timestamp: number = undefined) {
    if (this.isActiveTab) {
      this.router.navigate(['.'], {queryParams: {
          ...this.searchFrm.value,
          isPaginated,
          fromDate: this.searchFrm.value.fromDate ? moment(this.searchFrm.value.fromDate).format(DISPLAY_DATE_FORMAT) : null,
          endDate: this.searchFrm.value.endDate ? moment(this.searchFrm.value.endDate).format(DISPLAY_DATE_FORMAT) : null,
          prNos: this.searchFrm.value.prNos ? this.searchFrm.value.prNos.split(',') : null,
          timestamp
        }, relativeTo: this.activatedRoute});
    }
  }

  executeSearch(isPaginated = false) {
    this.isFilter = true;
    this.isLoading = true;
    let filter = new PurchaseReturnOrderFilter();
    if (this.searchFrm.controls.clinicId.value) {
      filter.clinicId = this.searchFrm.controls.clinicId.value;
    }
    if (this.searchFrm.controls.fromDate.value) {
      filter.startDate = moment(this.searchFrm.controls.fromDate.value).format(DISPLAY_DATE_FORMAT);

    }
    if (this.searchFrm.controls.endDate.value) {
      filter.endDate = moment(this.searchFrm.controls.endDate.value).add(1, 'days').format(DISPLAY_DATE_FORMAT);
    }
    if (this.searchFrm.controls.orderStatus.value && this.searchFrm.controls.orderStatus.value != "ALL") {
      filter.requestStatus = this.searchFrm.controls.orderStatus.value;
    }
    if (this.data != null) {
      filter.ORDER_IDS = this.data
    }
    if(this.searchFrm.controls.orderNo.value){
      filter.orderNo = this.searchFrm.controls.orderNo.value;
    }
    if(this.searchFrm.controls.vendor.value){
      filter.supplierId = this.searchFrm.controls.vendor.value;
    }
    if(this.searchFrm.controls.itemRefId.value){
      filter.itemRefId = this.searchFrm.controls.itemRefId.value;
    }

    // if (this.searchFrm.controls.orderType.value && this.searchFrm.controls.orderType.value != "ALL" && this.searchFrm.controls.orderType.value != "PO_TO") {
    //   filter.TRANSFER_PURCHASE_TYPE = this.searchFrm.controls.orderType.value;
    // }

    if (this.searchFrm.controls.prNos.value) {
      filter.grvnNo = this.searchFrm.controls.prNos.value;
      // filter.PR_NOS = this.searchFrm.controls.prNos.value.split(',');
    }

    this.setSearchFilterState();
    this.inventoryService.getPurchaseReturnOrderList(filter, this.page).subscribe(res => {
      if (res.statusCode === 'S0000') {
        this.isLoading = false;
        this.page.pageNumber = res.payload['pageNumber'];
        this.page.totalPages = res.payload['totalPages'];
        this.page.totalElements = res.payload['totalElements'];
        this.purchaseReturnOrderList = res.payload.content;
        if (!isPaginated) {
          this.selectedItemSet.next(new Set<string>());
          this.allItemsSelected = false;
        }

      }
    }, error => {
      this.isLoading = false;
    })
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    this.tableOffset = pageInfo.offset;
    window.scrollTo(0, 0);
    this.onSubmitSearch(true);
  }
  get TemplateFucType() {
    return TemplateFucType;
  }

  getStatus(requestStatus: any) {
    let status = requestStatus.replace(/_/g, ' ');
    return status === 'PARTIAL RECEIVED' ? 'PARTIALLY RECEIVED' : status;
  }
  getClinics() {
    this.storeStatusQuery
      .select()
      .subscribe((val) => {
        this.clinics = this.clinicQuery.getAll();
      });
  }
  getAllItem() {
    this.itemService.listAllItems('',true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.itemList = res.payload.map((item) => item.item);
        }
      }
    );
  }
  getSupplierList() {
    this.supplierService.listAllSuppliers().subscribe((res => {
      if (res && res.statusCode == "S0000") {
        this.supplierList = res.payload;
      }
    }))
  }

  private initData() {
    this.getClinics();
    this.getAllItem();
    this.getSupplierList();
    this.initForm(this.previousFilter);
    this.getFilterState();


    this.statusOptions = filterOptionsJson.OrderReturnRequestStatus.sort((a, b) => a.name.localeCompare(b.name));
    this.orderTypeOptions = filterOptionsJson.OrderType.sort((a, b) => a.name.localeCompare(b.name));

    this.getOrderList();

    this.itemService.listAllItems('',true).subscribe(res => {
      if (res && res.statusCode === "S0000") {
        this.itemLists.next(res.payload.map(item => item.item))
      }
    })

  }

  viewOrder(order: any) {
    this.router.navigate([`pages/inventory/return-order/view/${order.id}`])
  }

  getOrderList() {
    this.onSubmitSearch();
  }

  edit(row: any) {
    this.router.navigate([`pages/inventory/return-order/edit/${row.id}`])
  }

  onActionChange($event: unknown, row: any) {
    if ($event === 'Edit') {
      this.edit(row.data);
    }
    if ($event === 'View') {
      this.viewOrder(row.data);
    }
  }

  onSelectAll($event) {
    if ($event.target.checked) {
      this.allItemsSelected = true;
      this.selectedItemSet.next(
        new Set<string>(this.purchaseReturnOrderList.filter(r=> !this.isCheckboxDisabled(r)).map((item) => item.data.id)));
    } else {
      this.allItemsSelected = false;
      this.selectedItemSet.next(new Set<string>())
    }
  }

  onItemCheckBoxChange(row: any) {
    this.allItemsSelected = false;
    if (this.selectedItemSet.value.has(row.data.id)) {
      this.selectedItemSet.value.delete(row.data.id);
    } else {
      this.selectedItemSet.value.add(row.data.id);
    }
    this.selectedItemSet.next(this.selectedItemSet.value);
  }

  rejectSelected() {
    let items = [];
    this.selectedItemSet.value.forEach(res => {
      items.push(this.purchaseReturnOrderList.find(r => r.data.id == res))
    });

    let orderIds = [];

    let rejectSelectedPo=(()=>{
      if (items.length > 0) {
        items = items.map(item => orderIds.push(item.data.id))
      }
      this.apiInventoryService.rejectPurchaseReturnOrder(orderIds).subscribe((res: any) => {
          if (res.statusCode == "S0000") {
            this.onSubmitSearch(false, Date.now());
            this.alert.success('Purchase return orders has been rejected successfully')
            this.selectedItemSet.next(new Set<string>());
            this.allItemsSelected = false;
          }
        },
        error => {
          this.alert.error(JSON.stringify(error));
        })
    }).bind(this)

    rejectSelectedPo()

  }

  saveSelected() {
    let items = [];
    this.selectedItemSet.value.forEach(res => {
      items.push(this.purchaseReturnOrderList.find(r => r.data.id == res))
    });

    let orderIds = [];

    let saveSelectedPo=(()=>{
      if (items.length > 0) {
        items = items.map(item => orderIds.push(item.data.id))
      }
      this.apiInventoryService.issuePurchaseReturnOrder(orderIds).subscribe((res: any) => {
          if (res.statusCode == "S0000") {
            this.onSubmitSearch(false, Date.now());
            this.alert.success('Purchase return orders has been approved successfully')
            this.selectedItemSet.next(new Set<string>());
            this.allItemsSelected = false;
          }
        },
        error => {
          this.alert.error(JSON.stringify(error));
        })
    }).bind(this)

    saveSelectedPo()

  }

  setSearchFilterState() {
    this.inventoryService.setPageFilterState({ pageIndex: InventoryTab.PURCHASE_RETURN_APPROVAL, searchForm: this.searchFrm.getRawValue() });
  }

  initForm(previousFilter: any) {
    this.searchFrm = this.fb.group({
      fromDate: [moment().subtract(7, 'days').toDate()],
      endDate: [moment().toDate()],
      orderStatus: ['ALL'],
      orderType: ['PO_TO'],
      clinicId: [],
      vendor: [],
      itemRefId: [],
      orderNo: [],
      prNos: []
    });
    if (previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
    this.itemList = this.chargeItemQuery.getDrugItems();
  }

  getFilterState() {
    this.inventoryService.getPageFilterState().subscribe(res => {
      if (res && res.length > 0) {
        let find = res.find(frm => frm.pageIndex == InventoryTab.PURCHASE_RETURN_APPROVAL);
        if (find) {
          this.previousFilter = find.searchFrm;
          this.initForm(find.searchForm);

        }
      }
    })
  }

  clinicCode(requestClinicId?: string) {
    if (!requestClinicId) {
      return '';
    }
    const clinic = this.clinics.find((clinic) => clinic.id === requestClinicId);
    return clinic ? clinic.clinicCode : '';
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  getSupplierName(itemId: any) {
    if(this.supplierList && this.supplierList.length > 0) {
      let item = this.supplierList.find(item => item.id === itemId);
      return item ? item.name : ''
    }
  }

  isCheckboxDisabled(row: any) {
    // if (!row || !row.data || row.data.returnStatus === 'REJECTED' || row.data.returnStatus === 'APPROVED') {
    if (!row || !row.data || row.data.returnStatus !== 'CONFIRM') {
      return true;
    }
  }
}
