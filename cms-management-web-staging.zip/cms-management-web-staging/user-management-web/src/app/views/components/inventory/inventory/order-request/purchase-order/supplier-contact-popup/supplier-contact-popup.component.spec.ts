import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplierContactPopupComponent } from './supplier-contact-popup.component';

describe('SupplierContactPopupComponent', () => {
  let component: SupplierContactPopupComponent;
  let fixture: ComponentFixture<SupplierContactPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplierContactPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplierContactPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
