import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-below-minimum-purchase-amount-confirmation-popup',
  templateUrl: './min-purchase-confirm-popup.component.html',
  styleUrls: ['./min-purchase-confirm-popup.component.scss']
})
export class MinPurchaseConfirmPopupComponent implements OnInit {

  @Input() onConfirm: () => void
  @Input() onClose: () => void
  @Input() message: string
  constructor() { }

  ngOnInit() {
  }

}
