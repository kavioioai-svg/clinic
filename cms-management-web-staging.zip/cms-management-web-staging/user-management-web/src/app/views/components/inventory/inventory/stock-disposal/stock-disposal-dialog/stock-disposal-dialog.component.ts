import { Component, OnInit } from '@angular/core';
import { StockItem } from '../../../../../../objects/StockItem';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { InventoryService } from '../../../../../../services/inventory.service';
import { AlertService } from '../../../../../../services/alert.service';
import { StoreService } from '../../../../../../services/store.service';
import { ChargeItemQuery } from '../../../../../../state/charge-item/charge-item.query';
import { DISPLAY_DATE_FORMAT } from '../../../../../../constants/app.constants';
import DatePickerConfig from '../../../../../../objects/DatePickerConfig';
import { StockTakeApproveStatus } from '../../../../../../objects/StockTakeApproveStatus';
import { Page } from '../../../../../../model/page';
import { TemplateFucType } from '../../../../../../model/enum/enums';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap';
import * as moment from 'moment';
import { stockDisposalApproveRejection } from '../../../../../../objects/stockDisposalApproveRejection';

@Component({
  selector: 'app-stock-disposal-dialog',
  templateUrl: './stock-disposal-dialog.component.html',
  styleUrls: ['./stock-disposal-dialog.component.scss']
})
export class StockDisposalDialogComponent implements OnInit {

  stockDisposalItem: any;
  chargeItems: any;
  action: string;
  formGroup: FormGroup;
  isSubmitting: boolean;
  isBtnLoading: boolean;

  expiryDateDatePickerConfig: DatePickerConfig = new DatePickerConfig(
    '',
    null,
    moment().toDate(),
    'bottom',
    'right'
  );

  pendingDisposalList: any[] = [];
  page: Page = new Page();

  constructor(
    public bsModalRef: BsModalRef,
    private inventory: InventoryService,
    private store: StoreService,
    private fb: FormBuilder,
    private alert: AlertService,
    private modalService: BsModalService,
    private inventoryService: InventoryService,
  ) {
    this.page.pageNumber = 0;
    this.page.size = 6;
    this.isSubmitting = false;
  }

  async ngOnInit() {
    this.initForm();
    
    this.pendingDisposalList = [this.stockDisposalItem];
  
  }

  setPage(pageInfo) {
    if (this.page.pageNumber !== pageInfo.offset && pageInfo.offset > this.page.pageNumber) {
      this.page.pageNumber = pageInfo.offset;
    }
  }

  onScroll(event: any) {
    if (event.srcElement.type === 'number') {
      event.preventDefault();
    }
  }

  get StockTakeApproveStatus() {
    return StockTakeApproveStatus;
  }

  editDetails() {
    this.isBtnLoading = true;
    this.bsModalRef.hide();
    let obj = new stockDisposalApproveRejection(this.formGroup.value, this.stockDisposalItem);
    this.inventory.stockDisposalApproveRejection(
      obj,
    ).subscribe(res => {
        this.isBtnLoading = false;
        this.modalService.setDismissReason(res);
        this.bsModalRef.hide();
      }, error => {
        this.isBtnLoading = false;
        if (error.error && error.error.message) {
          this.alert.error(error.error.message);
        } else {
          this.alert.error(JSON.stringify(error) || "Request failed");
        }
      })
  }

  closeModal() {
    this.bsModalRef.hide();
  }

  initForm() {
    this.formGroup = this.fb.group({
      cpRemark: [null],
    });

    this.formGroup.patchValue(this.stockDisposalItem);
  }

  getBtnLabel() {
    return this.action === 'view' ? 'View' : 'Submit';
  }

  get TemplateFucType() {
    return TemplateFucType;
  }
}