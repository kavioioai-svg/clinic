import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../../services/auth.service';
import { AlertService } from '../../../../services/alert.service';
import { Alert } from 'selenium-webdriver';
import { get } from 'lodash';
import { StringValidators } from '../../../../validators/string.validators';

const getStr = (obj, ltr) => get(obj, ltr) || '';

const passwordValidators = [
  Validators.required,
  Validators.minLength(12),
  StringValidators.noSpace,
  StringValidators.containsCapital,
  StringValidators.containsSimple,
  StringValidators.containsNumber,
  StringValidators.containsSpecialCharacters,
];

@Component({
  selector: 'app-profile-change-password',
  templateUrl: './profile-change-password.component.html',
  styleUrls: ['./profile-change-password.component.scss']
})
export class ProfileChangePasswordComponent implements OnInit {
  formGroup: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private alertService: AlertService,
    private router: Router
  ) {}

  get password() {
    return this.formGroup.get("password");
  }

  get newPassword() {
    return this.formGroup.get("newPassword");
  }

  get confirmPassword() {
    return this.formGroup.get("confirmNewPassword");
  }

  ngOnInit() {
    this.formGroup = this.fb.group(
      {
        password: new FormControl('', Validators.required),
        newPassword: new FormControl('', passwordValidators),
        confirmNewPassword: new FormControl('', passwordValidators),
      }
    );
  }

  onBtnChangeClicked() {
    const { password, newPassword, confirmNewPassword } = this.formGroup.value;

    this.authService.changePassword(password, newPassword).subscribe(
      res => {
        alert('Password changed successfully.');
        this.authService.logout();
        this.router.navigate(['/pages/login']);
      },
      err => {
        this.alertService.error(getStr(err, 'error.message') || JSON.stringify(err))
      }
    );
  }
}
