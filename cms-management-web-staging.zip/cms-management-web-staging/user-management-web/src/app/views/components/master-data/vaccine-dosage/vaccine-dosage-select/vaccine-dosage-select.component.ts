import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Observable, Subject} from "rxjs";
import {BsModalService} from "ngx-bootstrap";
import {map} from "rxjs/operators";
import {ControlContainer, FormControl, FormGroup} from '@angular/forms';
import {NgxPermissionsService} from "ngx-permissions";
import { VaccineDosageService } from '../../../../../services/master-data-service/vaccine-dosage.service';
import { VaccineDosageFormComponent } from '../vaccine-dosage-form/vaccine-dosage-form.component';

@Component({
  selector: 'app-vaccine-dosage-select',
  templateUrl: './vaccine-dosage-select.component.html',
  styleUrls: ['./vaccine-dosage-select.component.scss']
})
export class VaccineDosageSelectComponent implements OnInit ,OnChanges{

  list:[] = [];
  @Input() placeholder: string;

  form: FormGroup
  @Input() value: string | undefined;
  @Output() change = new EventEmitter<string>();
  @Input() control: FormControl | undefined;
  @Input() data: any | undefined;

  constructor(private modalService: BsModalService,
              private vaccineDosageService: VaccineDosageService,
              private controlContainer: ControlContainer,
              private permissionService: NgxPermissionsService
  ) {
  }

  onAdd = (term:string) => {
    this.openPopUp(term)
  }

  ngOnInit() {
    this.form = <FormGroup>this.controlContainer.control;
    this.refreshList();
    this.value = this.control.value;
  }

  ngOnChanges(changes: SimpleChanges) {
  }

  private refreshList() {
    this.vaccineDosageService.listAll({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).subscribe(res => {
       if(res) {
         this.list = res.payload.map(a => ({
           ...a,
           label: `${a.code} ${a.description}`
         }));
       }
    })
  }

  modelChangeFn($event: any) {
    this.change.emit($event);
  }

  openPopUp(term) {
    const stockModel = this.modalService.show(VaccineDosageFormComponent, {
      initialState: {
        action: 'create',
        id: undefined,
        isFromModal: true,
        initState: term,
        onSelect: ((data: string) => {
          this.value = data
          this.refreshList()
          stockModel.hide()
        }).bind(this)
      },
      class: 'modal-lg item-master-select-popup',
    });
  }

  creatable() {
    return !!this.permissionService.getPermission("ROLE_UPDATE_VACCINE_DOSAGE");
  }

  SearchFn(term: string, option) {
    term = term.toLocaleLowerCase();
    const hasWhiteSpace = term.indexOf(' ') > -1 ? true : false;

    // If string is less than 4 characters and does not contain space,
    // search only through code
    if (!hasWhiteSpace) {
      if (term.length < 4) {
        return option.code.toLocaleLowerCase().indexOf(term) > -1;
      }
    }

    term = term.trim();
    if(option.description && option.code) {
      return (
        option.description.toLocaleLowerCase().indexOf(term) > -1 ||
        option.code.toLocaleLowerCase().indexOf(term) > -1
      );
    }
  }

}
