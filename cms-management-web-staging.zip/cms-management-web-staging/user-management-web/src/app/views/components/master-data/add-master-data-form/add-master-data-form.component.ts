import {Component, OnInit, ViewChild} from '@angular/core';
import {BsModalService, ModalDirective} from 'ngx-bootstrap';

@Component({
  selector: 'app-add-master-data-form',
  templateUrl: './add-master-data-form.component.html',
  styleUrls: ['./add-master-data-form.component.scss']
})
export class AddMasterDataFormComponent implements OnInit {
  @ViewChild('childModal',{static: false}) public childModal:ModalDirective;

  constructor(private modalService: BsModalService,) { }

  ngOnInit() {
  }

  closeModel() {
    this.childModal.hide();

  }
}
