import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MasterDataComponent} from './master-data.component';
import {SharedModule} from '../../../shared.module';
import {MasterDataRoutingModule} from './master-data-routing.module';
import {AddMasterDataFormComponent} from './add-master-data-form/add-master-data-form.component';
import {UomMatrixComponent} from './uom-matrix/uom-matrix.component';
import {UomComponent} from './uom/uom.component';
import {AllergyGroupComponent} from './alergy-group/allergy-group.component';
import {InstructionsComponent} from './instructions/instructions.component';
import {DosageInstructionsComponent} from './dosage-instructions/dosage-instructions.component';
import {UomFormComponent} from "./uom/uom-form/uom-form.component";
import {UomMatrixFormComponent} from "./uom-matrix/uom-matrix-form/uom-matrix-form.component";
import {AllergyGroupFormComponent} from "./alergy-group/alergy-group-form/allergy-group-form.component";
import {InstructionsFormComponent} from "./instructions/instructions-form/instructions-form.component";
import {
  DosageInstructionsFormComponent
} from "./dosage-instructions/dosage-instructions-form/dosage-instructions-form.component";
import {InstructionsSelectComponent} from "./instructions/instructions-select/instructions-select.component";
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {InstructionsPageComponent} from "./instructions/instructions-page/instructions-page.component";
import {
  DosageInstructionsPageComponent
} from "./dosage-instructions/dosage-instructions-page/dosage-instructions-page.component";
import {
  DosageInstructionsSelectComponent
} from "./dosage-instructions/dosage-instructions-select/dosage-instructions-select.component";
import {AllergyGroup} from "../../../objects/AllergyGroup";
import {AlergyGroupPageComponent} from "./alergy-group/alergy-group-page/alergy-group-page.component";
import {AlergyGroupSelectComponent} from "./alergy-group/alergy-group-select/alergy-group-select.component";
import {UomMatrixPageComponent} from "./uom-matrix/uom-matrix-page/uom-matrix-page.component";
import {UomMatrixSelectComponent} from "./uom-matrix/uom-matrix-select/uom-matrix-select.component";
import {UomPageComponent} from "./uom/uom-page/uom-page.component";
import {UomSelectComponent} from "./uom/uom-select/uom-select.component";
import {CautionariesComponent} from "./cautionaries/cautionaries.component";
import {CautionariesSelectComponent} from "./cautionaries/cautionaries-select/cautionaries-select.component";
import {CautionariesPageComponent} from "./cautionaries/cautionaries-page/cautionaries-page.component";
import {CautionariesFormComponent} from "./cautionaries/cautionaries-form/cautionaries-form.component";
import {CategoriesComponent} from "./categories/categories.component";
import {CategoriesSelectComponent} from "./categories/categories-select/categories-select.component";
import {CategoriesFormComponent} from "./categories/categories-form/categories-form.component";
import {CategoriesPageComponent} from "./categories/categories-page/categories-page.component";
import { RouteOfAdministrationComponent } from './route-of-administration/route-of-administration.component';
import { RouteOfAdminFormComponent } from './route-of-administration/route-of-admin-form/route-of-admin-form.component';
import { VaccineDosageComponent } from './vaccine-dosage/vaccine-dosage.component';
import { VaccineDosageFormComponent } from './vaccine-dosage/vaccine-dosage-form/vaccine-dosage-form.component';
import { VaccineDosagePageComponent } from './vaccine-dosage/vaccine-dosage-page/vaccine-dosage-page.component';
import { VaccineDosageSelectComponent } from './vaccine-dosage/vaccine-dosage-select/vaccine-dosage-select.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    MasterDataRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [MasterDataComponent,
    AddMasterDataFormComponent,
    UomComponent,
    UomFormComponent,
    UomPageComponent,
    UomSelectComponent,
    UomMatrixComponent,
    UomMatrixFormComponent,
    UomMatrixPageComponent,
    UomMatrixSelectComponent,
    AllergyGroupFormComponent,
    AllergyGroupComponent,
    AllergyGroupFormComponent,
    AlergyGroupPageComponent,
    AlergyGroupSelectComponent,
    InstructionsComponent,
    InstructionsFormComponent,
    InstructionsSelectComponent,
    InstructionsPageComponent,
    CautionariesComponent,
    CautionariesFormComponent,
    CautionariesSelectComponent,
    CautionariesPageComponent,
    CategoriesComponent,
    CategoriesFormComponent,
    CategoriesSelectComponent,
    CategoriesPageComponent,
    DosageInstructionsComponent,
    DosageInstructionsFormComponent,
    DosageInstructionsPageComponent,
    DosageInstructionsSelectComponent,
    RouteOfAdministrationComponent,
    RouteOfAdminFormComponent,
    VaccineDosageComponent,
    VaccineDosageFormComponent,
    VaccineDosagePageComponent,
    VaccineDosageSelectComponent,
    ] ,
  exports: [
    InstructionsSelectComponent,
    DosageInstructionsSelectComponent,
    AlergyGroupSelectComponent,
    UomMatrixSelectComponent,
    UomSelectComponent,
    CautionariesSelectComponent,
    CautionariesComponent,
    CategoriesSelectComponent,
    VaccineDosageSelectComponent,
  ],
  entryComponents: [
    AddMasterDataFormComponent,
    InstructionsFormComponent,
    DosageInstructionsFormComponent,
    UomFormComponent,
    CategoriesFormComponent,
    CautionariesFormComponent,
    UomMatrixFormComponent,
    VaccineDosageFormComponent,
  ]


})
export class MasterDataModule { }
