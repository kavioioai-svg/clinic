import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {ActivatedRoute, Router} from "@angular/router";
import {AlertService} from "../../../../../services/alert.service";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {DosageInstructionsService} from "../../../../../services/master-data-service/dosage-instructions.service";
import {DosageInstruction} from '../../../../../objects/DosageInstruction';
import {MasterDataTab} from '../../../../../model/enum/enums';
import {BsModalRef} from "ngx-bootstrap/modal";

type InternalInst = DosageInstruction & {
  'i18nDescription': [{key:string, value: number}]
}


@Component({
  selector: 'app-dosage-instructions-form',
  templateUrl: './dosage-instructions-form.component.html',
  styleUrls: ['./dosage-instructions-form.component.scss']
})
export class DosageInstructionsFormComponent implements OnInit {
  form: FormGroup;
   @Input() action: string;
   @Input() id: string | undefined;
  isReadOnly: boolean;
  isEdit: boolean;
  initState: string;
  isFromModal: boolean;
  backBtnText =  '< Back to Dosage Instructions';
  backUrl =  `pages/master-data/all/${MasterDataTab.DOS_INSTRUCTION}`;
  onSelect?: (id: string) => void

  constructor(private instructionService: DosageInstructionsService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              public bsModalRef: BsModalRef,
  ) { }

  ngOnInit() {
    this.form = this.instructionService.getInstructionForm(this.initState);
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.form.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.form.enable();
          this.isEdit = true;
          this.populateData();
          break;
      }
    });
  }

  private populateData() {
    this.instructionService.getInstructionByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      code: payload.code,
      description: payload.description,
      status: payload.status,
      instruct: payload.instruct,
      externalCode: payload.externalCode ? payload.externalCode : '',
      externalDescription: payload.externalDescription ? payload.externalDescription : '',
    });

    (this.form.get('i18nDescription') as FormArray).clear();
    // @ts-ignore
    Object.entries(payload.i18nDescription).forEach(([key, value], index) => {
      const i18Form = this.instructionService.geti18FormGroup();
      i18Form.patchValue({key:key, value:value});
      (this.form.get('i18nDescription') as FormArray).push(i18Form);
    });
  }

  getStatusTypeList() {
    return this.masterDataService.statuses;
  }

  get geti18DescriptionField(): FormArray {
    return this.form.get('i18nDescription') as FormArray;
  }

  addMorei18Field() {
    this.geti18DescriptionField.push(this.instructionService.geti18FormGroup());
  }

  deleteGroupItem(i: number) {
    this.geti18DescriptionField.removeAt(i);
  }

  private static convertToNetworkData(data: InternalInst | any): Instruction {
    return {
      ...data,
      // @ts-ignore
      i18nDescription: Object.fromEntries(data.i18nDescription.map(({key, value}) => ([key, value])))
    }
  }


  onSaveUpdateData() {
    const data = <Instruction>this.form.getRawValue();
    if (this.action === "edit") {
      this.instructionService.update(DosageInstructionsFormComponent.convertToNetworkData(data), this.id).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.code)
              this.alertService.success("Instruction updated successfully");
            }
          });

        }
      })
    } else {
      this.instructionService.create(DosageInstructionsFormComponent.convertToNetworkData(data)).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.onSelect && this.onSelect(data.code)
              this.alertService.success("Instruction created successfully");
              this.instructionService.getInstructionForm();
            }
          });
        }
      }, error => {
        if (error.error){
          this.alertService.error(`Instruction creation failed ${error.error.message}`);
        } else{
          this.alertService.error(`Instruction creation failed ${error.message}`);
        }

      })
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');

  }

  goToEdit() {
    this.router.navigate([`/pages/master-data/dosage-instructions/edit/${this.form.get('code').value}/${MasterDataTab.DOS_INSTRUCTION}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  closeModal() {
    this.bsModalRef.hide();
  }

}
