import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from "../../../../model/page";
import {ActivatedRoute, Router} from "@angular/router";
import {DosageInstructionsService} from "../../../../services/master-data-service/dosage-instructions.service";
import {FormBuilder, FormGroup} from '@angular/forms';
import {AlertService} from '../../../../services/alert.service';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import { VaccineDosage } from '../../../../objects/VaccineDosage';
import { VaccineDosageSelectComponent } from './vaccine-dosage-select/vaccine-dosage-select.component';
import { MasterDataTab, TemplateFucType } from '../../../../model/enum/enums';
import { VaccineDosageService } from '../../../../services/master-data-service/vaccine-dosage.service';
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-vaccine-dosage',
  templateUrl: './vaccine-dosage.component.html',
  styleUrls: ['./vaccine-dosage.component.scss'],
})
export class VaccineDosageComponent implements OnInit , AfterContentChecked {
  list: VaccineDosage[] = [];
  page: Page = new Page();
  itemStatusOptions = [];
  isLoading: boolean;
  isFilter: boolean;
  searchFrm: FormGroup;
  ngSelectValue = [];
  previousFilter: FormGroup;
  filterOptions = [];
  sorts: any;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;

  actionButtonList = [
    {
      action:'Edit',
      label:'Edit'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'BLOCKED',
      label:'Set to Blocked'
    },
  ];
  private isActiveTab: boolean;

  constructor(private router: Router,
              private vaccineDosageService: VaccineDosageService ,
              private fb: FormBuilder,
              private cdr: ChangeDetectorRef,
              private inventoryService: InventoryService,
              private masterDataService: MasterDataService,
              private activatedRoute: ActivatedRoute,
              private alertService: AlertService) { }

  ngOnInit() {
    this.page.size = 30
    this.page.pageNumber = 0
    this.populateSearchForm(this.previousFilter);


    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.VACCINE_DOSAGE);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex == MasterDataTab.VACCINE_DOSAGE;
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
    this.router.navigate([`/pages/master-data/vaccine-dosage/create/${MasterDataTab.VACCINE_DOSAGE}`]);
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getMasterData();
    }

  }

  onActionChange($event: unknown, row: any) {
    switch ($event) {
      case 'view':
      case 'Edit':
        this.router.navigate([`/pages/master-data/vaccine-dosage/${$event.toLocaleLowerCase()}/${row.code}/${MasterDataTab.VACCINE_DOSAGE}`]);
        break;
      case 'ACTIVE':
      case 'INACTIVE':
      case 'BLOCKED':
        this.changeStatus(row ,$event );
        break;
    }
  }

  private getMasterData() {
    this.vaccineDosageService.searchItem(this.searchFrm.value , this.page, {
      sortBy: this.sorts ? this.sorts[0].prop: undefined,
      direction: this.sorts ? this.sorts[0].dir.toUpperCase() : undefined
    }).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.list = res.payload;
      }
    })
  }
  changeStatus(row ,status ) {
    this.vaccineDosageService.update({
      ...row,
      status: status
    }, status).subscribe(res => {
      this.onSearch()
      // if(res.message === "Success") {
      //   this.ngSelectValue = [];
      //   let index = this.list.findIndex(x => x.code === res.payload.code);
      //   this.list[index] = res.payload;
      //   this.list =[...this.list];
      // }
    })
  }

  populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      code:  [],
      name: [],
      description:  [],
      status: ['ALL'],
    });

    this.searchFrm.valueChanges.subscribe(() => {
      this.page.pageNumber = 0
    })

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }

    this.filterOptions  = filterOptionsJson.searchFilterVaccineDosage;
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch(type?: any) {
    if (this.isActiveTab) {
      this.isLoading = true;
      this.isFilter = true;
      let filter: any = {};

      const {status, code, name, description} = this.searchFrm.value;
      
      filter.status = status;
      filter.code = code;
      filter.name = name;
      filter.description = description;
      
      if (status && status === 'ALL') {
        filter.status = null;
      }
      
      if (!type) {
        this.masterDataService.setSearchFilterState(MasterDataTab.VACCINE_DOSAGE, filter);
      }

      let apiSearchFilter = {...filter};

      this.vaccineDosageService.searchItem(apiSearchFilter, this.page, {
        sortBy: this.sorts ? this.sorts[0].prop: undefined,
        direction: this.sorts ? this.sorts[0].dir.toUpperCase() : undefined
      }).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.list = res.payload;
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
    }
  }
  get TemplateFucType() {
    return TemplateFucType
  }

  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.code.value || this.searchFrm.controls.name.value ||this.searchFrm.controls.description.value ||
      (this.searchFrm.controls.status.value !== 'ALL')
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  sort($event: any) {

    this.page.size = 30;
    this.page.pageNumber = 0;

    this.isFilter = true;
    this.sorts = $event.sorts;
    this.searchFrm.patchValue({
      sort: $event.sorts[0]
    })
    this.onSearch();
  }
}
