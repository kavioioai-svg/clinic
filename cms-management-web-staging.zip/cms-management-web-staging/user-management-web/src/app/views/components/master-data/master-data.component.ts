import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {AllergyGroup} from '../../../objects/AllergyGroup';
import {Page} from '../../../model/page';
import {ActivatedRoute, Router} from '@angular/router';
import {BsModalService} from 'ngx-bootstrap';
import {AddMasterDataFormComponent} from './add-master-data-form/add-master-data-form.component';
import {MasterDataTab} from '../../../model/enum/enums';
import {MasterDataService} from '../../../services/master-data-service/master-data.service';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-master-data',
  templateUrl: './master-data.component.html',
  styleUrls: ['./master-data.component.scss']
})
export class MasterDataComponent implements OnInit {
  listAllergyGroupData: AllergyGroup[] =[];
  page: Page = new Page();
  isLoading: boolean = false;
  actionIndex: string ;

  allergyGroupColumn = [
    {name: 'Group Code' , props: 'groupCode'},
    {name: 'Description' , props: 'description'},
    {name: 'Drugs' , props: 'drugIds'},
    {name: 'Status' , props: 'status'},
    {name: 'action' , props: ''},
  ]


  constructor(private activatedRoute: ActivatedRoute,
              private modalService: BsModalService,
              private masterDataService: MasterDataService,
              private router: Router,
              private permissionsService: NgxPermissionsService,
  ) {
    this.page.size = 50;
    this.page.pageNumber = 0;
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.actionIndex = params['tabIndex'];
      this.onInitialLoad();
    });

  }

  onInitialLoad() {
    if(this.actionIndex !== "-"){
      return
    }
    let permissions = [
      ['ROLE_ALLERGY_MANAGEMENT'],
      ['ROLE_VIEW_UOM_MATRIX'],
      ['ROLE_VIEW_UOM_MATRIX'],
      ['ROLE_VIEW_INSTRUCTION'],
      ['ROLE_VIEW_DOSAGE_INSTRUCTIONS'],
      ['ROLE_VIEW_CAUTIONARY'],
      ['ROLE_VIEW_CATEGORY'],
      ['ROLE_VIEW_CATEGORY']
    ]

    for (let i = 0; i < permissions.length; i++) {
      let a = permissions[i]
      for(let b in a){
        if(this.permissionsService.getPermission(a[b])){
          this.router.navigate([`pages/master-data/all/${i}`]);
          return true;

        }
      }
    }
  }


  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.getMasterData();
  }

  private getMasterData() {

  }

  addNewItem() {

    let initialState = {

    };
    const stockModel = this.modalService.show(AddMasterDataFormComponent, {
      initialState,
      class: 'modal-lg item-master-select-popup',
    });

    this.modalService.onHide.subscribe((e) => {
      if(e && e.message) {
      }
    });

  }

  get masterDataTab() {
    return MasterDataTab
  }


  onTabSelected(tab: MasterDataTab) {
    this.masterDataService.isOnTabChange(true);
    this.router.navigate([`pages/master-data/all/${tab}`]);
  }



}
