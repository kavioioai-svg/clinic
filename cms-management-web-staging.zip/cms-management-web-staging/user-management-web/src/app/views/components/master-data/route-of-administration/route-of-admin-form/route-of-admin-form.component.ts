import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {MasterDataTab} from '../../../../../model/enum/enums';
import {InstructionsService} from '../../../../../services/master-data-service/instructions.service';
import {AlertService} from '../../../../../services/alert.service';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {ActivatedRoute, Router} from '@angular/router';
import {RouteOfAdminService} from '../../../../../services/master-data-service/route-of-admin.service';
import {RouteOfAdministration} from "../../../../../objects/route-of-administration";

type InternalInst = RouteOfAdministration & {
  'i18nDescription': [{key:string, value: number}]
}

@Component({
  selector: 'app-route-of-admin-form',
  templateUrl: './route-of-admin-form.component.html',
  styleUrls: ['./route-of-admin-form.component.scss']
})
export class RouteOfAdminFormComponent implements OnInit {

  form: FormGroup;
  @Input() action: string;
  @Input() name?: string;
  initState?: any
  isReadOnly: boolean;
  isEdit: boolean;
  isFromModal: boolean;
  backBtnText =  '< Back to Route Of Admin';
  backUrl =  `pages/master-data/all/${MasterDataTab.ROUTE_OF_ADMIN}`;
  onSelect?: (id: string) => void

  constructor(private routeOfAdminService: RouteOfAdminService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.form = this.routeOfAdminService.getRouteOfAdminServiceForm(this.initState);
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
      this.name = params['id'];
      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.form.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.form.enable();
          this.isEdit = true;
          this.populateData();
          break;
      }
    });
  }

  private populateData() {

    this.routeOfAdminService.getRouteOfAdminByCode(this.name).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      name: payload.name,
      nehrCodeDispensedMed: payload.nehrCodeDispensedMed,
      nehrCodeVaccine: payload.nehrCodeVaccine,
      bodySiteRequired: payload.bodySiteRequired
    });

  }


  onSaveUpdateData() {
    const data = this.form.getRawValue();
    if (this.action === "edit") {
      this.routeOfAdminService.update(data , this.name).subscribe(item => {
        if (item && item.message === "Success") {
          this.populateResult(item.payload);
          this.onSelect && this.onSelect(data.name);
          this.alertService.success("Route of Administration updated successfully");
        }
      })

    } else {
      this.routeOfAdminService.create(data).subscribe(item => {
        if (item && item.message === "Success") {
          this.routeOfAdminService.getRouteOfAdminByCode(data.name).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.name);
              this.alertService.success("Route of Administration created successfully");
            }
          });
        }
      }, error => {
        if (error.error){
          this.alertService.error(`Route of Administration creation failed ${error.error.message}`);
        } else{
          this.alertService.error(`Route of Administration creation failed ${error.message}`);
        }

      })
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }

  goToEdit() {
    this.router.navigate([`/pages/master-data/route-of-admin/edit/${this.form.get('name').value}/${MasterDataTab.ROUTE_OF_ADMIN}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

}
