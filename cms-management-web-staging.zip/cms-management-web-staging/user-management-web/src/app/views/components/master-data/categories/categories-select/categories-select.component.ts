import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {BsModalService} from "ngx-bootstrap";
import {CategoriesFormComponent} from "../categories-form/categories-form.component";
import {Observable, Subject} from "rxjs";
import {map} from "rxjs/operators";
import {CategoriesService} from "../../../../../services/master-data-service/categories.service";
import {ControlContainer, FormGroup, FormControl} from '@angular/forms';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-categories-select',
  templateUrl: './categories-select.component.html',
  styleUrls: ['./categories-select.component.scss']
})
export class CategoriesSelectComponent implements OnInit , OnChanges{
  list: Observable<any>;
  text: Subject<string> = new Subject<string>()
  placeholder: string;
  formControlName?: string;
  form: FormGroup;

  @Input() value: string | undefined;
  @Input() isResetForm: boolean | undefined;
  @Input() data: any | undefined;
  @Output() change = new EventEmitter<string>();
  @Input() control: FormControl;

  constructor(private modalService: BsModalService,
              private categoriesService: CategoriesService,
              private controlContainer: ControlContainer,
              private permissionService: NgxPermissionsService
  ) {
  }

  onAdd = (term:string) => {
    this.openPopUp(term)
  }

  ngOnInit() {
    this.form = <FormGroup>this.controlContainer.control;
    this.list = this.refreshList();
  }

  private refreshList() {
    return this.text.pipe(source =>
      this.categoriesService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload));
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.isResetForm && this.isResetForm) {
      this.form.reset();
    }
    if (changes.data && changes.data.currentValue ) {
      this.value = this.data.category;
    }
  }

  modelChangeFn($event: any) {
    this.change.emit($event);
  }

  openPopUp(term: string) {

    const stockModel = this.modalService.show(CategoriesFormComponent, {
        initialState: {
          action: 'create',
          id: undefined,
          isFromModal: true,
          initState: {
            category: term
          },
          onSelect: ((id: string) => {
            this.list = this.refreshList();
            this.value = id
            stockModel.hide()
          }).bind(this)
        },
        class: 'modal-lg item-master-select-popup',
      });

  }

  creatable() {
    return !!this.permissionService.getPermission("ROLE_UPDATE_CATEGORY");
  }
}
