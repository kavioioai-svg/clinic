import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MasterDataComponent} from './master-data.component';
import {AllergyGroupFormComponent} from "./alergy-group/alergy-group-form/allergy-group-form.component";
import {InstructionsPageComponent} from "./instructions/instructions-page/instructions-page.component";
import {
  DosageInstructionsPageComponent
} from "./dosage-instructions/dosage-instructions-page/dosage-instructions-page.component";
import {UomComponent} from "./uom/uom.component";
import {CautionariesComponent} from "./cautionaries/cautionaries.component";
import {CautionariesPageComponent} from "./cautionaries/cautionaries-page/cautionaries-page.component";
import {CategoriesPageComponent} from "./categories/categories-page/categories-page.component";
import {UomMatrixPageComponent} from "./uom-matrix/uom-matrix-page/uom-matrix-page.component";
import {MasterDataTab} from '../../../model/enum/enums';
import {RouteOfAdminFormComponent} from './route-of-administration/route-of-admin-form/route-of-admin-form.component';
import { VaccineDosagePageComponent } from './vaccine-dosage/vaccine-dosage-page/vaccine-dosage-page.component';


const routes: Routes = [
  {
    path: '',
    //  canActivateChild: [NgxPermissionsGuard],
    data: {
     // title: 'master-data'
    },
    children: [
      { path: "", pathMatch: "full", redirectTo: `all/-` },
      {
        path: "all/:tabIndex",
        component: MasterDataComponent
      },
      { path: "uom/:action/:tabIndex",
        component: UomComponent,
      },
      { path: "uom/:action/:id/:tabIndex",
        component: UomComponent,
      },
      { path: "uom-matrix/:action/:tabIndex",
        component: UomMatrixPageComponent,
      },
      { path: "allergy-group/:action/:tabIndex",
        component: AllergyGroupFormComponent
      },
      { path: "instructions/:action/:tabIndex",
        component: InstructionsPageComponent
      },
      { path: "instructions/:action/:id/:tabIndex",
        component: InstructionsPageComponent
      },
      { path: "cautionaries/:action/:tabIndex",
        component: CautionariesPageComponent
      },
      { path: "cautionaries/:action/:id/:tabIndex",
        component: CautionariesPageComponent
      },
      { path: "categories/:action/:tabIndex",
        component: CategoriesPageComponent
      },
      { path: "categories/:action/:id/:tabIndex",
        component: CategoriesPageComponent
      },
      { path: "dosage-instructions/:action/:tabIndex",
        component: DosageInstructionsPageComponent
      },
      { path: "dosage-instructions/:action/:id/:tabIndex",
        component: DosageInstructionsPageComponent
      },
      { path: "vaccine-dosage/:action/:tabIndex",
        component: VaccineDosagePageComponent
      },
      { path: "vaccine-dosage/:action/:id/:tabIndex",
        component: VaccineDosagePageComponent
      },
      { path: "route-of-admin/:action/:tabIndex",
        component: RouteOfAdminFormComponent
      },
      { path: "route-of-admin/:action/:id/:tabIndex",
        component: RouteOfAdminFormComponent
      },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterDataRoutingModule { }
