import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from "../../../../model/page";
import {ActivatedRoute, Router} from "@angular/router";
import {CategoriesService} from "../../../../services/master-data-service/categories.service";
import {FormBuilder, FormGroup} from '@angular/forms';
import {AlertService} from '../../../../services/alert.service';
import {Observable, Subject} from 'rxjs';
import {map} from 'rxjs/operators';
import { MasterDataTab } from '../../../../model/enum/enums';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit , AfterContentChecked {
  list: any[] = [];
  page: Page = new Page();
  isLoading: boolean;
  isFilter: boolean;
  searchFrm: FormGroup;
  typeahead: Subject<string> = new Subject<string>();
  categoryList: Observable<any>;
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;
  private isActiveTab: boolean;

  constructor(private router: Router,
              private instructionsService: CategoriesService,
              private fb: FormBuilder,
              private cdr: ChangeDetectorRef,
              private masterDataService: MasterDataService,
              private inventoryService: InventoryService,
              private alertService: AlertService,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.page.size = 50
    this.page.pageNumber = 0
    this.getMasterData();
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.CATEGORIES);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });
    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '6'
      if (this.isActiveTab) {
        this.onSearch();
      }
    })

  }

  addNewItem() {
    this.router.navigate([`/pages/master-data/categories/create/${MasterDataTab.CATEGORIES}`]);
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset
    this.refreshList();

  }

  private getMasterData() {
    this.instructionsService.listAll(this.page).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.list = res.payload;
      }
    })
  }

  deleteItem(code: string) {
    this.instructionsService.deleteItem(code).subscribe(res => {
        if(res && res. statusCode === "S0000") {
          this.alertService.success(`" ${code} " Deleted Successfully`)
          this.refreshList();
        }
      },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      });
  }

  populateSearchForm(previousFilter?: any) {
    this.categoryList = this.getCategoryList();
    this.searchFrm = this.fb.group({
      category:  [undefined],
    });

    this.searchFrm.valueChanges.subscribe(() => {
      this.page.pageNumber = 0
    })

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch() {
    if (this.isActiveTab) {
    this.isLoading = true;
    this.isFilter = true;
    this.masterDataService.setSearchFilterState(MasterDataTab.CATEGORIES, this.searchFrm.value);
    this.instructionsService.searchItem(this.searchFrm.value, this.page).subscribe(res => {
        if (res.message === "Success") {
          this.page.pageNumber = res['pageNumber'];
          this.page.totalPages = res['totalPages'];
          this.page.totalElements = res['totalElements'];
          this.list = res.payload;
          this.isLoading = false;
        }
      },
      (err) => {
        this.isLoading = false;
        this.alertService.error(JSON.stringify(err));
      })
  }
  }

  getCategoryList() {
    return this.typeahead.pipe(source =>
      this.instructionsService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload));
  }

  refreshList() {
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getMasterData();
    }
  }
  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.category.value;
  }
  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };
}
