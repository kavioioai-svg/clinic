import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {BsModalService} from "ngx-bootstrap";
import {CautionariesFormComponent} from "../cautionaries-form/cautionaries-form.component";
import {InstructionsService} from "../../../../../services/master-data-service/instructions.service";
import {Observable, Subject} from "rxjs";
import {
  StockAdjustmentApprovalComponent
} from "../../../inventory/inventory/stock-adjustment/stock-adjustment-approval/stock-adjustment-approval.component";
import {map} from "rxjs/operators";
import {CautionariesService} from "../../../../../services/master-data-service/cautionaries.service";
import {FormControl} from '@angular/forms';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-cautionaries-select',
  templateUrl: './cautionaries-select.component.html',
  styleUrls: ['./cautionaries-select.component.scss']
})
export class CautionariesSelectComponent implements OnInit , OnChanges {
  list: Observable<any>;
  text: Subject<string> = new Subject<string>()
  placeholder: string;
  formControlName?: string;
  listItems: any[] =[];
  @Input()  value: string | undefined;
  @Output() change = new EventEmitter<string>();
  @Input()  control: FormControl | undefined;
  @Input()  data: any | undefined;

  constructor(private modalService: BsModalService,
              private instructionService: CautionariesService,
              private permissionService: NgxPermissionsService
  ) {
  }

  onAdd = (term:string) =>{
    this.openPopUp(term)
  }

  ngOnInit() {
    this.instructionService.listAll({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).subscribe(res => {
      if (res) {this.listItems = res.payload}
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.data && changes.data.currentValue ) {
      this.value = this.data.precautionaryInstructions;
    }
  }

  private refreshList() {
    return this.text.pipe(source =>
      this.instructionService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload));
  }

  modelChangeFn($event: any) {
    this.change.emit($event);
  }

  openPopUp(term: string) {
    const stockModel = this.modalService.show(CautionariesFormComponent, {
      initialState: {
        action: 'create',
        id: undefined,
        isFromModal: true,
        initState: {
          cautionary: term
        },
        onSelect: ((id: string) => {
          this.list = this.refreshList()
          this.value = id
          stockModel.hide()
        }).bind(this)
      },
      class: 'modal-lg item-master-select-popup',
    });
  }

  creatable() {
    return !!this.permissionService.getPermission("ROLE_UPDATE_CAUTIONARY");
  }
}
