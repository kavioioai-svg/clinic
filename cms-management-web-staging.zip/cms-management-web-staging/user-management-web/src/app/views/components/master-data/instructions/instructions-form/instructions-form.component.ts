import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {InstructionsService} from "../../../../../services/master-data-service/instructions.service";
import {AlertService} from "../../../../../services/alert.service";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {UomMatrix} from '../../../../../objects/UomMatrix';
import {MasterDataTab} from '../../../../../model/enum/enums';
import { ActivatedRoute, Router } from '@angular/router';
import {BsModalRef} from "ngx-bootstrap/modal";

type InternalInst = Instruction & {
  'i18nDescription': [{key:string, value: number}]
}

@Component({
  selector: 'app-instructions-form',
  templateUrl: './instructions-form.component.html',
  styleUrls: ['./instructions-form.component.scss']
})
export class InstructionsFormComponent implements OnInit {
  form: FormGroup;
  @Input() action: string;
  @Input() id?: string;
  initState?: any
  isReadOnly: boolean;
  isEdit: boolean;
  isFromModal: boolean;
  backBtnText =  '< Back to Instructions';
  backUrl =  `pages/master-data/all/${MasterDataTab.INSTRUCTION}`;
  onSelect?: (id: string) => void

  constructor(private instructionService: InstructionsService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              public bsModalRef: BsModalRef,
  ) { }

  ngOnInit() {
    this.form = this.instructionService.getInstructionForm(this.initState);
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.form.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.form.enable();
          this.isEdit = true;
          this.populateData();
          break;
      }
    });
  }

  private populateData() {
    this.instructionService.getInstructionByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      code: payload.code,
      description: payload.description,
      status: payload.status,
      externalCode: payload.externalCode ? payload.externalCode : '',
      externalDescription: payload.externalDescription ? payload.externalDescription : '',
      instruct: payload.instruct,
    });

    (this.form.get('i18nDescription') as FormArray).clear();
    // @ts-ignore
    Object.entries(payload.i18nDescription).forEach(([key, value], index) => {
      const i18Form = this.instructionService.geti18FormGroup();
      i18Form.patchValue({key:key, value:value});
      (this.form.get('i18nDescription') as FormArray).push(i18Form);
    });
  }

  getStatusTypeList() {
    return this.masterDataService.statuses;
  }

  get geti18DescriptionField(): FormArray {
    return this.form.get('i18nDescription') as FormArray;
  }

  addMorei18Field() {
    this.geti18DescriptionField.push(this.instructionService.geti18FormGroup());
  }

  deleteGroupItem(i: number) {
    this.geti18DescriptionField.removeAt(i);
  }

  private static convertToNetworkData(data: InternalInst): Instruction {
    return {
      ...data,
      // @ts-ignore
      i18nDescription: Object.fromEntries(data.i18nDescription.map(({key, value}) => ([key, value])))
    }
  }


  onSaveUpdateData() {
    const data = <Instruction>this.form.getRawValue();
    if (this.action === "edit") {
      this.instructionService.update(InstructionsFormComponent.convertToNetworkData(data), this.id).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.code);
              this.alertService.success("Instruction updated successfully");
            }
          });

        }
      })
    } else {
      this.instructionService.create(InstructionsFormComponent.convertToNetworkData(data)).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.onSelect && this.onSelect(data.code);
              this.alertService.success("Instruction created successfully");
              this.form = this.instructionService.getInstructionForm();
            }
          },
            (err) => {
              this.alertService.error(JSON.stringify(err));
            });
        }else if(item.message === "Duplicate record"){
          this.alertService.error("Duplicate Record Found")

        }
      }, error =>  this.alertService.error("Duplicate Record Found"))
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }
  addNewStatus(v) {

  }

  goToEdit() {
    this.router.navigate(['/pages/master-data/instructions/edit/', this.form.get('code').value, MasterDataTab.INSTRUCTION]);
    // this.router.navigate([`/pages/master-data/instructions/edit/${this.form.get('code').value}/${MasterDataTab.INSTRUCTION}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
   }
  closeModal() {
    this.bsModalRef.hide();
  }
}
