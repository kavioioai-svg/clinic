import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from "../../../../model/page";
import {ActivatedRoute, Router} from "@angular/router";
import {UomService} from "../../../../services/master-data-service/uom.service";
import { ItemService } from '../../../../services/item.service';
import { UomMatrixService } from '../../../../services/master-data-service/uom-matrix.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MasterDataService } from '../../../../services/master-data-service/master-data.service';
import { InventoryService } from '../../../../services/inventory.service';
import { AlertService } from '../../../../services/alert.service';
import { UomMatrix } from '../../../../objects/UomMatrix';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { MasterDataTab } from '../../../../model/enum/enums';
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-uom',
  templateUrl: './uom.component.html',
  styleUrls: ['./uom.component.scss']
})
export class UomComponent implements OnInit {
  list: Uom[] = [];
  uomMatrixRatioList: any[] = [];
  uomMatrixList: UomMatrix[] = [];
  page: Page = new Page();
  isLoading: boolean;
  isFilter: boolean;
  itemStatusOptions = [];
  searchFrm: FormGroup;
  ngSelectValue = [];
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;

  private isActiveTab: boolean;

  constructor(private  router: Router,
            private  itemService: ItemService,
            private uomService: UomService,
            private fb: FormBuilder,
            private cdr: ChangeDetectorRef,
            private masterDataService: MasterDataService,
            private inventoryService: InventoryService,
            private alertService: AlertService,
            private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.page.size = 500;
    this.page.pageNumber = 0;
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.UOM);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '1'
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getUomMatrixData();
    }
  }

   getUomMatrixData() {

    // this.uomMatrixService.listAllUomMatrix({
    //   size: 1000,
    //   pageNumber: 0,
    //   limit: 100,
    //   totalElements: 0,
    //   totalPages: 0
    // }).subscribe(res => {
    //    if(res) {
    //      this.uomMatrixList = res.payload;
    //      this.getExchangeRatioCodeList(res.payload);
    //    }
    // })
  }

  private getMasterData() {
    // this.instructionsService.listAll(this.page).subscribe(res => {
    //   if(res && res.payload.length > 0){
    //     this.page.pageNumber = 0//res.payload['pageNumber'];
    //     this.page.totalPages = 100//res.payload['totalPages'];
    //     this.page.totalElements = 100//res.payload['totalElements'];
    //     this.list = res.payload;
    //     this.getExchangeRatioCodeList(res.payload);
    //   }
    // })

    // this.uomMatrixService.itemSearch(filter, this.page).subscribe(res => {
    //   if (res.message === "Success") {
    //     this.page.pageNumber = res['pageNumber'];
    //     this.page.totalPages = res['totalPages'];
    //     this.page.totalElements = res['totalElements'];
    //     this.uomMatrixList = res.payload;
    //   }
    // },
    // (err) => {
    // })
  }

  getExchangeRatioCodeList(data: any) {
    data.forEach(r => {
      // @ts-ignore
      Object.entries(r.exchangeRatio).forEach(([key, value], index) => {
        this.uomMatrixRatioList.push({key:key, value:value});
      });
    });
    if(this.uomMatrixRatioList.length > 0){
      // @ts-ignore
      this.uomMatrixRatioList = Object.values(this.uomMatrixRatioList.reduce((acc,cur)=>Object.assign(acc,{[cur.key]:cur}),{}));

    }
  }

  
  getFilterExchangeRatioCodeList(data: any, filterText: any) {
    data.forEach(r => {
      // @ts-ignore
      Object.entries(r.exchangeRatio).forEach(([key, value], index) => {
        this.uomMatrixRatioList.push({key:key, value:value});
      });
    });
    if(this.uomMatrixRatioList.length > 0){
      // @ts-ignore
      this.uomMatrixRatioList = Object.values(this.uomMatrixRatioList.reduce((acc,cur)=>Object.assign(acc,{[cur.key]:cur}),{}));

      this.uomMatrixRatioList  = this.uomMatrixRatioList.filter(function (el) {
        return el.key.toLowerCase().match(filterText.toLowerCase());
      });
     
    }
  }


  populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      uomCode:  [undefined],
    });

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
  }

  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.uomCode.value
  }

  addNewItem() {
    this.router.navigate([`pages/master-data/uom-matrix/create/${MasterDataTab.MATRIX}`])
  }

  onChangeText(e){
    this.onSearch();
  }

  onSearch() {
    if (this.isActiveTab){
      this.isLoading = true;
      this.isFilter = true;
      let filter: any = {};
      const {uomCode} = this.searchFrm.value;
      filter.uomCode = uomCode;
      this.searchFrm = this.fb.group({
        uomCode:  uomCode,
      });

      this.masterDataService.setSearchFilterState(MasterDataTab.UOM, filter);
        this.uomService.listAllUomMatrix().subscribe(res => {
            if (res.message === "Success") {
              this.page.pageNumber = res['pageNumber'];
              this.page.totalPages = res['totalPages'];
              this.page.totalElements = res['totalElements'];
              this.uomMatrixList = res.payload;
              if(uomCode != null && uomCode !='' && uomCode != undefined) {

                this.getFilterExchangeRatioCodeList(res.payload, uomCode);

              }else{
                this.getExchangeRatioCodeList(res.payload);
              }
              
              this.isLoading = false;
            }
          },
          (err) => {
            this.isLoading = false;
            this.alertService.error(JSON.stringify(err));
          })

      
    
    }
  }
}
