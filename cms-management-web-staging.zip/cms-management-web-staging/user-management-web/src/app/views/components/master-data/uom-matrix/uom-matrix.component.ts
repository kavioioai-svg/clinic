import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import { UomMatrix } from 'app/objects/UomMatrix';
import {ActivatedRoute, Router} from '@angular/router';
import { ItemService } from 'app/services/item.service';
import {Page} from '../../../../model/page';
import {UomMatrixService} from '../../../../services/master-data-service/uom-matrix.service';
import {SyncQueue} from '../../../../objects/SyncQueue';
import {FormGroup, FormBuilder} from '@angular/forms';
import {AlertService} from '../../../../services/alert.service';
import {MasterDataTab, TemplateFucType} from 'app/model/enum/enums';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';
const filterOptionsJson = require('../../../../settings/filter-options.json');


@Component({
  selector: 'app-uom-matrix',
  templateUrl: './uom-matrix.component.html',
  styleUrls: ['./uom-matrix.component.scss']
})
export class UomMatrixComponent implements OnInit , AfterContentChecked{
  uomMatrixList: UomMatrix[] = [];
  page: Page = new Page();
  isLoading: boolean;
  isFilter: boolean;
  itemStatusOptions = [];
  searchFrm: FormGroup;
  ngSelectValue = [];
  previousFilter: FormGroup;
  sorts: any;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;

  actionButtonList = [
    {
      action:'Edit',
      label:'Edit'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'BLOCKED',
      label:'Set to Blocked'
    },
  ];
  private isActiveTab: boolean;

  constructor(  private  router: Router,
                private  itemService: ItemService,
                private uomMatrixService: UomMatrixService,
                private fb: FormBuilder,
                private cdr: ChangeDetectorRef,
                private masterDataService: MasterDataService,
                private inventoryService: InventoryService,
                private alertService: AlertService,
                private activatedRoute: ActivatedRoute){ }

  ngOnInit() {
    this.page.size = 40;
    this.page.pageNumber = 0;
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.MATRIX);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex == MasterDataTab.MATRIX
    //   this.isActiveTab = a.tabIndex === '2'
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
     this.router.navigate([`pages/master-data/uom-matrix/create/${MasterDataTab.MATRIX}`])
  }

  onActionChange($event: any, row: any) {
    switch ($event) {
      case 'view':
      case 'Edit':
        this.itemService.setCurrentDrugItemId(row.id);
        this.router.navigate([`/pages/master-data/uom-matrix/${$event.toLocaleLowerCase()}/${MasterDataTab.MATRIX}`]);
        break;
      case 'ACTIVE':
      case 'INACTIVE':
      case 'BLOCKED':
         this.changeStatus(row.id ,$event);
        break;
    }
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getUomMatrixData();
    }
  }

   getUomMatrixData() {
    this.uomMatrixService.listAllUomMatrix(this.page).subscribe(res => {
       if(res && res.payload.length > 0){
         this.page.pageNumber = res['pageNumber'];
         this.page.totalPages = res['totalPages'];
         this.page.totalElements = res['totalElements'];
         this.uomMatrixList = res.payload;
       }
    })
  }

  // getExchangeRatio(ratio) {
  //   let r = '';
  //   if(ratio){
  //     for (let key in ratio) {
  //       let value = ratio[key];
  //       r = key +' '+value
  //     }
  //   } else {
  //     return ''
  //   }
  //   console.log(1234,r)
  //   return r;
  // }

  getExchangeRatio(ratio) {
    let result = [];
    if (ratio) {
      for (let key in ratio) {
        let value = ratio[key];
        result.push(key + ' ' + value);
      }
    } else {
      return [];
    }
    return result;
  }


  changeStatus(id ,status) {
    this.uomMatrixService.changeStatus(id , status).subscribe(res => {
       if(res.message === "Success") {
         this.ngSelectValue = [];
         let updatedItem = {...res.payload, exchangeRatios: this.getExchangeRatio(res.payload.exchangeRatio)};
         let index = this.uomMatrixList.findIndex(x => x.id === res.payload.id);
         //this.uomMatrixList[index] = res.payload;
         this.uomMatrixList[index] = updatedItem;
         this.uomMatrixList =[...this.uomMatrixList];
       }
    })
  }

  populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      uomCode:  [undefined],
      status: ['ALL'],
    });

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
  }
  onChangeText(e){
    this.onSearch();
  }

  onSearch() {
    if (this.isActiveTab){
      this.isLoading = true;
      this.isFilter = true;
      let filter: any = {};
      const {uomCode, status} = this.searchFrm.value;
      filter.status = status;
      filter.uomCode = uomCode;
      if (status && status === 'ALL') {
        filter.status = null;
      }
      if(this.sorts){
        filter.sort = this.sorts[0];
      }
      this.searchFrm = this.fb.group({
        uomCode:  uomCode,
        status: status || "ALL"
      });
      this.masterDataService.setSearchFilterState(MasterDataTab.MATRIX, filter);
      this.uomMatrixService.itemSearch(filter, this.page).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.uomMatrixList = res.payload;
            this.uomMatrixList.forEach((item) => {
              (item as any).exchangeRatios = this.getExchangeRatio(item.exchangeRatio);
            })
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
    }
  }


  get TemplateFucType() {
    return TemplateFucType
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }
  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.uomCode.value ||
      (this.searchFrm.controls.status.value && this.searchFrm.controls.status.value !== 'ALL')
  }
  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  sort($event: any) {

    this.page.size = 30;
    this.page.pageNumber = 0;

    this.isFilter = true;
    this.sorts = $event.sorts;
    this.searchFrm.patchValue({
      sort: $event.sorts[0]
    })
    this.onSearch();
  }
}
