import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {BsModalService} from "ngx-bootstrap";
import {InstructionsFormComponent} from "../instructions-form/instructions-form.component";
import {InstructionsService} from "../../../../../services/master-data-service/instructions.service";
import {BehaviorSubject, combineLatest, Observable, Subject} from "rxjs";
import {
  StockAdjustmentApprovalComponent
} from "../../../inventory/inventory/stock-adjustment/stock-adjustment-approval/stock-adjustment-approval.component";
import {map, tap} from 'rxjs/operators';
import {ControlContainer, FormControl, FormGroup} from '@angular/forms';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-instructions-select',
  templateUrl: './instructions-select.component.html',
  styleUrls: ['./instructions-select.component.scss']
})
export class InstructionsSelectComponent implements OnInit , OnChanges{
  list: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  placeholder: string;
  formControlName?: string;
  form: FormGroup;
  instructionList: any[];
  valueSubject = new Subject<string>();

  @Input() value: string | undefined;
  @Input() control: FormControl | undefined;
  @Input() data: any | undefined;
  @Output() change = new EventEmitter<any>();

  constructor(private modalService: BsModalService,
              private instructionService: InstructionsService,
              private controlContainer: ControlContainer,
              private permissionService: NgxPermissionsService
              ) {
  }

  onAdd = (term:string) =>{
    console.log(term);
    this.openPopUp(term)
  }

  ngOnInit() {
    this.form = <FormGroup>this.controlContainer.control;
    this.refreshList();
    combineLatest([this.list, this.valueSubject]).subscribe(([list, value]) => {
      if (list && list.length > 0) {
        this.value = value;
        this.change.emit(list.find(r => r.code == value));
      }
    })
  }

  ngOnChanges(changes: SimpleChanges) {

    if (changes.data && changes.data.currentValue ) {
      this.value = this.data.frequencyCode;
      this.valueSubject.next(this.data.frequencyCode)
    }
  }

  private refreshList() {
    this.instructionService.listAll({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).pipe(tap(r => this.instructionList = r.payload)).pipe(map(res => res.payload))
    .subscribe(res => this.list.next(res.filter(item => item.status === 'ACTIVE')));
  }

  modelChangeFn($event: any) {
    if(this.instructionList && this.instructionList.length > 0) {
      this.change.emit(this.instructionList.find(r => r.code ==$event));
    }

  }

   openPopUp(term: string) {
     const stockModel = this.modalService.show(InstructionsFormComponent, {
      initialState: {
        action: 'create',
        id: undefined,
        isFromModal: true,
        initState: term,
        onSelect: ((data) => {
          this.refreshList();
          this.value = data;
          this.valueSubject.next(data);
          stockModel.hide();
        }).bind(this)
      },
      class: 'modal-lg item-master-select-popup',
    });
  }

  creatable() {
    return !!this.permissionService.getPermission("ROLE_UPDATE_INSTRUCTION");
  }

  SearchFn(term: string, option) {
    term = term.toLocaleLowerCase();
    const hasWhiteSpace = term.indexOf(' ') > -1 ? true : false;

    // If string is less than 4 characters and does not contain space,
    // search only through code
    if (!hasWhiteSpace) {
      if (term.length < 4) {
        return option.code.toLocaleLowerCase().indexOf(term) > -1;
      }
    }

    term = term.trim();
    if(option.description && option.code) {
      return (
        option.description.toLocaleLowerCase().indexOf(term) > -1 ||
        option.code.toLocaleLowerCase().indexOf(term) > -1
      );
    }
  }
}
