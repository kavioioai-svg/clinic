import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-vaccine-dosage-page',
  templateUrl: './vaccine-dosage-page.component.html',
  styleUrls: ['./vaccine-dosage-page.component.scss']
})
export class VaccineDosagePageComponent implements OnInit {
  action: string;
  id: string | undefined;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.action = params['action'];
      this.id = params['id'];
    });
  }

}
