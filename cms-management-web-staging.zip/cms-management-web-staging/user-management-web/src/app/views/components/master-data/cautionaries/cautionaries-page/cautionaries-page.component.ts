import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-cautionaries-page',
  templateUrl: './cautionaries-page.component.html',
  styleUrls: ['./cautionaries-page.component.scss']
})
export class CautionariesPageComponent implements OnInit {
  id: string;
  action: string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.action = params['action'];
      this.id = params['id'];
    });
  }

}
