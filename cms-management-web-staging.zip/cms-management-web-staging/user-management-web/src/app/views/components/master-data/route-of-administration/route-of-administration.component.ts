import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from '../../../../model/page';
import {FormBuilder, FormGroup} from '@angular/forms';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {ActivatedRoute, Router} from '@angular/router';
import {InstructionsService} from '../../../../services/master-data-service/instructions.service';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {AlertService} from '../../../../services/alert.service';
import {MasterDataTab, TemplateFucType} from '../../../../model/enum/enums';
import {RouteOfAdministration} from "../../../../objects/route-of-administration";
import {RouteOfAdminService} from "../../../../services/master-data-service/route-of-admin.service";
const filterOptionsJson = require('../../../../settings/filter-options.json');
@Component({
  selector: 'app-route-of-administration',
  templateUrl: './route-of-administration.component.html',
  styleUrls: ['./route-of-administration.component.scss']
})
export class RouteOfAdministrationComponent implements OnInit {

  list: RouteOfAdministration[] = [];
  page: Page = new Page();
  itemStatusOptions = [];
  isLoading: boolean;
  isFilter: boolean;
  searchFrm: FormGroup;
  ngSelectValue = [];
  filterOptions = [];
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;

  actionButtonList = [
    {
      action:'Edit',
      label:'Edit'
    }
  ];
  private isActiveTab: boolean;

  constructor(private router: Router,
              private routeOfAdministrationService: RouteOfAdminService,
              private fb: FormBuilder,
              private masterDataService: MasterDataService,
              private cdr: ChangeDetectorRef,
              private inventoryService: InventoryService,
              private activatedRoute: ActivatedRoute,
              private alertService: AlertService) { }

  ngOnInit() {
    this.page.size = 50
    this.page.pageNumber = 0
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.ROUTE_OF_ADMIN);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchForm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '7'
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
    this.router.navigate([`/pages/master-data/route-of-admin/create/${MasterDataTab.ROUTE_OF_ADMIN}`]);
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset;
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getMasterData();
    }

  }

  onActionChange($event: unknown, row: any) {
    console.log("xxxx row", row)
    switch ($event) {
      case 'view':
      case 'Edit':
        this.router.navigate([`/pages/master-data/route-of-admin/${$event.toLocaleLowerCase()}/${row.name}/${MasterDataTab.ROUTE_OF_ADMIN}`]);
        break;
      // case 'INACTIVE':
      // case 'BLOCKED':
      //   this.changeStatus(row.code ,$event );
      //   break;
    }
  }

  getMasterData() {
    console.log(this.searchFrm.value)
    this.routeOfAdministrationService.searchItem(this.searchFrm.value , this.page, undefined).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.list = res.payload;
      }
    })
  }

  populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      name:  []
    });

    this.searchFrm.valueChanges.subscribe(() => {
      this.page.pageNumber = 0
    })

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
    this.filterOptions  = filterOptionsJson.searchFilterInstruction;
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch(type?: any) {
    if (this.isActiveTab) {
      this.isLoading = true;
      this.isFilter = true;
      let filter: any = {};
      const {name} = this.searchFrm.value;
      filter.name = name;

      if (!type) {
        this.masterDataService.setSearchFilterState(MasterDataTab.ROUTE_OF_ADMIN, filter);
      }

      this.searchFrm = this.fb.group({
        name:  name,
      });
      this.routeOfAdministrationService.searchItem(filter, this.page, undefined).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.list = res.payload;
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
    }
  }

  get TemplateFucType() {
    return TemplateFucType
  }
  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };


}
