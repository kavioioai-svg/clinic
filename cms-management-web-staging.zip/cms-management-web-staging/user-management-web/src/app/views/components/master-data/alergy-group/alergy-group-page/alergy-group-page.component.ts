import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-alergy-group-page',
  templateUrl: './alergy-group-page.component.html',
  styleUrls: ['./alergy-group-page.component.scss']
})
export class AlergyGroupPageComponent implements OnInit {
  private action: string;

  constructor(private router: Router,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
    });
  }

}
