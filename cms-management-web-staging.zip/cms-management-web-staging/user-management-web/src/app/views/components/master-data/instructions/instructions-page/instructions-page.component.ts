import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-instructions-page',
  templateUrl: './instructions-page.component.html',
  styleUrls: ['./instructions-page.component.scss']
})
export class InstructionsPageComponent implements OnInit {
  id: string;
  action: string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      console.log(params['id'])
      this.action = params['action'];
      this.id = decodeURIComponent(params['id']);
    });
  }
}
