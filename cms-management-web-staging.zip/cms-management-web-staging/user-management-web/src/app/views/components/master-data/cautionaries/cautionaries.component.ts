import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from "../../../../model/page";
import {ActivatedRoute, Router} from "@angular/router";
import {InstructionsService} from "../../../../services/master-data-service/instructions.service";
import {CautionariesService} from "../../../../services/master-data-service/cautionaries.service";
import {FormBuilder, FormGroup} from '@angular/forms';
import {Observable, Subject} from 'rxjs';
import {AlertService} from '../../../../services/alert.service';
import {map} from 'rxjs/operators';
import {MasterDataTab} from '../../../../model/enum/enums';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-cautionaries',
  templateUrl: './cautionaries.component.html',
  styleUrls: ['./cautionaries.component.scss']
})
export class CautionariesComponent implements OnInit , AfterContentChecked{
  list: any[] = [];
  page: Page = new Page();
  isLoading: boolean;
  isFilter: boolean;
  searchFrm: FormGroup;
  typeahead: Subject<string> = new Subject<string>();
  selectedCautionary: string;
  cautionaryList: Observable<any>;
  previousFilter: FormGroup;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent
  private isActiveTab: boolean;

  constructor(private router: Router,
              private instructionsService: CautionariesService,
              private fb: FormBuilder,
              private cdr: ChangeDetectorRef,
              private masterDataService: MasterDataService,
              private inventoryService: InventoryService,
              private alertService: AlertService,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.page.size = 50
    this.page.pageNumber = 0
    this.getMasterData();
    this.cautionaryList =this.getCautionary();
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.CAUTIONARY);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '5'
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
    this.router.navigate([`/pages/master-data/cautionaries/create/${MasterDataTab.CAUTIONARY}`]);
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset
    this.refreshList();
  }

   getMasterData() {
    this.instructionsService.listAll(this.page).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.list = res.payload;
      }
    })
  }

   deleteItem(code: string) {
    this.instructionsService.deleteItem(code).subscribe(res => {
      if(res && res. statusCode === "S0000") {
        this.alertService.success(`" ${code} " Deleted Successfully`)
        this.refreshList();
      }
    },
      (err) => {
        this.alertService.error(JSON.stringify(err));
      });
  }


  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch() {
    if (this.isActiveTab) {
      this.isLoading = true;
      this.isFilter = true;
      this.masterDataService.setSearchFilterState(MasterDataTab.CAUTIONARY, this.searchFrm.value);
      this.instructionsService.searchItem(this.searchFrm.value, this.page).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.list = res.payload;
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
    }
  }

  getCautionary() {
    return this.typeahead.pipe(source =>
      this.instructionsService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload));
  }

  populateSearchForm(previousFilter?: any) {
    this.searchFrm = this.fb.group({
      cautionary:  [undefined],
    });

    this.searchFrm.valueChanges.subscribe(() => {
      this.page.pageNumber = 0
    })

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }
  }

   refreshList() {
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getMasterData();
    }
  }

  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.cautionary.value;
  }
  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };
}
