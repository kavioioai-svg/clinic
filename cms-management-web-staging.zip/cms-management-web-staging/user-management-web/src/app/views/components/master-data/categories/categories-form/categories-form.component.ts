import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormGroup} from "@angular/forms";
import {AlertService} from "../../../../../services/alert.service";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {CategoriesService} from "../../../../../services/master-data-service/categories.service";
import {MasterDataTab} from '../../../../../model/enum/enums';
import {BsModalRef} from "ngx-bootstrap/modal";

@Component({
  selector: 'app-categories-form',
  templateUrl: './categories-form.component.html',
  styleUrls: ['./categories-form.component.scss']
})
export class CategoriesFormComponent implements OnInit {
  form: FormGroup;
   @Input() action: string;
   @Input() id?: string;
   initState?: any
   isReadOnly: boolean;
   isEdit: boolean;
   isFromModal: boolean;
   onSelect?: (id: string) => void

   backBtnText =  '< Back to Categories';
   backUrl =  `pages/master-data/all/${MasterDataTab.CATEGORIES}`;

  constructor(private instructionService: CategoriesService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              public bsModalRef: BsModalRef,
  ) { }

  ngOnInit() {
    this.form = this.instructionService.getCategoryForm(this.initState);

    switch (this.action) {
      case 'view':
        this.isReadOnly = true;
        this.form.disable();
        this.populateData();
        break;
      case 'edit':
        this.isEdit = true;
        this.populateData();
        break;
    }
  }

  private populateData() {
    this.instructionService.getInstructionByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      code: payload.category,
    })
  }

  onSaveUpdateData() {
    const data = <{category: string}>this.form.getRawValue();
    let responseBodyObservable = this.action === 'edit' ?
      this.instructionService.update(this.form.getRawValue(), this.id) :
      this.instructionService.create(this.form.value);

    responseBodyObservable.subscribe(item => {
      if (item && item.message === "Success") {
        this.instructionService.getInstructionByCode(data.category).subscribe(item => {
          if (item && item.message === "Success") {
            this.populateResult(item.payload);
            this.alertService.success("Category updated successfully");
            this.onSelect && this.onSelect(data.category);
          }
        });

      }
    }, error => {
      if (error.error){
        this.alertService.error(`Category update failed ${error.error.message}`);
      } else{
        this.alertService.error(`Category update failed ${error.message}`);
      }

    })
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }
  closeModal() {
    this.bsModalRef.hide();
  }


}
