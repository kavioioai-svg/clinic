import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from "@angular/forms";
import {AlertService} from "../../../../../services/alert.service";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {CautionariesService} from "../../../../../services/master-data-service/cautionaries.service";
import { MasterDataTab } from '../../../../../model/enum/enums';
import {BsModalRef} from "ngx-bootstrap/modal";

@Component({
  selector: 'app-cautionaries-form',
  templateUrl: './cautionaries-form.component.html',
  styleUrls: ['./cautionaries-form.component.scss']
})
export class CautionariesFormComponent implements OnInit {
  form: FormGroup;
  @Input() action: string;
  @Input() id?: string;
  initState?: any
  isReadOnly: boolean;
  isEdit: boolean;
  isFromModal: boolean;
  onSelect?: (id: string) => void

  backBtnText =  '< Back to Cautionaries';
  backUrl =  `pages/master-data/all/${MasterDataTab.CAUTIONARY}`;
  constructor(private instructionService: CautionariesService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              public bsModalRef: BsModalRef,
  ) { }

  ngOnInit() {
    this.form = this.instructionService.getInstructionForm(this.initState);

    switch (this.action) {
      case 'view':
        this.isReadOnly = true;
        this.form.disable();
        this.populateData();
        break;
      case 'edit':
        this.isEdit = true;
        this.populateData();
        break;
    }
  }

  private populateData() {
    this.instructionService.getInstructionByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      code: payload.cautionary,
    })
  }

  onSaveUpdateData() {
    const data = <{cautionary: string}>this.form.getRawValue();
    if (this.action === "edit") {
      this.instructionService.update(this.form.getRawValue(), this.id).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.cautionary).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.cautionary);
              this.alertService.success("Cautionary updated successfully");
            }
          });

        }
      })
    } else {
      this.instructionService.create(this.form.getRawValue()).subscribe(item => {
        if (item && item.message === "Success") {
          this.instructionService.getInstructionByCode(data.cautionary).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.cautionary);
              this.alertService.success("Cautionary created successfully");
            }
          });
        }
      }, error => {
        if (error.error){
          this.alertService.error(`Cautionary creation failed ${error.error.message}`);
        } else{
          this.alertService.error(`Cautionary creation failed ${error.message}`);
        }

      })
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }
  closeModal() {
    this.bsModalRef.hide();
  }
}
