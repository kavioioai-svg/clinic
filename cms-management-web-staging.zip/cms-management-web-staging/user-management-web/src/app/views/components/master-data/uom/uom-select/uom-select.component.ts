import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Observable, Subject} from "rxjs";
import {BsModalService} from "ngx-bootstrap";
import {UomService} from "../../../../../services/master-data-service/uom.service";
import {UomFormComponent} from "../uom-form/uom-form.component";
import {map} from "rxjs/operators";
import {ControlContainer, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-uom-select',
  templateUrl: './uom-select.component.html',
  styleUrls: ['./uom-select.component.scss']
})
export class UomSelectComponent implements OnInit ,OnChanges{
  list: Observable<any>;
  text: Subject<string> = new Subject<string>()
  placeholder: string;
  formControlName?: string;
  drugFormGroup: FormGroup;

  @Input() value: string | undefined;
  @Input() isResetForm: boolean | undefined;
  @Output() change = new EventEmitter<string>();

  @Input() controlName: string;

  constructor(private modalService: BsModalService,
              private instructionService: UomService,
              private controlContainer: ControlContainer,
  ) {
  }

  onAdd = (term:string) =>{
    this.openPopUp(term)
  }

  ngOnInit() {
    this.drugFormGroup = <FormGroup>this.controlContainer.control;
    this.list = this.text.pipe(source =>
      this.instructionService.listAll({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      }), map(res => res.payload.map(item => item.uom)))
  }

   ngOnChanges(changes: SimpleChanges) {
    if (changes.isResetForm && this.isResetForm) {
      this.drugFormGroup.reset();
    }
  }

  modelChangeFn($event: any) {
    this.change.emit($event);
  }

  openPopUp(term: string) {
    let initialState = {
      action: 'create',
      id: undefined,
      isFromModal: true,
      initState: {
        uom: term
      }
    };
    const stockModel = this.modalService.show(UomFormComponent, {
      initialState,
      class: 'modal-lg item-master-select-popup',
    });
  }
}
