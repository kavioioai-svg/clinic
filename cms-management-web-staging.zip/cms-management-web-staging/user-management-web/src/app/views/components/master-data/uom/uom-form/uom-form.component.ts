import {Component, Input, OnInit} from '@angular/core';
import {ControlContainer, FormGroup} from '@angular/forms';
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {AlertService} from "../../../../../services/alert.service";
import {UomService} from "../../../../../services/master-data-service/uom.service";
import {BsModalService} from 'ngx-bootstrap';

@Component({
  selector: 'app-uom-form',
  templateUrl: './uom-form.component.html',
  styleUrls: ['./uom-form.component.scss']
})
export class UomFormComponent implements OnInit {
  form: FormGroup;
  @Input() action: string;
  @Input() id?: string;
  initState?: any
  isReadOnly: boolean;
  isEdit: boolean;
  isFromModal: boolean;

  constructor(private uomService: UomService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private modalService: BsModalService) { }

  ngOnInit() {
     this.form = this.uomService.getUomForm(this.initState);

    switch (this.action) {
      case 'view':
        this.isReadOnly = true;
        this.form.disable();
        this.populateData();
        break;
      case 'edit':
        this.isEdit = true;
        this.populateData();
        break;
    }
  }

  private populateData() {
    this.uomService.getInstructionByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      uom: payload.uom,
      multiply: payload.multiply,
    })
  }

  getStatusTypeList() {
    return this.masterDataService.statusTypeList;
  }

  onSaveUpdateData() {
    const data = <Uom>this.form.getRawValue();
    if (this.action === "edit") {
      this.uomService.update(this.form.getRawValue(), this.id).subscribe(item => {
        if (item && item.message === "Success") {
          this.uomService.getInstructionByCode(data.uom).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.alertService.success("Uom updated successfully");
            }
          });

        }
      })
    } else {
        this.uomService.create(this.form.getRawValue()).subscribe(item => {
        if (item && item.message === "Success") {
          this.uomService.getInstructionByCode(data.uom).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.alertService.success("Uom created successfully");
              if(this.isFromModal){this.modalService.hide(item.payload)}
            }
          });
        }
      }, error => {
          if (error.error){
            this.alertService.error(`Uom creation failed ${error.error.message}`);
          } else{
            this.alertService.error(`Uom creation failed ${error.message}`);
          }

        })
    }
  }

  goBack() {

  }

}
