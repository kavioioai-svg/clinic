import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-uom-matrix-page',
  templateUrl: './uom-matrix-page.component.html',
  styleUrls: ['./uom-matrix-page.component.scss']
})
export class UomMatrixPageComponent implements OnInit {
  action: string;
  id: string | undefined;

  constructor(
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.action = params['action'];
      this.id = params['id'];
    });
  }

}
