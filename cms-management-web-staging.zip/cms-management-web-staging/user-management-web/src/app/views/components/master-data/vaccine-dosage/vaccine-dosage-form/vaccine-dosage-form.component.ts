import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {ActivatedRoute, Router} from "@angular/router";
import {AlertService} from "../../../../../services/alert.service";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {DosageInstructionsService} from "../../../../../services/master-data-service/dosage-instructions.service";
import {MasterDataTab} from '../../../../../model/enum/enums';
import {BsModalRef} from "ngx-bootstrap/modal";
import { VaccineDosage } from '../../../../../objects/VaccineDosage';
import { VaccineDosageService } from '../../../../../services/master-data-service/vaccine-dosage.service';

type InternalInst = VaccineDosage;

@Component({
  selector: 'app-vaccine-dosage-form',
  templateUrl: './vaccine-dosage-form.component.html',
  styleUrls: ['./vaccine-dosage-form.component.scss']
})
export class VaccineDosageFormComponent implements OnInit {
  form: FormGroup;
   @Input() action: string;
   @Input() id: string | undefined;
  isReadOnly: boolean;
  isEdit: boolean;
  initState: string;
  isFromModal: boolean;
  backBtnText =  '< Back to Vaccine Dosages';
  backUrl =  `pages/master-data/all/${MasterDataTab.VACCINE_DOSAGE}`;
  onSelect?: (id: string) => void

  constructor(private vaccineDosageService: VaccineDosageService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              public bsModalRef: BsModalRef,
  ) { }

  ngOnInit() {
    this.form = this.vaccineDosageService.getDosageForm(this.initState);
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.form.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.form.enable();
          this.isEdit = true;
          this.populateData();
          break;
      }
    });
  }

  private populateData() {
    this.vaccineDosageService.getDosageByCode(this.id).subscribe(item => {
      if (item && item.message === "Success")  {
        this.populateResult(item.payload)
      }
    })
  }

  private populateResult(payload: any) {
    this.form.patchValue({
      code: payload.code,
      name: payload.name,
      description: payload.description,
      status: payload.status,
    });
  }

  getStatusTypeList() {
    return this.masterDataService.statuses;
  }

  onSaveUpdateData() {
    const data = <VaccineDosage>this.form.getRawValue();
    if (this.action === "edit") {
      this.vaccineDosageService.update(data, this.id).subscribe(item => {
        if (item && item.message === "Success") {
          this.vaccineDosageService.getDosageByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.populateResult(item.payload);
              this.onSelect && this.onSelect(data.code)
              this.alertService.success("Vaccine Dosage updated successfully");
            }
          });

        }
      })
    } else {
      this.vaccineDosageService.create(data).subscribe(item => {
        if (item && item.message === "Success") {
          this.vaccineDosageService.getDosageByCode(data.code).subscribe(item => {
            if (item && item.message === "Success") {
              this.onSelect && this.onSelect(data.code)
              this.alertService.success("Vaccine Dosage created successfully");
              this.vaccineDosageService.getDosageForm();
            }
          });
        }
      }, error => {
        if (error.error){
          this.alertService.error(`Vaccine Dosage creation failed ${error.error.message}`);
        } else{
          this.alertService.error(`Vaccine Dosage creation failed ${error.message}`);
        }

      })
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }

  goToEdit() {
    this.router.navigate([`/pages/master-data/vaccine-dosage/edit/${this.form.get('code').value}/${MasterDataTab.VACCINE_DOSAGE}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  closeModal() {
    this.bsModalRef.hide();
  }
}