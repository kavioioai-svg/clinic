import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-dosage-instructions-page',
  templateUrl: './dosage-instructions-page.component.html',
  styleUrls: ['./dosage-instructions-page.component.scss']
})
export class DosageInstructionsPageComponent implements OnInit {
  action: string;
  id: string | undefined;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.action = params['action'];
      this.id = params['id'];
    });
  }

}
