import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Observable, Subject} from "rxjs";
import {BsModalService} from "ngx-bootstrap";
import {UomMatrixService} from "../../../../../services/master-data-service/uom-matrix.service";
import {UomMatrixFormComponent} from "../uom-matrix-form/uom-matrix-form.component";
import {map} from "rxjs/operators";
import {FormControl} from '@angular/forms';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-uom-matrix-select',
  templateUrl: './uom-matrix-select.component.html',
  styleUrls: ['./uom-matrix-select.component.scss']
})
export class UomMatrixSelectComponent implements OnInit ,OnChanges {
  @Input() list: any[] =[];
  text: Subject<string> = new Subject<string>()
  placeholder: string;

  @Input() value: string | undefined;
  @Output() onDataChange = new EventEmitter<any>();
  @Output() selectedUomValue = new EventEmitter<any>();
  @Input() data?: any | undefined;
  @Input() control: FormControl | undefined | any;
  @Input() name?: string;
  @Input() readonly?: boolean;


  constructor(private modalService: BsModalService,
              private instructionService: UomMatrixService,
              private masterDataService: MasterDataService,
              private permissionService: NgxPermissionsService
  ) {
  }



  ngOnInit() {
    if (!this.list) {
      this.list = [];
    }
    if (!this.list.length) {
      this.instructionService.listAllUomMatrix({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      }).subscribe(res => {
        if(res) {
          this.list =res.payload.filter(e => e.status == 'ACTIVE');
        }
      });
    }

  }

  ngOnChanges(changes: SimpleChanges) {

    if (changes.data && changes.data.currentValue && changes.name && changes.name.currentValue !== 'common') {
      this.value = this.masterDataService.getControlValueForPatch(this.name ,this.data);
    }
    if ( changes.name && changes.name.currentValue === 'common') {
      this.value = this.data.value;
    }if (changes.control) {
      this.value = this.control.value;
    }
  }

  private refreshList() {
    return this.text.pipe(source =>
      this.instructionService.listAllUomMatrix({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      }), map(res => res.payload.filter(e => e.status == 'ACTIVE')));
  }

  modelChangeFn($event: any) {
    this.onDataChange.emit($event);
    this.selectedUomValue.emit($event);
  }

  openPopUp(data: string) {
    const stockModel = this.modalService.show(UomMatrixFormComponent, {
      initialState: {
        action: 'create',
        id: undefined,
        isFromModal: true,
        initData: data,
        onSelect: ((id: string) => {
          this.value = id
          stockModel.hide()
        }).bind(this)
      },
      class: 'modal-lg item-master-select-popup',
    });
  }

  creatable() {
    return !!this.permissionService.getPermission("ROLE_UPDATE_UOM_MATRIX");
  }

  onAdd = (term:string) =>{
    this.value = term;
    this.selectedUomValue.emit(term);
    return term;
  }

  omUomChange($event: any) {
    if($event) {
    //  this.onDataChange.emit($event);
      this.selectedUomValue.emit($event);
    }

  }
}
