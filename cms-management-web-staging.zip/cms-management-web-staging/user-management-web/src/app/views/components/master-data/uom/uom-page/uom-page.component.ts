import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-uom-page',
  templateUrl: './uom-page.component.html',
  styleUrls: ['./uom-page.component.scss']
})
export class UomPageComponent implements OnInit {
  action: string;
  id: string | undefined;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.action = params['action'];
      this.id = params['id'];
    });
  }
}
