import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Observable, Subject} from "rxjs";
import {BsModalService} from "ngx-bootstrap";
import {AllergyGroupService} from "../../../../../services/master-data-service/allergy-group.service";
import {AllergyGroupFormComponent} from "../alergy-group-form/allergy-group-form.component";
import {map} from "rxjs/operators";
import {ControlContainer, FormControl, FormGroup} from '@angular/forms';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {NgxPermissionsService} from "ngx-permissions";

@Component({
  selector: 'app-alergy-group-select',
  templateUrl: './alergy-group-select.component.html',
  styleUrls: ['./alergy-group-select.component.scss']
})
export class AlergyGroupSelectComponent implements OnInit ,OnChanges{
  list: Observable<any>;
  text: Subject<string> = new Subject<string>()
  placeholder: string;
  drugFormGroup: FormGroup;

  @Input() value: string | undefined;
  @Output() changeAllergyValue? = new EventEmitter<any>();
  @Input()  control: FormControl | undefined;
  @Input()  data: any | undefined;
  @Input()  name: string | undefined;

  constructor(private modalService: BsModalService,
              private instructionService: AllergyGroupService,
              private controlContainer: ControlContainer,
              private masterDataService: MasterDataService,
              private permissionService: NgxPermissionsService
  ) {
  }

  onAdd = (term:string) =>{
    this.openPopUp(term)
  }

  ngOnInit() {
    this.drugFormGroup = <FormGroup>this.controlContainer.control;
    this.list = this.loadAllergyGroupList();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.data && changes.data.currentValue ) {
      this.value = this.masterDataService.getControlValueForPatch(this.name ,this.data);
    }
  }
  modelChangeFn($event: any) {
    // let found = {};
    //     // this.list.subscribe(result => {
    //     //   if(result) {
    //     //     found= result.find(r => r.groupCode == $event);
    //     //     this.changeAllergyValue.emit(found);
    //     //   }
    //     // })
    this.changeAllergyValue.emit($event);
  }

  openPopUp(val: string) {
    const stockModel = this.modalService.show(AllergyGroupFormComponent, {
      initialState: {
        action: 'create',
        id: undefined,
        isFromModal: true,
        initState: val,
        onSelect: ((id: string) => {
          this.value = id;
          this.list = this.loadAllergyGroupList()
          stockModel.hide();
        })
      },
      class: 'modal-lg item-master-select-popup',
    });

    this.modalService.onHide.subscribe((element) => {
      this.list = this.loadAllergyGroupList();
    });
  }

   loadAllergyGroupList() {
    return this.text.pipe(source =>
      this.instructionService.listAllAllergyGroup({
        size: 1000,
        pageNumber: 0,
        limit: 100,
        totalElements: 0,
        totalPages: 0
      })).pipe(map(res => res.payload))
  }
  creatable() {
    return !!this.permissionService.getPermission("ROLE_PATIENT_MEDICAL_ALERTS_MODIFY");
  }
}
