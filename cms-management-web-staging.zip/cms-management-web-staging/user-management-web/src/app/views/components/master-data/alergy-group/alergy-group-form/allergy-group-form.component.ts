import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {AllergyGroup} from '../../../../../objects/AllergyGroup';
import {ActivatedRoute, Router} from '@angular/router';
import {FormGroup} from '@angular/forms';
import {AllergyGroupService} from '../../../../../services/master-data-service/allergy-group.service';
import {ItemService} from '../../../../../services/item.service';
import {AlertService} from '../../../../../services/alert.service';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {BsModalRef, BsModalService} from 'ngx-bootstrap';
import {MasterDataTab} from '../../../../../model/enum/enums';

@Component({
  selector: 'app-allergy-group-form',
  templateUrl: './allergy-group-form.component.html',
  styleUrls: ['./allergy-group-form.component.scss']
})
export class AllergyGroupFormComponent implements OnInit , OnDestroy  {
  allergyGroupForm: FormGroup;
  drugList: any[] = [];
  status: any[] = [];
  isReadOnly: boolean;
  isEdit: boolean;
  isFromModal: boolean;
  initState: string;
  public isFoodAllergy: false;
  backBtnText =  '< Back to Allergy Group';
  backUrl =  `pages/master-data/all/${MasterDataTab.ALLERGY}`;
  onSelect?: (id: string) => void

  @Input() action: string;

  constructor(private allergyGroupService: AllergyGroupService,
              private itemService: ItemService,
              private alertService: AlertService,
              private masterDataService: MasterDataService,
              private modalService: BsModalService,
              public bsModalRef: BsModalRef,
              private route: ActivatedRoute,
              private navi: Router,

              ) { }

  ngOnInit() {
    this.loadDrug();
    this.status = this.masterDataService.statuses;
    this.allergyGroupForm =  this.allergyGroupService.getAllergyFormGroup(this.initState);
    this.route.params.subscribe(params => {
      this.action = params['action'];


      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.allergyGroupForm.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.allergyGroupForm.enable();
          this.isEdit = true;
          this.populateData();
          break;

      }
    });
  }

  loadDrug() {
   this.itemService.listAllItems('',true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
       //  let data =  res.payload.map((item) => item.item).filter((item) => item.itemType === 'DRUG');
         let data =  res.payload.map((item) => item.item).filter((item) => item);
          this.drugList = [...this.drugList, ...data];
        }
      },
      (err) => {
      }
    );

  }

  onSaveUpdateData() {
    const data = <AllergyGroup>this.allergyGroupForm.getRawValue();
    if (this.allergyGroupForm.get('id').value) {
      this.allergyGroupService.editAllergyGroup(this.allergyGroupForm.get('id').value , data).subscribe(res => {
        if(res.message === 'Success') {
          // this.allergyGroupForm.reset();
          this.alertService.success('Allergy Group Updated Successfully.');
          this.onSelect && this.onSelect(data.id);
        }
      });
    } else {
      this.allergyGroupService.addAllergyGroup(this.masterDataService.processDataBeforeSubmission(data)).subscribe(res => {
        if(res.message === 'Success') {
          this.allergyGroupForm.reset();
          this.alertService.success('Allergy Group Added Successfully.');
          this.onSelect && this.onSelect(data.id);

          // if(this.isFromModal){
          //   this.modalService.setDismissReason(res.payload);
          //   this.bsModalRef.hide()
          // }
          // this.navigate.navigate(['pages/master-data/all'])
        }
      })
    }
  }

  goBack() {
    this.masterDataService.goBack('pages/master-data/');
  }
  populateData() {
    this.allergyGroupService.getAllergyGroupById(this.itemService.getCurrentDrugItemId()).subscribe(item => {
      if(item && item.message === "Success") {
        this.populateAllergyFormData(item.payload);
      }
    })
  }
  ngOnDestroy(){
    this.itemService.clearItemStorage();
  }

  populateAllergyFormData(data: AllergyGroup) {
    return this.allergyGroupForm.patchValue(data);
  }

  goToEdit(id:any) {
    this.navi.navigate([`/pages/master-data/allergy-group/edit/${MasterDataTab.ALLERGY}`]);
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
   }
  closeModal() {
    this.bsModalRef.hide();
  }

}
