import {AfterContentChecked, ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {AllergyGroupService} from '../../../../services/master-data-service/allergy-group.service';
import {AllergyGroup} from '../../../../objects/AllergyGroup';
import {Page} from '../../../../model/page';
import {ActivatedRoute, Router} from '@angular/router';
import {ItemService} from '../../../../services/item.service';
import {Drug} from '../../../../objects/request/Drug';
import {FormBuilder, FormGroup} from '@angular/forms';
import {CategoriesService} from '../../../../services/master-data-service/categories.service';
import {Observable, Subject} from 'rxjs';
import { AlertService } from '../../../../services/alert.service';
import {InventoryTab, MasterDataTab, TemplateFucType} from '../../../../model/enum/enums';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import {ChargeItemQuery} from '../../../../state/charge-item/charge-item.query';
import {ChargeItem} from '../../../../objects/ChargeItem';
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-allergy-group',
  templateUrl: './allergy-group.component.html',
  styleUrls: ['./allergy-group.component.scss']
})


export class AllergyGroupComponent implements OnInit ,AfterContentChecked {

  listAllergyGroupData: AllergyGroup[];
  page: Page = new Page();
  drugList: Array<ChargeItem>;
  searchFrm: FormGroup;
  itemStatusOptions = [];
  isLoading: boolean;
  isFilter: boolean;
  ngSelectValue = [];
  previousFilter: FormGroup;
  offset: any;
  sorts: any;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;
  actionButtonList = [
      {
       action:'Edit',
       label:'Edit'
      },
     {
       action:'ACTIVE',
       label:'Set to Active'
      },
     {
       action:'INACTIVE',
       label:'Set to Inactive'
      },
     {
       action:'BLOCKED',
       label:'Set to Blocked'
      },
    ];
  private isActiveTab: boolean;

  constructor(private router: Router,
              private itemService: ItemService,
              private AllergyGroupService: AllergyGroupService,
              private fb: FormBuilder,
              private cdr: ChangeDetectorRef,
              private masterDataService: MasterDataService,
              private inventoryService: InventoryService,
              private chargeItemQuery: ChargeItemQuery,
              private alertService: AlertService,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.page.size = 30;
    this.page.pageNumber = 0;
    this.getAllergyGroupData();
    this.populateSearchForm(this.previousFilter);

    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
       setTimeout(() => {
         this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.ALLERGY);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex == MasterDataTab.ALLERGY;
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
    this.router.navigate([`pages/master-data/allergy-group/create/${MasterDataTab.ALLERGY}`])
  }

  getAllergyGroupData() {
    this.AllergyGroupService.listAllAllergyGroup(this.page).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.listAllergyGroupData = res.payload;
      }
    })
  }

  setPage(pageInfo: any) {
    this.offset = pageInfo.offset;
    this.page.pageNumber = pageInfo.offset;
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getAllergyGroupData();
    }

  }

  onActionChange($event: any, row: any) {
    switch ($event) {
      case 'view':
      case 'Edit':
        this.itemService.setCurrentDrugItemId(row.id);
        this.router.navigate([`/pages/master-data/allergy-group/${$event.toLocaleLowerCase()}/${MasterDataTab.ALLERGY}`]);
        break;
      case 'ACTIVE':
      case 'INACTIVE':
      case 'BLOCKED':
        this.changeStatus(row.id ,$event);
        break;
    }
  }

  changeStatus(id ,status) {
    this.AllergyGroupService.changeStatus(id , status).subscribe(res => {
      if(res.message === "Success") {
        this.ngSelectValue = [];
        let index = this.listAllergyGroupData.findIndex(x => x.id === res.payload.id);
        this.listAllergyGroupData[index] = res.payload;
        this.listAllergyGroupData =[...this.listAllergyGroupData];
      }
    })
  }

  loadDrug() {
    this.itemService.listAllItems('' , true).subscribe(
      (res) => {
        if (res && res.statusCode === 'S0000') {
          this.drugList = res.payload.map((item) => item.item).filter((item) => item.itemType === 'DRUG');
        }
      },
      (err) => {
      }
    );
  }

  filterDrugName(drugIds: any[] , isList: boolean) {
   if(this.drugList && this.drugList.length > 0 && drugIds.length > 0) {
     if(!isList){
      if(this.drugList.find(id => drugIds[0] === id.id) != undefined){
        return  this.drugList.find(id => drugIds[0] === id.id).name
      }else{
        return 'N/A';
      }
     }
    let list = [];
     drugIds.forEach(d => {
       let a = this.drugList.find(id => d === id.id);
       if(a)list.push(a.name);
     //  list.push(.name)
     });
     return list;
   }
  }

   populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      groupCode:  [undefined],
      status: ['ALL'],
      drugIds:   [undefined],
    });
     if(previousFilter) {
       this.searchFrm.patchValue(previousFilter)
     }
     this.drugList = this.chargeItemQuery.getDrugItems();

   }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch() {
    if (this.isActiveTab) {
      let filter: any = {};
      this.isLoading = true;
      this.isFilter = true;
      const {groupCode, status, drugIds} = this.searchFrm.value;
      filter.groupCode = groupCode;
      filter.status = status;
      filter.drugIds = drugIds;


      if (status && status === 'ALL') {
        filter.status = null;
      }
      if (drugIds === "") {
        filter.drugIds = [];
      }

      if(this.sorts){
        filter.sort = this.sorts[0];
      }
      
      this.searchFrm = this.fb.group({
        groupCode:  groupCode,
        status: status || "ALL",
        drugIds: drugIds
      });
      this.masterDataService.setSearchFilterState(MasterDataTab.ALLERGY, filter);
      this.AllergyGroupService.searchItem(filter, this.page).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.listAllergyGroupData = res.payload;
            this.listAllergyGroupData.forEach((item) => {
              item.drugNameList = this.filterDrugName(item.drugIds, true);
              item.drugName = this.filterDrugName(item.drugIds, false);
            })
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
  }
  }

  get TemplateFucType() {
    return TemplateFucType
  }

  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn(): boolean {
    return  this.searchFrm.controls.groupCode.value ||
      (this.searchFrm.controls.drugIds.value && this.searchFrm.controls.drugIds.value.length > 0) ||
      (this.searchFrm.controls.status.value && this.searchFrm.controls.status.value !== 'ALL')
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  sort($event: any) {

    this.page.size = 30;
    this.page.pageNumber = 0;

    this.isFilter = true;
    this.sorts = $event.sorts;
    this.searchFrm.patchValue({
      sort: $event.sorts[0]
    })
    this.onSearch();
  }

}
