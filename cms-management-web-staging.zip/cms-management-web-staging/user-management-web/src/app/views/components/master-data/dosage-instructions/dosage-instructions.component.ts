import {AfterContentChecked, ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Page} from "../../../../model/page";
import {ActivatedRoute, Router} from "@angular/router";
import {DosageInstructionsService} from "../../../../services/master-data-service/dosage-instructions.service";
import {FormBuilder, FormGroup} from '@angular/forms';
import {AlertService} from '../../../../services/alert.service';
import {MasterDataTab, TemplateFucType} from 'app/model/enum/enums';
import {MasterDataService} from '../../../../services/master-data-service/master-data.service';
import {InventoryService} from '../../../../services/inventory.service';
import {DatatableComponent} from '@swimlane/ngx-datatable';
const filterOptionsJson = require('../../../../settings/filter-options.json');

@Component({
  selector: 'app-dosage-instructions',
  templateUrl: './dosage-instructions.component.html',
  styleUrls: ['./dosage-instructions.component.scss'],
})
export class DosageInstructionsComponent implements OnInit , AfterContentChecked {
  list: Instruction[] = [];
  page: Page = new Page();
  itemStatusOptions = [];
  isLoading: boolean;
  isFilter: boolean;
  searchFrm: FormGroup;
  ngSelectValue = [];
  previousFilter: FormGroup;
  filterOptions = [];
  sorts: any;
  @ViewChild('myTable' , {static: false}) table: DatatableComponent;

  actionButtonList = [
    {
      action:'Edit',
      label:'Edit'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'BLOCKED',
      label:'Set to Blocked'
    },
  ];
  private isActiveTab: boolean;

  constructor(private router: Router,
              private instructionsService: DosageInstructionsService ,
              private fb: FormBuilder,
              private cdr: ChangeDetectorRef,
              private inventoryService: InventoryService,
              private masterDataService: MasterDataService,
              private activatedRoute: ActivatedRoute,
              private alertService: AlertService) { }

  ngOnInit() {
    this.page.size = 30
    this.page.pageNumber = 0
    this.populateSearchForm(this.previousFilter);


    this.masterDataService.onTabChange$.subscribe(result => {
      if(result) {
        this.isLoading = true;
        setTimeout(() => {
          this.isLoading = false;
        }, 500)
      }
    });

    this.inventoryService.getPageFilterState().subscribe(res => {
      if(res && res.length > 0 ) {
        let find = res.find(frm => frm.pageIndex == MasterDataTab.DOS_INSTRUCTION);
        if(find){
          this.searchFrm.patchValue(find.searchForm);
          this.previousFilter = find.searchFrm;
          this.onSearch();
        }
      }
    });

    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex == MasterDataTab.DOS_INSTRUCTION;
      if (this.isActiveTab) {
        this.onSearch();
      }
    })
  }

  addNewItem() {
    this.router.navigate([`/pages/master-data/dosage-instructions/create/${MasterDataTab.DOS_INSTRUCTION}`]);
  }

  setPage(pageInfo: any) {
    this.page.pageNumber = pageInfo.offset
    if(this.isFilter) {
      this.onSearch()
    }else {
      this.getMasterData();
    }

  }

  onActionChange($event: unknown, row: any) {
    switch ($event) {
      case 'view':
      case 'Edit':
        this.router.navigate([`/pages/master-data/dosage-instructions/${$event.toLocaleLowerCase()}/${row.code}/${MasterDataTab.DOS_INSTRUCTION}`]);
        break;
      case 'ACTIVE':
      case 'INACTIVE':
      case 'BLOCKED':
        this.changeStatus(row ,$event );
        break;
    }
  }

  private getMasterData() {
    this.instructionsService.searchItem(this.searchFrm.value , this.page, {
      sortBy: this.sorts ? this.sorts[0].prop: undefined,
      direction: this.sorts ? this.sorts[0].dir.toUpperCase() : undefined
    }).subscribe(res => {
      if(res && res.payload.length > 0){
        this.page.pageNumber = res['pageNumber'];
        this.page.totalPages = res['totalPages'];
        this.page.totalElements = res['totalElements'];
        this.list = res.payload;
      }
    })
  }
  changeStatus(row ,status ) {
    this.instructionsService.update({
      ...row,
      status: status
    }, status).subscribe(res => {
      this.onSearch()
      // if(res.message === "Success") {
      //   this.ngSelectValue = [];
      //   let index = this.list.findIndex(x => x.code === res.payload.code);
      //   this.list[index] = res.payload;
      //   this.list =[...this.list];
      // }
    })
  }

  populateSearchForm(previousFilter?: any) {
    this.itemStatusOptions =  filterOptionsJson.itemStatusOptions;

    this.searchFrm = this.fb.group({
      code:  [],
      description:  [],
      status: ['ALL'],
      withBrokenIntegration: false
    });

    this.searchFrm.valueChanges.subscribe(() => {
      this.page.pageNumber = 0
    })

    if(previousFilter) {
      this.searchFrm.patchValue(previousFilter)
    }

    this.filterOptions  = filterOptionsJson.searchFilterInstruction;
  }

  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
  }

  onSearch(type?: any) {
    if (this.isActiveTab) {
      this.isLoading = true;
      this.isFilter = true;
      let filter: any = {};

      const {status, code, description, withBrokenIntegration} = this.searchFrm.value;
      
      filter.status = status;
      filter.code = code;
      filter.description = description;
      filter.withBrokenIntegration = withBrokenIntegration;
      
      if (status && status === 'ALL') {
        filter.status = null;
      }
      
      if (!type) {
        this.masterDataService.setSearchFilterState(MasterDataTab.DOS_INSTRUCTION, filter);
      }

      let apiSearchFilter = {...filter};
      apiSearchFilter.withBrokenIntegration = filter.withBrokenIntegration ? 'Yes' : 'No';

      this.instructionsService.searchItem(apiSearchFilter, this.page, {
        sortBy: this.sorts ? this.sorts[0].prop: undefined,
        direction: this.sorts ? this.sorts[0].dir.toUpperCase() : undefined
      }).subscribe(res => {
          if (res.message === "Success") {
            this.page.pageNumber = res['pageNumber'];
            this.page.totalPages = res['totalPages'];
            this.page.totalElements = res['totalElements'];
            this.list = res.payload;
            this.isLoading = false;
          }
        },
        (err) => {
          this.isLoading = false;
          this.alertService.error(JSON.stringify(err));
        })
    }
  }
  get TemplateFucType() {
    return TemplateFucType
  }

  clearFilter(e) {
    if(e)
      this.populateSearchForm();
  }

  showFilterBtn() {
    return this.searchFrm.controls.code.value ||this.searchFrm.controls.description.value ||
      (this.searchFrm.controls.status.value !== 'ALL')
  }

  onSort(pageInfo) {
    this.table = this.masterDataService.setCurrentPageIndex(this.table,pageInfo);
  };

  sort($event: any) {

    this.page.size = 30;
    this.page.pageNumber = 0;

    this.isFilter = true;
    this.sorts = $event.sorts;
    this.searchFrm.patchValue({
      sort: $event.sorts[0]
    })
    this.onSearch();
  }
}
