import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {MasterDataService} from '../../../../../services/master-data-service/master-data.service';
import {FormArray, FormGroup, Validators} from '@angular/forms';
import {UomMatrixService} from '../../../../../services/master-data-service/uom-matrix.service';
import {ItemService} from '../../../../../services/item.service';
import {Supplier} from '../../../../../objects/Supplier';
import {ActivatedRoute, Router} from '@angular/router';
import {AlertService} from '../../../../../services/alert.service';
import {UomMatrix} from '../../../../../objects/UomMatrix';
import { cloneDeep } from 'lodash';
import {MasterDataTab} from '../../../../../model/enum/enums';
import {map} from 'rxjs/operators';

type InternalUomMatrix = UomMatrix & {
  'exchangeRatio': [{key:string, value: number}]
}

@Component({
  selector: 'app-uom-matrix-form',
  templateUrl: './uom-matrix-form.component.html',
  styleUrls: ['./uom-matrix-form.component.scss']
})
export class UomMatrixFormComponent implements OnInit , OnDestroy {
  uomMatrixForm: FormGroup;
  isReadOnly: boolean;
  isEdit: boolean;
  backBtnText =  '< Back to UOM matrix';
  backUrl =  `pages/master-data/all/${MasterDataTab.MATRIX}`;
  isFromModal: boolean;
  initData: string;
  uomMatrixList: any[] = [];
  uomMatrixRatioList: any[] = [];
  noMatrixUomList: string[];

  onSelect?: (id: string) => void

  @Input() action: string;
  @Input() id: string | undefined;

  constructor(private masterDataService: MasterDataService,
              private uomMatrixService: UomMatrixService,
              private itemService: ItemService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private instructionService: UomMatrixService,
              private alertService: AlertService) { }

  ngOnInit(initData?: string) {
    this.getUomMatrixList();
    this.uomMatrixForm = this.uomMatrixService.getUomMatrixForm(this.initData);
    this.activatedRoute.params.subscribe(params => {
      this.action = params['action'];
      switch (this.action) {
        case 'view':
          this.isReadOnly = true;
          this.uomMatrixForm.disable();
          this.populateData();
          break;
        case 'edit':
          this.isReadOnly = false;
          this.uomMatrixForm.enable();
          this.isEdit = true;
          this.uomMatrixForm.get('uomCode').disable();
          this.populateData();
          break;

      }
    });
  }

  getStatusTypeList() {
    return this.masterDataService.statuses;
  }

  get getExchangeField(): FormArray {
    return this.uomMatrixForm.get('exchangeRatio') as FormArray;
  }

  addMoreExchangeRatioField() {
    this.getExchangeField.push(this.uomMatrixService.getRatioFormGroup());
  }

  deleteGroupItem(i: number) {
    this.getExchangeField.removeAt(i);
  }

  private static convertToNetworkData(data: InternalUomMatrix): UomMatrix {
    return {
      ...data,
      // @ts-ignore
      exchangeRatio: Object.fromEntries(data.exchangeRatio.map(({key, value}) => ([key, value])))
    }
  }

  onSaveUpdateData() {
    const data = <InternalUomMatrix>new UomMatrix(this.uomMatrixForm.getRawValue());
    if (this.uomMatrixForm.get('id').value) {
      this.uomMatrixService.editUomMatrix(this.uomMatrixForm.get('id').value , UomMatrixFormComponent.convertToNetworkData(data)).subscribe(res => {
        if(res.message === 'Success') {
          this.uomMatrixService.getUomMatrixForm();
          this.alertService.success('Uom Matrix Updated Successfully.');
          this.onSelect && this.onSelect(data.id)
        }
      });
    } else {

      this.uomMatrixService.addUomMatrix(this.masterDataService.processDataBeforeSubmission(UomMatrixFormComponent.convertToNetworkData(data))).subscribe(res => {
        if(res.message === 'Success') {
          this.alertService.success('Uom Matrix Added Successfully.');
          this.onSelect && this.onSelect(data.id)
         // this.navigate.navigate(['pages/master-data/all'])
        }
      },
        (err) => {
          let msg = JSON.stringify(err).includes('duplicate key') ? 'Uom Matrix Code Already Exists..' : JSON.stringify(err);
          this.alertService.error(msg);
        })
    }
  }



  ngOnDestroy() {
    this.itemService.clearItemStorage();
  }

   populateData() {
     this.uomMatrixService.getUomMatrixById(this.itemService.getCurrentDrugItemId()).subscribe(item => {
       if(item && item.message === "Success") {
         this.populateUomMatrix(item.payload);
       }
     })
  }

   populateUomMatrix(uom: any) {
     this.uomMatrixForm.patchValue({
       id: uom.id,
       uomCode: uom.uomCode,
       status: uom.status,
     });

     (this.uomMatrixForm.get('exchangeRatio') as FormArray).clear();
      // @ts-ignore
     Object.entries(uom.exchangeRatio).forEach(([key, value], index) => {
       const uomForm = this.uomMatrixService.getRatioFormGroup();
       uomForm.patchValue({key:key, value:value});
       if(index==0){
         uomForm.disable();
       }
       (this.uomMatrixForm.get('exchangeRatio') as FormArray).push(uomForm);
      });
  }

  goBack() {
    this.router.navigate([this.backUrl])
  }

  changeUom(val: any , index: number) {
     if(this.getExchangeField.controls.length > 1 && val) {
       let arr =  cloneDeep(this.getExchangeField);
       arr.removeAt(index);
       arr.controls.forEach((r : any)=>{
          if(r.controls.key.value == val.key) {
            this.getExchangeField.controls[index].get('key').setErrors({duplicate: true});
          }
       })
     }
  }

  getUomMatrixList() {
    this.instructionService.listAllUomMatrix({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).subscribe(res => {
       if(res) {
         this.uomMatrixList = res.payload;
         this.getExchangeRatioCodeList(res.payload);
         let uomCodes = this.uomMatrixList.map(a => a.uomCode);
         // @ts-ignore
         this.noMatrixUomList = this.uomMatrixList.flatMap((a) => Object.keys(a.exchangeRatio))
           .filter(b => !uomCodes.includes(b));
         this.uomMatrixForm.get("uomCode").setValidators([Validators.required]);
       }
    })
  }

  // forbiddenUomValidator(forbiddenList: any[]) {
  //   return (control: any) => {
  //     if (forbiddenList && forbiddenList.length) {
  //       const forbidden = forbiddenList.find(e => e === control.value);
  //       return forbidden ? {forbiddenUom: {value: control.value}} : null;
  //     }
  //     return null;
  //   }
  // }

  getExchangeRatioCodeList(data: any) {
    data.forEach(r => {
      // @ts-ignore
      Object.entries(r.exchangeRatio).forEach(([key, value], index) => {
        this.uomMatrixRatioList.push({key:key, value:value});
      });
    });
    if(this.uomMatrixRatioList.length > 0){
      // @ts-ignore
      this.uomMatrixRatioList = Object.values(this.uomMatrixRatioList.reduce((acc,cur)=>Object.assign(acc,{[cur.key]:cur}),{}));
    }

  }

  getSelectedUomValue($event: any) {
    let foundUom : any;
    if($event.uomCode){
      foundUom = this.uomMatrixList.find((r: any) => r.uomCode.toUpperCase() == $event.uomCode.toUpperCase());
    }else{
      foundUom = this.uomMatrixList.find((r: any) => r.uomCode.toUpperCase() == $event.toUpperCase());
    }
    (this.uomMatrixForm.get('exchangeRatio') as FormArray).clear();
    if(!foundUom) {
      const uomForm = this.uomMatrixService.getRatioFormGroup();
        uomForm.patchValue({key:$event.uomCode ? $event.uomCode : $event , value:1});
      uomForm.get('key').disable();
      uomForm.get('value').disable();
      (this.uomMatrixForm.get('exchangeRatio') as FormArray).push(uomForm);
    } else {
      // @ts-ignore
      Object.entries(foundUom.exchangeRatio).forEach(([key, value], index) => {
        const uomForm = this.uomMatrixService.getRatioFormGroup();
        if(key.toUpperCase() == foundUom.uomCode.toUpperCase()){
          uomForm.get('key').disable();
          uomForm.get('value').disable();
        }
        uomForm.patchValue({key:key, value:value});
        (this.uomMatrixForm.get('exchangeRatio') as FormArray).push(uomForm);
      });
    }

  }

  goToEdit(id:any) {
    this.router.navigate([`/pages/master-data/uom-matrix/edit/${MasterDataTab.MATRIX}`]);
    // this.action='edit';
    // this.uomMatrixForm.enable();
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
   }
}
