import { Injectable } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

import { AkitaNgFormsManager } from '@datorama/akita-ng-forms-manager';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { tap, mergeMap, map } from 'rxjs/operators';

import { ApiCmsManagementService } from '../../../services/api-cms-management.service';
import { CurrentMedicalCoverageStore } from './state/current-medical-coverage.store';
import { MedicalCoverageService } from '../../../state/medical-coverage/medical-coverage.service';
import { valueTrimmedRequiredValidator } from '../../../services/form.service';
import { combineLatest, of } from 'rxjs';
import {validatecontactNumber} from '../../../validators/PhoneNumberValidator';
import {validateEmail} from '../../../validators/email-validator';

export interface MedicalCoverageFormGroup {
  medicalCoverage: {
    accountManager: string;
    address: {
      address: string;
      attentionTo: string;
      postalCode: string;
    };
    allowedAccessLevel: Array<any>;
    code: string;
    contacts: Array<FormGroup>;
    costCenters: Array<FormGroup>;
    coveragePlans: Array<FormGroup>;
    creditTerms: number;
    endDate: string;
    medicineRefillAllowed: boolean;
    name: string;
    payAtClinic: boolean;
    policyHolderCount: number;
    projects: Array<FormGroup>;
    showDiscount: boolean;
    showMemberCard: boolean;
    startDate: string;
    status: string;
    trackAttendance: boolean;
    type: string;
    usePatientAddressForBilling: boolean;
    website: string;
    medicalCoverageExtraDetails: {
      tpaName: string;
      //logoFileDbData:
      termAndCondition: string;
      isTPA: boolean;
      updateName: string;
      skipNehrSubmission: boolean;
    };
    hrPortalAccessList: Array<FormGroup>;
    medicalService: Array<FormGroup>;
  };

  medicalCoveragePlanValidation: {
    coveragePlans: Array<FormGroup>;
  };

  medicalCoveragePlan: {
    allowedRelationship: string;
    capPerDay: { visits: number; limit: number };
    capPerLifeTime: { visits: number; limit: number };
    capPerMonth: { visits: number; limit: number };
    capPerVisit: { visits: number; limit: number };
    capPerWeek: { visits: number; limit: number };
    capPerYear: { visits: number; limit: number };
    clinicRemarks: string;
    code: string;
    copayment: { paymentType: string; value: number };
    endDate: string;
    excludedAllByDefault: boolean;
    excludedClinics: Array<string>;
    excludedMedicalServiceSchemes: Array<string>;
    filterDiagnosisCode: boolean;
    id: string;
    includedMedicalServiceSchemes: Array<string>;
    limitResetType: string;
    maximumNumberOfDiagnosisCodes: number;
    minimumNumberOfDiagnosisCodes: number;
    name: string;
    paymentRemarks: string;
    registrationRemarks: string;
    remarks: string;
    salesDiscount: { discountType: string; discountValue: number; remarks: string };
    brandedDrugDiscount: { discountType: string; discountValue: number; remarks: string };
    genericDrugDiscount: { discountType: string; discountValue: number; remarks: string };
    startDate: string;
    status: string;
  };
}

@Injectable({ providedIn: 'root' })
export class CurrentMedicalCoverageService {
  medicalCoverageBooleanSelection = [
    { value: true, label: 'YES' },
    { value: false, label: 'NO' },
  ];

  medicalCoverageTypes = [
    { value: 'CORPORATE', label: 'CORPORATE' },
    { value: 'INSURANCE', label: 'INSURANCE' },
    { value: 'MEDISAVE', label: 'MEDISAVE' },
    { value: 'CHAS', label: 'CHAS' },
  ];

  medicalCoverageStatus = [
    { value: 'ALL', label:'All' },
    { value: 'ACTIVE', label: 'Active' },
    { value: 'INACTIVE', label: 'Inactive' },
  ];

  medicalCoveragePlanStatus = [
    { value: 'ACTIVE', label: 'Active' },
    { value: 'INACTIVE', label: 'Inactive' },
  ];

  medicalPlanLimitResetType = [
    { value: 'CALENDAR', label: 'Calendar' },
    { value: 'FROM_FIRST_USE', label: 'From First Use' },
    { value: 'FROM_POLICY_HOLDER_CREATION_DATE', label: 'From Policy Holder Creation Date' },
    { value: 'BLANK', label: 'None' },
  ];

  medicalPlanPaymentType = [
    { value: 'DOLLAR', label: 'Dollar' },
    { value: 'PERCENTAGE', label: 'Percentage' },
  ];

  medicalPlanRelationship = [
    { value: 'CHILDREN', label: 'Children' },
    { value: 'PARENT', label: 'Parent' },
    { value: 'SPOUSE', label: 'Spouse' },
  ];

  personTitle = [
    { value: 'Mr', label: 'Mr' },
    { value: 'Mrs', label: 'Mrs' },
    { value: 'Miss', label: 'Miss' },
    { value: 'Dr', label: 'Dr' },
  ];

  constructor(
    private akitaMedicalCoverageService: MedicalCoverageService,
    private apiCmsManagementService: ApiCmsManagementService,
    private currentMedicalCoverageStore: CurrentMedicalCoverageStore,
    private formBuilder: FormBuilder
  ) {}

  // Form Creation
  createCompanySearchFormGroup() {
    return this.formBuilder.group({
      companyCode: [''],
      companyName: [''],
      medicalCoverageType: [''],
      startDate: [''],
      endDate: [''],
      status: [],
    });
  }

  createMedicalPlanSearchFormGroup() {
    return this.formBuilder.group({
      medicalPlanCode: '',
      medicalPlanName: '',
      startDate: '',
      endDate: '',
      status: '',
    });
  }
  createMedicalCoverageFormGroup(medicalCoverage, akitaNgFormsManager: AkitaNgFormsManager) {
    const {
      id = '',
      code = '',
      name = '',
      website = '',
      type = null,
      address = null,
      startDate = '',
      endDate = '',
      status = null,
      accountManager = '',
      creditTerms = 0,
      policyHolderCount = 0,
      showDiscount = null,
      showMemberCard = null,
      payAtClinic = null,
      medicineRefillAllowed = null,
      trackAttendance = null,
      usePatientAddressForBilling = null,
      contacts = [],
      costCenters = [],
      // coveragePlans = [],
      projects = [],
      allowedAccessLevel = new Array<string>(),
      parentCompanyName = '',
      displayName = '',
      rpaEnabled = false,
      hrPortalAccessList = [],
      isBusinessOfficeClaim = false,
      isAlertOnChangingPlan = false,
      isSuppressSurcharge = false,
      financialClass = '',
      ignoreSystemBalanceCheck = false,
      medicalService = [],
      medicalCoverageExtraDetail = null,
    } = medicalCoverage;

    const mcFormGroup = this.formBuilder.group({
      id: id,
      code: [code, valueTrimmedRequiredValidator()],
      name: [name, valueTrimmedRequiredValidator()],
      website: website,
      type: [type, valueTrimmedRequiredValidator()],
      address: this.getAddressFormGorup(),
      startDate: [startDate, valueTrimmedRequiredValidator()],
      endDate: [endDate, valueTrimmedRequiredValidator()],
      status: [status, valueTrimmedRequiredValidator()],
      accountManager: [accountManager, valueTrimmedRequiredValidator()],
      creditTerms: creditTerms,
      policyHolderCount: policyHolderCount,
      showDiscount: [showDiscount, valueTrimmedRequiredValidator()],
      showMemberCard: [showMemberCard, valueTrimmedRequiredValidator()],
      payAtClinic: [payAtClinic, valueTrimmedRequiredValidator()],
      medicineRefillAllowed: [medicineRefillAllowed, valueTrimmedRequiredValidator()],
      trackAttendance: [trackAttendance, valueTrimmedRequiredValidator()],
      usePatientAddressForBilling: [usePatientAddressForBilling, valueTrimmedRequiredValidator()],
      contacts: this.generateContactsFormArray(contacts),
      costCenters: this.generateCostCentersFormArray(costCenters),
      // coveragePlans: this.generateCoveragePlansFormArray(coveragePlans),
      projects: this.generateProjectFormArray(projects),
      allowedAccessLevel: [allowedAccessLevel],
      parentCompanyName: [parentCompanyName],
      displayName: [displayName],
      rpaEnabled: [rpaEnabled],
      hrPortalAccessList: [hrPortalAccessList],
      isBusinessOfficeClaim: [isBusinessOfficeClaim],
      isAlertOnChangingPlan: [isAlertOnChangingPlan],
      isSuppressSurcharge: [isSuppressSurcharge],
      financialClass: [financialClass],
      ignoreSystemBalanceCheck: [ignoreSystemBalanceCheck],
      medicalService: [medicalService],
      medicalCoverageExtraDetail: this.getMedicalCoverageExtraDetailsFormGorup(medicalCoverageExtraDetail),
    });

    akitaNgFormsManager.upsert('medicalCoverage', mcFormGroup);
    return mcFormGroup;
  }


  createMedicalCoveragePlanValidationFormGroup(medicalCoveragePlanValidation, akitaNgFormsManager: AkitaNgFormsManager) {
    const {
      coveragePlans = [],
    } = medicalCoveragePlanValidation;

    const mcPlanValidationFormGroup = this.formBuilder.group({
      coveragePlans: this.generateCoveragePlansFormArray(coveragePlans),
    });

    akitaNgFormsManager.upsert('medicalCoveragePlanValidation', mcPlanValidationFormGroup);
    return mcPlanValidationFormGroup;
  }

  getAddressFormGorup() {
    return this.formBuilder.group({
      address: [''],
      attentionTo: [''],
      postalCode: [''],
    });
  }

  getMedicalCoverageExtraDetailsFormGorup(medicalCoverageExtraDetail: any) {
    if(medicalCoverageExtraDetail){
      return this.formBuilder.group({
        medicalCoverageId: [medicalCoverageExtraDetail.id],
        tpaName: [medicalCoverageExtraDetail.tpaName],
        logoFileDbData:this.createLogoFileFormGroup(medicalCoverageExtraDetail.logoFileDbData),
        termAndCondition: [medicalCoverageExtraDetail.termAndCondition],
        isTPA: [medicalCoverageExtraDetail.tpa],
        updateName: [medicalCoverageExtraDetail.updateName],
        skipNehrSubmission: [medicalCoverageExtraDetail.skipNehrSubmission],
      });
    }else {
      return this.formBuilder.group({
        medicalCoverageId: [''],
        tpaName: [''],
        logoFileDbData:this.createLogoFileFormGroup(),
        termAndCondition: [''],
        isTPA: [false],
        updateName: [''],
        skipNehrSubmission: [false],
      });
    }
  }

  createLogoFileFormGroup(logoData?: any) {
    const logoFormArray = [];
    if (!logoData) {
      logoFormArray.push(this.getLogoFileDbDataFormGroup());
    } else {
      logoData.forEach((logo) => logoFormArray.push(this.getLogoFileDbDataFormGroup(logo)));
    }
    return this.formBuilder.array(logoFormArray);
  }

  getLogoFileDbDataFormGroup(logoData?: any) {
    return this.formBuilder.group({
      base64Str: [logoData ? logoData.base64Str : ''],
      name: [logoData ? logoData.name : ''],
      fileName: [logoData ? logoData.fileName : ''],
      uploader: [logoData ? logoData.uploader : ''],
      clinicId: [logoData ? logoData.clinicId : ''],
      fileTypeCode: [logoData ? logoData.fileTypeCode : ''],
      type: [logoData ? logoData.type : ''],
      size: [logoData ? logoData.size : ''],
      description: [logoData ? logoData.description : ''],
    });
  }

  generateContactsFormArray(contacts) {
    const contactsFormArray = [];
    contacts.forEach((contact) => contactsFormArray.push(this.createContactFormGroup(contact)));
    return this.formBuilder.array(contactsFormArray);
  }

  createContactFormGroup({
    directNumber = '',
    email = '',
    faxNumber = '',
    mobileNumber = '',
    name = '',
    title = '',
  } = {}) {
    return this.formBuilder.group({
      directNumber: [directNumber , validatecontactNumber] ,
      email: [email ,[validateEmail]],
      faxNumber: [faxNumber, validatecontactNumber],
      mobileNumber: [mobileNumber, validatecontactNumber],
      name: name,
      title: title,
    });
  }

  isContactFormGroupEmpty(contact) {
    const contactValues = contact.value;
    if (
      contactValues.directNumber === '' &&
      contactValues.email === '' &&
      contactValues.faxNumber === '' &&
      contactValues.mobileNumber === '' &&
      contactValues.name === '' &&
      contactValues.title === ''
    )
      return true;
    return false;
  }

  generateCostCentersFormArray(costCenters) {
    const costCentersFormArray = [];
    costCenters.forEach((costCentre) => {
      let eachCC;
      if (typeof costCentre === 'string') eachCC = { address: '', costCentre: costCentre ? costCentre : '' };
      else
        eachCC = {
          address: costCentre && costCentre.address ? costCentre.address : '',
          costCentre: costCentre && costCentre.costCentre ? costCentre.costCentre : '',
        };

      costCentersFormArray.push(this.createCostCentreFormGroup(eachCC));
    });
    return this.formBuilder.array(costCentersFormArray);
  }

  createCostCentreFormGroup({ address = '', costCentre = '' } = {}) {
    return this.formBuilder.group({
      address: address,
      costCentre: costCentre,
    });
  }

  isCostCentreFormGroupEmpty(costCenter) {
    const costCenterValues = costCenter.value;
    if (costCenterValues.address === '' && costCenterValues.costCentre === '') return true;
    return false;
  }

  generateProjectFormArray(projects) {
    const projectsFormArray = [];
    projects.forEach((project) => projectsFormArray.push(this.createCostCentreFormGroup(project)));
    return this.formBuilder.array(projectsFormArray);
  }

  createProjectFormGroup({ address = '', project = '' } = {}) {
    return this.formBuilder.group({
      address: address,
      project: project,
    });
  }

  isProjectFormGroupEmpty(project) {
    const projectValues = project.value;
    if (projectValues.address === '' && projectValues.project === '') return true;
    return false;
  }

  generateCoveragePlansFormArray(coveragePlans) {
    const coveragePlansFormArray = [];
    coveragePlans.forEach((coveragePlan) =>
      coveragePlansFormArray.push(this.createCoveragePlanFormGroup(coveragePlan))
    );
    return this.formBuilder.array(coveragePlansFormArray);
  }

  createCoveragePlanFormGroup(coveragePlan) {
    const {
      allowedRelationship = [],
      diagnosisIds=[],
      capPerDay = { visits: 0, limit: 0 },
      capPerLifeTime = { visits: 0, limit: 0 },
      capPerMonth = { visits: 0, limit: 0 },
      capPerVisit = { visits: 0, limit: 0 },
      capPerWeek = { visits: 0, limit: 0 },
      capPerYear = { visits: 0, limit: 0 },
      clinicRemarks = '',
      code = '',
      copayment = { paymentType: undefined, value: 0 },
      endDate = '',
      excludeAllByDefault = false,
      excludedClinics = [],
      filterDiagnosisCode = false,
      id = '',
      limitResetType = undefined,
      maximumNumberOfDiagnosisCodes = 0,
      minimumNumberOfDiagnosisCodes = 0,
      isDentalChas = undefined,
      isSflChas = undefined,
      isPhpcChas = undefined,
      name = '',
      paymentRemarks = '',
      registrationRemarks = '',
      remarks = '',
      salesDiscount = { discountType: undefined, discountValue: '' },
      brandedDrugDiscount = { discountType: undefined, discountValue: '' },
      genericDrugDiscount = { discountType: undefined, discountValue: '' },
      startDate = '',
      status = undefined,
      planType = '',
      extraChargeAddOnAmount = undefined,
      usableOnTeleConsult = undefined,
      listOnTeleConsult = undefined,
      teleConsultRemark = '',
      externalUniquePlanCode = '',
      allowSelectWithChasPlan = undefined,
    } = coveragePlan;

    const updatedCapPerDay = Number.isInteger(capPerDay.limit)
      ? (capPerDay.limit * 0.01).toFixed(2)
      : Number(capPerDay.limit).toFixed(2);
    const updatedCapPerLifeTime = Number.isInteger(capPerLifeTime.limit)
      ? (capPerLifeTime.limit * 0.01).toFixed(2)
      : Number(capPerLifeTime.limit).toFixed(2);
    const updatedCapPerMonth = Number.isInteger(capPerMonth.limit)
      ? (capPerMonth.limit * 0.01).toFixed(2)
      : Number(capPerMonth.limit).toFixed(2);
    const updatedCapPerVisit = Number.isInteger(capPerVisit.limit)
      ? (capPerVisit.limit * 0.01).toFixed(2)
      : Number(capPerVisit.limit).toFixed(2);
    const updatedCapPerWeek = Number.isInteger(capPerWeek.limit)
      ? (capPerWeek.limit * 0.01).toFixed(2)
      : Number(capPerWeek.limit).toFixed(2);
    const updatedCapPerYear = Number.isInteger(capPerYear.limit)
      ? (capPerYear.limit * 0.01).toFixed(2)
      : Number(capPerYear.limit).toFixed(2);

    const updatedCopaymentValue = Number.isInteger(copayment.value)
      ? (copayment.value * 0.01).toFixed(2)
      : Number(copayment.value).toFixed(2);
    const updatedSalesDiscountValue =
      salesDiscount.discountType && salesDiscount.discountType === 'DOLLAR'
        ? Number.isInteger(salesDiscount.discountValue)
          ? (salesDiscount.discountValue * 0.01).toFixed(2)
          : Number(salesDiscount.discountValue).toFixed(2)
        : salesDiscount.discountValue;

    const updatedBrandedDrugDiscountValue =
      brandedDrugDiscount.discountType && brandedDrugDiscount.discountType === 'DOLLAR'
        ? Number.isInteger(brandedDrugDiscount.discountValue)
          ? (brandedDrugDiscount.discountValue * 0.01).toFixed(2)
          : Number(brandedDrugDiscount.discountValue).toFixed(2)
        : brandedDrugDiscount.discountValue;

    const updatedGenericDrugDiscountValue =
      genericDrugDiscount.discountType && genericDrugDiscount.discountType === 'DOLLAR'
        ? Number.isInteger(genericDrugDiscount.discountValue)
          ? (genericDrugDiscount.discountValue * 0.01).toFixed(2)
          : Number(genericDrugDiscount.discountValue).toFixed(2)
        : genericDrugDiscount.discountValue;
    const mpFormGroup = this.formBuilder.group({
      allowedRelationship: [allowedRelationship],
      diagnosisIds: [diagnosisIds, filterDiagnosisCode === true ? Validators.required : null],
      capPerDay: this.formBuilder.group({
        visits: capPerDay.visits,
        limit: updatedCapPerDay,
      }),
      capPerLifeTime: this.formBuilder.group({
        visits: capPerLifeTime.visits,
        limit: updatedCapPerLifeTime,
      }),
      capPerMonth: this.formBuilder.group({
        visits: capPerMonth.visits,
        limit: updatedCapPerMonth,
      }),
      capPerVisit: this.formBuilder.group({
        visits: capPerVisit.visits,
        limit: updatedCapPerVisit,
      }),
      capPerWeek: this.formBuilder.group({
        visits: capPerWeek.visits,
        limit: updatedCapPerWeek,
      }),
      capPerYear: this.formBuilder.group({
        visits: capPerYear.visits,
        limit: updatedCapPerYear,
      }),
      clinicRemarks: [clinicRemarks],
      code: [code, valueTrimmedRequiredValidator()],
      copayment: this.formBuilder.group({
        paymentType: [copayment.paymentType],
        value: [updatedCopaymentValue],
      }),
      endDate: [endDate, valueTrimmedRequiredValidator()],
      excludeAllByDefault: [excludeAllByDefault],
      excludedClinics: [excludedClinics],
      filterDiagnosisCode: [filterDiagnosisCode],
      id: [id],
      limitResetType: [limitResetType, valueTrimmedRequiredValidator()],
      maximumNumberOfDiagnosisCodes: [maximumNumberOfDiagnosisCodes],
      minimumNumberOfDiagnosisCodes: [minimumNumberOfDiagnosisCodes],
      isDentalChas: [isDentalChas],
      isSflChas: [isSflChas],
      isPhpcChas: [isPhpcChas],
      name: [name, valueTrimmedRequiredValidator()],
      paymentRemarks: [paymentRemarks],
      registrationRemarks: [registrationRemarks],
      remarks: [remarks],
      salesDiscount: this.formBuilder.group({
        discountType: [salesDiscount.discountType],
        discountValue: [updatedSalesDiscountValue],
        remarks: [salesDiscount.remarks],
      }),
      brandedDrugDiscount: this.formBuilder.group({
        discountType: [brandedDrugDiscount.discountType],
        discountValue: [updatedBrandedDrugDiscountValue],
        remarks: [brandedDrugDiscount.remarks],
      }),
      genericDrugDiscount: this.formBuilder.group({
        discountType: [genericDrugDiscount.discountType],
        discountValue: [updatedGenericDrugDiscountValue],
        remarks: [genericDrugDiscount.remarks],
      }),
      startDate: [startDate, valueTrimmedRequiredValidator()],
      status: [status, valueTrimmedRequiredValidator()],
      planType: [planType],
      extraChargeAddOnAmount: [extraChargeAddOnAmount],
      usableOnTeleConsult: [usableOnTeleConsult],
      listOnTeleConsult: [listOnTeleConsult],
      teleConsultRemark: [teleConsultRemark],
      externalUniquePlanCode: [externalUniquePlanCode],
      allowSelectWithChasPlan: [allowSelectWithChasPlan],
    });

    return mpFormGroup;
  }

  generateMCItemFormArray(mcItems) {
    const mcItemsFormArray = [];
    mcItems.forEach((mcItem) => mcItemsFormArray.push(this.createMCItemFormGroup(mcItem)));
    return this.formBuilder.array(mcItemsFormArray);
  }

  createMCItemFormGroup({
    itemId = '',
    price = {
      price: 0,
      taxIncluded: false,
    },
  } = {}) {
    return this.formBuilder.group({
      itemId: itemId,
      price: this.formBuilder.group({
        price: price.price ?(price.price).toFixed(2)  : 0.0,
        taxIncluded: price.taxIncluded,
      }),
    });
  }

  generateMCExclusionFormArray(mcExclusions) {
    const mcExclusionsFormArray = [];
    mcExclusions.forEach((mcExclusion) => mcExclusionsFormArray.push(this.createMCExclusionFormGroup(mcExclusion)));
    if (!mcExclusionsFormArray.length) {
      mcExclusionsFormArray.push(this.createMCExclusionFormGroup());
    }
    return this.formBuilder.array(mcExclusionsFormArray);
  }

  createMCExclusionFormGroup({ exclusionType = '', value = '' } = {}) {
    return this.formBuilder.group({
      selected: [false],
      exclusionType: [exclusionType],
      value: [value],
    });
  }

  // Current Medical Coverage Store
  setLoadingState(loadingState) {
    this.currentMedicalCoverageStore.update({ loadingState });
  }

  setCurrentCompanyId(companyId) {
    this.currentMedicalCoverageStore.update({ currentCompanyId: companyId });
  }
  setCurrentPlanId(planId) {
    this.currentMedicalCoverageStore.update({ currentPlanId: planId });
  }
  setIsEditMode(mode) {
    this.currentMedicalCoverageStore.update({ isEdit: mode });
  }
  setIsEditPlanMode(mode) {
    this.currentMedicalCoverageStore.update({ isEditPlan: mode });
  }

  updateCompanySearchCode(code) {
    this.currentMedicalCoverageStore.update({ companySearchCompanyCode: code });
  }
  updateCompanySearchEndDate(endDate) {
    this.currentMedicalCoverageStore.update({ companySearchEndDate: endDate });
  }
  updateCompanySearchMedicalCoverageType(mct) {
    this.currentMedicalCoverageStore.update({ companySearchMedicalCoverageType: mct });
  }
  updateCompanySearchName(name) {
    this.currentMedicalCoverageStore.update({ companySearchCompanyName: name });
  }
  updateCompanySearchStartDate(startDate) {
    this.currentMedicalCoverageStore.update({ companySearchStartDate: startDate });
  }
  updateCompanySearchStatus(status) {
    this.currentMedicalCoverageStore.update({ companySearchStatus: status });
  }

  updatePlanSearchCode(code) {
    this.currentMedicalCoverageStore.update({ planSearchPlanCode: code });
  }
  updatePlanSearchEndDate(endDate) {
    this.currentMedicalCoverageStore.update({ planSearchEndDate: endDate });
  }
  updatePlanSearchName(name) {
    this.currentMedicalCoverageStore.update({ planSearchPlanName: name });
  }
  updatePlanSearchStartDate(startDate) {
    this.currentMedicalCoverageStore.update({ planSearchStartDate: startDate });
  }
  updatePlanSearchStatus(status) {
    this.currentMedicalCoverageStore.update({ planSearchStatus: status });
  }

  updateChargeItemAddedCodeName(codeName) {
    this.currentMedicalCoverageStore.update({ chargeItemAddedCodeName: codeName });
  }
  updateChargeItemAddedList(list) {
    this.currentMedicalCoverageStore.update({ chargeItemAddedList: list });
  }
  updateChargeItemCodeName(codeName) {
    this.currentMedicalCoverageStore.update({ chargeItemCodeName: codeName });
  }
  updateChargeItemType(itemType) {
    this.currentMedicalCoverageStore.update({ chargeItemType: itemType });
  }
  updateChargeItemAddedListFilter(filter) {
    this.currentMedicalCoverageStore.update({ chargeItemAddedListFilter: filter });
  }

  // Configuration etc.
  generateDefaultDatepickerConfig(minDate = undefined, maxDate = undefined) {
    const datepickerConfig = new BsDatepickerConfig();
    datepickerConfig.adaptivePosition = true;
    datepickerConfig.containerClass = 'theme-blue';
    datepickerConfig.dateInputFormat = 'DD-MM-YYYY';
    if (minDate) datepickerConfig.minDate = minDate;
    if (maxDate) datepickerConfig.maxDate = maxDate;

    return datepickerConfig;
  }

  // External API Calls
  createMedicalCoverage(medicalCoverageValue) {
    return this.apiCmsManagementService.addMedicalCoverage(medicalCoverageValue).pipe(
      mergeMap((res) => combineLatest(of(res), this.akitaMedicalCoverageService.getMedicalCoverageList())),
      map((res) => res[0]),
      tap((res) => {
        if (res.payload) {
          this.setCurrentCompanyId(res.payload.id);
          this.setIsEditMode(true);
        }
      })
    );
  }

  editMedicalCoverage(medicalCoverageValue, reload = true) {
    return this.apiCmsManagementService.modifyMedicalCoverage(medicalCoverageValue.id, medicalCoverageValue).pipe(
      mergeMap((res) => this.akitaMedicalCoverageService.getMedicalCoverageList().pipe(map((data) => res))),
      tap((res) => {
        if (res.payload) {
          if (reload) {
            this.setCurrentCompanyId(res.payload.id);
            this.setIsEditMode(true);
          }
        }
      })
    );
  }

  createMedicalCoveragePlan(medicalCoverageId, medicalCoveragePlanValue) {
    return this.apiCmsManagementService.addMedicalCoveragePlan(medicalCoverageId, medicalCoveragePlanValue).pipe(
      mergeMap((res) => combineLatest(of(res), this.akitaMedicalCoverageService.getMedicalCoverageList())),
      map((res) => res[0]),
      map((res) => {
        this.setLoadingState(false);
        if (res.payload && res.payload.coveragePlans) {
          this.setCurrentPlanId(
            res.payload.coveragePlans.find((item) => item.code === medicalCoveragePlanValue.code).id
          );
          this.setIsEditPlanMode(true);
        }

        return res;
      })
    );
  }

  editMedicalCoveragePlan(medicalCoverageId, medicalCoveragePlanValue, reload = true) {
    return this.apiCmsManagementService
      .modifyMedicalCoveragePlan(medicalCoverageId, medicalCoveragePlanValue.id, medicalCoveragePlanValue)
      .pipe(
        tap((data) => this.setLoadingState(false)),
        mergeMap((res) => combineLatest(of(res), this.akitaMedicalCoverageService.getMedicalCoverageList())),
        map((res) => {
          if (res[0].payload) {
            if (reload) {
              this.setCurrentPlanId(
                res[0].payload.coveragePlans.find((item) => item.code === medicalCoveragePlanValue.code).id
              );
              this.setIsEditPlanMode(true);
            }
          }

          return res;
        })
      );
  }

  modifyMedicalCoverageItem(medicalCoverageId, planId, medicalCoverageItems) {
    return this.apiCmsManagementService.addMedicalCoverageItems(medicalCoverageId, planId, medicalCoverageItems);
  }

  modifyMedicalCoverageExclusion(medicalCoverageId, planId, medicalCoverageExclusions) {
    return this.apiCmsManagementService.addMedicalCoverageExclusions(
      medicalCoverageId,
      planId,
      medicalCoverageExclusions
    );
  }
}
