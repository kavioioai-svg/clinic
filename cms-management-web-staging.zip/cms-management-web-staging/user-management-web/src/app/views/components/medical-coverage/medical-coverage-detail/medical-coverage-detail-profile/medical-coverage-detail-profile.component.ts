import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { BsDatepickerConfig } from 'ngx-bootstrap';
import * as moment from 'moment';
import { cloneDeep } from 'lodash';
import { AlertService } from '../../../../../services/alert.service';
import { CurrentMedicalCoverageQuery } from '../../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../../current-medical-coverage.service';
import {LogoFileDbData, MedicalCoverage} from '../../../../../objects/MedicalCoverage';
import {UploadFile} from '../../../../../objects/File';
import {ClinicQuery} from '../../../../../state/clinic/clinic.query';
import {StoreService} from '../../../../../services/store.service';
import {MedicalCoverageTab} from "../../../../../model/enum/enums";

@Component({
  selector: 'app-medical-coverage-detail-profile',
  templateUrl: './medical-coverage-detail-profile.component.html',
  styleUrls: ['./medical-coverage-detail-profile.component.scss'],
})
export class MedicalCoverageDetailProfileComponent implements OnInit {
  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  @Input('medicalCoverageFormGroup') medicalCoverageFormGroup: FormGroup;
  @Input('medicalCoveragePlanValidationFormGroup') medicalCoveragePlanValidationFormGroup: FormGroup;
  @Input('currentMedicalCoverageFormGroup') currentMedicalCoverageFormGroup: FormGroup;

  endDateBsConfig: BsDatepickerConfig;
  startDateBsConfig: BsDatepickerConfig;
  clinics: any[] = [];
  logoFiles: any[] = [];
  action: string;

  constructor(
    private alertService: AlertService,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private router: Router,
    private clinicQuery: ClinicQuery,
    private StoreService: StoreService,
    private route: ActivatedRoute,
  ) {}

  ngOnInit() {
    if ((this.medicalCoverageFormGroup.get('costCenters') as FormArray).length === 0) this.addCostCentre();
    if ((this.medicalCoverageFormGroup.get('contacts') as FormArray).length === 0) this.addContacts();
    if ((this.medicalCoverageFormGroup.get('projects') as FormArray).length === 0) this.addProject();

    this.endDateBsConfig = this.medicalCoverageService.generateDefaultDatepickerConfig();
    this.startDateBsConfig = this.medicalCoverageService.generateDefaultDatepickerConfig();

    this.currentMedicalCoverageQuery
      .select((entity) => entity.isEdit)
      .subscribe((isEdit) => {
        if (isEdit) {
          this.medicalCoverageFormGroup.get('code').disable({ onlySelf: true, emitEvent: false });
        } else {
          this.medicalCoverageFormGroup.get('code').enable({ onlySelf: true, emitEvent: false });
        }
      });

    this.medicalCoverageFormGroup.get('startDate').valueChanges.subscribe((val) => {
      if (val) this.endDateBsConfig.minDate = moment(val).add(1, 'd').toDate();
      else this.endDateBsConfig.minDate = undefined;
    });

    this.medicalCoverageFormGroup.get('endDate').valueChanges.subscribe((val) => {
      if (val) this.startDateBsConfig.maxDate = moment(val).subtract(1, 'd').toDate();
      else this.startDateBsConfig.maxDate = undefined;
    });
    this.clinics = this.clinicQuery.getAll();
    this.dateSubscription();

    this.route.params.subscribe(params => {
      if(this.isEdit()){
        this.action = 'edit';
      }else{
        this.action = 'create';
      }
      
    });
  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select((entity) => entity.loadingState);
  }

  getBooleanTypeList() {
    return this.medicalCoverageService.medicalCoverageBooleanSelection;
  }

  getMedicalCoverageTypeList() {
    return this.medicalCoverageService.medicalCoverageTypes;
  }

  getStatusTypeList() {
    return this.medicalCoverageService.medicalCoveragePlanStatus;
  }

  isEdit() {
    return this.currentMedicalCoverageQuery.getValue().isEdit;
  }

  dateSubscription() {
    this.medicalCoverageFormGroup.get('startDate').valueChanges.subscribe((startDate) => {
      const minEndDate = moment(startDate).add(1, 'd');
      this.endDateBsConfig.minDate = minEndDate.toDate();
    });

    this.medicalCoverageFormGroup.get('endDate').valueChanges.subscribe((endDate) => {
      const maxStartDate = moment(endDate).subtract(1, 'd');
      this.startDateBsConfig.maxDate = maxStartDate.toDate();
    });
  }

  addContacts() {
    (this.medicalCoverageFormGroup.get('contacts') as FormArray).push(
      this.medicalCoverageService.createContactFormGroup()
    );
  }

  deleteContacts(index) {
    (this.medicalCoverageFormGroup.get('contacts') as FormArray).removeAt(index);
  }

  addCostCentre() {
    (this.medicalCoverageFormGroup.get('costCenters') as FormArray).push(
      this.medicalCoverageService.createCostCentreFormGroup()
    );
  }

  deleteCostCentre(index) {
    (this.medicalCoverageFormGroup.get('costCenters') as FormArray).removeAt(index);
  }

  addProject() {
    (this.medicalCoverageFormGroup.get('projects') as FormArray).push(
      this.medicalCoverageService.createProjectFormGroup()
    );
  }

  deleteProject(index) {
    (this.medicalCoverageFormGroup.get('projects') as FormArray).removeAt(index);
  }

   reloadMedicalCoverageDetail(isEdit = false) {
    if (isEdit) this.alertService.success('Medical Coverage information updated successfully.', true);
    else this.alertService.success('Medical Coverage created successfully.', true);
     this.StoreService.retrieveMedicalCoverage()

     this.router.navigate([`/pages/medical-coverage/detail/edit/${MedicalCoverageTab.PROFILE_TAB}`]);
    return false;
  }

  onSaveMedicalCoverage() {
    this.medicalCoverageService.setLoadingState(true);

    //Remove any empty forms within the form array
    (<FormArray>this.medicalCoverageFormGroup.get('contacts')).controls.forEach((contact, index) => {
      if (this.medicalCoverageService.isContactFormGroupEmpty(contact)) this.deleteContacts(index);
    });

    (<FormArray>this.medicalCoverageFormGroup.get('costCenters')).controls.forEach((costCenter, index) => {
      if (this.medicalCoverageService.isCostCentreFormGroupEmpty(costCenter)) this.deleteCostCentre(index);
    });

    (<FormArray>this.medicalCoverageFormGroup.get('projects')).controls.forEach((project, index) => {
      if (this.medicalCoverageService.isProjectFormGroupEmpty(project)) this.deleteProject(index);
    });

    const mcFormGroupValue = <MedicalCoverage>this.medicalCoverageFormGroup.getRawValue();
    const mcPlanValidationFormGroupValue = <MedicalCoverage>this.medicalCoveragePlanValidationFormGroup.getRawValue();
    if (mcFormGroupValue.allowedAccessLevel.length < 1) mcFormGroupValue.allowedAccessLevel = ['ALL_ACCESS'];
    mcFormGroupValue.costCenters = mcFormGroupValue.costCenters.map((item) => item.costCentre);

    if (typeof mcFormGroupValue.startDate === 'object')
      mcFormGroupValue.startDate = moment(new Date(mcFormGroupValue.startDate)).format('DD-MM-YYYY');
    if (mcFormGroupValue.endDate) {
      if (typeof mcFormGroupValue.endDate === 'object')
        mcFormGroupValue.endDate = moment(new Date(mcFormGroupValue.endDate)).format('DD-MM-YYYY');
    }

    mcFormGroupValue.creditTerms = mcFormGroupValue.creditTerms ? Number(mcFormGroupValue.creditTerms) : 0;

    mcPlanValidationFormGroupValue.coveragePlans.forEach((plan, index) => {
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerDay.limit = Number(plan.capPerDay.limit);
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerLifeTime.limit = Number(plan.capPerLifeTime.limit);
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerMonth.limit = Number(plan.capPerMonth.limit);
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerVisit.limit = Number(plan.capPerVisit.limit);
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerWeek.limit = Number(plan.capPerWeek.limit);
      mcPlanValidationFormGroupValue.coveragePlans[index].capPerYear.limit = Number(plan.capPerYear.limit);

      if (plan.copayment && plan.copayment.value)
        mcPlanValidationFormGroupValue.coveragePlans[index].copayment.value = Number(plan.copayment.value);
      if (plan.salesDiscount && plan.salesDiscount.discountValue)
        mcPlanValidationFormGroupValue.coveragePlans[index].salesDiscount.discountValue = Number(plan.salesDiscount.discountValue);
    });

    if (this.currentMedicalCoverageQuery.getValue().isEdit) {
      mcFormGroupValue.coveragePlans = [];
      this.medicalCoverageService.editMedicalCoverage(mcFormGroupValue).subscribe(
        (res) => {
          this.medicalCoverageService.setLoadingState(false);
          if (res.payload) this.reloadMedicalCoverageDetail(true);
        },
        (err) => {
          this.medicalCoverageService.setLoadingState(false);
          this.alertService.error('Error editing Medical Coverage information.');
        }
      );
    } else {
      mcFormGroupValue.medicalCoverageExtraDetail.logoFileDbData = this.addCompanyLogo(mcFormGroupValue);
      this.medicalCoverageService.createMedicalCoverage(mcFormGroupValue).subscribe(
        (res) => {
          this.medicalCoverageService.setLoadingState(false);
          if (res.payload) {
            this.reloadMedicalCoverageDetail();
            // this.medicalCoverageFormGroup.reset();
          }
        },
        (err) => {
          this.medicalCoverageService.setLoadingState(false);
          this.alertService.error('Error creating Medical Coverage.');
        }
      );
    }
  }

  getPersonTitleType() {
    return this.medicalCoverageService.personTitle;
  }

  uploadFile($event: any , newIndex?: number) {
    let index ;
    if($event.deletedId ) {
      if( this.logoFiles.length > 0) {
        let index = $event.index ? $event.index : this.logoFiles.findIndex(file => file.id === $event.deletedId);
        if(index >= 0)
           this.getLogo.removeAt(index)
        }
    } else if($event.index ){
        this.getLogo.removeAt($event.index);
        let data = this.getLogo.getRawValue();
        this.medicalCoverageFormGroup.patchValue({
          medicalCoverageExtraDetail: {
            logoFileDbData: data
          }
        });
    } else {
      this.logoFiles.push(new UploadFile($event));
      if(this.isEdit()) {
        let logo = this.getLogo.getRawValue();
        logo[$event.newIndex].base64Str = $event.base64Str;
        logo[$event.newIndex].fileName = $event.fileName;
        logo[$event.newIndex].type = $event.type;
        logo[$event.newIndex].size = $event.size;

        this.medicalCoverageFormGroup.patchValue({
          medicalCoverageExtraDetail: {
            logoFileDbData: logo
          }
        });
      }
    }

    if(this.logoFiles && this.logoFiles.length > 0) {
      if(this.isEdit()) {

      } else {
        this.medicalCoverageFormGroup.patchValue({
          medicalCoverageExtraDetail: {
            logoFileDbData: this.logoFiles
          }
        });
      }
    }
  }

  get medicalCoverageExtraDetail(): FormArray {
    return this.medicalCoverageFormGroup.get('medicalCoverageExtraDetail') as FormArray;
  }
  get getLogo(): FormArray {
    return this.medicalCoverageExtraDetail.get('logoFileDbData') as FormArray;
  }

  addMoreLogo() {
    this.getLogo.push(this.medicalCoverageService.getLogoFileDbDataFormGroup())
  }

  deleteLogo(i: number) {
    this.getLogo.removeAt(i);
  }

   addCompanyLogo(mcFormGroupValue , isEdit = false) {
    let extraDetails: any = this.medicalCoverageExtraDetail.getRawValue();
    if(isEdit) {
      extraDetails.logoFileDbData.forEach(r => {
        mcFormGroupValue.medicalCoverageExtraDetail.logoFileDbData.push(r)
      });
    } else {
      mcFormGroupValue.medicalCoverageExtraDetail.logoFileDbData = [];
       extraDetails.logoFileDbData.forEach((r:any , index: number) => {
        mcFormGroupValue.medicalCoverageExtraDetail.logoFileDbData.push(r);
      });
    }
     return mcFormGroupValue.medicalCoverageExtraDetail.logoFileDbData
  }

  showMobileValidationError(value: any, i: number): string {
    if (!value) return '';
    if (value["vaildContactNumber"]) {
      return 'Contact Number is invalid'
    }
    return ''
  }
}

