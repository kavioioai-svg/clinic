import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageDetailComponent } from './medical-coverage-detail.component';

describe('MedicalCoverageDetailComponent', () => {
  let component: MedicalCoverageDetailComponent;
  let fixture: ComponentFixture<MedicalCoverageDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
