import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageMedicalPlanComponent } from './medical-coverage-medical-plan.component';

describe('MedicalCoverageMedicalPlanComponent', () => {
  let component: MedicalCoverageMedicalPlanComponent;
  let fixture: ComponentFixture<MedicalCoverageMedicalPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageMedicalPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageMedicalPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
