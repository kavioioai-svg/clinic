import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { adjustDownPrice } from '../../../../../services/utils.service';
import { AlertService } from '../../../../../services/alert.service';
import { CurrentMedicalCoverageQuery } from '../../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../../current-medical-coverage.service';
import { StoreStatusService } from '../../../../../state/store-status/store-status.service';
import {MedicalPlanTab,TemplateFucType} from "../../../../../model/enum/enums";

@Component({
  selector: 'app-medical-coverage-detail-plan',
  templateUrl: './medical-coverage-detail-plan.component.html',
  styleUrls: ['./medical-coverage-detail-plan.component.scss']
})
export class MedicalCoverageDetailPlanComponent implements OnInit {

  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  @Input('medicalCoverageFormGroup') medicalCoverageFormGroup: FormGroup

  listingSearchFormGroup: FormGroup;
  ngSelectValue = [];
  actionDropdown: Array<string> = [];

  actionButtonList = [
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
  ];

  constructor(
    private alertService: AlertService,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private router: Router,
    private storeStatusService: StoreStatusService
  ) { }

  ngOnInit() {
    this.listingSearchFormGroup = this.medicalCoverageService.createMedicalPlanSearchFormGroup();

    this.listingSearchFormGroup.valueChanges.subscribe(a=>{
      if (this.isStartDateGreaterThanEndDate(a)) {
        this.alertService.error('Start date must be less than or equal to end date');
      }
    })

    this.listingSearchFormGroup.get('medicalPlanCode').valueChanges.subscribe(planCode =>
      this.medicalCoverageService.updatePlanSearchCode(planCode));

    this.listingSearchFormGroup.get('medicalPlanName').valueChanges.subscribe(planName =>
      this.medicalCoverageService.updatePlanSearchName(planName));

    this.listingSearchFormGroup.get('startDate').valueChanges.subscribe(startDate =>
      this.medicalCoverageService.updatePlanSearchStartDate(startDate));

    this.listingSearchFormGroup.get('endDate').valueChanges.subscribe(endDate =>
      this.medicalCoverageService.updatePlanSearchEndDate(endDate));

    this.listingSearchFormGroup.get('status').valueChanges.subscribe((status) => {
      if(status === 'ALL'){
        status = '';
      }
      this.medicalCoverageService.updatePlanSearchStatus(status);
    })
  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select(entity => entity.loadingState);
  }

  getMedicalCoverageTypeList() {
    return this.medicalCoverageService.medicalCoverageStatus;
  }

  getMedicalCoverageStatusList() {
    return this.medicalCoverageService.medicalCoverageStatus;
  }

  selectMedicalCoveragePlanList() {
    return this.currentMedicalCoverageQuery.selectMedicalCoveragePlanList();
  }

  onChange($event, row) {
    console.log(111,row.endDate)
    this.medicalCoverageService.setLoadingState(true);

    const rowValue = { ...row };
    rowValue.status = ($event === 'ACTIVE') ? 'ACTIVE' : 'INACTIVE';

    const endDate = new Date(row.endDate);
    const today = new Date();
    if (endDate.getTime() < today.getTime()) {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.error(`Error: Medical Coverage Plan "${row.name} is expired"`);
      this.ngSelectValue = [];
      return;
    }

    this.medicalCoverageService.editMedicalCoveragePlan(this.currentMedicalCoverageQuery.getValue().currentCompanyId, rowValue, false).subscribe(res => {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.success(`Medical Coverage Plan "${row.name}" status has been changed to ${$event === 'ACTIVE' ? 'active' : 'inactive'}`);
      this.ngSelectValue = [];
    }, err => {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.success(`Error changing status for the Medical Coverage Plan "${row.name}"`);
      this.ngSelectValue = [];
    });
  }

  getProperValue(type, value) {
    return value ? adjustDownPrice(value) : '-';
  }

  redirectToMedicalPlan($event, row) {
    this.medicalCoverageService.setIsEditPlanMode(true);
    this.medicalCoverageService.setCurrentPlanId(row.id);
    this.clearFilters();
    this.storeStatusService.setLoadingStatus(false);
    this.router.navigate([`/pages/medical-coverage/plan/${$event.toLocaleLowerCase()}/${MedicalPlanTab.MEDICAL_PLAN_TAB}/`]);
    return false;
  }

  clearFilters() {
    this.medicalCoverageService.updatePlanSearchCode('');
    this.medicalCoverageService.updatePlanSearchName('');
    this.medicalCoverageService.updatePlanSearchStartDate('');
    this.medicalCoverageService.updatePlanSearchEndDate('');
    this.medicalCoverageService.updatePlanSearchStatus('');
  }
  get TemplateFucType() {
    return TemplateFucType
  }

  isStartDateGreaterThanEndDate(formValues): boolean {
    const startDate = new Date(formValues.startDate);
    const endDate = new Date(formValues.endDate);
    return (startDate > endDate) && (formValues.endDate !== '');
  }

}
