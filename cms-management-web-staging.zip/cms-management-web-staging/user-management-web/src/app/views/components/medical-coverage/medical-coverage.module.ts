import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ContentLoaderModule } from '@ngneat/content-loader';

import { CurrentMedicalCoverageService } from './current-medical-coverage.service';
import { MedicalCoverageDetailComponent } from './medical-coverage-detail/medical-coverage-detail.component';
import { MedicalCoverageDetailPlanComponent } from './medical-coverage-detail/medical-coverage-detail-plan/medical-coverage-detail-plan.component';
import { MedicalCoverageDetailProfileComponent } from './medical-coverage-detail/medical-coverage-detail-profile/medical-coverage-detail-profile.component';
import { MedicalCoverageListingComponent } from './medical-coverage-listing/medical-coverage-listing.component';
import { MedicalCoverageRoutingModule } from './medical-coverage-routing.module';
import { MedicalCoveragePlanComponent } from './medical-coverage-plan/medical-coverage-plan.component';
import { MedicalCoverageMedicalPlanComponent } from './medical-coverage-plan/medical-coverage-medical-plan/medical-coverage-medical-plan.component';
import { MedicalCoverageItemPriceComponent } from './medical-coverage-plan/medical-coverage-item-price/medical-coverage-item-price.component';
import { MedicalCoverageExcludedItemComponent } from './medical-coverage-plan/medical-coverage-excluded-item/medical-coverage-excluded-item.component';
import { SharedModule } from '../../../shared.module';
import { SelectListModule } from '../../../components/select-list/select-list.module';
import { DialogService } from '../../../services/dialog.service';
import { StoreStatusService } from '../../../state/store-status/store-status.service';
import { CurrentMedicalCoverageQuery } from './state/current-medical-coverage.query';

@NgModule({
  declarations: [
    MedicalCoverageDetailComponent,
    MedicalCoverageDetailPlanComponent,
    MedicalCoverageDetailProfileComponent,
    MedicalCoverageListingComponent,
    MedicalCoveragePlanComponent,
    MedicalCoverageMedicalPlanComponent,
    MedicalCoverageItemPriceComponent,
    MedicalCoverageExcludedItemComponent ],
  imports: [ ContentLoaderModule, CommonModule, MedicalCoverageRoutingModule, SelectListModule, SharedModule ],
  providers: [ CurrentMedicalCoverageService,DialogService,StoreStatusService,CurrentMedicalCoverageQuery ]
})
export class MedicalCoverageModule { }
