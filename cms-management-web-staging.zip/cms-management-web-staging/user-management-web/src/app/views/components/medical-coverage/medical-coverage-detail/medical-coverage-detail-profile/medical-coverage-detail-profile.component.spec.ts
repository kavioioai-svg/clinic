import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageDetailProfileComponent } from './medical-coverage-detail-profile.component';

describe('MedicalCoverageDetailProfileComponent', () => {
  let component: MedicalCoverageDetailProfileComponent;
  let fixture: ComponentFixture<MedicalCoverageDetailProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageDetailProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageDetailProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
