import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageDetailPlanComponent } from './medical-coverage-detail-plan.component';

describe('MedicalCoverageDetailPlanComponent', () => {
  let component: MedicalCoverageDetailPlanComponent;
  let fixture: ComponentFixture<MedicalCoverageDetailPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageDetailPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageDetailPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
