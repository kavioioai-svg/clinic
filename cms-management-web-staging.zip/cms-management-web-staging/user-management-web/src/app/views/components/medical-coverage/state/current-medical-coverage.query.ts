import { Injectable } from '@angular/core';

import { combineLatest, of } from 'rxjs';
import { map, mergeMap, withLatestFrom, tap, filter } from 'rxjs/operators';
import { Query } from '@datorama/akita';
import * as moment from 'moment';

import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { ChargeItem } from '../../../../objects/ChargeItem';
import { ChargeItemQuery } from '../../../../state/charge-item/charge-item.query';
import { CurrentMedicalCoverageState, CurrentMedicalCoverageStore } from './current-medical-coverage.store';
import { MedicalCoverageQuery } from '../../../../state/medical-coverage/medical-coverage.query';
import { StoreStatusService } from '../../../../state/store-status/store-status.service';

@Injectable({ providedIn: 'root' })
export class CurrentMedicalCoverageQuery extends Query<CurrentMedicalCoverageState> {

  loadingState$ = this.select(entity => entity.loadingState);
  constructor(
    private apiCmsManagementService: ApiCmsManagementService,
    private chargeItemQuery: ChargeItemQuery,
    private medicalCoverageQuery: MedicalCoverageQuery,
    protected store: CurrentMedicalCoverageStore,
    private storeStatusService: StoreStatusService
  ) { super(store) }

  selectFilteredCompany() {
    return combineLatest(
      this.select(entity => entity.companySearchCompanyCode),
      this.select(entity => entity.companySearchCompanyName),
      this.select(entity => entity.companySearchMedicalCoverageType),
      this.select(entity => entity.companySearchStartDate),
      this.select(entity => entity.companySearchEndDate),
      this.select(entity => entity.companySearchStatus),
      this.medicalCoverageQuery.selectAll(),
      this.selectLoading()
    ).pipe(
      map(data => {
        if (!data[7]) {
          const searchCode = (data[0] && data[0].length > 0 ? data[0] : '').toLowerCase();
          const searchName = (data[1] && data[1].length > 0 ? data[1] : '').toLowerCase();
          const searchMedicalCoverageType = data[2] || '';
          const searchStartDate = data[3] ? moment(data[3], 'DD-MM-YYYY') : undefined;
          const searchEndDate = data[4] ? moment(data[4], 'DD-MM-YYYY') : undefined;
          const searchStatus = (data[5] && data[5].length > 0 ? data[5] : '').toLowerCase();

          const searchList = data[6].filter(coverage => {

            const matchingCode = searchCode.length > 0 ? (coverage.code ? coverage.code.toLowerCase().includes(searchCode) : false) : true;
            const matchingName = searchName.length > 0 ? coverage.name.toLowerCase().includes(searchName) : true;
            const matchingMedicalCoverageType = searchMedicalCoverageType.length > 0 ? searchMedicalCoverageType.includes(coverage.type) : true;
            const withinStartDate = searchStartDate ? moment(coverage.startDate, 'DD-MM-YYYY').isSameOrAfter(searchStartDate) : true;
            const withinEndDate = searchEndDate ? moment(coverage.endDate, 'DD-MM-YYYY').isSameOrBefore(searchEndDate) : true;
            const matchingStatus = searchStatus ? searchStatus === coverage.status.toLowerCase() : true;

            return matchingCode && matchingName && matchingMedicalCoverageType && withinStartDate && withinEndDate && matchingStatus;
          });

          return searchList;
        } else {
          return data[6];
        }
      })
    )
  }

  selectMedicalCoveragePlanList() {
    return combineLatest(
      this.select(entity => entity.planSearchPlanCode),
      this.select(entity => entity.planSearchPlanName),
      this.select(entity => entity.planSearchStartDate),
      this.select(entity => entity.planSearchEndDate),
      this.select(entity => entity.planSearchStatus),
      this.selectCompanyById('coveragePlans'),
      this.selectLoading()
    ).pipe(
      map(data => {
        if (!data[6]) {
          const searchCode = (data[0] && data[0].length > 0 ? data[0] : '').toLowerCase();
          const searchName = (data[1] && data[1].length > 0 ? data[1] : '').toLowerCase();
          const searchStartDate = data[2] ? moment(data[2], 'DD-MM-YYYY') : undefined;
          const searchEndDate = data[3] ? moment(data[3], 'DD-MM-YYYY') : undefined;
          const searchStatus = (data[4] && data[4].length > 0 ? data[4] : '').toLowerCase();

          const searchList = data[5].filter(coverage => {
            const matchingCode = searchCode.length > 0 ? (coverage.code ? coverage.code.toLowerCase().includes(searchCode) : false) : true;
            const matchingName = searchName.length > 0 ? coverage.name.toLowerCase().includes(searchName) : true;
            const withinStartDate = searchStartDate ? moment(coverage.startDate, 'DD-MM-YYYY').isSameOrAfter(searchStartDate) : true;
            const withinEndDate = searchEndDate ? moment(coverage.endDate, 'DD-MM-YYYY').isSameOrBefore(searchEndDate) : true;
            const matchingStatus = searchStatus ? searchStatus === coverage.status.toLowerCase() : true;

            return matchingCode && matchingName && withinStartDate && withinEndDate && matchingStatus;
          });

          return searchList;
        } else {
          return data[5];
        }
      })
    )
  }

  selectCompanyById(property?) {
    return this.select(entity => entity.currentCompanyId).pipe(
      mergeMap(currentCompanyId => this.medicalCoverageQuery.selectEntity(currentCompanyId)),
      map(data => data && property ? data[property] : data)
    );
  }

  getCompanyById(property?) {
    return property ? this.medicalCoverageQuery.getEntity(this.getValue().currentCompanyId)[property] :
      this.medicalCoverageQuery.getEntity(this.getValue().currentCompanyId);
  }

  selectCompanyPlanById() {
    return this.select(entity => entity.currentPlanId).pipe(
      withLatestFrom(this.select(entity => entity.currentCompanyId)),
      mergeMap(ids => this.medicalCoverageQuery.selectEntity(ids[1]).pipe(map(data => data.coveragePlans.find(plan => plan.id === data[0]))))
    );
  }

  getCompanyPlanById() {
    if (this.getCompanyById('coveragePlans')) return this.getCompanyById('coveragePlans').find(plan => plan.id === this.getValue().currentPlanId);
    return null;
  }

  selectMedicalCoverageItemList() {
    return combineLatest(
      this.select(entity => entity.currentCompanyId),
      this.select(entity => entity.currentPlanId)
    ).pipe(
      tap(data => console.log(data)),
      mergeMap(ids => this.apiCmsManagementService.searchMedicalCoverageItems(ids[0], ids[1]))
    );
  }

  selectMedicalCoverageExclusionList() {
    return this.select(entity => entity.currentPlanId).pipe(
      withLatestFrom(this.select(entity => entity.currentCompanyId)),
      mergeMap(ids => this.apiCmsManagementService.searchMedicalCoverageExclusions(ids[1], ids[0]))
    );
  }

  selectChargeItem() {
    return combineLatest(
      this.select(entity => entity.chargeItemCodeName),
      this.select(entity => entity.chargeItemType),
      this.select(entity => entity.chargeItemAddedList)
    ).pipe(
      map(data => {
        const searchCodeName = data[0] && data[0].length > 0 ? data[0].toLowerCase() : '';
        const searchItemType = data[1] && data[1].length > 0 ? data[1].toLowerCase() : '';
        const chargeItemAddedList = data[2];

        return [searchCodeName, searchItemType, chargeItemAddedList];
      }),
      mergeMap(data => {
        const value = this.chargeItemQuery.selectAll({
          filterBy: (entity: ChargeItem) => {
            const searchCodeName = <string>data[0];
            const searchItemType = <string>data[1];
            const chargeItemAddedSet = new Set(data[2]);

            return !chargeItemAddedSet.has(entity.id) && (searchItemType ? entity.itemType.toLowerCase() === searchItemType : true) && entity.name.toLowerCase().includes(searchCodeName);
          }
        });

        this.storeStatusService.setLoadingStatus(true);
        return value;
      })
    );
  }

  selectAddedChargeItem() {
    return combineLatest(
      this.select(entity => entity.chargeItemAddedCodeName),
      this.select(entity => entity.chargeItemAddedList)
    ).pipe(
      mergeMap(data => {
        return this.chargeItemQuery.selectAll({
          filterBy: (entity: ChargeItem) => {
            const searchCodeName = <string>data[0];
            const chargeItemAddedSet = new Set(data[1]);

            return entity.name.toLowerCase().includes(searchCodeName) && chargeItemAddedSet.has(entity.id);
          }
        });
      })
    );
  }

  selectAddedChargeItemTable() {
    return combineLatest(
      this.select(entity => entity.chargeItemAddedListFilter).pipe(map(data => data && data.length > 0 ? data.toLowerCase() : '')),
      this.select(entity => entity.chargeItemAddedList).pipe(map(data => new Set(data)))
    ).pipe(
      mergeMap(data => this.chargeItemQuery.selectAll({ filterBy: entity => data[1].has(entity.id) && (entity.name.toLowerCase().includes(data[0]) || entity.code.toLowerCase().includes(data[0])) }))
    );
  }

}
