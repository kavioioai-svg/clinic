import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';

import { AkitaNgFormsManager } from '@datorama/akita-ng-forms-manager';
import { Observable } from 'rxjs';

import { CurrentMedicalCoverageQuery } from '../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../current-medical-coverage.service';
import { DialogService } from '../../../../services/dialog.service';
import { StoreStatusService } from '../../../../state/store-status/store-status.service';
import { MedicalCoverageTab, MedicalPlanTab} from "../../../../model/enum/enums";

@Component({
  selector: 'app-medical-coverage-detail',
  templateUrl: './medical-coverage-detail.component.html',
  styleUrls: ['./medical-coverage-detail.component.scss']
})
export class MedicalCoverageDetailComponent implements OnDestroy, OnInit {

  medicalCoverageFormGroup: FormGroup
  medicalCoveragePlanValidationFormGroup: FormGroup
  actionIndex: number;

  constructor(
    private akitaNgFormsManager: AkitaNgFormsManager,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private dialogService: DialogService,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private router: Router,
    private storeStatusService: StoreStatusService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnDestroy() {
    this.akitaNgFormsManager.unsubscribe();
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.actionIndex = params['tabIndex'];
    });
    if (this.akitaNgFormsManager.getForm('medicalCoverage')) this.akitaNgFormsManager.remove('medicalCoverage');
    if (this.akitaNgFormsManager.getForm('medicalCoveragePlanValidation')) this.akitaNgFormsManager.remove('medicalCoveragePlanValidation');

    if (this.isEdit()) this.medicalCoverageFormGroup = this.medicalCoverageService.createMedicalCoverageFormGroup(this.currentMedicalCoverageQuery.getCompanyById(), this.akitaNgFormsManager);
    else this.medicalCoverageFormGroup = this.medicalCoverageService.createMedicalCoverageFormGroup({}, this.akitaNgFormsManager);

    if (this.isEdit()) this.medicalCoveragePlanValidationFormGroup = this.medicalCoverageService.createMedicalCoveragePlanValidationFormGroup(this.currentMedicalCoverageQuery.getCompanyById(), this.akitaNgFormsManager);
    else this.medicalCoveragePlanValidationFormGroup = this.medicalCoverageService.createMedicalCoveragePlanValidationFormGroup({}, this.akitaNgFormsManager);
  }

  canDeactivate(): Observable<boolean> | boolean {
    if (this.medicalCoverageFormGroup.dirty) return this.dialogService.confirm('There are unsaved changes. Leave this page?');
    return true;
  }

  isEdit() {
    return this.currentMedicalCoverageQuery.getValue().isEdit;
  }

  invalidPlans() {
    const invalidPlans = [];

    (<FormArray> this.medicalCoveragePlanValidationFormGroup.get('coveragePlans')).controls.forEach(formGroup => {
      if (formGroup.invalid) invalidPlans.push(formGroup.get('code').value + ' - ' + formGroup.get('name').value);
    });

    let invalidPlansString = '';
    invalidPlans.forEach((value, index) => {
      invalidPlansString = invalidPlansString.concat(value, (index === invalidPlans.length - 1) ? '' : ', ');
    });

    return invalidPlansString;
  }

  createNewMedicalPlan() {
    this.medicalCoverageService.setIsEditPlanMode(false);
    this.medicalCoverageService.setCurrentPlanId('');
    this.clearFilters();

    this.storeStatusService.setLoadingStatus(false);
    this.router.navigate([`/pages/medical-coverage/plan/edit/${MedicalPlanTab.MEDICAL_PLAN_TAB}/`]);
    return false;
  }

  redirectToCompanyListing() {
    this.router.navigate(['/pages/medical-coverage/all']);
    this.clearFilters();
    return false;
  }

  clearFilters() {
    this.medicalCoverageService.updatePlanSearchCode('');
    this.medicalCoverageService.updatePlanSearchName('');
    this.medicalCoverageService.updatePlanSearchStartDate('');
    this.medicalCoverageService.updatePlanSearchEndDate('');
    this.medicalCoverageService.updatePlanSearchStatus('');
  }
  get MedicalCoverageTab() {
    return MedicalCoverageTab;
  }
  onTabSelected(tab: MedicalCoverageTab) {
    this.router.navigate([`/pages/medical-coverage/detail/edit/${tab}`]);
  }

}
