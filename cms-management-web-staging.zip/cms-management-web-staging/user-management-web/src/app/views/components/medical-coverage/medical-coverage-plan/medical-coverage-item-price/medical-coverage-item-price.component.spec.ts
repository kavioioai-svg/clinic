import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageItemPriceComponent } from './medical-coverage-item-price.component';

describe('MedicalCoverageItemPriceComponent', () => {
  let component: MedicalCoverageItemPriceComponent;
  let fixture: ComponentFixture<MedicalCoverageItemPriceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageItemPriceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageItemPriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
