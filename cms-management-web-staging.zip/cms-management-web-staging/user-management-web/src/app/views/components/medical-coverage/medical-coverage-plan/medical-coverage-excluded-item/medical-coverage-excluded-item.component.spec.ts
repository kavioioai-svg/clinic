import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageExcludedItemComponent } from './medical-coverage-excluded-item.component';

describe('MedicalCoverageExcludedItemComponent', () => {
  let component: MedicalCoverageExcludedItemComponent;
  let fixture: ComponentFixture<MedicalCoverageExcludedItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageExcludedItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageExcludedItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
