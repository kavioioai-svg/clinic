import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { map, tap } from 'rxjs/operators';

import { AlertService } from '../../../../../services/alert.service';
import { adjustDownPrice, adjustUpPrice, UtilsService } from '../../../../../services/utils.service';
import { ChargeItemQuery } from '../../../../../state/charge-item/charge-item.query';
import { CurrentMedicalCoverageQuery } from '../../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../../current-medical-coverage.service';

@Component({
  selector: 'app-medical-coverage-item-price',
  templateUrl: './medical-coverage-item-price.component.html',
  styleUrls: ['./medical-coverage-item-price.component.scss'],
})
export class MedicalCoverageItemPriceComponent implements OnInit {
  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  @Input('coverageFilterFormGroup') coverageFilterFormGroup: FormGroup;
  @Input('medicalCoverageItemsFormArray') medicalCoverageItemsFormArray: FormArray;

  chargeItemFilter: FormGroup = this.formBuilder.group({
    keywordSearch: '',
    keywordSearchAdded: '',
    searchAddedItem: '',
    type: '',
  });

  addedChargeItemList$;
  addedChargeItemTable$;
  chargeItemList$;
  itemTypeList$ = this.chargeItemQuery.selectItemType().pipe(
    map((data) =>
      data
        .filter((item) => item !== undefined && item !== null && item.trim().length > 0)
        .map((item) => item.toLowerCase())
        .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
        .map((item) => ({ label: this.utilsService.convertToTitleCase(item), value: item.toUpperCase() }))
    ),
    tap((data) => {
      if (data && data.length > 0) this.chargeItemFilter.get('type').setValue(data[0].value);
    })
  );

  toBeSelected = new FormControl(new Array<any>());
  toBeUnselected = new FormControl(new Array<any>());

  constructor(
    private alertService: AlertService,
    private chargeItemQuery: ChargeItemQuery,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private formBuilder: FormBuilder,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private utilsService: UtilsService
  ) {}

  ngOnInit() {
    this.chargeItemFilter.get('keywordSearch').valueChanges.subscribe((keywordSearch) => {
      this.medicalCoverageService.updateChargeItemCodeName(keywordSearch);
    });

    this.chargeItemFilter
      .get('keywordSearchAdded')
      .valueChanges.subscribe((keywordSearchAdded) =>
        this.medicalCoverageService.updateChargeItemAddedCodeName(keywordSearchAdded)
      );

    this.chargeItemFilter
      .get('searchAddedItem')
      .valueChanges.subscribe((searchAddedItem) =>
        this.medicalCoverageService.updateChargeItemAddedListFilter(searchAddedItem)
      );

    this.chargeItemFilter.get('type').valueChanges.subscribe((type) => {
      this.medicalCoverageService.updateChargeItemType(type);
    });

    this.chargeItemList$ = this.currentMedicalCoverageQuery.selectChargeItem();
    this.addedChargeItemList$ = this.currentMedicalCoverageQuery.selectAddedChargeItem();
    this.addedChargeItemTable$ = this.currentMedicalCoverageQuery.selectAddedChargeItemTable();
  }

  ngOnDestroy() {
    this.medicalCoverageService.updateChargeItemCodeName('');
    this.medicalCoverageService.updateChargeItemAddedCodeName('');
    this.medicalCoverageService.updateChargeItemAddedListFilter('');
    this.chargeItemQuery.selectItemType().pipe(
      map((data) =>
        data
          .filter((item) => item !== undefined && item !== null && item.trim().length > 0)
          .map((item) => item.toLowerCase())
          .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
          .map((item) => ({ label: this.utilsService.convertToTitleCase(item), value: item.toUpperCase() }))
      ),
      tap((data) => {
        if (data && data.length > 0) this.chargeItemFilter.get('type').setValue(data[0].value);
      })
    );
  }

  updateList(updatedFormValue) {
    const currentSelectedId = updatedFormValue.map((item) => item.itemId);
    this.medicalCoverageService.updateChargeItemAddedList(currentSelectedId);
    this.medicalCoverageItemsFormArray = this.medicalCoverageService.generateMCItemFormArray(updatedFormValue);
  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select((entity) => entity.loadingState);
  }

  getChargeItemFormGroup(id) {
    if (this.medicalCoverageItemsFormArray.controls.find((control) => control.value.itemId === id)) {
      return <FormGroup>(
        this.medicalCoverageItemsFormArray.controls.find((control) => control.value.itemId === id).get('price')
      );
    }
    return undefined;
  }

  adjustDownPrice(value) {
    if (value && value.price) return adjustDownPrice(value.price);
    return '0.00';
  }

  adjustUpPrice(value) {
    return adjustUpPrice(value);
  }

  ngForTrackBy(index, item) {
    return item.id;
  }

  onSaveMedicalItem() {
    this.medicalCoverageService.setLoadingState(true);
    const filteredMedicalCoverageItemList = this.medicalCoverageItemsFormArray
      .getRawValue()
      .filter((item) => item.price && item.price.price && item.price.price !== '' && item.price.price !== '0.00')
      .map((item) => {
        return {
          itemId: item.itemId,
          price: {
            price: item.price.price === '' ? -1 : item.price.price,
            taxIncluded: false,
          },
        };
      });

    const updatedList = filteredMedicalCoverageItemList.map((item) => item.itemId);
    this.medicalCoverageService.updateChargeItemAddedList(updatedList);

    this.medicalCoverageService
      .modifyMedicalCoverageItem(
        this.currentMedicalCoverageQuery.getValue().currentCompanyId,
        this.currentMedicalCoverageQuery.getValue().currentPlanId,
        filteredMedicalCoverageItemList
      )
      .subscribe(
        (res) => {
          this.medicalCoverageService.setLoadingState(false);
          if (res.payload) this.alertService.success('Medical Coverage Items information updated successfully.');
        },
        (err) => {
          this.medicalCoverageService.setLoadingState(false);
          this.alertService.error('Error updating Medical Coverage Items');
        }
      );
  }
}
