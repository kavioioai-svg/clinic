import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoveragePlanComponent } from './medical-coverage-plan.component';

describe('MedicalCoveragePlanComponent', () => {
  let component: MedicalCoveragePlanComponent;
  let fixture: ComponentFixture<MedicalCoveragePlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoveragePlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoveragePlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
