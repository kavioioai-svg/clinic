import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';

import { AkitaNgFormsManager } from '@datorama/akita-ng-forms-manager';
import { Observable } from 'rxjs';

import { AlertService } from '../../../../services/alert.service';
import { ApiCmsManagementService } from '../../../../services/api-cms-management.service';
import { CurrentMedicalCoverageQuery } from '../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../current-medical-coverage.service';
import { StoreStatusService } from '../../../../state/store-status/store-status.service';
import { DialogService } from '../../../../services/dialog.service';
import {MedicalCoverageTab, MedicalPlanTab} from "../../../../model/enum/enums";

@Component({
  selector: 'app-medical-coverage-plan',
  templateUrl: './medical-coverage-plan.component.html',
  styleUrls: ['./medical-coverage-plan.component.scss']
})
export class MedicalCoveragePlanComponent implements OnDestroy, OnInit {

  medicalCoverageItems;
  medicalCoverageExclusions;

  coverageSelectedFormGroup: FormGroup;
  medicalCoverageItemsFormArray: FormArray;
  medicalCoverageExclusionFormArray: FormArray;
  actionIndex: number;

  constructor(
    private alertService: AlertService,
    private akitaNgFormsManager: AkitaNgFormsManager,
    private apiCmsManagementService: ApiCmsManagementService,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private dialogService: DialogService,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private router: Router,
    private storeStatusService: StoreStatusService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnDestroy() {
    this.akitaNgFormsManager.unsubscribe();
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.actionIndex = params['tabIndex'];
    });

    if (this.akitaNgFormsManager.getForm('medicalPlan')) this.akitaNgFormsManager.remove('medicalPlan');

    if (this.currentMedicalCoverageQuery.getValue().isEditPlan) {
      this.coverageSelectedFormGroup = this.medicalCoverageService.createCoveragePlanFormGroup(this.currentMedicalCoverageQuery.getCompanyPlanById());

      this.apiCmsManagementService.searchMedicalCoverageItems(this.currentMedicalCoverageQuery.getValue().currentCompanyId, this.currentMedicalCoverageQuery.getValue().currentPlanId)
        .subscribe(data => {
          if (data && data.payload) {
            this.medicalCoverageItems = data.payload.medicalCoverageItem.itemCoverageSchemes;
            this.medicalCoverageItemsFormArray = this.medicalCoverageService.generateMCItemFormArray(data.payload.medicalCoverageItem.itemCoverageSchemes);
            const addedChargeItem = data.payload.medicalCoverageItem.itemCoverageSchemes.map(item => item.itemId);
            this.medicalCoverageService.updateChargeItemAddedList(addedChargeItem);

            this.medicalCoverageExclusions = data.payload.medicalCoverageItem.itemCoverageExclusionSchemes;
            this.medicalCoverageExclusionFormArray = this.medicalCoverageService.generateMCExclusionFormArray(data.payload.medicalCoverageItem.itemCoverageExclusionSchemes);
          }
        }, error => {
          this.medicalCoverageItemsFormArray = this.medicalCoverageService.generateMCItemFormArray([]);
          this.medicalCoverageExclusionFormArray = this.medicalCoverageService.generateMCExclusionFormArray([]);
          this.alertService.error('Error loading medical coverage item & exclusion list');
        });
    } else this.coverageSelectedFormGroup = this.medicalCoverageService.createCoveragePlanFormGroup({});

    this.akitaNgFormsManager.upsert('medicalPlan', this.coverageSelectedFormGroup);
    this.storeStatusService.setLoadingStatus(true);
  }

  activateItemInclusionExclusion() {
    this.medicalCoverageItems = [];
    this.medicalCoverageItemsFormArray = this.medicalCoverageService.generateMCItemFormArray([]);
    this.medicalCoverageService.updateChargeItemAddedList([]);

    this.medicalCoverageExclusions = [];
    this.medicalCoverageExclusionFormArray = this.medicalCoverageService.generateMCExclusionFormArray([]);
  }

  canDeactivate(): Observable<boolean> | boolean {
    if (this.coverageSelectedFormGroup.dirty) return this.dialogService.confirm('There are unsaved changes. Leave this page?');
    return true;
  }

  selectIsEditPlan() {
    return this.currentMedicalCoverageQuery.select(entity => entity.isEditPlan);
  }

  redirectToPlanListing() {
    this.router.navigate([`/pages/medical-coverage/detail/edit/${MedicalCoverageTab.PLAN_TAB}`]);
    return false;
  }

  get MedicalPlanTab() {
    return MedicalPlanTab;
  }
  onTabSelected(tab: MedicalPlanTab) {
    this.router.navigate([`/pages/medical-coverage/plan/view/${tab}`]);
  }

}
