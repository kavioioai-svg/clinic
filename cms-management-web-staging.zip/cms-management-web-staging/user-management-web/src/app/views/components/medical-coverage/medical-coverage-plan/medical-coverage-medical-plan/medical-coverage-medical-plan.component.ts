import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';

import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { catchError, debounceTime, filter, map, switchMap, tap, distinctUntilChanged } from 'rxjs/operators';
import { concat, Observable, of, Subject, throwError } from 'rxjs';

import { adjustUpPrice } from '../../../../../services/utils.service';
import { AlertService } from '../../../../../services/alert.service';
import { ApiCmsManagementService } from '../../../../../services/api-cms-management.service';
import { ClinicQuery } from '../../../../../state/clinic/clinic.query';
import { CurrentMedicalCoverageService } from '../../current-medical-coverage.service';
import { CurrentMedicalCoverageQuery } from '../../state/current-medical-coverage.query';
import { HttpResponseBody } from '../../../../../objects/response/HttpResponseBody';
import { valueTrimmedRequiredValidator } from '../../../../../services/form.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicalCoverageTab } from '../../../../../model/enum/enums';

@Component({
  selector: 'app-medical-coverage-medical-plan',
  templateUrl: './medical-coverage-medical-plan.component.html',
  styleUrls: ['./medical-coverage-medical-plan.component.scss'],
})
export class MedicalCoverageMedicalPlanComponent implements OnInit {
  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  @Input('coverageSelectedFormGroup') coverageSelectedFormGroup: FormGroup;
  @Output('activateEditPlan') activateEditPlan = new EventEmitter<any>();

  clinicList$: Observable<Array<any>>;
  clinicListGrouped$: Observable<any>;
  endDateBsConfig: BsDatepickerConfig;
  startDateBsConfig: BsDatepickerConfig;
  diagnosisList: any;
  tempCodes: any = []
  loading: boolean;
  diagnosisList$: Observable<any>;
  diagnosisSearchTerm: string;
  diagnosisTypeahead$ = new Subject<string>();
  codeError: boolean;
  operation: string;

  loadingState$ = this.currentMedicalCoverageQuery.loadingState$;

  constructor(
    private alertService: AlertService,
    private apiCmsManagementService: ApiCmsManagementService,
    private clinicQuery: ClinicQuery,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private activatedRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    if(!this.coverageSelectedFormGroup.get('id').value) {
      this.coverageSelectedFormGroup.get('endDate').setValue(this.currentMedicalCoverageQuery.getCompanyById('endDate'));
      this.coverageSelectedFormGroup.get('startDate').setValue(this.currentMedicalCoverageQuery.getCompanyById('startDate'));
      this.coverageSelectedFormGroup.get('status').setValue(this.currentMedicalCoverageQuery.getCompanyById('status'));
    }
    const endDateMax =
      this.currentMedicalCoverageQuery.getCompanyById('endDate') !== ''
        ? moment(this.currentMedicalCoverageQuery.getCompanyById('endDate'), 'DD-MM-YYYY')
        : undefined;
    const endDateMin = moment(this.currentMedicalCoverageQuery.getCompanyById('startDate'), 'DD-MM-YYYY').add(1, 'd');
    const startDateMax =
      this.currentMedicalCoverageQuery.getCompanyById('endDate') !== ''
        ? moment(this.currentMedicalCoverageQuery.getCompanyById('endDate'), 'DD-MM-YYYY').subtract(1, 'd')
        : undefined;
    const startDateMin = moment(this.currentMedicalCoverageQuery.getCompanyById('startDate'), 'DD-MM-YYYY');

    this.endDateBsConfig = this.medicalCoverageService.generateDefaultDatepickerConfig(
      endDateMin.toDate(),
      endDateMax.toDate()
    );
    this.startDateBsConfig = this.medicalCoverageService.generateDefaultDatepickerConfig(
      startDateMin.toDate(),
      startDateMax.toDate()
    );

    this.clinicList$ = this.clinicQuery
      .selectAll()
      .pipe(
        map((data) =>
          data.map((item) => ({ id: item.id, clinicCode: item.clinicCode, name: item.name, groupName: item.groupName }))
        )
      );

    this.clinicListGrouped$ = this.clinicQuery.selectAll().pipe(
      map((data) =>
        data.map((item) => ({
          id: item.id,
          clinicCode: item.clinicCode,
          name: item.name,
          groupName: item.groupName && item.groupName.length > 0 ? item.groupName : 'Ungrouped',
        }))
      ),
      map((items) => {
        let clinicMap = {};
        const excludedClinics = this.coverageSelectedFormGroup.get('excludedClinics').value;

        items.forEach((item) => {
          let groupArray = item.groupName in clinicMap ? clinicMap[item.groupName] : new Array<any>();
          groupArray.push({
            value: item.id,
            label: `${item.name} [${item.clinicCode}]`,
            groupName: item.groupName,
            selected: excludedClinics.indexOf(item.id) !== -1,
          });
          clinicMap[item.groupName] = groupArray;
        });

        return clinicMap;
      })
    );

    this.coverageSelectedFormGroup
      .get('copayment')
      .get('paymentType')
      .valueChanges.subscribe((paymentType) => {
        if (paymentType && paymentType.length > 0)
          this.coverageSelectedFormGroup.get('copayment').get('value').setValidators([valueTrimmedRequiredValidator()]);
        else this.coverageSelectedFormGroup.get('copayment').get('value').clearValidators();
      });

    this.coverageSelectedFormGroup
      .get('salesDiscount')
      .get('discountType')
      .valueChanges.subscribe((paymentType) => {
        if (paymentType && paymentType.length > 0)
          this.coverageSelectedFormGroup
            .get('salesDiscount')
            .get('discountValue')
            .setValidators([valueTrimmedRequiredValidator()]);
        else this.coverageSelectedFormGroup.get('salesDiscount').get('discountValue').clearValidators();
      });

      this.coverageSelectedFormGroup
      .get('brandedDrugDiscount')
      .get('discountType')
      .valueChanges.subscribe((paymentType) => {
        if (paymentType && paymentType.length > 0)
          this.coverageSelectedFormGroup
            .get('brandedDrugDiscount')
            .get('discountValue')
            .setValidators([valueTrimmedRequiredValidator()]);
        else this.coverageSelectedFormGroup.get('brandedDrugDiscount').get('discountValue').clearValidators();
      });

      this.coverageSelectedFormGroup
      .get('genericDrugDiscount')
      .get('discountType')
      .valueChanges.subscribe((paymentType) => {
        if (paymentType && paymentType.length > 0)
          this.coverageSelectedFormGroup
            .get('genericDrugDiscount')
            .get('discountValue')
            .setValidators([valueTrimmedRequiredValidator()]);
        else this.coverageSelectedFormGroup.get('genericDrugDiscount').get('discountValue').clearValidators();
      });

      this.coverageSelectedFormGroup
      .get('code')
      .valueChanges.subscribe((paymentType) => {
        if(this.codeError){
          this.codeError = false;
        }
      });

    this.dateSubscription();
    this.tryDiagnosisTypeahead();
    this.codeError = false;


    this.activatedRouter.params.subscribe(params => {
      this.operation = params['action'];
    });
    
    const diagnosisIds = this.coverageSelectedFormGroup.get('diagnosisIds').value;
    if (diagnosisIds && diagnosisIds.length){
      this.apiCmsManagementService.searchDiagnosisByIds(diagnosisIds).subscribe(result => {
        if(result.statusCode === 'S0000') {
          this.diagnosisList = result.payload;
          this.tempCodes = result.payload;
        }
      })
    }
  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select((entity) => entity.loadingState);
  }

  getMedicalPlanBooleanType() {
    return this.medicalCoverageService.medicalCoverageBooleanSelection;
  }

  getMedicalPlanLimitResetType() {
    return this.medicalCoverageService.medicalPlanLimitResetType;
  }

  getMedicalPlanPaymentType() {
    return this.medicalCoverageService.medicalPlanPaymentType;
  }

  getMedicalPlanRelationshipType() {
    return this.medicalCoverageService.medicalPlanRelationship;
  }

  getMedicalPlanStatusType() {
    return this.medicalCoverageService.medicalCoverageStatus;
  }

  getMedicalCoveragePlanStatusType() {
    return this.medicalCoverageService.medicalCoveragePlanStatus;
  }

  getBooleanTypeList() {
    return this.medicalCoverageService.medicalCoverageBooleanSelection;
  }

  getClinicList() {
    return this.clinicQuery
      .selectAll()
      .pipe(map((data) => data.map((item) => ({ id: item.id, clinicCode: item.clinicCode, name: item.name }))));
  }

  dateSubscription() {
    this.coverageSelectedFormGroup.get('startDate').valueChanges.subscribe((startDate) => {
      this.endDateBsConfig.minDate = moment(startDate).add(1, 'd').toDate();
    });

    this.coverageSelectedFormGroup.get('endDate').valueChanges.subscribe((endDate) => {
      this.startDateBsConfig.maxDate = moment(endDate).subtract(1, 'd').toDate();
    });
  }

  runDiagnosisTypeahead() {
    try {
      this.diagnosisList$ = this.diagnosisTypeahead$.pipe(
        filter((input) => input !== undefined && input !== null && input.trim().length > 0),
        debounceTime(400),
        tap((data: string) => {
          this.loading = true;
          this.diagnosisSearchTerm = data;
        }),
        map((data) => this.apiCmsManagementService.searchDiagnosis(encodeURI(data), [], true)),
        catchError((errors) => of(<HttpResponseBody>{ page: {}, payload: '' })),
        tap((data) => (this.loading = false))
      );
    } catch (err) {
      console.error('Search Diagnosis Err', err);
    }
  }

  tryDiagnosisTypeahead() {
    this.diagnosisTypeahead$.pipe(
      distinctUntilChanged(),
      debounceTime(400),
      distinctUntilChanged(),
      tap(() => (this.loading = true)),
      switchMap((term: string) => {
        return this.apiCmsManagementService.searchDiagnosis(encodeURI(term), [], true)
      }),
      catchError(errors => of(<HttpResponseBody>{ page: {}, payload: '' }))
    ).subscribe(
      data => {
        this.loading = false;
        if (data && data.payload) {
          this.diagnosisList = [...this.tempCodes, ...data.payload];
        }
      },
      err => {
        this.loading = false;
        throwError('Error');
        if (err && err.error && err.error.message) {
          this.alertService.error(JSON.stringify(err.error.message));
        }
      }
    );
  }

  reloadMedicalCoveragePlanDetail(isEdit = false) {
    if (isEdit) this.alertService.success('Medical Coverage Plan information updated successfully.', true);
    else {
      this.alertService.success('Medical Coverage Plan created successfully.', true);
      this.activateEditPlan.emit();
    }

    return false;
  }

  onSaveMedicalPlan() {
    this.medicalCoverageService.setLoadingState(true);

    const coveragePlanValue = this.coverageSelectedFormGroup.getRawValue();
    if (typeof coveragePlanValue.startDate === 'object')
      coveragePlanValue.startDate = moment(new Date(coveragePlanValue.startDate)).format('DD-MM-YYYY');
    if (coveragePlanValue.endDate) {
      if (typeof coveragePlanValue.endDate === 'object')
        coveragePlanValue.endDate = moment(new Date(coveragePlanValue.endDate)).format('DD-MM-YYYY');
    }

    if (coveragePlanValue.maximumNumberOfDiagnosisCodes === '') coveragePlanValue.maximumNumberOfDiagnosisCodes = 0;

    coveragePlanValue.capPerDay.limit = adjustUpPrice(coveragePlanValue.capPerDay.limit);
    coveragePlanValue.capPerLifeTime.limit = adjustUpPrice(coveragePlanValue.capPerLifeTime.limit);
    coveragePlanValue.capPerMonth.limit = adjustUpPrice(coveragePlanValue.capPerMonth.limit);
    coveragePlanValue.capPerVisit.limit = adjustUpPrice(coveragePlanValue.capPerVisit.limit);
    coveragePlanValue.capPerWeek.limit = adjustUpPrice(coveragePlanValue.capPerWeek.limit);
    coveragePlanValue.capPerYear.limit = adjustUpPrice(coveragePlanValue.capPerYear.limit);
    coveragePlanValue.copayment.value = adjustUpPrice(coveragePlanValue.copayment.value);
    if (coveragePlanValue.salesDiscount.discountType === 'DOLLAR')
      coveragePlanValue.salesDiscount.discountValue = adjustUpPrice(coveragePlanValue.salesDiscount.discountValue);

    if (this.currentMedicalCoverageQuery.getValue().isEditPlan) {
      coveragePlanValue.id = this.currentMedicalCoverageQuery.getValue().currentPlanId;
      this.medicalCoverageService
        .editMedicalCoveragePlan(this.currentMedicalCoverageQuery.getValue().currentCompanyId, coveragePlanValue)
        .subscribe(
          (res) => {
            if (res[0].payload) this.reloadMedicalCoveragePlanDetail(true);
            setTimeout(() =>{this.router.navigate([`/pages/medical-coverage/detail/edit/${MedicalCoverageTab.PLAN_TAB}`]);},2000);
            this.medicalCoverageService.setLoadingState(false);
          },
          (err) => this.alertService.error('Error editing Medical Coverage Plan info.')
        );
    } else {
      delete coveragePlanValue.id;
      coveragePlanValue.code = coveragePlanValue.code.replace(/\s+/g, '');
      this.medicalCoverageService
        .createMedicalCoveragePlan(this.currentMedicalCoverageQuery.getValue().currentCompanyId, coveragePlanValue)
        .subscribe(
          (res) => {
            if(this.codeError){
              this.codeError = false;
            }

            if (res.payload) this.reloadMedicalCoveragePlanDetail();
            setTimeout(() =>{this.router.navigate([`/pages/medical-coverage/detail/edit/${MedicalCoverageTab.PLAN_TAB}`]);},2000);

            this.medicalCoverageService.setLoadingState(false);
          },
          (err) => {
            this.alertService.error(err.error.message ? err.error.message : 'Error creating Medical Coverage Plan')
            this.codeError = true;
            this.medicalCoverageService.setLoadingState(false);
          }
        );
    }
  }

  onFilterDiagnosisCodeChange(value) {
    if (value)
      this.coverageSelectedFormGroup.get('diagnosisIds').setValidators(Validators.required);
    else this.coverageSelectedFormGroup.get('diagnosisIds').clearValidators();
    this.coverageSelectedFormGroup.get('diagnosisIds').updateValueAndValidity();
    console.log("this.coverageSelectedFormGroup", this.coverageSelectedFormGroup);
  }
  
}
