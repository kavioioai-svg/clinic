import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NgxPermissionsGuard } from 'ngx-permissions';


import { MedicalCoverageListingComponent } from './medical-coverage-listing/medical-coverage-listing.component';
import { MedicalCoverageDetailComponent } from './medical-coverage-detail/medical-coverage-detail.component';
import { MedicalCoveragePlanComponent } from './medical-coverage-plan/medical-coverage-plan.component';
import {
  MedicalCoverageDetailProfileComponent
} from "./medical-coverage-detail/medical-coverage-detail-profile/medical-coverage-detail-profile.component";

const routes: Routes = [{
  path: '',
  canActivateChild: [NgxPermissionsGuard],
  data: {
    title: 'Medical Coverage'
  },
  children: [
    { path: '', pathMatch: 'full', redirectTo: 'all' },
    { path: 'all', component: MedicalCoverageListingComponent },
    { path: 'all:action', component: MedicalCoverageDetailProfileComponent },
    { path: 'detail/:action/:tabIndex/:id', component: MedicalCoverageDetailComponent  },
    { path: 'detail/:action/:tabIndex', component: MedicalCoverageDetailComponent  },
    { path: "plan/:action/:tabIndex", component: MedicalCoveragePlanComponent },
    { path: "plan/:action/:tabIndex/:id", component: MedicalCoveragePlanComponent }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MedicalCoverageRoutingModule { }
