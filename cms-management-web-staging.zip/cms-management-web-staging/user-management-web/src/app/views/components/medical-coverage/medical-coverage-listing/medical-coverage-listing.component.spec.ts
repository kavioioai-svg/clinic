import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalCoverageListingComponent } from './medical-coverage-listing.component';

describe('MedicalCoverageListingComponent', () => {
  let component: MedicalCoverageListingComponent;
  let fixture: ComponentFixture<MedicalCoverageListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalCoverageListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalCoverageListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
