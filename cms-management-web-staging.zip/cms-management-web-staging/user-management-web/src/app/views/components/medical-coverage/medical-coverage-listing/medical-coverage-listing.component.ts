import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { AlertService } from '../../../../services/alert.service';
import { CurrentMedicalCoverageQuery } from '../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../current-medical-coverage.service';
import { MedicalCoverageTab, TemplateFucType } from '../../../../model/enum/enums';

@Component({
  selector: 'app-medical-coverage-listing',
  templateUrl: './medical-coverage-listing.component.html',
  styleUrls: ['./medical-coverage-listing.component.scss']
})
export class MedicalCoverageListingComponent implements OnDestroy, OnInit {

  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  listingSearchFormGroup: FormGroup;
  ngSelectValue = [];
  actionDropdown: Array<string> = [];

  actionButtonList = [
    {
      action:'INACTIVE',
      label:'Set to Inactive'
    },
    {
      action:'ACTIVE',
      label:'Set to Active'
    },
  ];

  constructor(
    private alertService: AlertService,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private router: Router
  ) {}

  ngOnInit() {
    this.listingSearchFormGroup = this.medicalCoverageService.createCompanySearchFormGroup();
    this.listingSearchFormGroup.valueChanges.subscribe(a=>{
      if (this.isStartDateGreaterThanEndDate(a)) {
        this.alertService.error('Start date must be less than or equal to end date');
      }
    })

    this.listingSearchFormGroup.get('companyCode').valueChanges.subscribe(companyCode =>
      this.medicalCoverageService.updateCompanySearchCode(companyCode));

    this.listingSearchFormGroup.get('companyName').valueChanges.subscribe(companyName =>
      this.medicalCoverageService.updateCompanySearchName(companyName));

    this.listingSearchFormGroup.get('medicalCoverageType').valueChanges.subscribe(medicalCoverageType =>
      this.medicalCoverageService.updateCompanySearchMedicalCoverageType(medicalCoverageType));

    this.listingSearchFormGroup.get('startDate').valueChanges.subscribe(startDate =>
      this.medicalCoverageService.updateCompanySearchStartDate(startDate));

    this.listingSearchFormGroup.get('endDate').valueChanges.subscribe(endDate =>
      this.medicalCoverageService.updateCompanySearchEndDate(endDate));

    this.listingSearchFormGroup.get('status').valueChanges.subscribe(status =>
      this.medicalCoverageService.updateCompanySearchStatus(status === 'ALL' ? undefined : status ));

  }

  ngOnDestroy() {
    this.clearFilters();
  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select(entity => entity.loadingState);
  }

  getMedicalCoverageTypeList() {
    return this.medicalCoverageService.medicalCoverageTypes;
  }

  getMedicalCoverageStatusList() {
    return this.medicalCoverageService.medicalCoverageStatus;
  }

  getFilteredCompanyList() {
    return this.currentMedicalCoverageQuery.selectFilteredCompany();
  }

  onChange($event, row) {
    console.log($event);
    this.medicalCoverageService.setLoadingState(true);

    const rowValue = { ...row };
    rowValue.coveragePlans = [];

    const endDate = new Date(row.endDate);
    const today = new Date();
    if (endDate.getTime() < today.getTime()) {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.error(`Error: Medical Coverage "${row.name} is expired"`);
      this.ngSelectValue = [];
      return;
    }

    if (rowValue.allowedAccessLevel.length === 0) rowValue.allowedAccessLevel = ['ALL_ACCESS'];
    rowValue.status = ($event === 'ACTIVE') ? 'ACTIVE' : 'INACTIVE';

    this.medicalCoverageService.editMedicalCoverage(rowValue, false).subscribe(res => {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.success(`Medical Coverage "${row.name}" status has been changed to ${$event === 'ACTIVE' ? 'active' : 'inactive'}`);
      this.ngSelectValue = [];
    }, err => {
      this.medicalCoverageService.setLoadingState(false);
      this.alertService.error(`Error changing status for the Medical Coverage "${row.name}"`);
      this.ngSelectValue = [];
    });
  }

  createNewCompanyDetails() {
    this.medicalCoverageService.setIsEditMode(false);
    this.medicalCoverageService.setCurrentCompanyId('');
    this.clearFilters();
    this.router.navigate([`/pages/medical-coverage/detail/edit/${MedicalCoverageTab.PROFILE_TAB}`]);
    return false;
  }

  redirectToCompanyDetails($event, row) {
    this.medicalCoverageService.setIsEditMode(true);
    this.medicalCoverageService.setCurrentCompanyId(row.id);
    this.clearFilters();
    this.router.navigate([`/pages/medical-coverage/detail/${$event.toLocaleLowerCase()}/${MedicalCoverageTab.PROFILE_TAB}`]);
    return false;
  }

  clearFilters() {
    this.listingSearchFormGroup.reset();
  }
  get TemplateFucType() {
    return TemplateFucType
  }

  showFilterBtn(): boolean {
    return true;
  }

  isStartDateGreaterThanEndDate(formValues): boolean {
    const startDate = new Date(formValues.startDate);
    const endDate = new Date(formValues.endDate);
    return (startDate > endDate) && (formValues.endDate !== '');
  }

}
