import { Component, OnInit, Input } from '@angular/core';
import { FormArray } from '@angular/forms';

import { map } from 'rxjs/operators';

import { AlertService } from '../../../../../services/alert.service';
import { ApiCmsManagementService } from '../../../../../services/api-cms-management.service';
import { ChargeItemQuery } from '../../../../../state/charge-item/charge-item.query';
import { CurrentMedicalCoverageQuery } from '../../state/current-medical-coverage.query';
import { CurrentMedicalCoverageService } from '../../current-medical-coverage.service';
import { UtilsService } from '../../../../../services/utils.service';
import {ChargeItem} from "../../../../../objects/ChargeItem";
import {ItemService} from "../../../../../services/item.service";
import {ActivatedRoute} from "@angular/router";
import {MasterDataService} from "../../../../../services/master-data-service/master-data.service";
import {CategoriesService} from "../../../../../services/master-data-service/categories.service";

@Component({
  selector: 'app-medical-coverage-excluded-item',
  templateUrl: './medical-coverage-excluded-item.component.html',
  styleUrls: ['./medical-coverage-excluded-item.component.scss']
})
export class MedicalCoverageExcludedItemComponent implements OnInit {

  readonly tableArray = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];

  @Input('medicalCoverageExclusionFormArray') medicalCoverageExclusionFormArray: FormArray;

  dropdownOptions = [
    { label: 'Item', value: 'DRUG', code:'DRUG' },
    { label: 'Drug Category', value: 'DRUG_CATEGORY' },
    { label: 'MIMS', value: 'MIMS' },
  ]

  itemCategory$;
  itemList$;
  mimsType$;
  drugList: Array<ChargeItem>;
  private isActiveTab: boolean;

  constructor(
    private alertService: AlertService,
    private apiCmsManagementService: ApiCmsManagementService,
    private chargeItemQuery: ChargeItemQuery,
    private currentMedicalCoverageQuery: CurrentMedicalCoverageQuery,
    private medicalCoverageService: CurrentMedicalCoverageService,
    private utilsService: UtilsService,
    private itemService: ItemService,
    private activatedRoute: ActivatedRoute,
    private categoriesService: CategoriesService
  ) {}

  ngOnInit() {
    this.itemCategory$ = this.categoriesService.listAll({
      size: 1000,
      pageNumber: 0,
      limit: 100,
      totalElements: 0,
      totalPages: 0
    }).pipe(map(res => res.payload.map(a => ({
      label: a.category,
      value: a.category,
    }))));

    this.mimsType$ = this.apiCmsManagementService.listMims().pipe(
      map(data => data.payload.values.filter(item => item.status.toUpperCase() === 'ACTIVE').map(item => ({ label: `${item.code} - ${item.description}`, value: item.code })))
    );


    this.activatedRoute.params.subscribe(a => {
      this.isActiveTab = a.tabIndex === '2'
      if (this.isActiveTab) {
        this.itemService.listAllItems().subscribe(
          (res) => {
            if (res && res.statusCode === 'S0000') {
              this.drugList = res.payload.filter((item)=>item.item.status ==="ACTIVE").map((item) => item.item);
            }
          },
          (error) => {
            if (error && error.error) {
              this.alertService.error(error.error.message)
            }
          }
        );
      }
    })

  }

  getLoadingState() {
    return this.currentMedicalCoverageQuery.select(entity => entity.loadingState);
  }

  addExcludedItem() {
    this.medicalCoverageExclusionFormArray.push(this.medicalCoverageService.createMCExclusionFormGroup());
  }

  deleteExcludedItem(index) {
    this.medicalCoverageExclusionFormArray.removeAt(index);
  }

  onSaveMedicalExclusionList() {
    this.medicalCoverageService.setLoadingState(true);

    const filteredMedicalCoverageExclusionList = this.medicalCoverageExclusionFormArray.getRawValue()
      .map(item => ({ exclusionType: item.exclusionType, value: item.value }));

    this.medicalCoverageService.modifyMedicalCoverageExclusion(this.currentMedicalCoverageQuery.getValue().currentCompanyId,
      this.currentMedicalCoverageQuery.getValue().currentPlanId, filteredMedicalCoverageExclusionList).subscribe(res => {
        this.medicalCoverageService.setLoadingState(false);
        if (res.payload) this.alertService.success('Medical Coverage Exclusion information updated successfully.');
      }, err => {
        this.medicalCoverageService.setLoadingState(false);
        this.alertService.error("Error updating Medical Coverage Exclusion");
      });
  }

  customSearchFn(term: string, item: any) {
    term = term.toLowerCase();
    return item.code.toLowerCase().indexOf(term) > -1 || item.name.toLowerCase().indexOf(term) > -1;
  }

}
