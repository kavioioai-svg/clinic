import { Injectable } from '@angular/core';

import { Store, StoreConfig } from '@datorama/akita';

export interface CurrentMedicalCoverageState {

  loadingState: boolean;

  currentCompanyId: string;
  currentPlanId: string;
  isEdit: boolean;
  isEditPlan: boolean;

  companySearchCompanyCode: string;
  companySearchCompanyName: string;
  companySearchEndDate: string;
  companySearchMedicalCoverageType: Array<string>;
  companySearchStartDate: string;
  companySearchStatus: string;

  planSearchPlanCode: string;
  planSearchEndDate: string;
  planSearchPlanName: string;
  planSearchStartDate: string;
  planSearchStatus: string;

  chargeItemAddedCodeName: string;
  chargeItemAddedList: Array<string>;
  chargeItemCodeName: string;
  chargeItemType: string;
  chargeItemAddedListFilter: string;
}

export function createInitialState(): CurrentMedicalCoverageState {
  return {
    loadingState: false,
    chargeItemAddedCodeName: '',
    chargeItemAddedList: [],
    chargeItemCodeName: '',
    chargeItemType: '',
    chargeItemAddedListFilter: '',
    companySearchCompanyCode: '',
    companySearchCompanyName: '',
    companySearchEndDate: '',
    companySearchMedicalCoverageType: [],
    companySearchStartDate: '',
    companySearchStatus: '',
    currentCompanyId: '',
    currentPlanId: '',
    isEdit: undefined,
    isEditPlan: undefined,
    planSearchPlanCode: '',
    planSearchEndDate: '',
    planSearchPlanName: '',
    planSearchStartDate: '',
    planSearchStatus: ''
  }
}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'medicalCoverageState' })
export class CurrentMedicalCoverageStore extends Store<CurrentMedicalCoverageState> {

  constructor() { super(createInitialState()); }

}
