import { LoadingRetryComponent } from './components/loading-retry/loading-retry.component';
import { LoadingComponent } from './components/loading/loading.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule , BsModalRef } from 'ngx-bootstrap/modal';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ErrorsComponent } from './components/shared/form/errors/errors.component';
import { RouterModule } from '../../node_modules/@angular/router';
import { AlertComponent } from './directives/alert/alert.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChasRowItemComponent } from './components/claim/claim-chas/chas-row-item/chas-row-item.component';
import { AppResetPasswordComponent } from './components/app-reset-password/app-reset-password.component';
import { ValidateMatchPasswordDirective } from './validators/validate-match-password.directive';
import { DisplayDollarPipe } from './pipes/display-dollar.pipe';
import { DisplayDollarEmptyPipe } from './pipes/display-dollar-empty.pipe';
import { DisplayDateFullDateFormatPipe } from './pipes/display-date-full-date-format.pipe';
import { TextTruncatePipe } from './pipes/text-truncate.pipe';
import { DisplayDatePipe } from './pipes/display-date.pipe';
import { DisplayPaymentModePipe } from './pipes/display-payment-mode.pipe';
import { CaseSummeryBillAdjDetailsComponent } from './components/claim/claim-bill-adjustment/case-summery-bill-adj-details/case-summery-bill-adj-details.component';
import {DatePickerWithIconComponent} from './components/date-picker-with-icon/date-picker-with-icon.component';
import {StockItemInvalidPipe} from './pipes/stock-item-invalid.pipe';
import {InventoryDisplayStockAdjustmentVariancePipe} from './pipes/inventory-display-stock-adjustment-variance.pipe';
import {
  StockAdjustmentApprovalComponent
} from './views/components/inventory/inventory/stock-adjustment/stock-adjustment-approval/stock-adjustment-approval.component';
import {SkeletonLoaderComponent} from './components/skeleton-loader/skeleton-loader.component';
import {TooltipModule , TooltipConfig} from 'ngx-bootstrap';
import {TemplateFunctionsPipe} from './pipes/template-functions.pipe';
import {FileUploadComponent} from './components/file-upload/file-upload.component';
import {BackButtonComponent} from './components/button/back-button/back-button.component';
import {SaveButtonComponent} from './components/button/save-button/save-button.component';
import {NumberDirectiveDirective} from './validators/number-directive.directive';
import {SelectWithCustomFilterComponent} from './components/select-with-custom-filter/select-with-custom-filter.component';
import {ClearFilterButtonComponent} from './components/button/clear-filter-button/clear-filter-button.component';
import {ActionButtonComponent} from './components/button/action-button/action-button.component';
import {ItemPricingComponent} from './views/components/item-pricing-master/item-pricing/item-pricing.component'
import {ClinicItemMasterFormComponent} from './views/components/item-pricing-master/item-pricing/clinic-item-master-form/clinic-item-master-form.component'
import {ClinicGroupItemMasterFormComponent} from './views/components/item-pricing-master/item-pricing/clinic-group-item-master-form/clinic-group-item-master-form.component'
import {MedicalCoverageItemMasterFormComponent} from './views/components/item-pricing-master/item-pricing/medical-coverage-item-master-form/medical-coverage-item-master-form.component'
import {ItemTabListComponent} from './views/components/supplier/tab-list/item-tab-list/item-tab-list.component'
import {InvoiceListComponent} from "./views/components/invoice/invoice/invoice-list/invoice-list.component";
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AccordionModule.forRoot(),
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ModalModule.forRoot(),
    TimepickerModule.forRoot(),
    ModalModule.forRoot(),
    NgSelectModule,
    PopoverModule.forRoot(),
    CollapseModule.forRoot(),
    TabsModule.forRoot(),
    AngularSvgIconModule,
    NgxPermissionsModule,
    RouterModule,
    NgxDatatableModule,
    TooltipModule,
    ModalModule.forRoot()

  ],
    exports: [
        CommonModule,
        NgSelectModule,
        AccordionModule,
        AlertComponent,
        FormsModule,
        ReactiveFormsModule,
        BsDropdownModule,
        ModalModule,
        PopoverModule,
        TabsModule,
        CollapseModule,
        BsDatepickerModule,
        TimepickerModule,
        ModalModule,
        AngularSvgIconModule,
        NgxPermissionsModule,
        ErrorsComponent,
        RouterModule,
        NgxDatatableModule,
        LoadingComponent,
        LoadingRetryComponent,
        ChasRowItemComponent,
        DisplayDollarPipe,
        DisplayDollarEmptyPipe,
        DisplayDateFullDateFormatPipe,
        TextTruncatePipe,
        TemplateFunctionsPipe,
        DisplayDatePipe,
        DisplayPaymentModePipe,
        CaseSummeryBillAdjDetailsComponent,
        DatePickerWithIconComponent,
        StockItemInvalidPipe,
        InventoryDisplayStockAdjustmentVariancePipe,
        SkeletonLoaderComponent,
        TooltipModule,
        ModalModule,
        FileUploadComponent,
        BackButtonComponent,
        SaveButtonComponent,
        NumberDirectiveDirective,
        SelectWithCustomFilterComponent,
        ClearFilterButtonComponent,
        ActionButtonComponent,
        ItemPricingComponent,
        ItemTabListComponent,
        ClinicItemMasterFormComponent,
        ClinicGroupItemMasterFormComponent,
        MedicalCoverageItemMasterFormComponent,
        InvoiceListComponent,
    ],
    declarations: [
        AlertComponent,
        ErrorsComponent,
        LoadingComponent,
        LoadingRetryComponent,
        ChasRowItemComponent,
        AppResetPasswordComponent,
        ValidateMatchPasswordDirective,
        DisplayDollarPipe,
        DisplayDollarEmptyPipe,
        DisplayDateFullDateFormatPipe,
        TextTruncatePipe,
        TemplateFunctionsPipe,
        DisplayDatePipe,
        DisplayPaymentModePipe,
        CaseSummeryBillAdjDetailsComponent,
        DatePickerWithIconComponent,
        StockItemInvalidPipe,
        InventoryDisplayStockAdjustmentVariancePipe,
        SkeletonLoaderComponent,
        FileUploadComponent,
        BackButtonComponent,
        SaveButtonComponent,
        NumberDirectiveDirective,
        SelectWithCustomFilterComponent,
        ClearFilterButtonComponent,
        ActionButtonComponent,
        ItemPricingComponent,
        ItemTabListComponent,
        ClinicItemMasterFormComponent,
        ClinicGroupItemMasterFormComponent,
        MedicalCoverageItemMasterFormComponent,
        InvoiceListComponent,
    ],
  providers: [TooltipConfig , BsModalRef ,StockItemInvalidPipe],
  entryComponents: [AppResetPasswordComponent, CaseSummeryBillAdjDetailsComponent, ClinicItemMasterFormComponent, ClinicGroupItemMasterFormComponent, MedicalCoverageItemMasterFormComponent
  ],
})
export class SharedModule {}
