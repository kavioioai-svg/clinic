export const navigation = [
  // {
  //   name: 'All User',
  //   url: '/pages/user/all',
  //   icon: '',
  //   svgIcon: '/assets/svg/user.svg',
  //   permissions: ['ROLE_AA_ADMIN']
  // },
  {
    name: 'User Doctor',
    url: '/pages/user/doctor',
    icon: '',
    svgIcon: '/assets/svg/user.svg',
    permissions: ['ROLE_USER_CREATE']
  },
  {
    name: 'All Groups',
    url: '/pages/group/all',
    icon: '',
    svgIcon: '/assets/svg/modulegroup.svg',
    permissions: ['ROLE_AA_ADMIN']
  }, // {
  //   name: 'All Module',
  //   url: '/pages/module/all',
  //   icon: '',
  //   svgIcon: '/assets/svg/module.svg'
  // },
  // {
  //   name: 'Doctor',
  //   url: '/pages/doctor/all',
  //   icon: '',
  //   svgIcon: '/assets/svg/doctor.svg',
  //   permissions: ['ROLE_DOCTOR_MANAGE']
  // },
  {
    name: 'Clinic',
    url: '/pages/clinic/',
    icon: '',
    svgIcon: '/assets/svg/clinic.svg',
    permissions: ['ROLE_CLINIC_MANAGE']
  },
  {
    name: 'Item',
    url: '/pages/item/',
    icon: '',
    svgIcon: '/assets/svg/drugs.svg',
    permissions: ['ROLE_VIEW_ITEM']
  },
  {
    name: 'Claims',
    url: '/pages/claims',
    icon: '',
    svgIcon: '/assets/svg/claims.svg',
  },{
    name: 'Bill Management',
    url: '/pages/claim/refund-bill',
    icon: '',
    svgIcon: '/assets/svg/claims.svg',
    permissions: ['ROLE_SO_CORRECTION', 'ROLE_REFUND']
  },
  {
    name: 'Medical Coverage',
    url: '/pages/medical-coverage',
    icon: '',
    svgIcon: '/assets/svg/medical-coverage.svg',
    permissions: ['ROLE_VIEW_MEDICAL_COVERAGE']
  },
  {
    name: 'Sales Price',
    url: '/pages/clinic-item',
    icon: '',
    svgIcon: '/assets/svg/clinic.svg',
    permissions: ['ROLE_ITEM_MANAGEMENT_CONTROLLER']
  },
  {
    name: 'Reports',
    url: '/pages/report',
    icon: '',
    svgIcon: '/assets/svg/reports.svg',
    permissions: ['ROLE_REPORT_VIEWER']
  },
  {
    name: 'Services',
    url: '/pages/services',
    icon: '',
    svgIcon: '/assets/svg/settings.svg',
    permissions: ['ROLE_MWOC_UPPROJ', 'ROLE_NOTICEBOARD_MANAGE', 'ROLE_COMPANY_GROUPING_MANAGEMENT', 'ROLE_WEB_APPOINTMENT_MGMT_VIEW']
  },
  {
    name: 'Inventory',
    url: `/pages/inventory/`,
    icon: '',
    svgIcon: '/assets/svg/inventory.svg',
    permissions: ['ROLE_INVENTORY_MANAGEMENT'],
  },
  {
    name: 'Master Data',
    url: `/pages/master-data/`,
    icon: '',
    svgIcon: '/assets/svg/reports.svg',
    permissions: ['ROLE_VIEW_MASTER_DATA'],
  },
  {
    name: 'Supplier',
    url: `/pages/supplier/`,
    icon: '',
    svgIcon: '/assets/svg/patients.svg',
    permissions: ['ROLE_VIEW_SUPPLIER_MAIN']
  },
  {
    name: 'Invoice',
    url: `/pages/invoice/`,
    icon: '',
    svgIcon: '/assets/svg/inventory.svg',
    permissions: ['ROLE_INVOICE_MANAGEMENT'],
  },
];
// Template
// {
//     name: 'Coverage',
//     url: '/pages/coverage',
//     icon: 'icon-expense',
//     children: [
//         {
//             name: 'Add',
//             url: '/pages/coverage/add',
//             icon: 'icon-plus'
//         },
//         {
//             name: 'Search',
//             url: '/pages/coverage/search',
//             icon: 'icon-search'
//         }
//     ]
// },
